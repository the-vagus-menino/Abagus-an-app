/* =====================================================================
   ABAGUS profile picture editor (shared by the Vault page and the Groups page).
   Pick a photo (or take one), drag to position it, zoom, and save a 256 x 256 JPEG.
   * Everything happens on this device. The photo is re-drawn on a canvas, so location, camera model and every other piece of
     hidden metadata (EXIF) is removed and sideways phone photos are straightened.
   * Safe by design: only still raster images up to 15 MB and 80 megapixels are accepted (no SVG, no scripts, no huge-image tricks).
   * Result is at most 29 KB (the limit the database rules allow). In groups it is encrypted with the group key before it leaves the device.
   * Keyboard: arrow keys move, + and - zoom, Enter saves, Escape cancels. Screen readers get plain-language labels.
   ===================================================================== */
(function () {
  'use strict';
  var OUT = 256, VIEW = 280, MAX_IN = 15 * 1024 * 1024, MAX_PIXELS = 80e6, MAX_OUT = 29000;
  var OK_TYPE = /^image\/(jpeg|png|webp|gif|avif|bmp|heic|heif)$/i;
  function h(tag, p) { var e = document.createElement(tag); if (p) for (var k in p) { if (k === 'text') e.textContent = p[k]; else if (k === 'class') e.className = p[k]; else if (k.slice(0, 2) === 'on') e.addEventListener(k.slice(2), p[k]); else if (p[k] === true) e.setAttribute(k, ''); else if (p[k] != null && p[k] !== false) e.setAttribute(k, p[k]); } for (var i = 2; i < arguments.length; i++) if (arguments[i]) e.appendChild(arguments[i]); return e; }
  function css() { if (document.getElementById('pfCss')) return; document.head.appendChild(h('link', { id: 'pfCss', rel: 'stylesheet', href: 'avatar.css' })); }

  /* The same box used everywhere to show a picture or the person's initial. */
  function avatarEl(u8, label, cls) {
    var box = h('span', { class: 'pf-av ' + (cls || ''), 'aria-hidden': 'true' });
    if (u8 && u8.length) { var url = URL.createObjectURL(new Blob([u8], { type: 'image/jpeg' })); var img = h('img', { alt: '', draggable: 'false' }); img.onload = function () { try { URL.revokeObjectURL(url); } catch (_) {} }; img.src = url; box.appendChild(img); }
    else box.appendChild(document.createTextNode(String(label || '?').trim().slice(0, 1).toUpperCase() || '?'));
    return box;
  }

  async function decode(file) {
    if (!file) throw new Error('No picture chosen.');
    if (file.size > MAX_IN) throw new Error('That picture is too big (over 15 MB). Choose a smaller one.');
    if (file.type && !OK_TYPE.test(file.type)) throw new Error('Choose a photo (JPEG, PNG, WebP or similar). Drawings like SVG are not allowed.');
    var bm;
    try { bm = await createImageBitmap(file, { imageOrientation: 'from-image' }); } catch (_) { throw new Error('That file could not be read as a picture. Try another one.'); }
    if (bm.width * bm.height > MAX_PIXELS) { try { bm.close(); } catch (_) {} throw new Error('That picture is too large to process (over 80 megapixels). Choose a smaller one.'); }
    return bm;
  }

  /* edit({ title, hasCurrent }) -> Promise<Uint8Array | 'remove' | null>  (null = cancelled) */
  function edit(o) {
    o = o || {}; css();
    return new Promise(function (resolve) {
      var bm = null, scale = 1, minScale = 1, ox = 0, oy = 0, done = false, drag = null;
      var canvas = h('canvas', { class: 'pf-canvas', width: VIEW, height: VIEW, tabindex: '0', role: 'img', 'aria-label': 'Picture preview. Drag, or use the arrow keys, to move it. Plus and minus zoom.' });
      var ctx = canvas.getContext('2d');
      var zoom = h('input', { type: 'range', class: 'pf-zoom', min: '100', max: '400', value: '100', 'aria-label': 'Zoom', disabled: true });
      var msg = h('p', { class: 'pf-msg', role: 'status', 'aria-live': 'polite' });
      var save = h('button', { type: 'button', class: 'pf-btn primary', disabled: true, 'data-pf': 'save', text: 'Save picture' });
      var file = h('input', { type: 'file', accept: 'image/*', class: 'pf-hidden', 'aria-label': 'Choose a photo' });
      var cam = h('input', { type: 'file', accept: 'image/*', capture: 'user', class: 'pf-hidden', 'aria-label': 'Take a photo' });
      var empty = h('div', { class: 'pf-empty' }, h('span', { class: 'pf-ic', 'aria-hidden': 'true', text: '\uD83D\uDC64' }), h('b', { text: 'Choose a photo' }), h('small', { text: 'Drag it to centre your face, then zoom. It is made small on this device.' }));
      var stage = h('div', { class: 'pf-stage' }, canvas, h('span', { class: 'pf-ring', 'aria-hidden': 'true' }), empty);
      var dlg = h('dialog', { class: 'pf-dialog', 'aria-labelledby': 'pfTitle' },
        h('div', { class: 'pf-head' }, h('h2', { id: 'pfTitle', text: o.title || 'Profile picture' }), h('button', { type: 'button', class: 'pf-x', 'aria-label': 'Close', onclick: function () { finish(null); }, text: '\u00d7' })),
        stage, h('label', { class: 'pf-zl' }, h('span', { text: 'Zoom' }), zoom), msg,
        h('div', { class: 'pf-actions' },
          h('button', { type: 'button', class: 'pf-btn', 'data-pf': 'choose', onclick: function () { file.click(); }, text: 'Choose photo' }),
          h('button', { type: 'button', class: 'pf-btn', 'data-pf': 'camera', onclick: function () { cam.click(); }, text: 'Take photo' }),
          o.hasCurrent ? h('button', { type: 'button', class: 'pf-btn danger', 'data-pf': 'remove', onclick: function () { finish('remove'); }, text: 'Remove picture' }) : null,
          save, h('button', { type: 'button', class: 'pf-btn', onclick: function () { finish(null); }, text: 'Cancel' })), file, cam);

      function clampPos() {
        var w = bm.width * scale, hh = bm.height * scale;
        ox = Math.min(0, Math.max(VIEW - w, ox)); oy = Math.min(0, Math.max(VIEW - hh, oy));
      }
      function draw() {
        ctx.clearRect(0, 0, VIEW, VIEW); ctx.fillStyle = '#0b0b14'; ctx.fillRect(0, 0, VIEW, VIEW);
        if (bm) { clampPos(); ctx.drawImage(bm, ox, oy, bm.width * scale, bm.height * scale); }
      }
      function setScale(next, cx, cy) {
        if (!bm) return; next = Math.max(minScale, Math.min(minScale * 4, next));
        var px = (cx == null ? VIEW / 2 : cx), py = (cy == null ? VIEW / 2 : cy), k = next / scale;
        ox = px - (px - ox) * k; oy = py - (py - oy) * k; scale = next; zoom.value = String(Math.round(scale / minScale * 100)); draw();
      }
      async function load(f) {
        msg.textContent = ''; save.disabled = true;
        try {
          var next = await decode(f); if (bm && bm.close) try { bm.close(); } catch (_) {} bm = next;
          minScale = VIEW / Math.min(bm.width, bm.height); scale = minScale; ox = (VIEW - bm.width * scale) / 2; oy = (VIEW - bm.height * scale) / 2;
          zoom.disabled = false; zoom.value = '100'; empty.classList.add('hidden'); save.disabled = false; draw(); canvas.focus();
          msg.textContent = 'Drag to move, use the slider to zoom.';
        } catch (e) { msg.textContent = e.message; msg.className = 'pf-msg bad'; setTimeout(function () { msg.className = 'pf-msg'; }, 100); }
      }
      file.addEventListener('change', function () { var f = file.files[0]; file.value = ''; load(f); });
      cam.addEventListener('change', function () { var f = cam.files[0]; cam.value = ''; load(f); });
      zoom.addEventListener('input', function () { setScale(minScale * Number(zoom.value) / 100); });
      canvas.addEventListener('wheel', function (e) { if (!bm) return; e.preventDefault(); var r = canvas.getBoundingClientRect(); setScale(scale * (e.deltaY < 0 ? 1.08 : 0.92), (e.clientX - r.left) * VIEW / r.width, (e.clientY - r.top) * VIEW / r.height); }, { passive: false });
      canvas.addEventListener('pointerdown', function (e) { if (!bm) return; drag = { x: e.clientX, y: e.clientY, ox: ox, oy: oy }; try { canvas.setPointerCapture(e.pointerId); } catch (_) {} canvas.classList.add('drag'); });
      canvas.addEventListener('pointermove', function (e) { if (!drag) return; var r = canvas.getBoundingClientRect(), k = VIEW / r.width; ox = drag.ox + (e.clientX - drag.x) * k; oy = drag.oy + (e.clientY - drag.y) * k; draw(); });
      function up() { drag = null; canvas.classList.remove('drag'); }
      canvas.addEventListener('pointerup', up); canvas.addEventListener('pointercancel', up);
      canvas.addEventListener('keydown', function (e) {
        if (!bm) return; var step = e.shiftKey ? 24 : 8, used = true;
        if (e.key === 'ArrowLeft') ox += step; else if (e.key === 'ArrowRight') ox -= step; else if (e.key === 'ArrowUp') oy += step; else if (e.key === 'ArrowDown') oy -= step;
        else if (e.key === '+' || e.key === '=') setScale(scale * 1.1); else if (e.key === '-' || e.key === '_') setScale(scale * 0.9); else used = false;
        if (used) { e.preventDefault(); draw(); }
      });
      dlg.addEventListener('keydown', function (e) { if (e.key === 'Enter' && !save.disabled && e.target.tagName !== 'BUTTON' && e.target.tagName !== 'INPUT') { e.preventDefault(); save.click(); } });
      dlg.addEventListener('cancel', function (e) { e.preventDefault(); finish(null); });
      save.addEventListener('click', async function () {
        if (!bm) return; save.disabled = true; msg.textContent = 'Making your picture\u2026';
        try { finish(await render()); } catch (e) { msg.textContent = e.message; save.disabled = false; }
      });
      async function render() {
        var out = document.createElement('canvas'); out.width = OUT; out.height = OUT; var c = out.getContext('2d'), k = OUT / VIEW;
        c.fillStyle = '#ffffff'; c.fillRect(0, 0, OUT, OUT); c.drawImage(bm, ox * k, oy * k, bm.width * scale * k, bm.height * scale * k);   // a fresh canvas has no metadata
        for (var q = 0.88; q > 0.25; q -= 0.08) {
          var blob = await new Promise(function (res) { out.toBlob(res, 'image/jpeg', q); });
          if (blob && blob.size <= MAX_OUT) return new Uint8Array(await blob.arrayBuffer());
        }
        throw new Error('That picture could not be made small enough. Try another one.');
      }
      function finish(v) {
        if (done) return; done = true; if (bm && bm.close) try { bm.close(); } catch (_) {}
        dlg.classList.add('closing'); setTimeout(function () { try { dlg.close(); } catch (_) {} if (dlg.parentNode) dlg.parentNode.removeChild(dlg); resolve(v); }, 140);
      }
      document.body.appendChild(dlg); draw(); if (dlg.showModal) dlg.showModal(); else dlg.setAttribute('open', '');
      var first = dlg.querySelector('[data-pf=choose]'); if (first) first.focus();
    });
  }

  /* ---------- my own picture (stored in my account, shown wherever I am) ---------- */
  var mine = { uid: null, u8: null, v: 0, name: '' };
  function db() { return window.VaultDB; }
  async function loadMine() {
    if (!mine.uid || !db()) return; try { var p = await db().get('users/' + mine.uid); mine.u8 = p && p.avatar ? p.avatar : null; mine.v = (p && p.avatarV) || 0; } catch (_) {}
    paintChip();
  }
  function paintChip() {
    var chip = document.getElementById('acctChip'); if (!chip) return;
    var old = chip.querySelector('.pf-av.chip'); if (old) old.remove();
    if (!mine.uid) return; var av = avatarEl(mine.u8, mine.name, 'chip'); chip.insertBefore(av, chip.firstChild);
  }
  async function change() {
    var r = await edit({ title: 'Your profile picture', hasCurrent: !!mine.u8 }); if (r == null) return null;
    var v = Date.now();
    if (r === 'remove') { await db().set('users/' + mine.uid, { avatar: null, avatarV: v }, true); mine.u8 = null; }
    else { await db().set('users/' + mine.uid, { avatar: r, avatarV: v }, true); mine.u8 = r; }
    mine.v = v; paintChip(); paintRow();
    window.dispatchEvent(new CustomEvent('abagus:avatar', { detail: { avatar: mine.u8, v: v } }));
    if (typeof window.showToast === 'function') window.showToast('ok', r === 'remove' ? 'Picture removed.' : 'Profile picture saved.', 2400);
    return mine.u8;
  }
  var rowEl = null;
  function paintRow() {
    if (!rowEl) return; rowEl.textContent = '';
    rowEl.appendChild(avatarEl(mine.u8, mine.name, 'md'));
    rowEl.appendChild(h('div', { class: 'pf-row-t' }, h('b', { text: 'Profile picture' }), h('small', { text: mine.u8 ? 'Shown to the members of your groups. In a group it is encrypted so only members can see it.' : 'Add a photo so people in your groups know it is you.' })));
    rowEl.appendChild(h('button', { type: 'button', class: 'pf-btn', id: 'pfChange', onclick: function () { change().catch(function (e) { if (typeof window.showToast === 'function') window.showToast('error', (e && e.message) || 'Could not save the picture.', 6000); }); }, text: mine.u8 ? 'Change' : 'Add picture' }));
  }
  function mountRow() {
    var out = document.getElementById('acdOut'); if (!out || rowEl) return; css();
    rowEl = h('div', { class: 'pf-row', id: 'pfRow' }); out.parentNode.insertBefore(rowEl, out); paintRow();
  }
  function wire() {
    mountRow();
    window.addEventListener('abagus:user', function (e) {
      var u = e.detail || {}; var changed = u.uid !== mine.uid;
      mine.uid = u.uid || null; mine.name = u.name || ''; if (changed) { mine.u8 = null; mine.v = 0; }
      if (mine.uid) loadMine(); else paintChip(); paintRow();
    });
  }
  window.AbagusAvatar = { edit: edit, avatarEl: avatarEl, decode: decode, change: change, _mine: function () { return mine; } };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', wire); else wire();
})();
