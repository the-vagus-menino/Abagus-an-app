# Character themes

34 looks (Spider-Man, Iron Man, Ultron, Thanos, Loki, Deadpool, Black Panther, Moon Knight, The Punisher, Doctor Strange, The Dark Knight, Joker,
John Wick, Interstellar, Hogwarts Express, The Matrix, Stranger Things, Dune, Moon Ride, WALL-E, Kung Fu Panda, Shinchan, Ghibli Meadow, Freedom Sky,
plus the ten v3 looks: Dodge Hellcat, Dragon Rider, Baymax, Doraemon, Deadpool Light, Scarlet Witch, Shang-Chi, Agent Noir, Ghost Rider, Wonder Woman).
Open the sparkle button in the top bar (floating button on phones) to pick one. Each theme sets, on every page:

- a full palette (light or dark, every text pair checked at WCAG AA by `scripts/themes-gen.py`)
- an animated canvas background of its own, plus your artwork as a faded backdrop
- its own tap effect, page transition, card entrance, button hover motion and headline loop
- Power (Soft / Normal / Max): Soft is gentle and light on the battery (fewer particles, no blur, quiet headline); Max adds card glow, a glowing headline, a ring on every tap and bigger bursts.
- Extras (on by default): mouse-only card tilt with a moving highlight, a soft spotlight that follows the pointer, a reading-progress line in the theme colours, and tap combos (five quick taps, four on Max, set off a finale).
- Theme changes spread out as a circle from where you tapped (View Transitions API; other browsers switch instantly). Cards now enter one after another, and the artwork drifts slower than the page when you scroll.
- Keyboard: T opens the picker, arrow keys move between themes, Enter picks. Previous and Next buttons sit beside Surprise me.
- Motion (Auto/Full/Calm/Off), Artwork and Tap effects switches. Auto follows the system "reduce motion" setting; frame rate adapts on slow devices.

Files: `themes.css`, `themes.js`, `themes-boot.js` (no-flash), `themes/art` and `themes/thumb` (webp, about 600 KB total).
Edit sources in `scripts/themes-src/*.part`, `scripts/themes-base.css` and the palette table in `scripts/themes-gen.py`, then run
`python3 scripts/themes-gen.py && node scripts/themes-build.mjs`. Tests: `python3 tests/test_themes.py` and `python3 tests/test_themes2.py`.
No inline scripts and no network are used, so the CSP is unchanged. "Default" in the picker restores the original look exactly.

## Iron Man (rebuilt)
- Scene: pre-drawn hex grid with energy pulses from the arc reactor, a 10-block coil reactor with ticks and rotating triangles, altitude ladder, compass tape, JARVIS typing log, an Iron Man flyby streak, and a targeting reticle that follows the mouse (or lingers where you last touched).
- Touch: tap = charge flash, hex shockwave, beams and a TARGET LOCKED bracket. Press and hold = charging ring and percentage; lift after about half a second = UNIBEAM. Phones get a short vibration. Dragging while holding leaves a spark trail.
- Cards get HUD corner brackets and a cyan glow; buttons glow on hover.
- Every theme now shows a ring where a finger lands and vibrates briefly on phones (Extras switch).

## v3: ten new looks and a natural-motion pass
- New: `dodge`, `dragonrider`, `baymax`, `doraemon`, `deadpool2`, `scarletwitch`, `shangchi`, `agent`, `ghostrider`, `wonderwoman`. Each has a palette (WCAG AA checked), its own scene (`25-scenes2.part`), tap effect (`35-clicks2.part`), card/button/entrance motion, page wipe, artwork and picker thumbnail. A new "Cars" filter holds Dodge.
- Motion: shared `ease`, `damp` (frame-rate independent smoothing), `nz` (organic noise) and `wnd` (wind) helpers. Pointer parallax, spotlight and art drift use exponential damping; with no pointer the scene drifts on its own; the artwork breathes slowly; particles fade in and out with smoothstep; rings expand with ease-out; comic/ora pops spring; card tilt is a damped spring that eases back to flat; card hover and entrance use softer curves; Calm mode holds a steady 30 fps.
- Fixes: tap effects of the previous theme no longer linger after a switch; a stray `}` in `themes-base.css` that made browsers drop the overlay/vignette rule is gone.
- Tests: `tests/test_themes3.py` covers the ten new looks.

## v4: realism pass (`36-pro.part`, `37-shangchi.part`, `38-moonknight.part`)
- **Every theme:** light now falls off like real light (sprite-based, not a flat ramp); film grain + vignette sit in the background plane only (never over text); a slow light drift and soft bokeh give depth (off for Matrix, Iron Man, Agent, Ultron, Dodge, Shinchan, Deadpool Light); every tap leaves a flash of light and nudges the camera on a spring; sparks are tapered streaks with a glow; ring shock-waves have a soft halo and a lit edge.
- **Shared tools:** `bolt()` (branching lightning with a hot core), `drawRing()` (lit 3-D metal ring with conic highlight, glowing runes, near/far halves), `sprite()`/`glow()`.
- **Shang-Chi:** golden-hour Ta Lo (karst peaks, mist, sun, god-rays, swaying bamboo) with ten metal bracelets on a tilted orbit that morph between tunnel and emblem, shed embers and throw lightning. Tap = rings thrown out, curve back, orbit, collapse. Hold = rings gather round the finger; release (after 0.55 s) = full blast with camera kick and vibration on phones.
- **Moon Knight:** cratered moon that waxes and wanes with earthshine, starfield and shooting stars, three lit dune ridges, pyramids, wind-blown sand and drifting linen bandages. Tap = a silver crescent dart spins in on a curve, bites in with a moonlight flash, sand and sparks, wobbles, then turns to dust.
- Known: `tests/test_themes2.py` "tilt clears when the mouse leaves" already failed before this pass.
