# What changed

## Maintenance pass 4 (one domain, Cloud Functions upgrade)
- **Canonical domain is `abagus.netlify.app`.** The old `abagusv53.netlify.app` is removed from the Cloud Functions CORS lists and from the Netlify cover function (localhost and Netlify deploy previews are still allowed). Page tags, sitemap and robots already used `abagus.netlify.app`.
- **Cloud Functions upgrade:** `firebase-functions` ^5 to ^7.3.0, `firebase-admin` ^12 to ^13. The code moved to the modular admin API (`firebase-admin/app`, `/auth`, `/firestore`), which works on admin 12, 13 and 14; admin 14 removed the old `admin.firestore()` / `admin.auth()` style. Behaviour, endpoints, secrets and access checks are unchanged. Your website and `firestore.rules` are not affected: functions deploy separately.
- **To deploy:** `cd functions && npm install && cd .. && firebase deploy --only functions`. Test on the emulator or watch the first deploy's logs; to roll back, put the two version numbers back to ^5.0.0 and ^12.0.0 and redeploy. The modular code runs on both.
- New test `tests/test_functions.py` (stubs the Firebase packages, so it runs offline): owner-only gating (401/403/200), public counters, CORS lists, Netlify origin check.
- Not done: `firebase-admin` 14 (needs `firebase-functions-test` 4, which was not out yet).

## Maintenance pass 3 (bug fixes, offline, chat)
- **Crypto core, CSP hashes, file formats and `firestore.rules`: untouched** (`guard` passes against the original pins; `doctor` 14 ok).
- **Fixed: cover pictures failed on the live site.** `netlify/functions/geminiCover.js` only accepted the old origin `abagusv53.netlify.app`, so requests from `abagus.netlify.app` got a 403. It now accepts both domains, localhost and Netlify deploy previews.
- **Fixed: stale CORS lists.** `functions/index.js` and `functions/owner.js` now allow `https://abagus.netlify.app` (the owner panel and stats endpoints could not be called from the real domain). Redeploy functions after pulling this.
- **Service worker (`sw.js`, shell version 42):** only complete 200 responses are cached (a 206 partial response made `cache.put` throw), cache writes can no longer fail unhandled and are kept alive with `waitUntil`, the offline fallback now matches the PWA start URL `index.html?source=pwa`, and the favicon and apple-touch icon are part of the offline shell.
- **Group chat (`chat.js`):** refreshes are serialised so a timer refresh and a send can no longer render out of order; the chat refreshes the moment the tab becomes visible again; the visibility listener is removed when the chat closes (it used to pile up on every open); swiping to scroll vertically no longer triggers a reply.
- **Pages:** `me.html` and `dashboard.html` now have the apple-touch icon and manifest link like the other pages. `manifest.webmanifest` gained app shortcuts (Groups, My dashboard).
- **New safety net (`ux-safety.js`, external, so no CSP hash changed):** the browser now asks before a tab is closed or reloaded while a seal/open is running, and the passphrase boxes are emptied when the page is left or restored from the back/forward cache. `index.html` also shows a clear message when JavaScript is off. `sw.js` shell version 43 caches the new file. New test: `tests/test_safety.py` (8 checks).
- Checked and clean: syntax of all 27 scripts and functions, CSS brace balance for every stylesheet, no duplicate ids, no unsafe HTML sinks beyond the two already-reviewed ones.
- Still open, needs your decision (unchanged): canonical domain choice, subresource integrity for the two CDN cipher libraries (inside the guarded crypto core), `firebase-functions` ^5 upgrade, and the ~500 KB size of `index.html`.

## Maintenance pass 2 (hygiene, SEO, offline)
- **Crypto core, CSP hashes, file formats and `firestore.rules`: untouched.**
- `index.html`: removed the duplicate `mobile-web-app-capable` meta tag.
- `_headers` and `robots.txt`: `groups.html` and `me.html` are now noindex like `dashboard.html` (they are signed-in pages).
- `sitemap.xml`: lastmod refreshed.
- `sw.js` shell version 41 so every device picks up this pass.
- `package.json`: added `npm test` (runs every suite) and `npm run themes` (regenerate palettes + rebuild `themes.css`/`themes.js`); declared Node >= 22.
- Removed the stray `tests/__pycache__` folder from the project.
- Still open, needs your decision: canonical domain (`abagus.netlify.app` vs the Firebase domain), subresource integrity for the two CDN cipher libraries (they sit inside the guarded crypto core), `firebase-functions` ^5 upgrade (needs network + redeploy), and the size of `index.html` (about 500 KB).

## Maintenance pass (audit, performance, tests)
- **Crypto core, CSP hashes, file formats and `firestore.rules`: untouched** (`guard` passes against the original pins).
- `sw.js` shell version 40: install now adds files one by one, so a single failed file no longer aborts the whole offline install.
- `_headers`: `/themes/*` and `/icons/*` are cached for a day with background revalidation (about 880 KB of theme art no longer re-downloads on every visit).
- Cloud Functions runtime moved from Node 20 to Node 22 (`firebase.json`, `functions/package.json`). Redeploy functions after pulling this.
- Tilt: the card now settles flat at 0.08deg instead of 0.03deg (invisible difference, about 0.3 s sooner). Source in `scripts/themes-src/40-ui.part`, `themes.js` rebuilt with `node scripts/themes-build.mjs`.
- Test fix: `test_themes2` "tilt clears when the mouse leaves" waited 250 ms for an ease-out that takes about 1 s. It now waits 1.5 s. test_themes2 24/24, test_themes 8/8; `npm run doctor` 14 ok.
- Open findings are listed in the reply that accompanied this pass (domain mismatch, CDN libraries without integrity pinning, file size).

## Iron Man blood-red pass + Theme button in the bottom dock
- Iron Man is now blood red (accent #E01E2B, red-orange second colour, red arc reactor, red hex grid and embers). Palette is WCAG AA checked (0 failures).
- Stronger touch: every tap adds a red screen pulse, two chasing shock rings, more sparks, a camera kick and a short vibration; buttons and cards flash red and press in while held; red glowing dock blob, nav underline and progress line.
- The Theme (sparkle) button is now the sixth button of the bottom dock on phones, next to Home, Vault, Security, Learn and Activity, on the Vault and Activity pages. The floating pill is hidden when the dock has it.
- `sw.js` shell version 39. Tests: test_themes 8/8, test_themes2 23/24 (the one failure, "tilt clears when the mouse leaves", already failed before), test_themes3 14/14.

## Themes v3: ten new looks + natural motion
- Added exactly ten themes from your images: Dodge Hellcat, Dragon Rider, Baymax, Doraemon, Deadpool Light, Scarlet Witch, Shang-Chi, Agent Noir, Ghost Rider, Wonder Woman (34 total). Details in THEMES.md.
- Shared motion engine reworked (damped parallax, eased rings and pops, smoother particles, spring card tilt, idle drift, steady Calm fps). Fixed lingering effects after a theme switch and a stray CSS brace.
- `sw.js` shell version 35. Tests: test_themes 8/8, test_themes2 24/24, test_themes3 14/14; doctor passes.


## UI Pro pass: one design layer for every page
- New `ui-pro.css`, loaded last on `index.html`, `dashboard.html`, `groups.html`, `me.html`. Glass navigation with animated underline, soft aurora background, pill buttons with lift and glow, gradient primary buttons, rounded layered cards with hover lift, focus rings, story-ring avatars, gradient hero accent word, polished dropzone, thin scrollbars, bigger phone tap targets.
- Uses the existing theme tokens, so light/dark and all accent colours still work. Respects reduced motion and high contrast.
- Tests: the Groups suites (`test_groups`, `test_groups2`, `test_groups3`, `test_groups4`, `test_google`) now open the Media tab first, because Chat became the default tab in V3. `test_groups` 55/55.
- Crypto core, CSP and file formats untouched; `npm run doctor` passes (14 ok). `sw.js` shell version 32 and caches `ui-pro.css`.


## Upgrade V3: WhatsApp-style group chat, app-shell layout, mobile-number dashboard
- **Group chat** (`chat.js`, new default "Chat" tab in every group): bubbles, day separators, sender colours, reply-to-message (button or swipe), delete (own, or any by admins), jump-to-latest, auto-refresh every 4 s, unread counts. Every message is sealed with the group key before upload; the server stores only `{t, uid, iv, ct}`. Files moved to a "Media" tab.
- **Layout like Instagram / YouTube** (`chat.css`): story-style row of your groups with unread badges, bottom tab bar on phones, side rail on wide screens, rounded cards.
- **Mobile-number dashboard** (`me.html`, `me.js`): profile, groups with unread counts, security status, quick actions. No Google account needed. The Groups nav "Me" link goes here for mobile-number users and to `dashboard.html` for Google users.
- **Rules:** new `groups/{gid}/messages` block (live members only, ciphertext-only, size-capped, no edits). **Publish `firestore.rules` before using chat.**
- Crypto core, CSP of every page and file formats untouched; `doctor` passes (14 ok). `sw.js` shell version 31.
- Not yet done: reactions, typing indicators, read receipts, push notifications (need Cloud Functions + FCM), voice notes, polls. Chat loads the full message list (shows last 200); add paging before heavy use. Existing Playwright tests that expect the Files tab first need `tab` set to Media.


## Upgrade V2: navigation, Discover groups, unified gallery
- **Nothing in the crypto core, key wrapping, file formats, authentication or the CSP of any page was changed.** `guard.mjs` passes against the original pins (no pin was regenerated). No inline script was edited, so no CSP hash changed.
- **Navigation:** Home / Groups / Dashboard on all three pages; a "Groups" button with a badge on the Home bar (`index.html`, `dashboard.html`, `groups.html`, new `ui-plus.css`).
- **Discover groups** (`groups.js`, `groups.css`): ranking by member count with gold/silver/bronze, search, Top Ranked / Newest / My Groups, Open or Join, skeletons and empty states.
- **Privacy design:** owner-only opt-in (`discoverable`, `publicDesc` in `firestore.rules`); a server-only `publicGroups/<gid>` summary with six approved fields written by `functions/directory.js`; clients can read it when signed in and can never write it. Private groups stay private by default.
- **Gallery:** filters with counts, Grid/Compact, play badges, drag-and-drop, progress bars with Retry, lightbox with previous/next, counter, arrows, Esc, swipe. No download button (capture policy unchanged).
- **Fixed:** the entrance-animation observer was created inside the photo viewer on every open. It now starts once.
- **PWA:** `sw.js` shell version 30; `ui-plus.css` pre-cached (the Groups files were already cached). Decrypted content is never cached (it only exists as in-memory blob URLs).
- **Tests:** new `tests/test_groups4.py` (38 checks); `tests/fbshared.py` models the new rules.

## Twenty-sixth pass: owner-only Self-check, the false repair message, your real logo
- **The repair message from your screenshot was a false alarm.** The Groups page does not load the encryption carrier, but the Self-check expected it because the page address (`/groups`) did not end in `.html`. It now expects only the parts the page itself loads.
- **Self-check is now only for `partha9178712507@gmail.com`** (signed in with Google). Everyone else (signed out, mobile-number users, other Google users) sees no Self-check button, no floating button, no repair message, and the shortcut does nothing. This is a convenience gate, not a security boundary: the checks run on the device and reveal nothing private. The change to the address is `OWNER_EMAIL` at the top of `selfcheck.js`. The quiet automatic repair of a failed own-file load (at most once per 10 minutes, no message) still protects everyone.
- **Your logo** (the two images you sent) replaces the old icon: header wordmark and triangle mark on the Vault, Dashboard and Groups pages (they follow light/dark theme), app icons, maskable icons, Apple touch icon, favicon, and the social-share card (`icons/og-logo.png`). The old cream icon is gone from the Groups header.
- The user event now carries the account email (`index.html`, `firebase-lite.js`) so the owner check can work.
- Tests: `test_brand.py` (20), `test_selfcheck.py` (39, including the owner-only checks).

## Twenty-fifth pass: simple Firebase storage again, Google for groups, group security, picture editor
- **Back to simple:** files are stored in Firebase (Firestore) again, exactly like your earlier version. The R2/B2 cloud-bucket system, its Cloud Function, My Files and the viewer were removed, so there is nothing extra to deploy or pay for. (If you ever want large files again, that code is in the earlier ZIP.)
- **Google accounts can use groups** (create, join, upload, open). The Groups page has "Continue with Google" next to the mobile sign-in; `firebase-lite.js` and `cloudkey.js` no longer require a mobile number.
- **Group security:** Relaxed / Standard / Strict safety levels; invites default to one person for one day and show their uses; one-person codes switch themselves off; emergency freeze by the owner (enforced by `firestore.rules`: file reads, uploads and joining stop); fingerprint / face / PIN asked again for removing people, changing admins, changing the safety level, freezing and deleting.
- **Rules:** `frozen` (owner only), invite `maxUses`/`uses` (joiners can only add one use and switch a used-up code off), new log types. Settings values are still limited to the allowed lists.
- **Profile picture editor** (`avatar.js`, `avatar.css`): pick or take a photo, drag, zoom, keyboard controls, 256 x 256 JPEG under 29 KB, metadata removed, only still images up to 15 MB / 80 MP. Used for your picture and the group picture; on the Vault page mobile accounts get "Profile picture" in the account window and the header chip shows it.
- **Groups look and motion:** staggered entrance, unlock animation, loading placeholders, preset cards, frozen banner (reduced-motion safe).
- Kept from earlier passes: premium visual finish, script-hash CSP (no `unsafe-inline` for scripts), security headers, the in-site Self-check, the project doctor, view-transition fix.
- Tests: `test_groups3.py` (group security), `test_google.py` (Google accounts), `test_selfcheck.py`, `test_doctor.py`, plus your existing suites.

## Twentieth pass: Groups page, 120 MB, settings, pictures, Vault Group method
- **New independent page `groups.html`** with its own design, security policy, small Firebase module (`firebase-lite.js`) and styles (`groups.css`). Shares your sign-in. The old pop-up is gone; the header button is now a link.
- **Name tag:** the repeated diagonal pattern across photos and videos is replaced by one small corner tag. Admins can switch to the full pattern or turn it off.
- **Files up to 120 MB** (pieces are read and decrypted three at a time with progress; uploads read the file piece by piece).
- **Settings:** group name, description and picture; members can upload; share locked files from the Vault; capture policy; name tag mode; auto-lock time. Members may delete their own uploads.
- **Pictures:** profile picture (stored for you, small) and group picture, description and member pictures (encrypted with the group key).
- **Vault "Group" method:** third way to unlock (flag 128). Encrypt in the Vault for a group; it is sent to the group and every member opens it with their fingerprint. Core changes: flag mask, validation conditions, a share hook before saving; guard re-pinned.
- **Capture:** the web limits are unchanged and stated honestly. New `native/` wrapper (Capacitor) turns on Android's secure flag for real blocking; **not built or tested here**.
- Rules updated (settings, pictures, member uploads, vault files, 120 MB, delete own). `sw.js` v24. Tests: `test_groups2.py` (36), `test_groups.py` (55).

## Nineteenth pass: private groups
- **Groups** (header "Groups" button for mobile-number accounts): create a group and become its **owner**; make others **admins**; invite with a **code** (1/7/30 days, can be turned off); members view, admins upload photos and videos (25 MB each), delete, remove members, clear flags and manage invites. See `GROUPS.md`.
- **Secured by passkey:** the group key is locked per member by their own Abagus key, so opening a group asks for fingerprint, face or PIN. The key lives in memory only and is dropped after 3 idle minutes. File names, thumbnails, files and file names in the activity log are encrypted in the browser; the server holds ciphertext only.
- **Capture deterrence, stated honestly:** no website can block screenshots or recordings. Content is hidden on focus loss, common capture shortcuts are caught, every view carries the viewer's name, and a caught attempt **flags** the member: the open photo becomes the middle-finger emoji, and the server (rules) refuses them any photo/video data until an admin clears them. A flagged member cannot clear themselves or leave and rejoin. Policy can be "warn and log only". Members accept an honor code that explains all of this before joining.
- Bugs found by the new tests and fixed: thumbnails failed to decrypt; the activity log stored file names in plain text (now encrypted); the open viewer was closed instead of turning into the emoji on a capture.
- New: `groups.js`, `GROUPS.md`, group/invite/thumb rules in `firestore.rules` (publish them again), `VaultDB` helper in the Firebase module. `sw.js` is v23. `tests/test_groups.py` (55 checks) with `tests/fbshared.py`.
- **Not tested against real Firebase:** the access rules (modelled in tests only). Use the Rules Playground after publishing.

## Eighteenth pass: account-key state bugs (reported by the owner)
- **Reported:** the account dialog offered "Add this device" although no key had been created, and pasting a code then said no key was found.
- **Cause 1:** after a setup attempt the dialog marked the key as existing in memory even if nothing had been saved. It now shows only what the account really holds, and says "Cannot reach account" if Firestore does not answer.
- **Cause 2:** the phone's copy of the key was not tied to an account, so a second account on the same phone reused the first account's key and never made its own. Keys are now stored per account on the phone. A file still opens by its own key id on any phone that has that key, signed in or not.
- **Cause 3:** the server record was written before the phone was set up, so a failure could leave a key on the server that no phone could use. The phone is now set up first, and a failed save is undone. A phone that cannot do PRF now fails before any recovery code is shown.
- **Repair:** if the account lost its server record but the phone still holds the key, locking publishes a new recovery code.
- Clearer messages when an account has no key yet. `sw.js` is v21. `tests/test_cloudkey.py` now has 38 checks, including the exact flow from the report.

## Seventeenth pass: AnskarKey with your Abagus account (no Google needed)
- New choice inside AnskarKey: **This phone's passkey** (as before, other devices need your Google/Apple/password-manager sync) or **My Abagus account**.
- **Account key:** a random master key is made in the browser. The server keeps it only encrypted by a **recovery code** shown once; each phone keeps it locked by its **own** passkey. A new phone needs sign-in plus the recovery code once, then biometric only. Abagus cannot read the key or any file. New: `cloudkey.js`; header flag 64 (v7); clear-text block v2 carries an 8-byte public key id.
- **Rules:** `users/<uid>.cloudKey` is validated (`v`, `id`, `salt`, `iv`, `ct` with size limits).
- **Bug found by the new tests and fixed:** signing in on a new phone restored the first phone's passkey id from the account, which does not exist on the new phone unless Google/Apple synced it. The account key now always uses a passkey made on that phone.
- Core change: one flag mask (`0x30` -> `0x70`) and one condition in `handleUnlock`; guard re-pinned. `sw.js` is v20. `tests/test_cloudkey.py` (26 checks), shared double in `tests/fbstub.py`.
- **Limit:** lose the recovery code and every device, and the files cannot be opened by anyone.

## Sixteenth pass: packaging and rules fixes from an outside audit
Each claim was checked against the files before acting.
- **Fixed, packaging:** the uploaded zips were flat and partly lower-cased, but `firebase.json` and the code expect `functions/`. Server files now live in `functions/` (`index.js`, `owner.js`, `dailyImprovement.js`, `lib/github.js`, `lib/geminiClient.js`, `covertopics.json`, `package.json`), every relative require resolves with exact case, and the guard is at `scripts/guard.mjs` as `setup.md` says.
- **Fixed, Netlify:** the deploy zip had `geminicover.js`; the site calls `/.netlify/functions/geminiCover`, which is case-sensitive on Netlify. Both zips now use `geminiCover.js`.
- **Fixed, Firestore rules:** `authMethods` is no longer a free-form map (only `password` and `anskarKey{credentialId,createdAt}` with type and size limits); `provider`, `createdAt` and `updatedAt` are validated; and the stored mobile number must match the account's own sign-in ID, so nobody can claim another number. The test suite mirrors these rules against what the app writes.
- **Not a bug:** `index.js` requires `./covertopics.json`, which exists. `OWNER_API_BASE` is empty on purpose until the Cloud Functions are deployed; then set it to `https://us-central1-abagus-bd19f.cloudfunctions.net` (that is where `index.js` says the functions live) and keep that host in both pages' CSP `connect-src`.
- **Not included:** `.github/workflows/ci.yml` (named in `setup.md`) was not in the upload and is not recreated here, so an existing one in your repository is not overwritten. If you have none, the check it describes is `node scripts/guard.mjs` plus a syntax check.
- **Deploy zip** no longer carries `.guard/`; it is the project minus that folder.

## Fifteenth pass: everything brought in line
- In-app text: the "How it works" step, the FAQ (no storage, losing a passkey) and four new answers (AnskarKey, "Only open on this device", accounts, playing video).
- `firestore.rules`: your original default-deny comments restored. The only exception is the narrow `users/<uid>` rule for mobile-number accounts. The Cloud Functions' Admin SDK access to `geminiChanges/` and `stats/` is unaffected.
- `setup.md`, `readme.md` and `ACCOUNTS.md` describe the new features and tests. `sw.js` is v18.

## Fourteenth pass: mobile-number accounts
- **Create account / Sign in with a mobile number.** New dialog (header "Mobile" button, "Sign in with mobile" in the vault header and mobile menu). Sign up with username + mobile number (+ country code) + password; sign in with number + password. Google sign-in is unchanged.
- **One account per mobile number.** The Firebase sign-in ID is derived from the normalised number (`+<country><number>`), so Firebase itself refuses a second account. `09178712507`, `+91 91787 12507` and `9178712507` are the same number.
- **No SMS verification** (paid), so the number is an ID, not proof of ownership, and there is no password reset. The dialog says both.
- **Profile record** (`users/<uid>` in Firestore, rules in `firestore.rules`): `username`, `mobile`, `provider`, `createdAt`, `updatedAt`, `faceAuth`, `authMethods` (`password`, `anskarKey: {credentialId, createdAt}`). No photo, fingerprint, face data, password or key. Firestore loads only when needed, so sign-in works even if it is not set up (the dialog then says so).
- **AnskarKey follows the account.** Setting up AnskarKey while signed in links its (non-secret) credential id to the account. Signing in on a new phone restores it there, so unlocking a file asks for that phone's face, fingerprint or PIN. "Forget" on a device is respected and not re-added.
- Drive import and the dashboard stay Google-only. New: `account.js`, `firestore.rules`, `ACCOUNTS.md` (3 console steps). CSP gains `https://firestore.googleapis.com`; guard re-pinned. `sw.js` is v17. `tests/test_accounts.py` (31 checks, in-memory Firebase stand-in).

## Thirteenth pass: AnskarKey, device lock, new protection picker
- **AnskarKey (no passphrase):** step 2 of Encrypt now asks *How will you unlock it?* Choose **Passphrase** (exactly as before) or **AnskarKey**. With AnskarKey there is nothing to type: the phone or computer asks for fingerprint, face or screen-lock PIN, and the passkey's WebAuthn **PRF** secret becomes the key that feeds the existing PBKDF2 -> Argon2id -> HKDF chain. Abagus never sees a biometric.
- **Only open on this device:** a switch in the same step. A random HMAC key is created inside the browser as a **non-extractable** CryptoKey (IndexedDB); its output is mixed into the key. A copy of the file on another phone or computer cannot be opened, even with the right passphrase. Works with either method, or both together.
- **Unlock screen adapts:** it reads the file header and shows the passphrase box, the AnskarKey prompt, or a "locked to a different device" notice. A cancelled or failed passkey prompt is not counted as a wrong guess.
- **Security view:** the old "Set up device unlock" card, which only tested the passkey, is now a real manager for AnskarKey (set up, test, forget) and the device key (create, replace, delete).
- **Format:** files using either feature are **version 7** (header identical to v6; flag 16 = AnskarKey, 32 = device lock) with a short clear-text block after the header (credential id and device tag, neither secret). Passphrase-only files stay **v6, byte for byte as before**, and v2 to v6 still open.
- **Code:** new `anskarkey.js` (outside the crypto core). The core gained only the hooks that take the key secret from it; `.guard/pins.json` was re-pinned by hand. CSP unchanged. `sw.js` is v13.
- **Limits, honestly:** AnskarKey needs a passkey provider that supports PRF (Chrome 128+ on Android with Google Password Manager, current Chrome/Edge on desktop, Safari 18). The app tests this at set-up and says so if it is not available. A deleted passkey, or a cleared browser profile for device-locked files, means the file cannot be recovered. That is the design, and the UI says it before you encrypt.
- **Damaged pictures:** if a picture was recompressed or resized by a sharing app, Decrypt now says so and how to resend it, instead of falling back to a passphrase box. `sw.js` is v14.
- **UI:** a pulsing ring and "Waiting for your fingerprint, face or PIN…" while the passkey prompt is open; a "Passkey not on this phone?" help on the unlock screen; the chosen method is remembered; the AnskarKey panel gets a green edge once set up. `sw.js` is v15.
- **Play without downloading:** decrypted video, audio and images play in the page from memory. A single playable file under 700 MB is no longer sent to a save dialog on desktop (that was why nothing could play there). The type is inferred from the extension when the file carried none, and an unplayable format gets a clear message. Larger files still stream to disk. `tests/test_play.py` (7 checks). `sw.js` is v16; crypto-core pins re-set for the one-line condition.
- **Tests:** `tests/test_anskarkey.py` (39 checks, virtual PRF authenticator over http://localhost).

## Twelfth pass: Gemini cover pictures + motion
- **Gemini covers:** every encryption now ends as a PNG whose picture is made by Gemini. 45 fixed topics (`covertopics.json`, mirrored in `covers.js`) are used one by one, one per encryption, wrapping after 45. The position is kept in this browser only. If Gemini is off, slow (14 s) or offline, the old built-in picture is used, so encrypting never waits on it.
- **Key safety:** new Cloud Function `geminiCover` (in `index.js`) holds the key as a secret. It accepts only a topic number 0 to 44 and builds the prompt itself, so nothing from the file or passphrase is sent, and callers cannot inject prompts.
- `carrier.js`: the cover is scaled to the size the payload needs and the ciphertext is hidden in its low bits exactly as before. Decrypting is unchanged. The cover no longer reveals the file type.
- **UI:** drifting aurora backdrop, staggered reveal of cards and steps, hover lift, button shine, and a flip-up cover card (topic, number, thumbnail) after sealing. All of it is off under reduced motion.
- Crypto core and both CSPs are untouched (no CSP change needed: the functions host and `blob:`/`data:` images were already allowed). `sw.js` is v12 and precaches `covers.js`.
- **To switch on:** `firebase functions:secrets:set GEMINI_API_KEY`, deploy functions, add your site to `ALLOWED_ORIGINS`, then set `window.ABAGUS_COVER_URL` (top of the `abagus-ux3-ui` script) to the `geminiCover` URL.


## Themes v2: more power, smoother motion
- **Power levels:** Soft / Normal / Max in the Themes panel (saved per device, applied before first paint by `themes-boot.js`). It scales particle counts, artwork strength, glow, card shadows and headline animation.
- **Theme reveal:** switching themes now spreads out as a circle from the tapped card or button (View Transitions API, skipped under reduced motion or Motion Off).
- **Extras:** card tilt with a moving highlight (mouse only, never on touch, skips panels wider than 560 px), pointer spotlight, theme-coloured reading-progress line, tap combos, artwork scroll parallax, staggered card entrances.
- **Controls:** T hotkey, arrow-key navigation in the grid, Previous button, `AbagusThemes.next()/prev()/power()`.
- **Code:** edited `scripts/themes-src/*.part` and `scripts/themes-base.css`, rebuilt with `python3 scripts/themes-gen.py && node scripts/themes-build.mjs`. New `tests/test_themes2.py` (19 checks). `sw.js` is v34. CSP unchanged (no inline script added).
- **Iron Man rebuild + touch:** new HUD scene, hold-to-charge and UNIBEAM, lock-on reticle, HUD card corners; touch ring and haptics for all themes. `tests/test_themes2.py` is now 24 checks.
- **Themes realism pass:** shared film grain, vignette, soft light falloff, bokeh, camera kick, tapered sparks; Shang-Chi and Moon Knight rebuilt (scene, tap, hold-to-blast). `sw.js` is v36.

## Human pass: ui-human.css
- New `ui-human.css` after `ui-pro.css` on all four pages: ledger-paper background, hand-drawn headline underline, margin-note eyebrow, uneven-corner stitched cards with a slight tilt, stamped tags, bead-slide buttons, large numerals. Tokens only; themes still apply. `sw.js` v38.
