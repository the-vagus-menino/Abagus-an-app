# Abagusment — the element-number code

Abagusment is a step in Abagus's encryption that is **always on** (there is no setting for it). Every text file
is rewritten with the periodic table *before* it is compressed and sealed by the real ciphers.

## The rule
* A **capital** letter becomes the atomic number of the first element (lowest number) whose symbol starts with it.
  `P` -> 15 (P), `A` -> 13 (Al), `T` -> 22 (Ti), `H` -> 1 (H).
* A **small** letter is the same number with a `.` in front: `m` -> `.12` (Mg).
* Anything else stays as it is: `J` and `Q` (no element), spaces, punctuation, other alphabets, emoji.
* Items are joined by **one space**. So `PATHA ROY` becomes `15 13 22 1 13   37 8 39` (the real space is the middle of the three).
* To make the code reversible for *any* text: an original digit or backslash is written with a backslash in front (`5` -> `\5`, `\` -> `\\`).
  A `.` needs no escape, because a `.` that is a real character is always followed by a space or the end.

| Letter | Keyword (symbol) | Number | Small letter |
|---|---|---|---|
| A | Al | 13 | .13 |
| B | Be | 4 | .4 |
| C | C | 6 | .6 |
| D | Dy | 66 | .66 |
| E | Eu | 63 | .63 |
| F | F | 9 | .9 |
| G | Ga | 31 | .31 |
| H | H | 1 | .1 |
| I | In | 49 | .49 |
| J | — | — | (unchanged) |
| K | K | 19 | .19 |
| L | Li | 3 | .3 |
| M | Mg | 12 | .12 |
| N | N | 7 | .7 |
| O | O | 8 | .8 |
| P | P | 15 | .15 |
| Q | — | — | (unchanged) |
| R | Rb | 37 | .37 |
| S | Si | 14 | .14 |
| T | Ti | 22 | .22 |
| U | U | 92 | .92 |
| V | V | 23 | .23 |
| W | W | 74 | .74 |
| X | Xe | 54 | .54 |
| Y | Y | 39 | .39 |
| Z | Zn | 30 | .30 |

(The example in the original brief listed an extra `37` after the first `13`; the rule above, applied to `PATHA ROY`,
gives `15 13 22 1 13   37 8 39`.)

## How Abagus knows a file used it
1. **Format version 6** and **header flag 8** (`0x08` in the flags byte). The header is authenticated by every cipher layer.
2. **A one-byte tag for every packed file**, inside the encrypted stream: `0` = stored as-is, `1` = Abagusment.
3. **A keyword line** at the top of every encoded file: `Ba-Ga-U-S:1` (symbols for 56-31-92-16, scheme version 1).
   The decoder refuses data that does not start with it, and refuses malformed bodies (unknown number, missing separator, bad escape).

Older files (v2 to v5) have no tag and open exactly as before. The status line and the inspector show
"Abagusment decoded" (or "Not in this older file").

## What it applies to
Files that are valid UTF-8 text with no NUL byte (`.txt`, `.md`, `.csv`, `.json`, code, logs...). Images, video, audio,
PDFs, archives and any other binary are stored as-is, because there is no lettering to rewrite. An empty file is stored as-is.
Text with a leading BOM keeps it. Decoding is byte-exact.

## Cost
Each letter becomes 2 to 4 characters plus a separator, so coded text is roughly 3 to 4 times larger before compression.
Gzip (the compression switch) claws most of that back, but compressed size still ends up larger than for the raw text.

## What it is, and is not
The table is public and has no key, so **Abagusment on its own is an encoding, not secrecy**. Anyone who knows the rule can
undo it. It is applied *before*, and never instead of, AES-256-GCM, XChaCha20-Poly1305 and AES-256-CTR/HMAC-SHA512, and it does
not touch key derivation, so it neither adds to nor takes away from the strength of the encryption. What protects a file is
the passphrase and those ciphers.

## Where the code lives
`index.html`, inside the CRYPTO CORE markers: `ABAGUS_*` constants, `AbagusEncoder`, `AbagusDecoder`, `abagusPlan`,
`abagusEncodeGenerator`, `abagusDecodeGenerator`. Tests: `tests/test_abagus.py`.
