/* Mobile-number dashboard: profile, security status, my groups with unread chat counts. Works for mobile-number AND Google accounts.
   No Google Drive needed. Everything shown comes from the signed-in account and the device itself. Plain script. */
(function () {
  'use strict';
  var body = function () { return document.getElementById('meBody'); };
  function h(tag, p) { var e = document.createElement(tag); if (p) for (var k in p) { if (k === 'text') e.textContent = p[k]; else if (k === 'class') e.className = p[k]; else if (k.slice(0, 2) === 'on') e.addEventListener(k.slice(2), p[k]); else e.setAttribute(k, p[k]); }
    for (var i = 2; i < arguments.length; i++) { var c = arguments[i]; if (c != null) e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); } return e; }
  function lsGet(k) { try { return localStorage.getItem(k); } catch (_) { return null; } }
  async function draw(u) {
    var b = body(); if (!b) return; b.textContent = '';
    if (!u.uid) { b.appendChild(h('div', { class: 'gp-empty' }, h('h2', { text: 'Sign in to see your dashboard' }), h('p', { class: 'grp-note', text: 'Use your mobile number. No Google account needed.' }),
      h('button', { class: 'btn primary', onclick: function () { if (window.AbagusAccount) window.AbagusAccount.open('signin'); } }, 'Sign in'))); return; }
    var name = u.name || 'You';
    b.appendChild(h('div', { class: 'me-hero' }, h('div', { class: 'me-av', text: name.charAt(0).toUpperCase() }), h('div', null, h('h2', { text: name }), h('small', { text: u.phone || u.email || '' }))));
    var passkey = !!lsGet('abagus-device-passkey-v1'), groups = [];
    try { groups = await window.VaultDB.list('users/' + u.uid + '/groups', { orderBy: 'joinedAt', dir: 'desc' }); } catch (_) {}
    var counts = await Promise.all(groups.map(function (g) { return window.AbagusChat ? window.AbagusChat.unread(window.VaultDB, g.gid) : 0; }));
    var total = counts.reduce(function (a, c) { return a + c; }, 0);
    b.appendChild(h('div', { class: 'me-stats' }, [['Groups', groups.length], ['Unread', total], ['Security', passkey ? 'On' : 'Off']].map(function (s) { return h('div', { class: 'me-stat' }, h('b', { text: String(s[1]) }), h('span', { text: s[0] })); })));
    b.appendChild(h('div', { class: 'me-actions' }, h('a', { href: 'groups.html' }, 'Open Groups', h('small', { text: 'Chat, media, invites' })), h('a', { href: 'index.html#vault' }, 'Lock a file', h('small', { text: 'Encrypt in the Vault' }))));
    var gc = h('div', { class: 'me-card' }, h('h3', { text: 'Your groups' }));
    if (!groups.length) gc.appendChild(h('p', { class: 'grp-note', text: 'No groups yet. Create or join one from the Groups tab.' }));
    groups.forEach(function (g, i) { gc.appendChild(h('a', { class: 'me-row', href: 'groups.html' }, h('span', { class: 'me-av', style: 'width:42px;height:42px;font-size:17px;background:var(--sunk);color:var(--ink)', text: String(g.name || '?').charAt(0).toUpperCase() }),
      h('span', { class: 'grow' }, h('b', { text: g.name || 'Group' }), h('small', { text: g.role || 'member' })), counts[i] ? h('span', { class: 'ak-chip ready', text: counts[i] + ' new' }) : null)); });
    b.appendChild(gc);
    var sc = h('div', { class: 'me-card' }, h('h3', { text: 'Security' }));
    [['Password', 'Signs you in with your mobile number', true], ['AnskarKey', 'Fingerprint, face or PIN on this phone', passkey], ['Self-lock', 'Groups lock after a few idle minutes', true]].forEach(function (r) {
      sc.appendChild(h('div', { class: 'me-row' }, h('span', { class: 'grow' }, h('b', { text: r[0] }), h('small', { text: r[1] })), h('span', { class: 'ak-chip' + (r[2] ? ' ready' : ''), text: r[2] ? 'On' : 'Not set up' }))); });
    sc.appendChild(h('button', { class: 'btn small', style: 'margin-top:8px', onclick: function () { if (window.AbagusAccount) window.AbagusAccount.open(); } }, 'Manage account & keys'));
    b.appendChild(sc);
  }
  window.addEventListener('abagus:user', function (e) { window.__meUser = e.detail || {}; draw(window.__meUser); });
})();
