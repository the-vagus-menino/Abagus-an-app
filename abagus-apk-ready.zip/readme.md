# Tests

`test_ui.py` covers the live demo, tier cards, scroll beads, readiness checklist and SEALED stamp.

`test_theme.py` covers the Appearance panel (modes + accents, keyboard, persistence over http), live Auto mode,
WCAG contrast for every accent in both themes, the dark-mode ciphertext fix, the reading bead, the hero word split,
reduced motion and phone overflow.

`test_abagus.py` covers the always-on Abagusment layer: the letter table, the spec example, a 3000-string fuzz through the streaming decoder, rejection of malformed data, a check that the packed stream really holds coded text, 8-file mixed batches (text, binary, empty, BOM, Latin-1, NUL, >3 MiB), all layer counts, offline fallback, and opening a v5 file from the release before it (`fixtures/`).

`test_anskarkey.py` covers AnskarKey and the device lock with a virtual passkey authenticator: set-up, no-passphrase round trip, tampered flags, a different passkey or device, cancelled prompts, PRF-less devices and unchanged v6 files.

`test_accounts.py` covers mobile-number accounts against an in-memory stand-in for Firebase: validation, one account per number however it is typed, sign-in, the profile record, linking AnskarKey, a second phone, and Firestore being unavailable.

`test_cloudkey.py` covers the account key: creating it with a recovery code, using it, adding a second phone that shares nothing with the first, wrong and malformed codes, other accounts, cancelling, and being signed out.

`test_groups2.py` covers the standalone Groups page and the newer features: pictures, settings, member uploads, 120 MB limit and multi-piece files, name tag modes, and the Vault Group method end to end.

`test_groups.py` covers private groups with three separate phones against a fake backend that models the key rules: invite codes (wrong, expired, turned off), roles, encrypted uploads, the capture flag and the middle-finger block, removal, outsiders, hostile names, and deleting a group.

`test_play.py` covers playing a decrypted video in the page with no save dialog.

`test_app.py` drives `index.html` in real headless Chromium: 3-layer encrypt → decrypt round trips,
keyfile + batch, wrong-passphrase refusal, the offline fallback, and two security regressions
(hostile filenames, Clear Session).

```
pip install playwright && playwright install chromium
python tests/test_app.py
python tests/test_abagus.py
python tests/test_ui.py
python tests/test_theme.py
python tests/test_anskarkey.py
python tests/test_accounts.py
python tests/test_play.py
python tests/test_cloudkey.py
python tests/test_groups.py
python tests/test_groups2.py
```

The two CDN cipher libraries (XChaCha20-Poly1305, Argon2id) are replaced by deterministic test doubles in
`harness.py`, so the tests run offline. They exercise the app's own plumbing for every layer; they are **not**
a substitute for the real libraries' own test suites.


## Checks and tools
- `npm run doctor` audits the project (files, syntax, CSP hashes, rules, secrets, headers); `npm run doctor:fix` repairs the safe things. After editing an inline script run `npm run csp`.
- In the site, "Self-check" in the footer finds device problems and fixes the safe ones.
- Tests: `python tests/test_groups3.py` (group security), `test_google.py`, `test_selfcheck.py`, `test_doctor.py`, and the older suites.

- Run everything with `npm test`. Theme suites: `test_themes.py`, `test_themes2.py`, `test_themes3.py`, `test_themes4.py`; branding: `test_brand.py`. After editing `scripts/themes-src` or `themes-palettes.css`, run `npm run themes`.

- `test_safety.py` covers the leave-page prompt while sealing, passphrase wiping on page hide, and the no-JavaScript message.
- `test_functions.py` runs the Cloud Functions and the Netlify cover function against stand-ins for the Firebase packages (owner gating, counters, CORS, origin check).
