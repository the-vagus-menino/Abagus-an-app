# Abagus native wrapper: the only way to truly block screenshots and screen recording

**Why this exists.** A web page cannot stop the phone's screenshot or screen-record tools. The operating system can, but only for a
native app. This folder wraps your site in a small Android/iOS app (Capacitor) and switches on the OS protection while a group is open.

**What it does**
- **Android:** `FLAG_SECURE` is set while a group is open. Screenshots fail ("can't take screenshot due to security policy"), screen
  recording and casting show a black screen, and the app preview in the recent-apps list is blanked.
- **iOS:** Apple does not let any app block screenshots. The plugin hides the app in the app switcher; detecting a screenshot or
  recording after it happens needs extra native code, which is **not** included.
- The web page already calls `PrivacyScreen.enable()` when a group opens and `disable()` when it closes (see `setGuard` in `groups.js`),
  but only when it detects it is running inside this wrapper. In a normal browser it does nothing extra.

**Not tested.** I could not build or run an Android app in the environment this was written in. Treat these steps as a starting
point and expect to fix small things.

## Build (Android)
1. Install Node 18+, Android Studio and a JDK.
2. In this folder:  `npm install`
3. Edit `capacitor.config.json`: replace both `YOUR-SITE.netlify.app` with your real domain.
4. `npx cap add android`  then  `npx cap sync`
5. `npx cap open android`, let Android Studio finish syncing, then **Run** on a phone or **Build > Build APK**.
6. In the app, sign in, open a group, and try a screenshot: it should be refused.

## Notes
- Passkeys (fingerprint/face) inside a wrapped WebView depend on the Android WebView version and Google Play services. If AnskarKey set-up
  fails inside the app, keep using the browser for that step: the key made there is the one used.
- Publishing to the Play Store needs a Google developer account (one-time fee) and a privacy policy.
- iOS builds need a Mac, Xcode and an Apple developer account.
