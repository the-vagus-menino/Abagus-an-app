#!/usr/bin/env bash
# Run from the native/ folder after `npx cap add android`. Copies the Abagus icons and splash into the Android project.
set -e
RES=android/app/src/main/res
rm -f $RES/mipmap-*/ic_launcher*.png $RES/mipmap-anydpi-v26/ic_launcher*.xml
cp -r android-res/. $RES/
python3 - <<'PY'
import glob
from PIL import Image
src = Image.open('splash-source.png').convert('RGB')
for f in glob.glob('android/app/src/main/res/drawable*/splash.png'):
    w, h = Image.open(f).size
    s = max(w, h) / src.width
    big = src.resize((int(src.width*s)+1, int(src.height*s)+1), Image.LANCZOS)
    l, t = (big.width-w)//2, (big.height-h)//2
    big.crop((l, t, l+w, t+h)).save(f)
    print('splash', f, w, h)
PY
