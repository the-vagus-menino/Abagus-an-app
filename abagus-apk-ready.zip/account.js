/* =====================================================================
   ABAGUS — mobile-number accounts.

   Create an account with a username, mobile number and password; sign in with the mobile number
   and password. One account per mobile number: the Firebase sign-in ID is derived from the
   normalised number (+<country><number>), so Firebase itself rejects a second account for it.

   Honest limits, stated in the dialog too:
     * The number is NOT verified (no SMS code — that is a paid service). Someone could register a
       number that is not theirs. Treat the number as an ID, not as proof of who someone is.
     * There is no password reset (no real mailbox). A forgotten password means a new account.
     * No face photo, fingerprint or biometric ever reaches Abagus. "Face / fingerprint" sign-in is
       the phone's own, through AnskarKey (a passkey). The account only remembers the passkey's
       non-secret id so a new device can find it after sign-in.

   This file talks to the backend only through window.VaultAuth and window.VaultProfile (defined in
   index.html's Firebase module), so it can be tested with a stand-in.
   ===================================================================== */
(function () {
  'use strict';
  var ID_DOMAIN = 'abagus-bd19f.firebaseapp.com';
  var $ = function (id) { return document.getElementById(id); };
  var toast = function (t, m, ms) { if (typeof window.showToast === 'function') window.showToast(t, m, ms || 4200); };
  var mode = 'signup';              // 'signup' | 'signin'
  var current = { uid: null, phone: null, name: null, google: false };
  var profile = null, profileErr = null, pendingName = null;   // pendingName: the username typed at sign-up, before Firebase has attached it

  /* ------------------------------ validation ------------------------------ */
  function normalizeMobile(cc, num) {
    var c = String(cc || '').replace(/\D/g, '').replace(/^0+/, '');
    var raw = String(num || '').trim();
    var n;
    if (raw.charAt(0) === '+') {               // a full international number was typed into the number box
      var all = raw.replace(/\D/g, '');
      if (c && all.indexOf(c) === 0) n = all.slice(c.length); else return null;
    } else n = raw.replace(/\D/g, '').replace(/^0+/, '');   // drop the trunk zero: 09178712507 -> 9178712507
    if (!c || c.length > 4 || n.length < 6 || c.length + n.length > 15 || c.length + n.length < 8) return null;
    return { e164: '+' + c + n, digits: c + n, cc: c };
  }
  function idEmail(digits) { return 'm' + digits + '@' + ID_DOMAIN; }
  function validUsername(u) { return /^[\p{L}\p{N}._ -]{3,24}$/u.test(u) && !/^\s|\s$/.test(u); }
  function mask(p) { return p ? p.slice(0, 3) + '\u2022'.repeat(Math.max(2, p.length - 6)) + p.slice(-3) : ''; }

  function explain(e) {
    var c = e && e.code;
    if (c === 'auth/email-already-in-use') return 'This mobile number already has an account. Use Sign in instead. Only one account can exist per number.';
    if (c === 'auth/weak-password') return 'That password is too weak. Use at least 10 characters.';
    if (c === 'auth/operation-not-allowed') return 'Mobile sign-up is not switched on yet. In Firebase, open Authentication, then Sign-in method, and enable Email/Password.';
    if (c === 'auth/invalid-credential' || c === 'auth/wrong-password' || c === 'auth/user-not-found' || c === 'auth/invalid-login-credentials')
      return 'The mobile number or password is not right.';
    if (c === 'auth/too-many-requests') return 'Too many attempts. Wait a few minutes and try again.';
    if (c === 'auth/network-request-failed') return 'Could not reach the sign-in service. Check your connection.';
    if (c === 'auth/user-disabled') return 'This account has been disabled.';
    return (e && e.message) || 'Something went wrong. Please try again.';
  }

  /* ------------------------------ dialog ------------------------------ */
  function msg(text, kind) {
    var m = $('acdMsg'); if (!m) return;
    m.textContent = text || ''; m.className = 'acd-msg' + (kind ? ' ' + kind : '') + (text ? '' : ' hidden');
  }
  function setMode(m) {
    mode = m === 'signin' ? 'signin' : 'signup';
    var up = mode === 'signup';
    $('acdTabUp').setAttribute('aria-selected', up ? 'true' : 'false');
    $('acdTabIn').setAttribute('aria-selected', up ? 'false' : 'true');
    $('acdUserRow').classList.toggle('hidden', !up);
    $('acdConfirmRow').classList.toggle('hidden', !up);
    $('acdNotes').classList.toggle('hidden', !up);
    $('acdSubmit').textContent = up ? 'Create account' : 'Sign in';
    $('acdPass').setAttribute('autocomplete', up ? 'new-password' : 'current-password');
    msg('');
  }
  function openDialog(which) {
    var d = $('acctDialog'); if (!d) return;
    render();
    if (!current.uid) setMode(which || 'signup');
    if (typeof d.showModal === 'function') { if (!d.open) d.showModal(); } else d.setAttribute('open', '');
    var f = $(current.uid ? 'acdClose2' : (mode === 'signup' ? 'acdUser' : 'acdNum')); if (f) setTimeout(function () { f.focus(); }, 30);
  }
  function closeDialog() { var d = $('acctDialog'); if (d && d.open) d.close(); }

  function render() {
    var signed = !!current.uid && !!current.phone;
    $('acdAuth').classList.toggle('hidden', signed);
    $('acdSigned').classList.toggle('hidden', !signed);
    $('acctDlgTitle').textContent = signed ? 'Your account' : 'Account';
    if (!signed) return;
    $('acdName').textContent = current.name || 'No username';
    $('acdPhone').textContent = mask(current.phone);
    var ak = profile && profile.authMethods && profile.authMethods.anskarKey;
    var local = window.AnskarKey && window.AnskarKey.credentialInfo && window.AnskarKey.credentialInfo();
    var chip = $('acdAkChip'), btn = $('acdAkBtn');
    var linked = !!(ak && ak.credentialId);
    chip.textContent = linked ? 'Linked to this account' : (local ? 'Set up here, not yet linked' : 'Not set up');
    chip.className = 'ak-chip ' + (linked ? 'ready' : '');
    btn.textContent = local ? (linked ? 'Test it' : 'Link to account') : 'Set up AnskarKey';
    var C = window.CloudKey, cs = C ? C.status() : { localReady: false };
    var hasCk = !!(profile && profile.cloudKey);
    $('acdCkChip').textContent = cs.localReady ? 'Ready on this device' : (profileErr ? 'Cannot reach account' : (hasCk ? 'Add this device' : 'Not created'));
    $('acdCkChip').className = 'ak-chip ' + (cs.localReady ? 'ready' : (profileErr ? 'warn' : ''));
    $('acdCkBtn').textContent = cs.localReady ? 'Test it' : (hasCk && !profileErr ? 'Add this device' : 'Set up Abagus key');
    $('acdCkForget').classList.toggle('hidden', !cs.localReady);
    $('acdProfileNote').classList.toggle('hidden', !profileErr);
    $('acdProfileNote').textContent = profileErr ? 'Your profile record could not be saved (' + profileErr + '). Sign-in still works. The site owner may need to enable Firestore and publish firestore.rules.' : '';
  }

  /* --------------------------- profile + AnskarKey --------------------------- */
  function baseProfile(extra) {
    var now = new Date().toISOString();
    var base = { username: current.name || pendingName || '', mobile: current.phone, provider: 'mobile', updatedAt: now,
      faceAuth: false, authMethods: { password: true, anskarKey: null } };
    if (extra) for (var k in extra) base[k] = extra[k];
    return base;
  }
  async function syncProfile(fresh) {
    if (!current.uid || !window.VaultProfile || !current.phone) return;
    profileErr = null;
    try {
      profile = await window.VaultProfile.load(current.uid);
      if (!profile) {
        profile = baseProfile({ createdAt: new Date().toISOString() });
        await window.VaultProfile.save(current.uid, profile);
      }
      var want = current.name || pendingName;
      if (want && profile.username !== want) {       // sign-up: the name is attached just after the first sign-in event
        profile.username = want;
        await window.VaultProfile.save(current.uid, { username: want, updatedAt: new Date().toISOString() });
      }
      var ak = profile.authMethods && profile.authMethods.anskarKey;
      var A = window.AnskarKey;
      if (A && ak && ak.credentialId && !A.credentialInfo()) {            // new device: pick up the passkey id
        if (A.adopt(ak.credentialId, ak.createdAt)) toast('ok', 'AnskarKey found on your account. Use your fingerprint, face or PIN to unlock files here.', 5200);
      } else if (A && A.credentialInfo() && !(ak && ak.credentialId)) {   // this device has one the account does not know yet
        await linkAnskar(A.credentialInfo());
      }
    } catch (e) { profileErr = (e && (e.code || e.message) || 'error').toString().slice(0, 60); }
    render();
  }
  async function linkAnskar(info) {
    if (!current.uid || !current.phone || !window.VaultProfile) return;
    var methods = { password: true, anskarKey: { credentialId: info.credentialId, createdAt: info.createdAt || new Date().toISOString() } };
    try {
      await window.VaultProfile.save(current.uid, { authMethods: methods, faceAuth: true, updatedAt: new Date().toISOString() });
      profile = Object.assign({}, profile || {}, { authMethods: methods, faceAuth: true }); profileErr = null;
    } catch (e) { profileErr = (e && (e.code || e.message) || 'error').toString().slice(0, 60); }
    render();
  }

  /* ------------------------------ submit ------------------------------ */
  async function submit(ev) {
    ev.preventDefault();
    var btn = $('acdSubmit');
    var num = normalizeMobile($('acdCc').value, $('acdNum').value);
    var pass = $('acdPass').value;
    if (!num) { msg('Enter a valid mobile number with its country code, for example +91 and 9178712507.', 'error'); $('acdNum').focus(); return; }
    var username = '';
    if (mode === 'signup') {
      username = $('acdUser').value.trim();
      if (!validUsername(username)) { msg('Choose a username of 3 to 24 letters, numbers, spaces, dots, dashes or underscores.', 'error'); $('acdUser').focus(); return; }
      if (pass.length < 10) { msg('Use a password of at least 10 characters.', 'error'); $('acdPass').focus(); return; }
      if (pass === num.digits || pass.toLowerCase() === username.toLowerCase()) { msg('The password cannot be your number or username.', 'error'); return; }
      if (pass !== $('acdPass2').value) { msg('The two passwords do not match.', 'error'); $('acdPass2').focus(); return; }
    } else if (!pass) { msg('Enter your password.', 'error'); $('acdPass').focus(); return; }
    if (!window.VaultAuth || !window.VaultAuth.signUp) { msg('Sign-in is not available on this page. Open the site over https.', 'error'); return; }
    btn.disabled = true; msg(mode === 'signup' ? 'Creating your account…' : 'Signing in…', '');
    try {
      if (mode === 'signup') {
        pendingName = username;
        await window.VaultAuth.signUp(idEmail(num.digits), pass);
        current.name = username;
        try { await window.VaultAuth.updateName(username); } catch (_) {}
        await syncProfile(); pendingName = null;
        toast('ok', 'Account created. Welcome, ' + username + '.', 4200);
      } else {
        await window.VaultAuth.signIn(idEmail(num.digits), pass);
        toast('ok', 'Signed in.', 2600);
      }
      try { localStorage.setItem('abagus-cc', num.cc); } catch (_) {}
      $('acdPass').value = ''; $('acdPass2').value = '';
      msg('');
      closeDialog();
    } catch (e) {
      msg(explain(e), 'error');
      if (e && e.code === 'auth/email-already-in-use') setMode('signin');
      if (e && e.code === 'auth/email-already-in-use') msg(explain(e), 'error');
    } finally { btn.disabled = false; pendingName = null; }
  }

  /* ------------------------------ wiring ------------------------------ */
  function wire() {
    document.querySelectorAll('[data-account-open]').forEach(function (b) {
      b.addEventListener('click', function (e) { e.preventDefault(); openDialog('signup'); });
    });
    var chip = $('acctChip');
    if (chip) chip.addEventListener('click', function (e) {
      if (e.target.closest('#signOutBtn') || e.target.closest('#dashChipBtn')) return;
      if (current.phone) openDialog();
    });
    var nav = $('navAcctBtn'); if (nav) nav.addEventListener('click', function () { if (current.phone) openDialog(); });
    $('acdTabUp').addEventListener('click', function () { setMode('signup'); });
    $('acdTabIn').addEventListener('click', function () { setMode('signin'); });
    $('acctForm').addEventListener('submit', submit);
    $('acdClose').addEventListener('click', closeDialog);
    $('acdClose2').addEventListener('click', closeDialog);
    $('acctDialog').addEventListener('click', function (e) { if (e.target === $('acctDialog')) closeDialog(); });
    $('acdShow').addEventListener('click', function () {
      var on = $('acdPass').type === 'password';
      $('acdPass').type = on ? 'text' : 'password'; $('acdPass2').type = on ? 'text' : 'password';
      this.textContent = on ? 'Hide' : 'Show'; this.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
    $('acdOut').addEventListener('click', async function () {
      try { await window.VaultAuth.signOut(); closeDialog(); } catch (e) { toast('error', explain(e)); }
    });
    $('acdCkBtn').addEventListener('click', async function () {
      var b = this; b.disabled = true;
      try { await window.CloudKey.getKey({ purpose: 'lock' }); await syncProfile(); }
      catch (e) { if (!(e && e.code === 'cancelled')) toast('error', (e && e.message) || 'Could not use the Abagus key.', 6000); }
      finally { b.disabled = false; render(); }
    });
    $('acdCkForget').addEventListener('click', function () {
      if (!window.confirm('Remove the Abagus key from this device?\n\nYou can add it back with your recovery code. Without the recovery code you could not.')) return;
      window.CloudKey.forgetLocal(); render(); toast('info', 'Removed from this device.', 3000);
    });
    window.addEventListener('abagus:cloudkey', function () { render(); if (window.AnskarKey) window.AnskarKey.repaint(); });
    $('acdAkBtn').addEventListener('click', async function () {
      var A = window.AnskarKey, b = this; if (!A) return;
      b.disabled = true;
      try {
        var info = A.credentialInfo();
        if (!info) { await A.enroll(); info = A.credentialInfo(); toast('ok', 'AnskarKey is ready.', 3200); }
        var linked = profile && profile.authMethods && profile.authMethods.anskarKey && profile.authMethods.anskarKey.credentialId;
        if (!linked) { await linkAnskar(info); toast(profileErr ? 'error' : 'ok', profileErr ? 'Could not save to your account.' : 'AnskarKey linked to your account.', 4200); }
        else { await A.test(); toast('ok', 'AnskarKey works on this device.', 3600); }
      } catch (e) { toast('error', (e && e.message) || 'AnskarKey could not be used.', 6000); }
      finally { b.disabled = false; render(); }
    });
    try { var cc = localStorage.getItem('abagus-cc'); if (cc) $('acdCc').value = '+' + cc; } catch (_) {}
    window.addEventListener('abagus:user', function (e) {
      var d = e.detail || {};
      var changed = d.uid !== current.uid;
      current = { uid: d.uid, phone: d.phone, name: d.name, google: !!d.google };
      if (changed) { profile = null; profileErr = null; }
      if (!d.uid) { render(); return; }
      render();
      if (changed || !profile) syncProfile();
    });
    window.addEventListener('abagus:anskar', function (e) {
      if (current.uid && current.phone && e.detail) linkAnskar(e.detail);
    });
  }

  window.AbagusAccount = { session: function () { return { uid: current.uid, phone: current.phone, name: current.name }; }, normalizeMobile: normalizeMobile, idEmail: idEmail, open: openDialog, _validUsername: validUsername };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', wire); else wire();
})();
