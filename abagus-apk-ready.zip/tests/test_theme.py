"""Theme + motion tests: Appearance panel, accents, Auto mode, contrast, dark demo fix, reading bead,
hero word split, reduced motion, phone overflow. Runs offline (same harness as the other tests)."""
import sys, os, threading, http.server, functools
sys.path.insert(0, os.path.dirname(__file__))
from harness import *
HERE = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
INDEX = os.environ.get('ABAGUS_INDEX', os.path.join(HERE, 'index.html'))
DASH = os.environ.get('ABAGUS_DASH', os.path.join(HERE, 'dashboard.html'))
def serve_dir(directory):
    class Quiet(http.server.SimpleHTTPRequestHandler):
        def log_message(self, *a): pass
    srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), functools.partial(Quiet, directory=directory))
    threading.Thread(target=srv.serve_forever, daemon=True).start(); return srv
res = []
def check(n, c, e=''): res.append(bool(c)); print('PASS' if c else 'FAIL', n, e)

def lum(h):
    h = h.strip().lstrip('#'); r, g, b = [int(h[i:i+2], 16) / 255 for i in (0, 2, 4)]
    f = lambda c: c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)
def ratio(a, b):
    la, lb = lum(a), lum(b); hi, lo = max(la, lb), min(la, lb); return (hi + 0.05) / (lo + 0.05)
def rgb_hex(css):  # "rgb(r, g, b)" -> "#rrggbb"
    n = [int(float(x)) for x in css[css.index('(') + 1:css.index(')')].replace('/', ',').split(',')[:3]]
    return '#%02x%02x%02x' % tuple(n)
tok = lambda pg, name: pg.evaluate("n=>getComputedStyle(document.documentElement).getPropertyValue(n).trim()", name)
attr = lambda pg, a: pg.evaluate("a=>document.documentElement.getAttribute(a)", a)
store = lambda pg, k: pg.evaluate("k=>localStorage.getItem(k)", k)

with sync_playwright() as p:
    b = p.chromium.launch(); ctx, pg = setup(b); open_page(pg, INDEX, view=None); pg.wait_for_timeout(1500)

    # ---- Appearance panel: open / structure / keyboard ----
    check('panel starts closed', pg.evaluate("document.getElementById('appearPanel').hidden") and pg.get_attribute('#appearBtn', 'aria-expanded') == 'false')
    pg.click('#appearBtn'); pg.wait_for_timeout(300)
    check('panel opens with 3 modes + 4 accents', not pg.evaluate("document.getElementById('appearPanel').hidden")
          and pg.locator('.ap-seg [role=radio]').count() == 3 and pg.locator('.ap-swatch').count() == 4)
    check('focus moves into the panel (a checked radio)', pg.evaluate("document.activeElement.getAttribute('aria-checked')") == 'true')
    pg.keyboard.press('Escape'); pg.wait_for_timeout(200)
    check('Escape closes and returns focus to the button', pg.evaluate("document.getElementById('appearPanel').hidden")
          and pg.evaluate("document.activeElement.id") == 'appearBtn' and pg.get_attribute('#appearBtn', 'aria-expanded') == 'false')
    pg.click('#appearBtn'); pg.wait_for_timeout(250); pg.mouse.click(30, 500); pg.wait_for_timeout(200)
    check('clicking outside closes the panel', pg.evaluate("document.getElementById('appearPanel').hidden"))

    # ---- Accent: apply, persist, reload, reset ----
    pg.click('#appearBtn'); pg.wait_for_timeout(250); pg.click('.ap-swatch[data-v=indigo]'); pg.wait_for_timeout(200)
    check('choosing Indigo sets data-accent and saves it', attr(pg, 'data-accent') == 'indigo' and store(pg, 'abagus-accent') == 'indigo')
    check('indigo swatch is aria-checked', pg.get_attribute('.ap-swatch[data-v=indigo]', 'aria-checked') == 'true')
    # Persistence across a reload is checked over http:// (how users load the site). Over file:// Chromium can drop
    # localStorage writes made just before a reload; the original theme toggle shows the same effect, so it's not the page.
    srv = serve_dir(HERE); url = f'http://127.0.0.1:{srv.server_address[1]}/index.html'
    hctx, hp = setup(b); hp.goto(url); hp.wait_for_function("document.getElementById('appearBtn')", timeout=10000)
    hp.click('#appearBtn'); hp.wait_for_timeout(250); hp.click('.ap-swatch[data-v=indigo]'); hp.wait_for_timeout(300)
    hp.reload(wait_until='load'); hp.wait_for_function("document.getElementById('appearBtn')", timeout=10000)
    check('accent survives a reload and is applied before paint (http)', attr(hp, 'data-accent') == 'indigo' and store(hp, 'abagus-accent') == 'indigo', repr(attr(hp, 'data-accent')))
    hp.click('#appearBtn'); hp.wait_for_timeout(250); hp.click('.ap-seg [data-v=dark]'); hp.wait_for_timeout(300)
    hp.reload(wait_until='load'); hp.wait_for_function("document.getElementById('appearBtn')", timeout=10000)
    check('mode choice survives a reload (http)', attr(hp, 'data-theme') == 'dark' and store(hp, 'abagus-theme') == 'dark')
    hctx.close(); srv.shutdown()
    pg.click('.ap-swatch[data-v=vermilion]'); pg.wait_for_timeout(200)   # panel is still open here
    check('Vermilion (default) removes the attribute and the saved value', attr(pg, 'data-accent') is None and store(pg, 'abagus-accent') is None)

    # ---- Mode: Ink / Paper / Auto follows the system live ----
    pg.click('.ap-seg [data-v=dark]'); pg.wait_for_timeout(200)
    check('Ink forces dark and saves it', attr(pg, 'data-theme') == 'dark' and store(pg, 'abagus-theme') == 'dark')
    pg.click('.ap-seg [data-v=auto]'); pg.wait_for_timeout(200)
    check('Auto clears the saved choice', store(pg, 'abagus-theme') is None)
    pg.emulate_media(color_scheme='light'); pg.wait_for_timeout(300); a = attr(pg, 'data-theme')
    pg.emulate_media(color_scheme='dark'); pg.wait_for_timeout(300); d = attr(pg, 'data-theme')
    check('Auto follows the system live (light -> dark, no reload)', a == 'light' and d == 'dark', f'{a} -> {d}')
    pg.click('.ap-seg [data-v=light]'); pg.wait_for_timeout(200); pg.emulate_media(color_scheme='dark'); pg.wait_for_timeout(300)
    check('an explicit choice is NOT overridden by the system', attr(pg, 'data-theme') == 'light')
    pg.keyboard.press('ArrowRight'); pg.wait_for_timeout(200)
    check('arrow keys move through the mode radios', attr(pg, 'data-theme') == 'dark')
    pg.keyboard.press('Escape')

    # ---- Browser-bar colour follows the theme ----
    m1 = pg.evaluate("document.querySelector('meta[name=theme-color]').content"); pg.click('.theme-toggle'); pg.wait_for_timeout(300)
    m2 = pg.evaluate("document.querySelector('meta[name=theme-color]').content")
    check('theme-color meta matches --paper and changes with the theme', m1 != m2 and m2.lower() == tok(pg, '--paper').lower(), f'{m1} -> {m2}')

    # ---- Contrast: every accent, both themes (WCAG AA 4.5:1 text, 3:1 for the accent itself) ----
    bad = []
    for theme in ('light', 'dark'):
        for acc in ('vermilion', 'indigo', 'verdigris', 'ochre'):
            pg.evaluate("([t,a])=>{const r=document.documentElement;r.setAttribute('data-theme',t);a==='vermilion'?r.removeAttribute('data-accent'):r.setAttribute('data-accent',a)}", [theme, acc])
            paper, sheet, sunk = tok(pg, '--paper'), tok(pg, '--sheet'), tok(pg, '--sunk')
            at, ac, on = tok(pg, '--accent-text'), tok(pg, '--accent'), tok(pg, '--on-accent')
            for name, r, need in (('text/paper', ratio(at, paper), 4.5), ('text/sheet', ratio(at, sheet), 4.5), ('text/sunk', ratio(at, sunk), 4.5),
                                  ('on-accent', ratio(on, ac), 4.5), ('accent/paper', ratio(ac, paper), 3.0)):
                if r < need: bad.append(f'{theme}/{acc}/{name}={r:.2f}')
    check('all 4 accents x 2 themes meet WCAG AA', not bad, ', '.join(bad))
    pg.evaluate("()=>{const r=document.documentElement;r.removeAttribute('data-accent')}")

    # ---- Dark demo: ciphertext bytes must be legible (were --paper on --sunk = invisible) ----
    pg.evaluate("document.documentElement.setAttribute('data-theme','dark')"); pg.fill('#demoInput', 'legibility check'); pg.wait_for_timeout(400)
    fg = pg.evaluate("(()=>{const e=document.querySelector('#demoTape .ct');return e?getComputedStyle(e).color:null})()")
    bg = pg.evaluate("getComputedStyle(document.getElementById('demoTape')).backgroundColor")
    check('dark theme: ciphertext bytes contrast >= 4.5:1', fg is not None and ratio(rgb_hex(fg), rgb_hex(bg)) >= 4.5, f'{fg} on {bg}')
    pg.evaluate("document.documentElement.setAttribute('data-theme','light')"); pg.wait_for_timeout(200)
    fg = pg.evaluate("getComputedStyle(document.querySelector('#demoTape .ct')).color"); bg = pg.evaluate("getComputedStyle(document.getElementById('demoTape')).backgroundColor")
    check('light theme: ciphertext bytes contrast >= 4.5:1', ratio(rgb_hex(fg), rgb_hex(bg)) >= 4.5, f'{fg} on {bg}')

    # ---- Reading bead on the nav rule ----
    pg.evaluate("window.scrollTo({top:0,behavior:'instant'})"); pg.wait_for_timeout(300)
    z = pg.evaluate("[document.querySelector('.site-nav').style.getPropertyValue('--read'), document.querySelector('.site-nav').style.getPropertyValue('--bead-o')]")
    pg.evaluate("window.scrollTo({top:(document.documentElement.scrollHeight-innerHeight)/2,behavior:'instant'})"); pg.wait_for_timeout(300)
    mid = pg.evaluate("[document.querySelector('.site-nav').style.getPropertyValue('--read'), document.querySelector('.site-nav').style.getPropertyValue('--bead-o')]")
    check('reading bead hidden at top, ~50% and visible mid-page', z[1] == '0' and 0.4 < float(mid[0]) < 0.6 and mid[1] == '1', f'{z} -> {mid}')

    # ---- Hero headline: split into words, text unchanged ----
    words = pg.locator('.hero h1.split .w').count(); txt = ' '.join(pg.inner_text('.hero h1').split())
    check('hero headline split into words, wording unchanged', words >= 6 and txt.replace('\n', ' ') == 'Lock it here, before it goes anywhere.', f'{words} words: {txt}')
    check('headline is visible once split (not stuck hidden)', pg.evaluate("getComputedStyle(document.querySelector('.hero h1')).visibility") == 'visible')

    # ---- Dashboard shares the theme system (its Firebase code can't run offline; the shell can) ----
    ctxd = b.new_context(viewport={'width': 1280, 'height': 900}); ctxd.add_init_script("try{localStorage.setItem('abagus-accent','ochre')}catch(e){}")
    d = ctxd.new_page(); d.errors = []; d.on('pageerror', lambda e: d.errors.append(str(e)[:120])); d.goto('file://' + DASH); d.wait_for_timeout(900)
    check('dashboard: has Appearance button and applies the saved accent', d.locator('#appearBtn').count() == 1 and attr(d, 'data-accent') == 'ochre')
    ctxd.close()

    # ---- Reduced motion: no splitting, headline visible, panel still works ----
    ctxr = b.new_context(viewport={'width': 1280, 'height': 900}, reduced_motion='reduce'); r = ctxr.new_page(); r.errors = []
    r.on('pageerror', lambda e: r.errors.append(str(e)[:120])); r.goto('file://' + INDEX); r.wait_for_timeout(700)
    check('reduced motion: headline not split, immediately visible',
          r.locator('.hero h1.split').count() == 0 and r.evaluate("getComputedStyle(document.querySelector('.hero h1')).visibility") == 'visible')
    r.click('#appearBtn'); r.wait_for_timeout(150); r.click('.ap-swatch[data-v=verdigris]'); r.wait_for_timeout(150)
    check('reduced motion: Appearance panel still works', attr(r, 'data-accent') == 'verdigris')
    check('reduced motion: no page errors', not r.errors, str(r.errors[:2])); ctxr.close()

    # ---- Phones: no sideways scroll, panel stays inside the screen ----
    bad = []
    for w in (360, 390):
        c2 = b.new_context(viewport={'width': w, 'height': 800}); q = c2.new_page(); q.goto('file://' + INDEX); q.wait_for_timeout(900)
        over = q.evaluate("document.documentElement.scrollWidth-document.documentElement.clientWidth")
        q.click('#appearBtn'); q.wait_for_timeout(300); bb = q.locator('#appearPanel').bounding_box()
        if over > 0 or bb['x'] < 0 or bb['x'] + bb['width'] > w + 0.5: bad.append(f'{w}px over={over} panel={bb}')
        c2.close()
    check('phones 360/390: no overflow, panel inside the viewport', not bad, '; '.join(bad))

    check('no page errors', not pg.errors, str(pg.errors[:2]))
    b.close()
print(sum(res), '/', len(res)); sys.exit(0 if all(res) else 1)
