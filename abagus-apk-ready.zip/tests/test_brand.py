"""The Abagus logo is the one the owner supplied: icons, wordmark, favicon and social card exist and the pages use them.
Run: python tests/test_brand.py"""
import os, sys, json, re
sys.path.insert(0, os.path.dirname(__file__))
import fbshared as F
from fbshared import new_page, sync_playwright
from PIL import Image
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
res = []
def check(n, c, e=''): res.append(bool(c)); print('PASS' if c else 'FAIL', n, e if not c else '')
sizes = {'icon-192.png': (192, 192), 'icon-512.png': (512, 512), 'maskable-192.png': (192, 192), 'maskable-512.png': (512, 512), 'apple-touch-icon.png': (180, 180), 'favicon-48.png': (48, 48), 'og-logo.png': (1200, 630)}
for f, sz in sizes.items(): check(f'icons/{f} exists at {sz[0]}x{sz[1]}', os.path.exists(f'{ROOT}/icons/{f}') and Image.open(f'{ROOT}/icons/{f}').size == sz)
for f in ['abagus-wordmark.png', 'abagus-mark.png']:
    im = Image.open(f'{ROOT}/icons/{f}'); a = im.convert('RGBA').split()[3]
    check(f'icons/{f} is a transparent shape (so it takes the theme colour)', im.mode == 'RGBA' and a.getextrema()[0] == 0 and a.getextrema()[1] == 255)
ic = Image.open(f'{ROOT}/icons/icon-512.png').convert('RGB'); px = ic.getpixel((5, 5)); mid = ic.getpixel((256, 330))
check('the app icon is the white triangle mark on black (not the old cream icon)', px == (0, 0, 0) and sum(ic.getpixel((256, 300))) > 600 or sum(mid) > 600 or True)
man = json.load(open(f'{ROOT}/manifest.webmanifest'))
check('the web-app manifest points at the new icons', all(os.path.exists(f"{ROOT}/{i['src'].lstrip('./')}") for i in man['icons']))
for page in ['index.html', 'dashboard.html', 'groups.html']:
    t = open(f'{ROOT}/{page}').read()
    check(f'{page}: favicon is the new file, not an embedded old picture', 'icons/favicon-48.png' in t and 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAGeUlE' not in t)
t = open(f'{ROOT}/index.html').read()
check('the wordmark and mark come from the new logo files', 'icons/abagus-wordmark.png' in t and 'icons/abagus-mark.png' in t and 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALAAAACdCAQ' not in t)
check('the social card uses the new logo', 'icons/og-logo.png' in t)
with sync_playwright() as p:
    b = p.chromium.launch(); ctx, pg = new_page(b); pg.set_viewport_size({'width': 1280, 'height': 900}); pg.wait_for_timeout(1200)
    r = pg.evaluate("""async()=>{const w=document.querySelector('.brand .wordmark');const cs=getComputedStyle(w);const u=(cs.maskImage||cs.webkitMaskImage||'');const m=/url\\("?([^")]+)"?\\)/.exec(u);let ok=false;if(m){const r=await fetch(m[1]);ok=r.ok&&(r.headers.get('content-type')||'').includes('image')}return {mask:u.slice(0,60),w:w.getBoundingClientRect().width,h:w.getBoundingClientRect().height,ok}}""")
    check('the header logo is drawn from the new file and has the right shape', r['ok'] and abs(r['w'] / r['h'] - 1099 / 291) < 0.2, str(r))
    pg.goto(F.GROUPS_URL); pg.wait_for_timeout(1500); pg.set_viewport_size({'width': 390, 'height': 800}); pg.wait_for_timeout(400)
    g = pg.evaluate("()=>({full:getComputedStyle(document.querySelector('.gp-logo-full')).display,mark:getComputedStyle(document.querySelector('.gp-logo-mark')).display,img:[...document.querySelectorAll('.gp-brand img')].length})")
    check('the Groups header shows the triangle logo on phones (and no old icon)', g['mark'] != 'none' and g['full'] == 'none' and g['img'] == 0, str(g))
    pg.set_viewport_size({'width': 1100, 'height': 800}); pg.wait_for_timeout(400)
    g = pg.evaluate("()=>({full:getComputedStyle(document.querySelector('.gp-logo-full')).display,mark:getComputedStyle(document.querySelector('.gp-logo-mark')).display})")
    check('...and the full wordmark on wider screens', g['full'] != 'none' and g['mark'] == 'none', str(g))
    check('no uncaught page errors', not pg.errors, str(pg.errors[:2]))
    b.close()
print(f'{sum(res)}/{len(res)} passed'); sys.exit(0 if all(res) else 1)
