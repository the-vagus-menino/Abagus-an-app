"""AnskarKey + device lock, end to end in real headless Chromium with a virtual WebAuthn authenticator
(CTAP2, user-verifying, PRF/hmac-secret). The page is served from http://localhost because passkeys need a
secure context. Run: python tests/test_anskarkey.py"""
import os, sys, base64, threading, functools, http.server, socketserver
sys.path.insert(0, os.path.dirname(__file__))
from harness import CHACHA, ARGON, CORS, sync_playwright

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
res = []
def check(n, c, e=''): res.append(bool(c)); print('PASS' if c else 'FAIL', n, e)

class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
httpd = socketserver.TCPServer(('127.0.0.1', 0), functools.partial(Quiet, directory=ROOT))
PORT = httpd.server_address[1]
threading.Thread(target=httpd.serve_forever, daemon=True).start()
URL = f'http://localhost:{PORT}/index.html#vault'

def new_page(b, prf=True, verified=True):
    ctx = b.new_context(viewport={'width': 1100, 'height': 900}, accept_downloads=True, service_workers='block')
    ctx.add_init_script("try{localStorage.setItem('vault_sound_muted_v1','1')}catch(e){}; delete window.showSaveFilePicker;")
    ctx.route('**/@noble/ciphers@1.0.0/chacha.js', lambda r: r.fulfill(status=200, headers=CORS, body=CHACHA))
    ctx.route('**/@noble/hashes@1.5.0/argon2.js', lambda r: r.fulfill(status=200, headers=CORS, body=ARGON))
    pg = ctx.new_page(); pg.errors = []
    pg.on('pageerror', lambda e: pg.errors.append(str(e)[:200]))
    cdp = ctx.new_cdp_session(pg)
    cdp.send('WebAuthn.enable')
    auth = cdp.send('WebAuthn.addVirtualAuthenticator', {'options': {
        'protocol': 'ctap2', 'transport': 'internal', 'hasResidentKey': True, 'hasUserVerification': True,
        'isUserVerified': verified, 'automaticPresenceSimulation': True, 'hasPrf': prf}})
    pg.cdp, pg.auth = cdp, auth['authenticatorId']
    pg.goto(URL); pg.wait_for_timeout(700)
    return ctx, pg

def unwrap(pg, raw):
    if raw[:8] != b'\x89PNG\r\n\x1a\n': return raw
    b64 = base64.b64encode(raw).decode()
    out = pg.evaluate("""async b64 => { const u = Uint8Array.from(atob(b64), c => c.charCodeAt(0));
      const r = await AbagusCarrier.extract(new File([u], 'x.png')); let s=''; for (let i=0;i<r.length;i+=32768) s += String.fromCharCode.apply(null, r.subarray(i,i+32768)); return btoa(s); }""", b64)
    return base64.b64decode(out)

def lock(pg, data, method='anskar', device=False, pw=None, name='note.txt'):
    pg.set_input_files('#lockFileInput', [{'name': name, 'mimeType': 'application/octet-stream', 'buffer': data}])
    pg.evaluate("v=>{const s=document.getElementById('cascadeMode'); s.value=v; s.dispatchEvent(new Event('change'))}", 'double')
    if method == 'anskar': pg.click('#methodAnskar')
    else:
        pg.fill('#lockPassword', pw); pg.fill('#lockPasswordConfirm', pw)
    if device and not pg.is_checked('#deviceOnlyToggle'): pg.click('label.switch-row:has(#deviceOnlyToggle)')
    try:
        with pg.expect_download(timeout=60000) as d:
            pg.click('#lockBtn')
    except Exception:
        return None, pg.inner_text('#lockMsg')
    raw = open(d.value.path(), 'rb').read()
    return unwrap(pg, raw), pg.inner_text('#lockMsg')

def unlock(pg, locked, pw=None, name='x.locked'):
    pg.click('#tabUnlockBtn'); pg.wait_for_timeout(150)
    pg.set_input_files('#unlockFileInput', {'name': name, 'mimeType': 'application/octet-stream', 'buffer': locked})
    pg.wait_for_timeout(400)
    if pw is not None and pg.is_visible('#unlockPassword'): pg.fill('#unlockPassword', pw)
    pg.click('#unlockBtn')
    pg.wait_for_function("()=>{const a=document.getElementById('previewArea');const m=document.getElementById('unlockMsg');return (a&&!a.classList.contains('hidden'))||(m&&/fail|too many|locked|cancel|device|enter|damaged|cannot|could not|newer/i.test(m.textContent))}", timeout=60000)
    ok = pg.evaluate("()=>!document.getElementById('previewArea').classList.contains('hidden')")
    if not ok: return None, pg.inner_text('#unlockMsg')
    with pg.expect_download(timeout=30000) as d: pg.click('#downloadBtn')
    return open(d.value.path(), 'rb').read(), pg.inner_text('#unlockMsg')

DATA = b'Meeting notes: the AnskarKey test payload. ' * 400
with sync_playwright() as p:
    b = p.chromium.launch()

    # ---------- picker UI ----------
    ctx, pg = new_page(b)
    check('passphrase is the default method', pg.is_visible('#lockPwBlock') and not pg.is_visible('#lockAkBlock') and pg.get_attribute('#methodPick', 'data-method') == 'password')
    pg.click('#methodAnskar')
    check('AnskarKey hides the passphrase fields and shows its panel', not pg.is_visible('#lockPwBlock') and pg.is_visible('#lockAkBlock'))
    check('encrypt button and summary follow the method', pg.inner_text('#lockBtn') == 'Encrypt with AnskarKey' and 'AnskarKey' in pg.inner_text('#inspMethod'))
    pg.keyboard.press('Escape'); pg.focus('#methodAnskar'); pg.keyboard.press('ArrowLeft')
    check('arrow keys move the selection back', pg.get_attribute('#methodPick', 'data-method') == 'password' or pg.get_attribute('#methodPassword', 'aria-checked') == 'true')
    pg.click('#methodAnskar')
    check('status chip says not set up yet', 'Not set up' in pg.inner_text('#lockAkChip'))

    # ---------- set up + AnskarKey round trip, no passphrase anywhere ----------
    pg.click('#lockAkSetup'); pg.wait_for_function("()=>/Ready/i.test(document.getElementById('lockAkChip').textContent)", timeout=20000)
    check('AnskarKey set up from the panel', pg.evaluate("()=>!!localStorage.getItem('abagus-anskarkey-v1')"))
    locked, msg = lock(pg, DATA, 'anskar')
    check('AnskarKey file is v7 with flag 16 and no device flag', locked and locked[4] == 7 and (locked[42] & 0x10) and not (locked[42] & 0x20) and locked[:4] == b'SVL3', msg[:80])
    check('clear-text block follows the 65-byte header', locked and (locked[65] | locked[66] << 8) > 10)
    check('passphrase was never needed', 'AnskarKey' in msg)
    rec, m = unlock(pg, locked)
    check('AnskarKey file opens with no passphrase, byte-identical', rec == DATA, m[:80])
    check('unlock screen hid the passphrase field for this file', not pg.is_visible('#unlockPwBlock') and pg.is_visible('#unlockAkBlock') and pg.inner_text('#unlockBtn') == 'Unlock with AnskarKey')
    check('summary shows the unlock method', 'AnskarKey' in pg.inner_text('#inspUMethod'))
    # tamper: clear the AnskarKey flag -> must not open
    t = bytearray(locked); t[42] &= ~0x10
    pg.click('#clearSessionBtn'); pg.wait_for_timeout(200)
    rec, m = unlock(pg, bytes(t), pw='anything at all 123')
    check('removing the AnskarKey flag does not open the file', rec is None, m[:60])
    # damaged extension block
    t = bytearray(locked); t[65] = 0xFF; t[66] = 0xFF
    rec, m = unlock(pg, bytes(t))
    check('damaged AnskarKey block is refused cleanly', rec is None and 'damaged' in m.lower(), m[:80])
    check('no uncaught page errors (AnskarKey)', not pg.errors, str(pg.errors[:2]))
    ctx.close()

    # ---------- a different passkey cannot open it ----------
    ctx1, pg1 = new_page(b); pg1.click('#methodAnskar')
    locked1, _ = lock(pg1, DATA, 'anskar')
    ctx2, pg2 = new_page(b)   # fresh authenticator = someone else's passkey
    rec, m = unlock(pg2, locked1)
    check('a different device/passkey cannot open it', rec is None, m[:90])
    for _ in range(6):
        pg2.click('#unlockBtn'); pg2.wait_for_timeout(250)
    check('failed passkey prompts never trigger the passphrase lockout', 'too many' not in pg2.inner_text('#unlockMsg').lower() and 'locked for' not in pg2.inner_text('#unlockMsg').lower())
    ctx1.close(); ctx2.close()

    # ---------- cancelled biometric ----------
    ctx, pg = new_page(b, verified=False)
    pg.click('#methodAnskar')
    pg.set_input_files('#lockFileInput', [{'name': 'a.txt', 'mimeType': 'text/plain', 'buffer': b'hi'}])
    pg.click('#lockBtn'); pg.wait_for_timeout(2500)
    msg = pg.inner_text('#lockMsg')
    check('failed biometric gives a plain message and no file', msg and 'Encryption complete' not in msg, msg[:90])
    check('encrypt button works again afterwards', pg.is_enabled('#lockBtn'))
    ctx.close()

    # ---------- PRF unsupported ----------
    ctx, pg = new_page(b, prf=False)
    pg.click('#methodAnskar'); pg.click('#lockAkSetup'); pg.wait_for_timeout(2500)
    check('no PRF support: nothing is saved and the user is told', not pg.evaluate("()=>!!localStorage.getItem('abagus-anskarkey-v1')") and 'Not set up' in pg.inner_text('#lockAkChip'))
    ctx.close()

    # ---------- device lock with a passphrase ----------
    PW = 'correct horse battery staple 42'
    ctx, pg = new_page(b)
    pg.click('label.switch-row:has(#deviceOnlyToggle)')
    check('device warning appears when switched on', pg.is_visible('#deviceNote'))
    pg.click('label.switch-row:has(#deviceOnlyToggle)')
    dl, msg = lock(pg, DATA, 'password', device=True, pw=PW)
    check('device-locked file is v7 with flag 32 only', dl and dl[4] == 7 and (dl[42] & 0x20) and not (dl[42] & 0x10), msg[:80])
    rec, m = unlock(pg, dl, pw=PW)
    check('opens on the same device with the passphrase', rec == DATA, m[:80])
    check('unlock screen says this is the device', 'that device' in pg.inner_text('#unlockDeviceNote').lower())
    pg.click('#clearSessionBtn'); pg.wait_for_timeout(200)
    rec, m = unlock(pg, dl, pw='the wrong passphrase 000')
    check('wrong passphrase still refused on the right device', rec is None)
    check('device key is non-extractable', pg.evaluate("""async()=>{const db=await new Promise((r,j)=>{const q=indexedDB.open('abagus-device',1);q.onsuccess=()=>r(q.result);q.onerror=j});
      const rec=await new Promise(r=>{const q=db.transaction('k').objectStore('k').get('device');q.onsuccess=()=>r(q.result)});
      let blocked=false; try{await crypto.subtle.exportKey('raw',rec.key)}catch(e){blocked=true}
      return rec.key.extractable===false && blocked}"""))
    ctx.close()
    ctx, pg = new_page(b)   # fresh browser profile = another device
    rec, m = unlock(pg, dl, pw=PW)
    check('another device cannot open it, even with the right passphrase', rec is None and 'different device' in pg.inner_text('#unlockDeviceNote').lower(), m[:100])
    check('and it says why', 'device' in m.lower(), m[:100])
    ctx.close()

    # ---------- AnskarKey + device together ----------
    ctx, pg = new_page(b); pg.click('#methodAnskar')
    both, msg = lock(pg, DATA, 'anskar', device=True)
    check('both flags set (16 + 32)', both and (both[42] & 0x30) == 0x30 and both[4] == 7, msg[:80])
    rec, m = unlock(pg, both)
    check('AnskarKey + device lock opens on this device', rec == DATA, m[:80])
    ctx.close()

    # ---------- plain passphrase files are unchanged ----------
    ctx, pg = new_page(b)
    plain, msg = lock(pg, DATA, 'password', pw=PW)
    check('passphrase-only files are still version 6 with no extra block', plain and plain[4] == 6 and not (plain[42] & 0x30), msg[:60])
    rec, m = unlock(pg, plain, pw=PW)
    check('passphrase round trip unchanged', rec == DATA, m[:60])
    check('passphrase screen is shown again for a passphrase file', pg.is_visible('#unlockPwBlock') and not pg.is_visible('#unlockAkBlock'))
    check('no uncaught page errors (rest)', not pg.errors, str(pg.errors[:2]))

    # ---------- the picture goes through the real PNG path, and a recompressed copy is explained ----------
    ctx, pg = new_page(b); pg.click('#methodAnskar')
    pg.set_input_files('#lockFileInput', [{'name': 'n.txt', 'mimeType': 'text/plain', 'buffer': DATA}])
    with pg.expect_download(timeout=60000) as d: pg.click('#lockBtn')
    png_name, png = d.value.suggested_filename, open(d.value.path(), 'rb').read()
    ctx2, pg2 = new_page(b)   # another phone, opening the actual picture
    pg2.click('#tabUnlockBtn'); pg2.wait_for_timeout(150)
    pg2.set_input_files('#unlockFileInput', {'name': png_name, 'mimeType': 'image/png', 'buffer': png}); pg2.wait_for_timeout(1200)
    check('the shared PNG is recognised as AnskarKey on another device', pg2.is_visible('#unlockAkBlock') and not pg2.is_visible('#unlockPwBlock'))
    jpg = base64.b64decode(pg2.evaluate("""async b64 => { const u=Uint8Array.from(atob(b64),c=>c.charCodeAt(0)); const bm=await createImageBitmap(new Blob([u],{type:'image/png'}));
      const c=document.createElement('canvas'); c.width=bm.width; c.height=bm.height; c.getContext('2d').drawImage(bm,0,0);
      const bl=await new Promise(r=>c.toBlob(r,'image/jpeg',0.8)); const a=new Uint8Array(await bl.arrayBuffer()); let s=''; for(const x of a) s+=String.fromCharCode(x); return btoa(s); }""", base64.b64encode(png).decode()))
    pg2.set_input_files('#unlockFileInput', {'name': 'copy.jpg', 'mimeType': 'image/jpeg', 'buffer': jpg}); pg2.wait_for_timeout(1200)
    check('a recompressed copy is explained, not shown as a password screen', 'compressed' in pg2.inner_text('#unlockMsg') and 'File or Document' in pg2.inner_text('#unlockMsg'))
    ctx.close(); ctx2.close()

    # ---------- help for a phone without the passkey + remembered choice ----------
    ctx, pg = new_page(b); pg.click('#methodAnskar'); pg.reload(); pg.wait_for_timeout(700)
    check('the chosen method is remembered after a reload', pg.get_attribute('#methodPick', 'data-method') == 'anskar' and pg.is_visible('#lockAkBlock'))
    pg.click('#lockAkSetup'); pg.wait_for_timeout(1500)
    lk, _ = lock(pg, DATA, 'anskar')
    ctx3, pg3 = new_page(b)
    pg3.click('#tabUnlockBtn'); pg3.set_input_files('#unlockFileInput', {'name': 'x.locked', 'mimeType': 'application/octet-stream', 'buffer': lk}); pg3.wait_for_timeout(600)
    check('unlock screen offers help for a phone without the passkey', pg3.is_visible('.ak-help summary'))
    pg3.click('#unlockBtn'); pg3.wait_for_timeout(1500)
    check('failed prompt points to the same account or another phone', 'same Google or Apple account' in pg3.inner_text('#unlockMsg'))
    ctx.close(); ctx3.close()
    b.close()

print(f'{sum(res)}/{len(res)} passed'); sys.exit(0 if all(res) else 1)
