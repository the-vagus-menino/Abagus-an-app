"""UI behaviour tests: live demo, tier cards, scroll beads, readiness checklist, SEALED stamp."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from harness import *
INDEX = os.environ.get('ABAGUS_INDEX', os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'index.html')))
res=[]
def check(n,c,e=''): res.append(bool(c)); print('PASS' if c else 'FAIL',n,e)
with sync_playwright() as p:
    b=p.chromium.launch(); ctx,pg=setup(b); open_page(pg, INDEX, view=None)
    # demo
    t1=pg.inner_text('#demoTape'); pg.fill('#demoInput','Different words entirely'); pg.wait_for_timeout(300); t2=pg.inner_text('#demoTape')
    check('demo re-encrypts on input (fresh nonce/ciphertext)', t1!=t2 and 'bytes' in pg.inner_text('#demoBytes').lower(), pg.inner_text('#demoBytes'))
    pg.fill('#demoInput',''); pg.wait_for_timeout(300); check('demo handles empty message (nonce+tag only = 28 bytes)', pg.inner_text('#demoBytes').lower()=='28 bytes')
    # tier cards use real constants (they live in the Security view of the app shell)
    pg.evaluate("abagusView('security')"); pg.wait_for_timeout(400)
    check('tier cards populated from real constants', pg.inner_text('.tcard[data-tier=paranoid] [data-f=mem]')=='256 MiB' and '9 M' in pg.inner_text('.tcard[data-tier=paranoid] [data-f=rounds]'))
    check('membit blocks scale 8/16/32', [pg.locator(f'.tcard[data-tier={k}] .membits i').count() for k in ('standard','maximum','paranoid')]==[8,16,32])
    pg.click('[data-use-tier=maximum]'); pg.wait_for_timeout(300)
    check('"Use Maximum" sets the tool tier + highlights card', pg.evaluate("currentSecurityLevel")=='maximum' and pg.evaluate("document.querySelector('.tcard[data-tier=maximum]').classList.contains('active')"))
    # app shell: dock switches views, title + focus follow
    pg.evaluate("abagusView('home')"); pg.wait_for_timeout(300)
    pg.click('.topnav [data-top=vault]'); pg.wait_for_timeout(400)
    check('top nav opens the Vault view with its own title', pg.evaluate("document.body.dataset.view")=='vault' and pg.title().startswith('Vault'), pg.title())
    check('heading receives focus after a view change', pg.evaluate("document.activeElement && document.activeElement.id")=='deskTitle')
    # readiness + step marks + stamp
    pg.evaluate("document.getElementById('app').scrollIntoView()")
    rows=lambda: pg.evaluate("[...document.querySelectorAll('#lockReady .ready-row')].map(r=>r.classList.contains('on'))")
    check('readiness starts empty', rows()==[False,False,False])
    pg.set_input_files('#lockFileInput',[{'name':'a.txt','mimeType':'text/plain','buffer':b'hello'*100}])
    pg.fill('#lockPassword','correct horse battery'); pg.fill('#lockPasswordConfirm','correct horse batter')
    check('readiness: file+length on, match off', rows()==[True,True,False])
    check('step 1 checked, step 2 not yet', pg.evaluate("[...document.querySelectorAll('#lockView .step-n')].slice(0,2).map(e=>e.classList.contains('done'))")==[True,False])
    pg.fill('#lockPasswordConfirm','correct horse battery')
    check('readiness all on; step 2 checked', rows()==[True,True,True] and pg.evaluate("document.querySelectorAll('#lockView .step-n')[1].classList.contains('done')"))
    pg.evaluate("setLayers(2)"); pg.evaluate("setSecurityLevel('standard')")
    with pg.expect_download(timeout=90000) as d: pg.click('#lockBtn')
    pg.wait_for_timeout(2800)
    check('SEALED stamp appears after success', pg.evaluate("document.getElementById('lockStamp').classList.contains('show')"))
    pg.set_input_files('#lockFileInput',[]); pg.wait_for_timeout(200)
    check('stamp and readiness reset when the file is removed', not pg.evaluate("document.getElementById('lockStamp').classList.contains('show')") and rows()[0]==False)
    pg.click('#clearSessionBtn'); check('clear session resets readiness', rows()==[False,False,False])
    check('no page errors', not pg.errors, str(pg.errors[:2]))
    b.close()
print(sum(res),'/',len(res)); sys.exit(0 if all(res) else 1)
