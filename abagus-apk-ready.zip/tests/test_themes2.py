"""Themes v2: Power levels, theme-reveal transition, card tilt, spotlight, progress line, tap combos, keyboard. Served over local http."""
import os, sys, threading, functools, http.server
from playwright.sync_api import sync_playwright
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ok = bad = 0
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), functools.partial(http.server.SimpleHTTPRequestHandler, directory=ROOT))
srv.RequestHandlerClass.log_message = lambda *a: None
threading.Thread(target=srv.serve_forever, daemon=True).start()
BASE = 'http://127.0.0.1:%d/' % srv.server_address[1]
def check(name, cond, info=''):
    global ok, bad
    if cond: ok += 1; print('PASS', name)
    else: bad += 1; print('FAIL', name, info)
with sync_playwright() as p:
    b = p.chromium.launch(); ctx = b.new_context(viewport={'width': 1280, 'height': 800}); pg = ctx.new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)[:160]))
    pg.add_init_script("try{localStorage.setItem('vault_sound_muted_v1','1');localStorage.setItem('abagus-vibe-motion','full')}catch(e){}")
    pg.goto(BASE + 'index.html'); pg.wait_for_timeout(500)
    # keyboard: T opens the picker, arrows move focus, Enter picks
    pg.keyboard.press('t'); pg.wait_for_timeout(200)
    check('T opens the picker', pg.evaluate("!document.getElementById('vPanel').hidden"))
    check('Power and Extras switches exist', pg.locator('.vp-seg').count() == 5, pg.locator('.vp-seg').count())
    pg.click('.vp-card[data-id="ironman"]'); pg.wait_for_timeout(1200)
    check('theme applied through the reveal', pg.evaluate("document.documentElement.getAttribute('data-vibe')") == 'ironman')
    check('no view transition left running', pg.evaluate("document.getAnimations().length >= 0"))
    # power
    for lvl in ('soft', 'max', 'normal'):
        pg.click('.vp-seg [data-v="%s"]' % lvl); pg.wait_for_timeout(250)
        check('power %s sets the attribute and survives' % lvl, pg.evaluate("document.documentElement.getAttribute('data-vpower')") == lvl and pg.evaluate("localStorage.getItem('abagus-vibe-power')") == lvl)
    pg.click('.vp-seg [data-v="max"]'); pg.wait_for_timeout(200)
    pg.evaluate("document.body.insertAdjacentHTML('beforeend','<div id=\"tt\" class=\"tile\" style=\"position:fixed;left:200px;top:200px;width:320px;height:180px;z-index:50\">card</div><div id=\"tb\" class=\"tile\" style=\"position:fixed;left:560px;top:200px;width:640px;height:180px;z-index:50\">big</div>')"); pg.wait_for_timeout(200)
    check('Max gives the card glow', 'rgb' in pg.evaluate("getComputedStyle(document.getElementById('tt')).boxShadow"))
    pg.keyboard.press('Escape'); pg.wait_for_timeout(100)
    # progress line follows scroll
    pg.mouse.wheel(0, 900); pg.wait_for_timeout(500)
    check('progress line exists and grows with scroll', pg.evaluate("(function(){var e=document.getElementById('vProg');return !!e && e.style.transform!=='scaleX(0)'})()"))
    # tilt on a mouse hover
    pg.mouse.move(200 + 320 * .8, 200 + 180 * .3); pg.wait_for_timeout(250)
    pg.mouse.move(200 + 320 * .85, 200 + 180 * .35); pg.wait_for_timeout(250)
    check('card tilts under the mouse', pg.evaluate("document.getElementById('tt').classList.contains('v-tilt') && getComputedStyle(document.getElementById('tt')).transform !== 'none'"))
    pg.mouse.move(900, 300); pg.wait_for_timeout(250); pg.mouse.move(910, 310); pg.wait_for_timeout(250)
    check('oversized panels never tilt', pg.evaluate("!document.getElementById('tb').classList.contains('v-tilt')"))
    pg.mouse.move(2, 2); pg.wait_for_timeout(1500)  # the tilt eases back to flat (damped), so allow ~1 s
    check('tilt clears when the mouse leaves', pg.evaluate("!document.querySelector('.v-tilt')"))
    # extras off: nothing tilts
    pg.evaluate("localStorage.setItem('abagus-vibe-extras','0')"); pg.reload(); pg.wait_for_timeout(600)
    pg.evaluate("document.body.insertAdjacentHTML('beforeend','<div id=\"tt\" class=\"tile\" style=\"position:fixed;left:200px;top:200px;width:320px;height:180px;z-index:50\">card</div>')"); pg.wait_for_timeout(200)
    pg.mouse.move(200 + 320 * .8, 200 + 180 * .3); pg.wait_for_timeout(250); pg.mouse.move(200 + 320 * .85, 200 + 180 * .3); pg.wait_for_timeout(250)
    check('Extras off: no tilt', pg.evaluate("!document.querySelector('.v-tilt') && document.documentElement.getAttribute('data-vextras')==='off'"))
    pg.evaluate("localStorage.setItem('abagus-vibe-extras','1')"); pg.reload(); pg.wait_for_timeout(600)
    # tap combo does not throw, canvas stays alive
    for i in range(6): pg.mouse.click(600 + i * 6, 400); pg.wait_for_timeout(60)
    pg.wait_for_timeout(400)
    check('combo taps run without errors', not errs, errs)
    # next / prev API and Default restores
    pg.evaluate("AbagusThemes.next()"); pg.wait_for_timeout(1000)
    check('next() moves along the catalogue', pg.evaluate("AbagusThemes.current()") == 'ultron')
    pg.evaluate("AbagusThemes.prev()"); pg.wait_for_timeout(1000)
    check('prev() moves back', pg.evaluate("AbagusThemes.current()") == 'ironman')
    pg.evaluate("AbagusThemes.set('')"); pg.wait_for_timeout(1000)
    check('Default removes progress line, canvases, tilt', pg.evaluate("!document.getElementById('vProg') && !document.getElementById('vBack') && !document.querySelector('.v-tilt')"))
    # phone: no spotlight/tilt work, panel fits
    m = b.new_context(viewport={'width': 390, 'height': 800}, has_touch=True, is_mobile=True); mp = m.new_page(); merrs = []
    mp.on('pageerror', lambda e: merrs.append(str(e)[:160])); mp.goto(BASE + 'index.html'); mp.wait_for_timeout(500)
    mp.evaluate("AbagusThemes.set('thanos')"); mp.wait_for_timeout(1000); mp.click('#dockTheme'); mp.wait_for_timeout(300)
    w = mp.evaluate("document.getElementById('vPanel').getBoundingClientRect().width"); sw = mp.evaluate("document.documentElement.scrollWidth")
    check('phone: panel fits and page does not scroll sideways', w <= 390 and sw <= 391, (w, sw))
    check('phone: no page errors', not merrs, merrs)
    b.close()

# ---- Iron Man: hold to charge, tap blast, touch ring, no errors ----
with sync_playwright() as p2:
    b2 = p2.chromium.launch(); c2 = b2.new_context(viewport={'width': 1280, 'height': 800}); q = c2.new_page(); e2 = []
    q.on('pageerror', lambda e: e2.append(str(e)[:160]))
    q.add_init_script("try{localStorage.setItem('vault_sound_muted_v1','1');localStorage.setItem('abagus-vibe-motion','full');localStorage.setItem('abagus-vibe','ironman')}catch(e){}")
    q.goto(BASE + 'index.html'); q.wait_for_timeout(900)
    check('Iron Man scene draws (canvas present)', q.evaluate("!!document.getElementById('vBack') && AbagusThemes.current()==='ironman'"))
    q.mouse.move(500, 400); q.wait_for_timeout(300)
    q.mouse.down(); q.wait_for_timeout(300)
    check('holding starts the charge', q.evaluate("(function(){var c=document.getElementById('vTop');return !!c})()"))
    q.wait_for_timeout(500); q.mouse.up(); q.wait_for_timeout(400)
    q.mouse.click(700, 300); q.wait_for_timeout(500)
    q.screenshot(path='/tmp/ironman_desktop.png')
    check('hold, release and tap run without errors', not e2, e2)
    m2 = b2.new_context(viewport={'width': 390, 'height': 800}, has_touch=True, is_mobile=True); mq = m2.new_page(); me = []
    mq.on('pageerror', lambda e: me.append(str(e)[:160]))
    mq.add_init_script("try{localStorage.setItem('vault_sound_muted_v1','1');localStorage.setItem('abagus-vibe','ironman')}catch(e){}")
    mq.goto(BASE + 'index.html'); mq.wait_for_timeout(900)
    mq.touchscreen.tap(200, 400); mq.wait_for_timeout(150)
    mq.screenshot(path='/tmp/ironman_mobile_tap.png'); mq.wait_for_timeout(1200)
    mq.screenshot(path='/tmp/ironman_mobile.png')
    check('phone: Iron Man taps run without errors', not me, me)
    check('phone: Theme button sits in the bottom dock', mq.evaluate("(function(){var b=document.getElementById('dockTheme');if(!b)return false;var r=b.getBoundingClientRect();return r.width>0&&r.bottom<=innerHeight})()"))
    b2.close()
print(ok, '/', ok + bad); sys.exit(1 if bad else 0)
