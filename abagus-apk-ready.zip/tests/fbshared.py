"""Shared fake backend for multi-phone tests. One in-memory database (served by the test web server) is used by every
browser context, so several 'phones' can interact live. The stand-in Firestore also MODELS the key access rules of
firestore.rules (who may read, write and delete what) so client behaviour can be tested against them. It is a model,
not the real rules engine: publish firestore.rules and use the Firebase Rules Playground to check the real thing."""
import os, sys, json, threading, functools, http.server, socketserver
sys.path.insert(0, os.path.dirname(__file__))
from harness import CHACHA, ARGON, CORS, sync_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
DB = {'docs': {}, 'users': {}}
class H(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
    def _send(self, obj):
        b = json.dumps(obj).encode(); self.send_response(200); self.send_header('Content-Type', 'application/json'); self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        if self.path == '/__fb/db': return self._send(DB)
        return super().do_GET()
    def do_POST(self):
        n = int(self.headers.get('Content-Length', 0)); body = json.loads(self.rfile.read(n) or b'null')
        if self.path == '/__fb/doc':
            if body['data'] is None: DB['docs'].pop(body['path'], None)
            else: DB['docs'][body['path']] = body['data']
        elif self.path == '/__fb/user': DB['users'][body['email']] = body['rec']
        self._send({'ok': True})
httpd = socketserver.ThreadingTCPServer(('127.0.0.1', 0), functools.partial(H, directory=ROOT))
httpd.daemon_threads = True
PORT = httpd.server_address[1]
threading.Thread(target=httpd.serve_forever, daemon=True).start()
URL = f'http://localhost:{PORT}/index.html#vault'
GROUPS_URL = f'http://localhost:{PORT}/groups.html'

XHR = "function xhr(m,u,b){const x=new XMLHttpRequest();x.open(m,u,false);x.setRequestHeader('Content-Type','application/json');x.send(b?JSON.stringify(b):null);return JSON.parse(x.responseText||'null')}"
STUBS = {
'firebase-app.js': "export const initializeApp=(c)=>({c});",
'firebase-auth.js': XHR + """
const st=(window.__fb=window.__fb||{cur:null,curRec:null,ls:[]});
const mk=(rec)=>({uid:rec.uid,email:rec.email,get displayName(){return rec.displayName},photoURL:null,providerData:[{providerId:rec.google?'google.com':'password'}],getIdToken:async()=>'t'});
const notify=()=>st.ls.forEach(f=>f(st.cur));
const err=(code)=>Object.assign(new Error(code),{code});
try{ const sv=JSON.parse(localStorage.getItem('fbstub-email')||'null'); if(sv){ const rec=xhr('GET','/__fb/db').users[sv]; if(rec){ st.curRec=rec; st.cur=mk(rec) } } }catch(e){}
export const getAuth=()=>({get currentUser(){return st.cur}});
export const onAuthStateChanged=(a,cb)=>{st.ls.push(cb);setTimeout(()=>cb(st.cur),0);return()=>{}};
export async function createUserWithEmailAndPassword(a,email,pw){
  const us=xhr('GET','/__fb/db').users; if(us[email]) throw err('auth/email-already-in-use'); if(pw.length<6) throw err('auth/weak-password');
  const rec={uid:'uid'+(Object.keys(us).length+1),email,pw,displayName:null}; xhr('POST','/__fb/user',{email,rec}); st.curRec=rec; st.cur=mk(rec); localStorage.setItem('fbstub-email',JSON.stringify(email)); notify(); return{user:st.cur}}
export async function signInWithEmailAndPassword(a,email,pw){
  const rec=xhr('GET','/__fb/db').users[email]; if(!rec||rec.pw!==pw) throw err('auth/invalid-credential'); st.curRec=rec; st.cur=mk(rec); localStorage.setItem('fbstub-email',JSON.stringify(email)); notify(); return{user:st.cur}}
export async function signOut(){st.cur=null;st.curRec=null;localStorage.removeItem('fbstub-email');notify()}
export async function updateProfile(user,p){st.curRec.displayName=p.displayName; xhr('POST','/__fb/user',{email:st.curRec.email,rec:st.curRec})}
export class GoogleAuthProvider{addScope(){}setCustomParameters(){}static credentialFromResult(){return null}}
export const signInWithPopup=async()=>{
  if(!localStorage.getItem('fbstub-google')) throw err('auth/popup-closed-by-user');          // tests opt in to a pretend Google account
  const flag=localStorage.getItem('fbstub-google'), email=(flag&&flag.includes('@'))?flag:'person@gmail.com', us=xhr('GET','/__fb/db').users; let rec=us[email];
  if(!rec){ rec={uid:'guid'+(Object.keys(us).length+1),email,pw:'',displayName:'Google Person',google:true}; xhr('POST','/__fb/user',{email,rec}) }
  st.curRec=rec; st.cur=mk(rec); localStorage.setItem('fbstub-email',JSON.stringify(email)); notify(); return{user:st.cur}};
export const reauthenticateWithPopup=signInWithPopup, signInWithRedirect=signInWithPopup, getRedirectResult=async()=>null;
""",
'firebase-firestore.js': XHR + """
const st=(window.__fb=window.__fb||{cur:null,curRec:null,ls:[]});
const err=(code)=>Object.assign(new Error(code),{code});
export class Bytes{constructor(a){this.a=Array.from(a)} static fromUint8Array(u){return new Bytes(u)} toUint8Array(){return Uint8Array.from(this.a)} toJSON(){return{__bytes:this.a}}}
const revive=(v)=>{ if(Array.isArray(v)) return v.map(revive); if(v&&typeof v==='object'){ if(v.__bytes) return new Bytes(v.__bytes); const o={}; for(const k in v) o[k]=revive(v[k]); return o } return v };
const docs=()=>xhr('GET','/__fb/db').docs;
const uid=()=>st.cur&&st.cur.uid;
const seg=(p)=>p.split('/');
const memOf=(D,g,u)=>D['groups/'+g+'/members/'+u];
const isMember=(D,g)=>!!uid()&&!!memOf(D,g,uid());
const roleIn=(D,g,rs)=>isMember(D,g)&&rs.includes(memOf(D,g,uid()).role);
const isAdmin=(D,g)=>roleIn(D,g,['owner','admin']), isOwner=(D,g)=>roleIn(D,g,['owner']);
const gset=(D,g)=>((D['groups/'+g]||{}).settings)||{};
const clean=(D,g)=>isMember(D,g)&&memOf(D,g,uid()).flagged!==true;
const frozen=(D,g)=>((D['groups/'+g]||{}).frozen)===true;
const live=(D,g)=>clean(D,g)&&(!frozen(D,g)||isOwner(D,g));
const canWrite=(D,g)=>(isAdmin(D,g)||(clean(D,g)&&gset(D,g).memberUpload===true))&&(!frozen(D,g)||isOwner(D,g));
const changedKeys=(nd,old)=>Object.keys(Object.assign({},old,nd)).filter(k=>JSON.stringify(nd[k])!==JSON.stringify(old[k]));
function validSettings(x){ if(x==null) return true; const ok=['memberUpload','vaultShare','watermark','idleMin']; if(typeof x!=='object'||Object.keys(x).some(k=>!ok.includes(k))) return false;
  return (!('memberUpload' in x)||typeof x.memberUpload==='boolean')&&(!('vaultShare' in x)||typeof x.vaultShare==='boolean')&&(!('watermark' in x)||['off','corner','full'].includes(x.watermark))&&(!('idleMin' in x)||[1,3,10].includes(x.idleMin)) }
function can(op,path,nd,old,D){ const s=seg(path);
  if(s[0]==='users'){ return !!uid()&&s[1]===uid() }
  if(s[0]==='invites'){ if(op==='get') return !!uid(); if(op==='list') return false; if(op==='create') return isAdmin(D,nd.gid)&&(nd.maxUses===undefined||(Number.isInteger(nd.maxUses)&&nd.maxUses>=1&&nd.maxUses<=1000));
    if(op==='update'){ if(!old) return false; const ch=changedKeys(nd,old); if(isAdmin(D,old.gid)&&ch.every(k=>k==='active')) return true;
      return old.active===true&&(old.maxUses||0)>0&&ch.every(k=>['uses','active'].includes(k))&&nd.uses===(old.uses||0)+1&&nd.uses<=old.maxUses&&nd.active===(nd.uses<old.maxUses) }
    return !!old&&isAdmin(D,old.gid) }
  if(s[0]==='publicGroups') return op==='read'&&!!uid();   // server-written directory summary: signed-in read, never a client write
  if(s[0]!=='groups') return false;
  const g=s[1];
  if(s.length===2){ if(op==='read') return isMember(D,g); if(op==='create') return !!uid()&&nd.ownerUid===uid(); if(op==='update'){ const ck=changedKeys(nd,old); return isAdmin(D,g)&&ck.every(k=>['name','policy','settings','descEnc','avatar','frozen','discoverable','publicDesc'].includes(k))&&(!ck.includes('frozen')&&!ck.includes('discoverable')||isOwner(D,g))&&(!('discoverable' in nd)||typeof nd.discoverable==='boolean')&&(!('publicDesc' in nd)||(typeof nd.publicDesc==='string'&&nd.publicDesc.length<=140))&&validSettings(nd.settings) } if(op==='delete') return isOwner(D,g) }
  const sub=s[2];
  if(sub==='members'){ const t=s[3];
    if(op==='read') return isMember(D,g);
    if(op==='create'){ if(t!==uid()) return false; if(nd.flagged!==false||nd.violations!==0) return false;
      if(nd.role==='owner') return !!D['groups/'+g]&&D['groups/'+g].ownerUid===uid(); const inv=D['invites/'+nd.inviteId]; return nd.role==='member'&&!!inv&&inv.gid===g&&inv.active===true&&inv.expiresAt>Date.now()&&((inv.maxUses||0)===0||(inv.uses||0)<inv.maxUses)&&!frozen(D,g) }
    if(op==='update'){ const ch=changedKeys(nd,old);
      if(t===uid()){ if(ch.every(k=>['flagged','violations','lastViolation'].includes(k))&&nd.flagged===true) return true; return ch.every(k=>['wrappedKey','name','avatar','avatarV'].includes(k)) }
      if(old.role==='owner') return false;
      if(isAdmin(D,g)&&ch.every(k=>k==='flagged')) return true;
      return isOwner(D,g)&&ch.every(k=>k==='role')&&['member','admin'].includes(nd.role) }
    if(op==='delete'){ if(t===uid()&&old.role!=='owner'&&old.flagged!==true) return true; if(isOwner(D,g)) return true; return isAdmin(D,g)&&t!==uid()&&old.role==='member' } }
  if(sub==='files'){
    if(s.length===4){ if(op==='read') return isMember(D,g); if(op==='update') return false;
      if(op==='create'){ if(!canWrite(D,g)||nd.uploadedBy!==uid()) return false; if(!['image','video','vault'].includes(nd.kind)) return false; if(nd.kind==='vault'&&gset(D,g).vaultShare===false) return false; return nd.size<=125829120&&nd.chunks>=1&&nd.chunks<=200 }
      return isAdmin(D,g)||(isMember(D,g)&&old&&old.uploadedBy===uid()) }
    if(s[4]==='chunks'){ if(op==='read') return live(D,g); if(op==='create') return canWrite(D,g);
      const f=D['groups/'+g+'/files/'+s[3]]; return isAdmin(D,g)||(isMember(D,g)&&!!f&&f.uploadedBy===uid()) } }
  if(sub==='thumbs'){ if(op==='read') return live(D,g); if(op==='create') return canWrite(D,g);
    const f=D['groups/'+g+'/files/'+s[3]]; return isAdmin(D,g)||(isMember(D,g)&&!!f&&f.uploadedBy===uid()) }
  if(sub==='invites') return isAdmin(D,g);
  if(sub==='log'){ if(op==='read'||op==='delete') return isAdmin(D,g); return isMember(D,g)&&(isAdmin(D,g)||nd.type==='violation') }
  return false }
export const getFirestore=()=>({});
export const doc=(db,...p)=>({p:p.join('/')});
export const collection=(db,...p)=>({col:p.join('/')});
export const orderBy=(f,d)=>({f,d:d||'asc'});
export const query=(c,o)=>Object.assign({},c,{ord:o});
export async function getDoc(r){ const D=docs(); if(!can(r.p.startsWith('invites/')?'get':'read',r.p,null,D[r.p],D)) throw err('permission-denied'); const d=D[r.p]; return{exists:()=>!!d,data:()=>revive(JSON.parse(JSON.stringify(d)))}}
export async function setDoc(r,data,o){ const D=docs(), old=D[r.p]; const nd=Object.assign({},o&&o.merge&&old?old:{},JSON.parse(JSON.stringify(data)));
  if(!can(old?'update':'create',r.p,revive(nd),revive(old||{}),D)) throw err('permission-denied'); xhr('POST','/__fb/doc',{path:r.p,data:nd}) }
export async function deleteDoc(r){ const D=docs(), old=D[r.p]; if(!can('delete',r.p,null,old||{},D)) throw err('permission-denied'); xhr('POST','/__fb/doc',{path:r.p,data:null}) }
export async function getDocs(q){ const D=docs(); if(!can(q.col.startsWith('invites')?'list':'read',q.col+'/_',null,null,D)) throw err('permission-denied');
  let rows=Object.keys(D).filter(k=>k.startsWith(q.col+'/')&&seg(k).length===seg(q.col).length+1).map(k=>({id:seg(k).pop(),d:D[k]}));
  if(q.ord){ rows.sort((a,b)=>{const x=a.d[q.ord.f],y=b.d[q.ord.f]; return (x>y?1:x<y?-1:0)*(q.ord.d==='desc'?-1:1)}) }
  return{docs:rows.map(r=>({id:r.id,data:()=>revive(JSON.parse(JSON.stringify(r.d)))}))}}
"""}

def new_page(b, prf=True):
    ctx = b.new_context(viewport={'width': 1100, 'height': 900}, service_workers='block')
    ctx.add_init_script("try{localStorage.setItem('vault_sound_muted_v1','1')}catch(e){}")
    ctx.route('**/@noble/ciphers@1.0.0/chacha.js', lambda r: r.fulfill(status=200, headers=CORS, body=CHACHA))
    ctx.route('**/@noble/hashes@1.5.0/argon2.js', lambda r: r.fulfill(status=200, headers=CORS, body=ARGON))
    ctx.route('https://www.gstatic.com/firebasejs/**', lambda r: r.fulfill(status=200, content_type='text/javascript', headers=CORS, body=STUBS.get(r.request.url.split('/')[-1], '')))
    pg = ctx.new_page(); pg.errors = []
    pg.on('pageerror', lambda e: pg.errors.append(str(e)[:200]))
    pg.on('dialog', lambda d: d.accept())
    cdp = ctx.new_cdp_session(pg); cdp.send('WebAuthn.enable')
    cdp.send('WebAuthn.addVirtualAuthenticator', {'options': {'protocol': 'ctap2', 'transport': 'internal', 'hasResidentKey': True,
        'hasUserVerification': True, 'isUserVerified': True, 'automaticPresenceSimulation': True, 'hasPrf': prf}})
    pg.goto(URL); pg.wait_for_function('()=>window.__authReady===true', timeout=15000); pg.wait_for_timeout(400)
    return ctx, pg
