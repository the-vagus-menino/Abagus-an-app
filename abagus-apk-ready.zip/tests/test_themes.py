"""Character themes: 34 looks, picker, persistence, forced light/dark, tap effects, every page, no page errors. Served over a local http port."""
import os, sys, threading, functools, http.server
from playwright.sync_api import sync_playwright
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ok = bad = 0
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), functools.partial(http.server.SimpleHTTPRequestHandler, directory=ROOT))
srv.RequestHandlerClass.log_message = lambda *a: None
threading.Thread(target=srv.serve_forever, daemon=True).start()
BASE = 'http://127.0.0.1:%d/' % srv.server_address[1]   # localStorage is only reliable over http, like the real site
def check(name, cond, info=''):
    global ok, bad
    if cond: ok += 1; print('PASS', name)
    else: bad += 1; print('FAIL', name, info)
with sync_playwright() as p:
    b = p.chromium.launch(); ctx = b.new_context(viewport={'width': 1280, 'height': 800}); pg = ctx.new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)[:160]))
    pg.add_init_script("try{localStorage.setItem('vault_sound_muted_v1','1')}catch(e){}")
    pg.goto(BASE + 'index.html'); pg.wait_for_timeout(500)
    ids = pg.evaluate("AbagusThemes.list.map(t=>t.id)")
    check('34 themes in the catalogue', len(ids) == 34, len(ids))
    pg.click('#vBtn'); check('picker lists every theme plus Default', pg.locator('.vp-card').count() == 35)
    pg.click('.vp-card[data-id="ironman"]'); pg.wait_for_timeout(300)
    check('choosing a theme sets it and its mode', pg.evaluate("document.documentElement.getAttribute('data-vibe')+document.documentElement.getAttribute('data-theme')") == 'ironmandark')
    check('background canvas is mounted', pg.evaluate("!!document.getElementById('vBack')"))
    pg.evaluate("document.documentElement.setAttribute('data-theme','light')"); pg.wait_for_timeout(150)
    check('another control cannot flip a theme to the wrong mode', pg.evaluate("document.documentElement.getAttribute('data-theme')") == 'dark')
    pg.reload(); pg.wait_for_load_state('load'); pg.wait_for_timeout(600)
    v = pg.evaluate("[document.documentElement.getAttribute('data-vibe'), localStorage.getItem('abagus-vibe'), location.href]"); check('theme survives a reload', v[0] == 'ironman', v)
    for page in ['index.html', 'groups.html', 'dashboard.html']:
        pg.goto(BASE + page); pg.wait_for_timeout(1500)
        for i in ids:
            pg.evaluate("id=>AbagusThemes.set(id)", i); pg.wait_for_timeout(60); pg.evaluate("document.dispatchEvent(new PointerEvent('pointerdown',{clientX:400,clientY:300,button:0,bubbles:true}))")
    check('all themes x pages x taps: no page errors', not errs, errs)
    pg.evaluate("AbagusThemes.set('')"); pg.wait_for_timeout(200)
    check('Default removes every layer', pg.evaluate("[document.documentElement.hasAttribute('data-vibe'),!!document.getElementById('vBack'),localStorage.getItem('abagus-vibe')]") == [False, False, None])
    b.close()
print(ok, '/', ok + bad); sys.exit(1 if bad else 0)
