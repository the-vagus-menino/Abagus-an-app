"""Mobile-number accounts, end to end in headless Chromium against an in-memory stand-in for Firebase
(the real index.html Firebase module runs unchanged; only the gstatic SDK files are replaced).
Run: python tests/test_accounts.py"""
import os, sys, json, threading, functools, http.server, socketserver
sys.path.insert(0, os.path.dirname(__file__))
from harness import CHACHA, ARGON, CORS, sync_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
res = []
def check(n, c, e=''): res.append(bool(c)); print('PASS' if c else 'FAIL', n, e)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
httpd = socketserver.TCPServer(('127.0.0.1', 0), functools.partial(Q, directory=ROOT))
PORT = httpd.server_address[1]
threading.Thread(target=httpd.serve_forever, daemon=True).start()
URL = f'http://localhost:{PORT}/index.html#vault'

STUBS = {
'firebase-app.js': "export const initializeApp=(c)=>({c});",
'firebase-auth.js': """
const st=(window.__fb=window.__fb||{users:{},cur:null,ls:[],docs:{},fsFail:false});
const mk=(u)=>({uid:u.uid,email:u.email,get displayName(){return u.displayName},photoURL:null,providerData:[{providerId:'password'}],getIdToken:async()=>'t'});
const notify=()=>st.ls.forEach(f=>f(st.cur));
const err=(code)=>Object.assign(new Error(code),{code});
export const getAuth=()=>({get currentUser(){return st.cur}});
export const onAuthStateChanged=(a,cb)=>{st.ls.push(cb);setTimeout(()=>cb(st.cur),0);return()=>{}};
export async function createUserWithEmailAndPassword(a,email,pw){
  if(st.users[email]) throw err('auth/email-already-in-use'); if(pw.length<6) throw err('auth/weak-password');
  st.users[email]={uid:'uid'+(Object.keys(st.users).length+1),email,pw,displayName:null}; st.cur=mk(st.users[email]); notify(); return{user:st.cur}}
export async function signInWithEmailAndPassword(a,email,pw){
  const u=st.users[email]; if(!u||u.pw!==pw) throw err('auth/invalid-credential'); st.cur=mk(u); notify(); return{user:st.cur}}
export async function signOut(){st.cur=null;notify()}
export async function updateProfile(user,p){st.users[user.email].displayName=p.displayName}
export class GoogleAuthProvider{addScope(){}setCustomParameters(){}static credentialFromResult(){return null}}
export const signInWithPopup=async()=>{throw err('auth/popup-closed-by-user')};
export const reauthenticateWithPopup=signInWithPopup, signInWithRedirect=signInWithPopup, getRedirectResult=async()=>null;
""",
'firebase-firestore.js': """
const st=(window.__fb=window.__fb||{users:{},cur:null,ls:[],docs:{},fsFail:false});
const err=(code)=>Object.assign(new Error(code),{code});
export const getFirestore=()=>({});
export const doc=(db,c,id)=>({p:c+'/'+id});
export async function getDoc(r){ if(st.fsFail) throw err('permission-denied'); const d=st.docs[r.p]; return{exists:()=>!!d,data:()=>JSON.parse(JSON.stringify(d))}}
export async function setDoc(r,data,o){ if(st.fsFail) throw err('permission-denied'); st.docs[r.p]=Object.assign({},o&&o.merge?st.docs[r.p]:{},JSON.parse(JSON.stringify(data)))}
"""}

def new_page(b, state=None, prf=True):
    ctx = b.new_context(viewport={'width': 1100, 'height': 900}, service_workers='block')
    ctx.add_init_script("try{localStorage.setItem('vault_sound_muted_v1','1')}catch(e){}")
    if state: ctx.add_init_script('window.__fb=' + json.dumps(state))
    ctx.route('**/@noble/ciphers@1.0.0/chacha.js', lambda r: r.fulfill(status=200, headers=CORS, body=CHACHA))
    ctx.route('**/@noble/hashes@1.5.0/argon2.js', lambda r: r.fulfill(status=200, headers=CORS, body=ARGON))
    def sdk(route):
        name = route.request.url.split('/')[-1]
        route.fulfill(status=200, content_type='text/javascript', headers=CORS, body=STUBS.get(name, ''))
    ctx.route('https://www.gstatic.com/firebasejs/**', sdk)
    pg = ctx.new_page(); pg.errors = []
    pg.on('pageerror', lambda e: pg.errors.append(str(e)[:200]))
    pg.on('dialog', lambda d: d.accept())
    cdp = ctx.new_cdp_session(pg); cdp.send('WebAuthn.enable')
    cdp.send('WebAuthn.addVirtualAuthenticator', {'options': {'protocol': 'ctap2', 'transport': 'internal', 'hasResidentKey': True,
        'hasUserVerification': True, 'isUserVerified': True, 'automaticPresenceSimulation': True, 'hasPrf': prf}})
    pg.goto(URL); pg.wait_for_function('()=>window.__authReady===true', timeout=15000); pg.wait_for_timeout(500)
    return ctx, pg

def fb(pg): return pg.evaluate('JSON.parse(JSON.stringify(window.__fb))')
def fill_up(pg, user, cc, num, pw, pw2=None):
    pg.click('#acdTabUp'); pg.fill('#acdUser', user); pg.fill('#acdCc', cc); pg.fill('#acdNum', num)
    pg.fill('#acdPass', pw); pg.fill('#acdPass2', pw if pw2 is None else pw2)
def submit(pg): pg.click('#acdSubmit'); pg.wait_for_timeout(900)


import re as _re
def rules_ok(doc, email):
    """Mirror of validProfile()/validMethods() in firestore.rules, so the app and the rules cannot drift apart."""
    allowed = {'username','mobile','provider','createdAt','updatedAt','faceAuth','authMethods','cloudKey'}
    if not set(doc) <= allowed: return False
    if 'username' in doc and not (isinstance(doc['username'], str) and len(doc['username']) <= 60): return False
    if 'mobile' in doc:
        m = doc['mobile']
        if not (isinstance(m, str) and _re.fullmatch(r'\+[0-9]{8,15}', m) and email == 'm' + m[1:] + '@abagus-bd19f.firebaseapp.com'): return False
    if 'provider' in doc and doc['provider'] != 'mobile': return False
    for k in ('createdAt', 'updatedAt'):
        if k in doc and not (isinstance(doc[k], str) and len(doc[k]) <= 40): return False
    if 'faceAuth' in doc and not isinstance(doc['faceAuth'], bool): return False
    if 'authMethods' in doc:
        a = doc['authMethods']
        if not (isinstance(a, dict) and set(a) <= {'password','anskarKey'}): return False
        if 'password' in a and not isinstance(a['password'], bool): return False
        k = a.get('anskarKey')
        if k is not None:
            if not (isinstance(k, dict) and set(k) <= {'credentialId','createdAt'} and isinstance(k.get('credentialId'), str) and 0 < len(k['credentialId']) <= 1400): return False
            if 'createdAt' in k and not (isinstance(k['createdAt'], str) and len(k['createdAt']) <= 40): return False
    return True

PW = 'correct horse battery 42'
with sync_playwright() as p:
    b = p.chromium.launch()
    ctx, pg = new_page(b)
    check('signed-out header offers mobile sign-in', pg.is_visible('#phoneSignInBtn'))
    pg.click('#phoneSignInBtn')
    check('dialog opens on Create account', pg.is_visible('#acctDialog') and pg.is_visible('#acdUserRow'))

    # validation
    fill_up(pg, 'Anu', '+91', '12', PW); submit(pg)
    check('too-short number is refused', 'valid mobile number' in pg.inner_text('#acdMsg') and not fb(pg)['users'])
    fill_up(pg, 'Anu Kumar', '+91', '9178712507', 'short'); submit(pg)
    check('short password refused', 'at least 10' in pg.inner_text('#acdMsg'))
    fill_up(pg, 'Anu Kumar', '+91', '9178712507', PW, 'different one 99'); submit(pg)
    check('mismatched passwords refused', 'do not match' in pg.inner_text('#acdMsg'))
    fill_up(pg, 'a<b>', '+91', '9178712507', PW); submit(pg)
    check('odd username refused', 'username' in pg.inner_text('#acdMsg').lower())

    # create (typed with a trunk zero)
    fill_up(pg, 'Anu Kumar', '+91', '09178712507', PW); submit(pg)
    s = fb(pg); email = 'm919178712507@abagus-bd19f.firebaseapp.com'
    check('account created under the normalised number ID', list(s['users']) == [email], str(list(s['users'])))
    check('username attached to the account', s['users'][email]['displayName'] == 'Anu Kumar')
    check('header now shows the account, not the sign-in buttons', pg.is_visible('#acctChip') and not pg.is_visible('#phoneSignInBtn') and 'Anu Kumar' in pg.inner_text('#acctName'))
    check('number is masked in the header', '9178712507' not in pg.inner_text('#acctChip') and '+91' in pg.inner_text('#acctEmail'))
    check('Google-only dashboard link hidden for mobile accounts', not pg.is_visible('#dashChipBtn'))
    prof = s['docs'].get('users/' + s['users'][email]['uid'])
    check('profile record saved with the right fields', prof and prof['username'] == 'Anu Kumar' and prof['mobile'] == '+919178712507' and prof['faceAuth'] is False and prof['authMethods']['password'] is True and prof['authMethods']['anskarKey'] is None, str(prof))
    check('no password or secret in the profile', 'pw' not in json.dumps(prof) and PW not in json.dumps(s['docs']))

    # one account per mobile number, however it is typed
    pg.click('#acdOut') if pg.is_visible('#acdOut') else None
    pg.evaluate("document.getElementById('signOutBtn').click()"); pg.wait_for_timeout(600)
    for cc, num in [('+91', '9178712507'), ('91', '+91 91787 12507'), ('+91', '(0)9178712507')]:
        pg.click('#phoneSignInBtn'); fill_up(pg, 'Someone Else', cc, num, PW); submit(pg)
        check(f'second account for the same number refused ({cc} {num})', len(fb(pg)['users']) == 1 and 'already has an account' in pg.inner_text('#acdMsg'), pg.inner_text('#acdMsg')[:70])
        check('...and the dialog switches to Sign in', pg.get_attribute('#acdTabIn', 'aria-selected') == 'true' and not pg.is_visible('#acdUserRow'))
        pg.evaluate("document.getElementById('acctDialog').close()")

    # sign in
    pg.click('#phoneSignInBtn'); pg.click('#acdTabIn'); pg.fill('#acdCc', '+91'); pg.fill('#acdNum', '9178712507'); pg.fill('#acdPass', 'wrong password 123'); submit(pg)
    check('wrong password refused', 'not right' in pg.inner_text('#acdMsg') and not pg.is_visible('#acctChip'))
    pg.fill('#acdPass', PW); submit(pg)
    check('sign in with number + password works', pg.is_visible('#acctChip') and 'Anu Kumar' in pg.inner_text('#acctName'))

    # AnskarKey linked to the account
    pg.click('#acctChip .acct-id'); pg.wait_for_timeout(300)
    check('account dialog shows the signed-in view', pg.is_visible('#acdSigned') and pg.is_visible('#acdAkBtn'))
    pg.click('#acdAkBtn'); pg.wait_for_function("()=>/Linked/.test(document.getElementById('acdAkChip').textContent)", timeout=20000)
    s = fb(pg); uid = s['users'][email]['uid']; prof = s['docs']['users/' + uid]
    local = pg.evaluate("JSON.parse(localStorage.getItem('abagus-anskarkey-v1')).credentialId")
    check('AnskarKey credential id saved on the account', prof['authMethods']['anskarKey']['credentialId'] == local and prof['faceAuth'] is True)
    check('every record the app wrote passes the Firestore rules (mirrored)', all(rules_ok(d, email) for d in s['docs'].values()) and len(s['docs']) == 1, str(s['docs'])[:120])
    check('a record claiming someone else\'s number would be refused', not rules_ok(dict(prof, mobile='+919999999999'), email) and not rules_ok(dict(prof, authMethods={'password': True, 'x': 1}), email) and not rules_ok(dict(prof, provider='admin'), email))
    check('profile still holds only allowed fields', set(prof) <= {'username','mobile','provider','createdAt','updatedAt','faceAuth','authMethods','cloudKey'}, str(sorted(prof)))
    state = dict(fb(pg), cur=None, ls=[])   # another phone: same server data, nobody signed in, no local passkey
    ctx.close()

    # another phone: same account, passkey not set up there yet
    ctx2, pg2 = new_page(b, state)
    check('new device starts without AnskarKey', pg2.evaluate("localStorage.getItem('abagus-anskarkey-v1')") is None)
    pg2.click('#phoneSignInBtn'); pg2.click('#acdTabIn'); pg2.fill('#acdCc', '+91'); pg2.fill('#acdNum', '9178712507'); pg2.fill('#acdPass', PW); submit(pg2); pg2.wait_for_timeout(800)
    got = pg2.evaluate("(JSON.parse(localStorage.getItem('abagus-anskarkey-v1'))||{}).credentialId")
    check('signing in on a new device brings the AnskarKey over', got == local)
    pg2.click('#methodAnskar'); pg2.wait_for_timeout(300)
    check('encrypt panel on the new device says AnskarKey is ready', 'Ready' in pg2.inner_text('#lockAkChip'))
    # Forget here, sign out and in again: must not come back by itself
    pg2.evaluate("localStorage.setItem('abagus-anskarkey-skip','1'); localStorage.removeItem('abagus-anskarkey-v1')")
    pg2.evaluate("document.getElementById('signOutBtn').click()"); pg2.wait_for_timeout(500)
    pg2.click('#phoneSignInBtn'); pg2.click('#acdTabIn'); pg2.fill('#acdNum', '9178712507'); pg2.fill('#acdPass', PW); submit(pg2); pg2.wait_for_timeout(600)
    check('a passkey the user chose to forget is not re-added on sign-in', pg2.evaluate("localStorage.getItem('abagus-anskarkey-v1')") is None)
    ctx2.close()

    # profile storage unavailable: sign-in must still work and say why
    ctx3, pg3 = new_page(b, {'users': state['users'], 'cur': None, 'ls': [], 'docs': {}, 'fsFail': True})
    pg3.click('#phoneSignInBtn'); pg3.click('#acdTabIn'); pg3.fill('#acdNum', '9178712507'); pg3.fill('#acdPass', PW); submit(pg3)
    pg3.click('#acctChip .acct-id'); pg3.wait_for_timeout(400)
    check('sign-in works even if Firestore is not set up', pg3.is_visible('#acctChip'))
    check('the dialog explains the profile could not be saved', pg3.is_visible('#acdProfileNote') and 'firestore.rules' in pg3.inner_text('#acdProfileNote'))
    check('no uncaught page errors', not (pg.errors + pg2.errors + pg3.errors), str((pg.errors + pg2.errors + pg3.errors)[:2]))
    ctx3.close(); b.close()
print(f'{sum(res)}/{len(res)} passed'); sys.exit(0 if all(res) else 1)
