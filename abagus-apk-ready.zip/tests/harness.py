import base64, hashlib, os, json
from playwright.sync_api import sync_playwright

# Test doubles for the two CDN libraries (sandbox is offline). They only need to be deterministic and
# API-compatible: the point is to exercise the app's own plumbing for all 3 layers + the Argon2 branch.
CHACHA = """
export function xchacha20poly1305(key, nonce24, aad){
  const iv = nonce24.slice(0,12);
  const k = crypto.subtle.importKey('raw', key, 'AES-GCM', false, ['encrypt','decrypt']);
  return {
    encrypt: async (pt)=>new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:aad||new Uint8Array(0)}, await k, pt)),
    decrypt: async (ct)=>new Uint8Array(await crypto.subtle.decrypt({name:'AES-GCM',iv,additionalData:aad||new Uint8Array(0)}, await k, ct))
  };
}"""
ARGON = """
export function argon2id(pw, salt, o){
  const out = new Uint8Array(o.dkLen); let a = 0x811c9dc5 ^ (o.m|0) ^ ((o.t|0)<<8);
  const mix = (b)=>{ a ^= b; a = Math.imul(a, 0x01000193) >>> 0; a ^= a >>> 13; a = Math.imul(a, 0x5bd1e995) >>> 0; };
  for (const b of pw) mix(b); for (const b of salt) mix(b);
  for (let i=0;i<out.length;i++){ mix(i); out[i] = a & 255; }
  return out;
}"""
CORS={'access-control-allow-origin':'*','content-type':'application/javascript'}

def setup(browser, stubs=True):
    ctx = browser.new_context(viewport={'width':1280,'height':900}, accept_downloads=True)
    ctx.add_init_script("delete window.showSaveFilePicker; try{localStorage.setItem('vault_sound_muted_v1','1')}catch(e){}")
    if stubs:
        ctx.route('**/@noble/ciphers@1.0.0/chacha.js', lambda r: r.fulfill(status=200, headers=CORS, body=CHACHA))
        ctx.route('**/@noble/hashes@1.5.0/argon2.js', lambda r: r.fulfill(status=200, headers=CORS, body=ARGON))
    pg = ctx.new_page(); pg.errors=[]
    pg.on('pageerror', lambda e: pg.errors.append(str(e)[:200]))
    return ctx, pg

def open_page(pg, path, view='vault'):
    # The app is split into Home / Vault / Security / Learn views; the encrypt tool lives in #vault.
    pg.goto('file://'+path+('#'+view if view else '')); pg.wait_for_timeout(500)

def encrypt(pg, files, pw, layers='triple', tier=None, keyfile=None, timeout=90000):
    pg.set_input_files('#lockFileInput', [{'name':n,'mimeType':'application/octet-stream','buffer':b} for n,b in files])
    if keyfile: pg.set_input_files('#lockKeyfileInput', {'name':keyfile[0],'mimeType':'application/octet-stream','buffer':keyfile[1]})
    pg.fill('#lockPassword', pw); pg.fill('#lockPasswordConfirm', pw)
    pg.evaluate("v=>{const s=document.getElementById('cascadeMode'); s.value=v; s.dispatchEvent(new Event('change'))}", layers)
    if tier: pg.evaluate("t=>setSecurityLevel(t)", tier)
    with pg.expect_download(timeout=timeout) as d:
        pg.click('#lockBtn')
    p = d.value.path(); name, raw = d.value.suggested_filename, open(p,'rb').read()
    if raw[:8] == b'\x89PNG\r\n\x1a\n':
        # Output is a picture carrier; unwrap it to the raw sealed payload (as the app itself does on decrypt).
        pg.last_png = (name, raw)
        b64 = base64.b64encode(raw).decode()
        out = pg.evaluate("""async b64 => { const u = Uint8Array.from(atob(b64), c => c.charCodeAt(0));
          const r = await AbagusCarrier.extract(new File([u], 'x.png')); let s=''; for (let i=0;i<r.length;i+=32768) s += String.fromCharCode.apply(null, r.subarray(i,i+32768)); return btoa(s); }""", b64)
        return name, base64.b64decode(out)
    return name, raw

def decrypt(pg, locked, pw, name='x.locked', keyfile=None, expected=None, timeout=90000):
    pg.click('#tabUnlockBtn'); pg.wait_for_timeout(200)
    pg.set_input_files('#unlockFileInput', {'name':name,'mimeType':'application/octet-stream','buffer':locked})
    if keyfile: pg.set_input_files('#unlockKeyfileInput', {'name':keyfile[0],'mimeType':'application/octet-stream','buffer':keyfile[1]})
    pg.fill('#unlockPassword', pw)
    if expected is not None: pg.fill('#expectedChecksum', expected)
    pg.click('#unlockBtn')
    pg.wait_for_function("()=>{const a=document.getElementById('previewArea');const m=document.getElementById('unlockMsg');return (a&&!a.classList.contains('hidden'))||(m&&/fail|too many|choose|enter/i.test(m.textContent))}", timeout=timeout)
    ok = pg.evaluate("()=>!document.getElementById('previewArea').classList.contains('hidden')")
    if not ok: return None, pg.inner_text('#unlockMsg')
    n = pg.evaluate("()=>(window.__recoveredEntries||[]).length")
    out=[]
    for k in range(n):
        with pg.expect_download(timeout=30000) as d:
            if n==1 and pg.is_visible('#downloadBtn'): pg.click('#downloadBtn')
            else: pg.locator('#previewContent button').nth(k).click()
        out.append((d.value.suggested_filename, open(d.value.path(),'rb').read()))
    return out, pg.inner_text('#unlockMsg')
