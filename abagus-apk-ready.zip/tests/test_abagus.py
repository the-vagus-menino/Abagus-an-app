"""Tests for the always-on Abagusment layer (element-number code for text), in real Chromium.
Run: python tests/test_abagus.py     (CDN cipher libraries are test doubles, see harness.py)
tests/fixtures/ holds a v5 file from the release before Abagusment, to prove old files still open."""
import os, sys, random
sys.path.insert(0, os.path.dirname(__file__))
from harness import *
HERE = os.path.dirname(__file__)
INDEX = os.environ.get('ABAGUS_INDEX', os.path.abspath(os.path.join(HERE, '..', 'index.html')))
PW = 'correct horse battery staple 42'
res = []
def check(n, c, e=''): res.append(bool(c)); print('PASS' if c else 'FAIL', n, e)

with sync_playwright() as p:
    b = p.chromium.launch()
    ctx, pg = setup(b); open_page(pg, INDEX)

    # ---- the code table, straight from the spec ----
    t = pg.evaluate("""()=>({n:ABAGUS_SYMBOLS.length,
      z:Object.fromEntries('PATHROYMSBCFKLNUVWXZDEGIJQ'.split('').map(c=>[c,ABAGUS_LETTER_TO_Z.get(c)??null])),
      kw:['P','A','M','S'].map(c=>ABAGUS_KEYWORD.get(c)), letters:ABAGUS_LETTER_TO_Z.size})""")
    check('118 elements in the table', t['n'] == 118)
    exp = dict(P=15, A=13, T=22, H=1, R=37, O=8, Y=39, M=12, S=14, B=4, C=6, F=9, K=19, L=3, N=7, U=92, V=23, W=74, X=54, Z=30, D=66, E=63, G=31, I=49, J=None, Q=None)
    check('first-element-by-number for every letter (J and Q have none)', t['z'] == exp, str({k: (t['z'][k], v) for k, v in exp.items() if t['z'][k] != v}))
    check('24 letters mapped; keywords are the element symbols', t['letters'] == 24 and t['kw'] == ['P', 'Al', 'Mg', 'Si'])
    enc = lambda s: pg.evaluate("s=>{const e=new AbagusEncoder();return e.push(s)}", s)
    check("spec example: 'PATHA ROY' -> '15 13 22 1 13   37 8 39'", enc('PATHA ROY') == '15 13 22 1 13   37 8 39', enc('PATHA ROY'))
    check("small letters get a dot: 'm' -> '.12' (Mg)", enc('m') == '.12')
    check('J and Q stay as they are', enc('JQjq') == 'J Q j q')
    check('digits, backslash and dots are escaped or safe', enc('a1.\\') == '.13 \\1 . \\\\')

    # ---- fuzz: encode -> decode over random text, fed to the decoder in random slices ----
    bad = pg.evaluate("""()=>{
      let seed=12345; const rnd=()=>((seed=(seed*1664525+1013904223)>>>0)/4294967296);
      const pool=['A','b','Z','q','J','7','0','.',' ','\\\\','\\n','\\r','\\t',',','é','ß','漢','😀','\\uFEFF','a','P','m','9',' ',' '];
      let fails=0;
      for(let n=0;n<3000;n++){
        let s=''; const len=Math.floor(rnd()*40); for(let i=0;i<len;i++) s+=pool[Math.floor(rnd()*pool.length)];
        const e=new AbagusEncoder(); const body=ABAGUS_SIGNATURE+e.push(s);
        const d=new AbagusDecoder(); let out='', i=0;
        while(i<body.length){ const step=1+Math.floor(rnd()*5); let piece=body.slice(i,i+step);
          // never split a surrogate pair (a UTF-8 decoder would not either)
          if(/[\\uD800-\\uDBFF]$/.test(piece) && i+step<body.length) piece+=body[i+step], i++;
          out+=d.push(piece); i+=step; }
        out+=d.end();
        if(out!==s) fails++;
      }
      return fails; }""")
    check('3000 random strings (digits, dots, backslashes, emoji, BOM, CRLF) round-trip, any chunking', bad == 0, f'{bad} failed')
    rej = pg.evaluate("""()=>{ const t=(x)=>{ try{ const d=new AbagusDecoder(); d.push(x); d.end(); return 'accepted'; }catch(e){ return 'rejected'; } };
      const S=ABAGUS_SIGNATURE; return [t('nope'), t(S+'999'), t(S+'15 '), t(S+'15x'), t(S+'\\\\'), t(S+'\\\\a'), t(S+'05'), t(S+'15 13')]; }""")
    check('malformed / foreign data is rejected', rej == ['rejected'] * 7 + ['accepted'], str(rej))

    # ---- always on: no switch anywhere, and the packed stream really contains coded text ----
    check('no user option for Abagusment exists', pg.evaluate("()=>document.querySelectorAll('input[id*=\"abagus\" i], input[name*=\"abagus\" i], select[id*=\"abagus\" i]').length===0"))
    packed = pg.evaluate("""async()=>{
      const txt=new File([new TextEncoder().encode('Patha Roy 2026')],'a.txt',{type:'text/plain'});
      const bin=new File([new Uint8Array([137,80,78,71,0,255,254,1,2,3])],'b.png',{type:'image/png'});
      const st={text:0,raw:0}; const parts=[];
      for await (const c of packFilesGenerator([txt,bin],st)) parts.push(Array.from(c));
      return {bytes:parts.flat(), st}; }""")
    raw = bytes(packed['bytes'])
    want = b'Ba-Ga-U-S:1\n' + b'15 .13 .22 .1 .13   37 .8 .39   \\2 \\0 \\2 \\6'
    check('text is coded inside the packed stream (keyword line + element numbers, exactly)', want in raw and b'Patha' not in raw and b'2026' not in raw)
    check('binary (PNG) is stored unchanged with tag 0', bytes([137,80,78,71,0,255,254,1,2,3]) in raw and packed['st'] == {'text': 1, 'raw': 1})

    # ---- full encrypt -> decrypt through the UI ----
    text = ('Hello, World! Pi = 3.14159; C:\\Users\\me\\file_01.txt\r\nJazz & Quartz — 東京 😀 ' * 4000).encode()   # > 1 MiB, multibyte, digits, backslashes
    big = ('The quick brown fox 0123456789 jumps. ' * 90000).encode()   # ~3.4 MiB: crosses several 1 MiB chunk edges
    files = [('notes.txt', b'Patha Roy 42\n'), ('mixed.md', text), ('big.log', big), ('pic.bin', os.urandom(5000)),
             ('empty.txt', b''), ('bom.txt', b'\xef\xbb\xbfBOM kept'), ('latin1.txt', 'caf\xe9'.encode('latin-1')), ('nul.txt', b'text\x00with nul')]
    name, locked = encrypt(pg, files, PW, 'triple')
    check('payload is v6 with the Abagusment flag', locked[:4] == b'SVL3' and locked[4] == 6 and locked[42] & 8 == 8)
    rec, msg = decrypt(pg, locked, PW, name)
    ok = rec and [r[1] for r in rec] == [f[1] for f in files] and [r[0] for r in rec] == [f[0] for f in files]
    check('8-file batch (text, binary, empty, BOM, Latin-1, NUL) is byte-identical after decrypt', ok, msg[:70])
    check('status line and inspector say Abagusment ran', 'Abagusment decoded' in msg and 'Decoded 4 text files' in pg.inner_text('#inspUAbagus'), pg.inner_text('#inspUAbagus'))
    ctx.close()

    # ---- single file, other layer counts and tiers, offline (no cascade libs) ----
    for layers, tier in [('none', None), ('double', 'maximum')]:
        ctx, pg = setup(b); open_page(pg, INDEX)
        n, l = encrypt(pg, [('one.txt', text)], PW, layers, tier=tier, timeout=120000)
        rec, msg = decrypt(pg, l, PW, n)
        check(f'single text file, layers={layers}, tier={tier or "default"}', rec and rec[0][1] == text, msg[:60]); ctx.close()
    ctx, pg = setup(b, stubs=False); open_page(pg, INDEX)
    n, l = encrypt(pg, [('off.txt', text)], PW, 'triple'); rec, _ = decrypt(pg, l, PW, n)
    check('offline fallback still codes and decodes text', rec and rec[0][1] == text and l[4] == 6); ctx.close()

    # ---- compression off, and a wrong passphrase still fails closed ----
    ctx, pg = setup(b); open_page(pg, INDEX); pg.evaluate("()=>{const c=document.getElementById('compressToggle'); c.checked=false; c.dispatchEvent(new Event('change'))}")
    n, l = encrypt(pg, [('plain.txt', text)], PW, 'double'); rec, _ = decrypt(pg, l, PW, n)
    check('works with compression switched off', rec and rec[0][1] == text and l[42] & 1 == 0); ctx.close()
    ctx, pg = setup(b); open_page(pg, INDEX); n, l = encrypt(pg, [('s.txt', b'secret 123')], PW, 'triple')
    rec, _ = decrypt(pg, l, 'wrong passphrase here!!', n); check('wrong passphrase still refused', rec is None)
    check('no uncaught page errors', not pg.errors, str(pg.errors[:2])); ctx.close()

    # ---- compatibility: a v5 file made by the previous release (committed fixture) still opens ----
    fx = os.path.join(HERE, 'fixtures', 'v5-before-abagusment.locked'); legacy = [b'Made before Abagusment 007', bytes(range(256)) * 4]
    ctx, pg = setup(b); open_page(pg, INDEX); l = open(fx, 'rb').read(); rec, msg = decrypt(pg, l, PW, 'old.txt.locked')
    check('v5 payload from the previous release opens; its text is left as it was', l[4] == 5 and rec and [r[1] for r in rec] == legacy, msg[:70])
    check('inspector says the older file has no Abagusment', 'older' in pg.inner_text('#inspUAbagus').lower()); ctx.close()
    b.close()
print(f'{sum(res)}/{len(res)} passed'); sys.exit(0 if all(res) else 1)
