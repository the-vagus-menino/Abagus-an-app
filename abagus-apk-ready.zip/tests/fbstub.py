"""Shared test double: serves the page over http://localhost with an in-memory stand-in for the Firebase SDK
and a virtual WebAuthn authenticator (PRF) per browser context."""
import os, sys, json, threading, functools, http.server, socketserver
sys.path.insert(0, os.path.dirname(__file__))
from harness import CHACHA, ARGON, CORS, sync_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
httpd = socketserver.TCPServer(('127.0.0.1', 0), functools.partial(Q, directory=ROOT))
PORT = httpd.server_address[1]
threading.Thread(target=httpd.serve_forever, daemon=True).start()
URL = f'http://localhost:{PORT}/index.html#vault'

STUBS = {
'firebase-app.js': "export const initializeApp=(c)=>({c});",
'firebase-auth.js': """
const st=(window.__fb=window.__fb||{users:{},cur:null,ls:[],docs:{},fsFail:false});
const mk=(u)=>({uid:u.uid,email:u.email,get displayName(){return u.displayName},photoURL:null,providerData:[{providerId:'password'}],getIdToken:async()=>'t'});
const notify=()=>st.ls.forEach(f=>f(st.cur));
const err=(code)=>Object.assign(new Error(code),{code});
export const getAuth=()=>({get currentUser(){return st.cur}});
export const onAuthStateChanged=(a,cb)=>{st.ls.push(cb);setTimeout(()=>cb(st.cur),0);return()=>{}};
export async function createUserWithEmailAndPassword(a,email,pw){
  if(st.users[email]) throw err('auth/email-already-in-use'); if(pw.length<6) throw err('auth/weak-password');
  st.users[email]={uid:'uid'+(Object.keys(st.users).length+1),email,pw,displayName:null}; st.cur=mk(st.users[email]); notify(); return{user:st.cur}}
export async function signInWithEmailAndPassword(a,email,pw){
  const u=st.users[email]; if(!u||u.pw!==pw) throw err('auth/invalid-credential'); st.cur=mk(u); notify(); return{user:st.cur}}
export async function signOut(){st.cur=null;notify()}
export async function updateProfile(user,p){st.users[user.email].displayName=p.displayName}
export class GoogleAuthProvider{addScope(){}setCustomParameters(){}static credentialFromResult(){return null}}
export const signInWithPopup=async()=>{throw err('auth/popup-closed-by-user')};
export const reauthenticateWithPopup=signInWithPopup, signInWithRedirect=signInWithPopup, getRedirectResult=async()=>null;
""",
'firebase-firestore.js': """
const st=(window.__fb=window.__fb||{users:{},cur:null,ls:[],docs:{},fsFail:false});
const err=(code)=>Object.assign(new Error(code),{code});
export const getFirestore=()=>({});
export const doc=(db,c,id)=>({p:c+'/'+id});
export async function getDoc(r){ if(st.fsFail) throw err('permission-denied'); const d=st.docs[r.p]; return{exists:()=>!!d,data:()=>JSON.parse(JSON.stringify(d))}}
export async function setDoc(r,data,o){ if(st.fsFail) throw err('permission-denied'); st.docs[r.p]=Object.assign({},o&&o.merge?st.docs[r.p]:{},JSON.parse(JSON.stringify(data)))}
"""}

def new_page(b, state=None, prf=True):
    ctx = b.new_context(viewport={'width': 1100, 'height': 900}, service_workers='block')
    ctx.add_init_script("try{localStorage.setItem('vault_sound_muted_v1','1')}catch(e){}")
    if state: ctx.add_init_script('window.__fb=' + json.dumps(state))
    ctx.route('**/@noble/ciphers@1.0.0/chacha.js', lambda r: r.fulfill(status=200, headers=CORS, body=CHACHA))
    ctx.route('**/@noble/hashes@1.5.0/argon2.js', lambda r: r.fulfill(status=200, headers=CORS, body=ARGON))
    def sdk(route):
        name = route.request.url.split('/')[-1]
        route.fulfill(status=200, content_type='text/javascript', headers=CORS, body=STUBS.get(name, ''))
    ctx.route('https://www.gstatic.com/firebasejs/**', sdk)
    pg = ctx.new_page(); pg.errors = []
    pg.on('pageerror', lambda e: pg.errors.append(str(e)[:200]))
    pg.on('dialog', lambda d: d.accept())
    cdp = ctx.new_cdp_session(pg); cdp.send('WebAuthn.enable')
    cdp.send('WebAuthn.addVirtualAuthenticator', {'options': {'protocol': 'ctap2', 'transport': 'internal', 'hasResidentKey': True,
        'hasUserVerification': True, 'isUserVerified': True, 'automaticPresenceSimulation': True, 'hasPrf': prf}})
    pg.goto(URL); pg.wait_for_function('()=>window.__authReady===true', timeout=15000); pg.wait_for_timeout(500)
    return ctx, pg

