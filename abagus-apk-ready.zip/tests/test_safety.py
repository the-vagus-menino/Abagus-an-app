"""Safety net: leave-page prompt while busy, passphrases wiped on page hide, noscript message. Run: python tests/test_safety.py"""
import os, sys
sys.path.insert(0, os.path.dirname(__file__))
from harness import *
INDEX = os.environ.get('ABAGUS_INDEX', os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'index.html')))
res = []
def check(n, c, e=''): res.append(bool(c)); print('PASS' if c else 'FAIL', n, e)
src = open(INDEX, encoding='utf8').read()
check('index.html has a noscript message', '<noscript>' in src and 'needs JavaScript' in src)
check('ux-safety.js is loaded by index.html', 'src="ux-safety.js"' in src)
check('ux-safety.js is in the offline shell', "'./ux-safety.js'" in open(os.path.join(os.path.dirname(INDEX), 'sw.js')).read())
with sync_playwright() as p:
    b = p.chromium.launch()
    ctx, pg = setup(b); open_page(pg, INDEX)
    pg.wait_for_timeout(500)
    # beforeunload: idle -> no prompt, busy -> prompt
    r = pg.evaluate("""()=>{const idle=new Event('beforeunload',{cancelable:true});window.dispatchEvent(idle);
      document.body.classList.add('is-busy');const busy=new Event('beforeunload',{cancelable:true});window.dispatchEvent(busy);
      document.body.classList.remove('is-busy');return [idle.defaultPrevented,busy.defaultPrevented]}""")
    check('no leave prompt when idle', r[0] is False, str(r))
    check('leave prompt while sealing or opening', r[1] is True, str(r))
    # passphrase wipe on pagehide
    pg.fill('#lockPassword', 'correct horse battery staple 42')
    pg.evaluate("window.dispatchEvent(new PageTransitionEvent('pagehide',{persisted:true}))")
    check('passphrase box emptied on page hide', pg.input_value('#lockPassword') == '')
    pg.fill('#lockPassword', 'another long passphrase 99')
    pg.evaluate("window.dispatchEvent(new PageTransitionEvent('pageshow',{persisted:true}))")
    check('passphrase box emptied when restored from cache', pg.input_value('#lockPassword') == '')
    check('no uncaught page errors', not pg.errors, str(pg.errors[:2]))
    ctx.close(); b.close()
print(f'{sum(res)}/{len(res)} passed'); sys.exit(0 if all(res) else 1)
