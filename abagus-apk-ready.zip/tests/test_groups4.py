"""Upgrade V2: public directory (ranking, privacy), discoverability controls, gallery filters/layout, lightbox navigation.
Same fake backend as test_groups.py. The Cloud Function that mirrors opted-in groups into publicGroups/ is simulated here by
writing the summary the way the server would. Run: python tests/test_groups4.py"""
import os, sys, json, base64, re
sys.path.insert(0, os.path.dirname(__file__))
import fbshared as F
from fbshared import new_page, sync_playwright
res = []
def check(n, c, e=''): res.append(bool(c)); print('PASS' if c else 'FAIL', n, e)
PW = 'correct horse battery 42'
IMG_JS = """async()=>{const c=document.createElement('canvas');c.width=48;c.height=36;const x=c.getContext('2d');x.fillStyle='#36c';x.fillRect(0,0,48,36);x.fillStyle='#fc3';x.fillRect(10,10,20,14);
 const b=await new Promise(r=>c.toBlob(r,'image/png'));const a=new Uint8Array(await b.arrayBuffer());let s='';for(const v of a)s+=String.fromCharCode(v);return btoa(s)}"""
VID_JS = """async()=>{const c=document.createElement('canvas');c.width=64;c.height=48;const x=c.getContext('2d');const st=c.captureStream(15);const r=new MediaRecorder(st,{mimeType:'video/webm'});const ch=[];r.ondataavailable=e=>ch.push(e.data);
 r.start();for(let i=0;i<10;i++){x.fillStyle='hsl('+i*30+',80%,50%)';x.fillRect(0,0,64,48);await new Promise(q=>setTimeout(q,80));}
 await new Promise(q=>{r.onstop=q;r.stop()});const a=new Uint8Array(await new Blob(ch).arrayBuffer());let s='';for(const b of a)s+=String.fromCharCode(b);return btoa(s)}"""
def signup(pg, user, num):
    pg.click('#phoneSignInBtn'); pg.fill('#acdUser', user); pg.fill('#acdCc', '+91'); pg.fill('#acdNum', num)
    pg.fill('#acdPass', PW); pg.fill('#acdPass2', PW); pg.click('#acdSubmit')
    pg.wait_for_function("()=>!document.getElementById('acctDialog').open", timeout=15000); pg.wait_for_timeout(600)
def key_dialog(pg): pg.wait_for_selector('#ckCode', timeout=20000); pg.check('#ckSaved'); pg.click('#ckGo')
def to_groups(pg): pg.goto(F.GROUPS_URL); pg.wait_for_function('()=>window.__authReady===true', timeout=15000); pg.wait_for_selector('#grpNewName', timeout=15000)
def tab(pg, n): pg.click(f'[data-tab="{n}"]'); pg.wait_for_timeout(500)
def wait_group(pg):
    pg.wait_for_selector('[data-tab="files"]', timeout=30000)
    if pg.get_attribute('[data-tab="files"]', 'aria-selected') != 'true': pg.click('[data-tab="files"]')
    pg.wait_for_timeout(500)
def make_group(pg, name): pg.fill('#grpNewName', name); pg.click('#grpCreate'); key_dialog(pg); wait_group(pg)
def denied(pg, js): return pg.evaluate("async()=>{try{await (" + js + ");return 'ok'}catch(e){return e.code||e.message}}")
def flat(): return json.dumps(F.DB)
APPROVED = {'name', 'publicDesc', 'memberCount', 'mediaCount', 'createdAt', 'v'}
def mirror(gid, **kw):       # what functions/directory.js writes (Admin SDK, bypasses rules)
    F.DB['docs']['publicGroups/' + gid] = dict({'name': 'x', 'publicDesc': '', 'memberCount': 1, 'mediaCount': 0, 'createdAt': '2026-01-01T00:00:00Z', 'v': 1}, **kw)

with sync_playwright() as p:
    b = p.chromium.launch()
    ctxA, A = new_page(b); signup(A, 'Owner One', '9300000001'); to_groups(A)
    check('Discover section renders with an empty state and no errors when nothing is listed', A.is_visible('#gdSearch') and A.wait_for_selector('#gdEmpty', timeout=8000) is not None)
    check('Discover pills exist: Top Ranked, Newest, My Groups', [x.strip() for x in A.locator('.gd-pill').all_inner_texts()] == ['Top Ranked', 'Newest', 'My Groups'])
    make_group(A, 'Family Vault')
    gid = [k.split('/')[1] for k in F.DB['docs'] if k.startswith('groups/') and k.count('/') == 1][0]
    check('a new group is private by default and has no directory entry', 'discoverable' not in F.DB['docs'][f'groups/{gid}'] and f'publicGroups/{gid}' not in F.DB['docs'])

    # ---------- gallery: filters, layout, lightbox ----------
    IMG = base64.b64decode(A.evaluate(IMG_JS)); VID = base64.b64decode(A.evaluate(VID_JS))
    check('drag-and-drop upload zone is present for people who may upload', A.is_visible('#grpDrop') and A.is_visible('#gfBar'))
    A.set_input_files('#grpUpload', [{'name': 'a.png', 'mimeType': 'image/png', 'buffer': IMG}, {'name': 'b.png', 'mimeType': 'image/png', 'buffer': IMG}, {'name': 'c.webm', 'mimeType': 'video/webm', 'buffer': VID}])
    A.wait_for_function("()=>document.querySelectorAll('.grp-tile').length===3", timeout=60000); A.wait_for_timeout(800)
    check('filter tabs show counts', 'Photos \u00b7 2' in A.inner_text('#gfBar') and 'Videos \u00b7 1' in A.inner_text('#gfBar'), A.inner_text('#gfBar'))
    A.click('[data-filter="video"]'); A.wait_for_timeout(500)
    check('Videos filter shows only the video, with a play badge', A.locator('.grp-tile').count() == 1 and A.locator('.grp-tile .gf-play').count() == 1)
    A.click('[data-filter="vault"]'); A.wait_for_timeout(400)
    check('Documents filter shows a friendly empty state', A.is_visible('#gfEmpty') and A.locator('.grp-tile').count() == 0)
    A.click('[data-filter="image"]'); A.wait_for_timeout(500)
    check('Photos filter shows both photos', A.locator('.grp-tile').count() == 2)
    A.click('#gfLayout'); A.wait_for_timeout(300)
    check('compact layout toggles and is remembered', 'compact' in (A.get_attribute('#grpGrid', 'class') or '') and A.evaluate("()=>localStorage.getItem('abagus-gp-layout')") == 'compact')
    A.click('#gfLayout'); A.click('[data-filter="all"]'); A.wait_for_timeout(500)
    A.click('.grp-tile >> nth=0'); A.wait_for_selector('#grpViewer img, #grpViewer video', timeout=20000); A.wait_for_timeout(500)
    check('lightbox shows a counter and previous/next controls', re.match(r'^1 / 3$', A.inner_text('.grp-vcount').strip()) is not None and A.is_visible('#grpNext') and A.is_visible('#grpPrev'))
    check('exactly one close button (existing contract)', A.locator('.grp-vclose').count() == 1)
    A.keyboard.press('ArrowRight'); A.wait_for_function("()=>document.querySelector('.grp-vcount')&&document.querySelector('.grp-vcount').textContent.trim()==='2 / 3'", timeout=20000)
    check('ArrowRight moves to the next item', True)
    A.keyboard.press('ArrowLeft'); A.wait_for_function("()=>document.querySelector('.grp-vcount')&&document.querySelector('.grp-vcount').textContent.trim()==='1 / 3'", timeout=20000)
    check('ArrowLeft moves back', True)
    check('lightbox has NO download control (security policy unchanged)', A.locator('#grpViewer a[download], #grpViewer [download], #grpViewer button:has-text("Download")').count() == 0)
    A.keyboard.press('Escape'); A.wait_for_timeout(300)
    check('Escape closes the lightbox', not A.is_visible('#grpViewer'))
    A.set_input_files('#grpUpload', [{'name': 'notes.pdf', 'mimeType': 'application/pdf', 'buffer': b'%PDF-1.4 hello'}]); A.wait_for_timeout(600)
    check('a document is refused here with a pointer to the Vault, not a crash', 'Vault' in A.inner_text('#grpProg') and A.locator('.grp-tile').count() == 3)

    # ---------- discoverability controls ----------
    tab(A, 'settings')
    check('owner sees the Discoverability card, switched off by default', A.is_visible('#grpDiscoverCard') and not A.is_checked('#setDiscoverable'))
    A.fill('#grpPubDesc', 'Photos from the family'); A.click('#grpPubSave'); A.wait_for_timeout(600)
    check('public line saved on the group document', F.DB['docs'][f'groups/{gid}'].get('publicDesc') == 'Photos from the family')
    A.check('#setDiscoverable'); A.wait_for_timeout(1500)
    check('owner can list the group', F.DB['docs'][f'groups/{gid}'].get('discoverable') is True)
    check('a client can never write the public directory', denied(A, f"VaultDB.set('publicGroups/{gid}', {{name:'Family Vault', memberCount: 999999}})") == 'permission-denied')
    # server mirror (simulated Cloud Function) for this group plus three others with different sizes
    mirror(gid, name='Family Vault', publicDesc='Photos from the family', memberCount=7, mediaCount=3, createdAt='2026-03-01T00:00:00Z')
    mirror('g_gold', name='Mega Club', publicDesc='The big one', memberCount=500, mediaCount=40, createdAt='2026-01-01T00:00:00Z')
    mirror('g_silver', name='Silver Team', memberCount=120, mediaCount=9, createdAt='2026-02-01T00:00:00Z')
    mirror('g_new', name='Brand New', memberCount=2, mediaCount=0, createdAt='2026-06-01T00:00:00Z')
    A.evaluate("AbagusGroups._lock()"); A.wait_for_selector('#gdList .gd-card', timeout=15000); A.wait_for_timeout(500)
    cards = A.locator('.gd-card')
    check('ranked by member count, highest first', [c.strip() for c in A.locator('.gd-card .gd-t b').all_inner_texts()] == ['Mega Club', 'Silver Team', 'Family Vault', 'Brand New'], str(A.locator('.gd-card .gd-t b').all_inner_texts()))
    check('gold, silver and bronze rank badges', A.locator('.gd-rank.gold').inner_text().strip() == '#1' and A.locator('.gd-rank.silver').inner_text().strip() == '#2' and A.locator('.gd-rank.bronze').inner_text().strip() == '#3' and A.locator('.gd-rank.num').inner_text().strip() == '#4')
    check('member and file counts are shown', '500 Members' in A.inner_text('.gd-card >> nth=0') and '40 files' in A.inner_text('.gd-card >> nth=0'))
    check('my group says Open Group, others say Join Group', A.locator('.gd-card[data-gid="%s"] [data-act="open"]' % gid).count() == 1 and A.locator('.gd-card[data-gid="g_gold"] [data-act="join"]').count() == 1)
    A.fill('#gdSearch', 'silver'); A.wait_for_timeout(300)
    check('search filters instantly and keeps real ranks', A.locator('.gd-card').count() == 1 and A.locator('.gd-rank.silver').count() == 1)
    A.fill('#gdSearch', 'zzzz'); A.wait_for_timeout(300)
    check('no match shows an empty state', A.is_visible('#gdEmpty'))
    A.fill('#gdSearch', ''); A.click('[data-sort="new"]'); A.wait_for_timeout(300)
    check('Newest sorts by creation date', A.locator('.gd-card .gd-t b').all_inner_texts()[0] == 'Brand New')
    A.click('[data-sort="mine"]'); A.wait_for_timeout(300)
    check('My Groups shows only my groups', A.locator('.gd-card').count() == 1 and A.locator('.gd-card .gd-t b').inner_text() == 'Family Vault')
    A.click('[data-sort="top"]'); A.click('.gd-card[data-gid="g_gold"] [data-act="join"]'); A.wait_for_timeout(300)
    check('Join Group points to the invite-code box (groups stay invite-only)', A.evaluate("()=>document.activeElement&&document.activeElement.id")=='grpCode')
    A.click('.gd-card[data-gid="%s"] [data-act="open"]' % gid); wait_group(A)
    check('Open Group opens my group', 'Family Vault' in A.inner_text('#grpTitle'))

    # ---------- privacy: the summary can only ever hold approved fields ----------
    pub = {k: v for k, v in F.DB['docs'].items() if k.startswith('publicGroups/')}
    check('every directory entry holds only approved fields', all(set(v) <= APPROVED for v in pub.values()))
    check('no keys, codes, members, file names or private text anywhere in the directory', not re.search(r'wrapped|descEnc|avatar|inviteId|photo|c\.webm|uid', json.dumps(pub)))

    # ---------- a second person: sees the directory, cannot flip discoverability, private groups stay hidden ----------
    ctxB, B = new_page(b); signup(B, 'Member Two', '9300000002'); to_groups(B)
    B.wait_for_selector('#gdList .gd-card', timeout=15000)
    check('another signed-in person can read the directory', B.locator('.gd-card').count() == 4)
    check('they have no Open button for a group they are not in', B.locator('[data-act="open"]').count() == 0)
    check('a non-member cannot read the group itself', denied(B, f"VaultDB.get('groups/{gid}')") == 'permission-denied')
    check('a non-owner cannot list a group', denied(B, f"VaultDB.set('groups/{gid}', {{discoverable:false}}, true)") == 'permission-denied')
    # hide a group: the server deletes the summary
    del F.DB['docs']['publicGroups/g_new']
    B.evaluate("AbagusGroups.open()"); B.wait_for_timeout(1200)
    check('removing a group from Discover removes it from the list', B.locator('.gd-card').count() == 3)
    check('no page errors', not A.errors and not B.errors, str(A.errors + B.errors))
    b.close()
print(sum(res), '/', len(res)); sys.exit(0 if all(res) else 1)
