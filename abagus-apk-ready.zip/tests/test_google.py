"""Groups work for people who sign in with Google, not only for mobile-number accounts.
A pretend Google account (person@gmail.com) is used; the sign-in service itself is the test fake. Run: python tests/test_google.py"""
import os, sys, base64
sys.path.insert(0, os.path.dirname(__file__))
import fbshared as F
from fbshared import new_page, sync_playwright
res = []
def check(n, c, e=''): res.append(bool(c)); print('PASS' if c else 'FAIL', n, e if not c else '')
PW = 'correct horse battery 42'
IMG_JS = """async()=>{const c=document.createElement('canvas');c.width=40;c.height=30;const x=c.getContext('2d');x.fillStyle='#37c';x.fillRect(0,0,40,30);const b=await new Promise(r=>c.toBlob(r,'image/png'));const a=new Uint8Array(await b.arrayBuffer());let s='';for(const v of a)s+=String.fromCharCode(v);return btoa(s)}"""
def key_dialog(pg): pg.wait_for_selector('#ckCode', timeout=20000); pg.check('#ckSaved'); pg.click('#ckGo')
def wait_group(pg):
    pg.wait_for_selector('[data-tab="files"]', timeout=30000)
    if pg.get_attribute('[data-tab="files"]', 'aria-selected') != 'true': pg.click('[data-tab="files"]')
    pg.wait_for_timeout(500)
def tab(pg, n): pg.click(f'[data-tab="{n}"]'); pg.wait_for_timeout(600)

with sync_playwright() as p:
    b = p.chromium.launch()
    ctx, G = new_page(b); G.evaluate("()=>localStorage.setItem('fbstub-google','1')")
    G.click('#googleSignInBtn'); G.wait_for_function("()=>window.AbagusAccount&&AbagusAccount.session().uid", timeout=15000); G.wait_for_timeout(800)
    s = G.evaluate("()=>AbagusAccount.session()")
    check('signed in with Google: an account with no mobile number', bool(s['uid']) and not s['phone'], str(s))
    check('the Groups button is shown for a Google account', not G.evaluate("()=>document.getElementById('groupsBtn').classList.contains('hidden')"))
    G.goto(F.GROUPS_URL); G.wait_for_selector('#grpNewName', timeout=20000)
    check('the Groups page offers "Create a group" (not "sign in with your mobile number")', G.locator('#grpNewName').count() == 1 and 'mobile number' not in G.inner_text('body').lower().split('create a group')[0][-200:])
    check('the profile card shows the Google name', 'Google Person' in G.inner_text('.gp-profile'))
    G.fill('#grpNewName', 'Google Crew'); G.click('#grpCreate'); key_dialog(G); wait_group(G)
    gid = [k.split('/')[1] for k in F.DB['docs'] if k.startswith('groups/') and k.count('/') == 1][0]
    owner = [v for k, v in F.DB['docs'].items() if k.startswith(f'groups/{gid}/members/')][0]
    check('the group was created and the Google account is its owner', owner['role'] == 'owner' and owner['name'] == 'Google Person')
    IMG = base64.b64decode(G.evaluate(IMG_JS))
    G.set_input_files('#grpUpload', [{'name': 'g.png', 'mimeType': 'image/png', 'buffer': IMG}]); G.wait_for_selector('.grp-tile', timeout=30000)
    check('a Google owner can upload and see the picture', G.locator('.grp-tile').count() == 1)
    tab(G, 'invites'); G.click('#grpMkInvite'); G.wait_for_selector('#grpCodeText'); code = G.inner_text('#grpCodeText').strip()

    ctxM, M = new_page(b)
    M.click('#phoneSignInBtn'); M.fill('#acdUser', 'Phone Person'); M.fill('#acdCc', '+91'); M.fill('#acdNum', '9500000001'); M.fill('#acdPass', PW); M.fill('#acdPass2', PW); M.click('#acdSubmit')
    M.wait_for_function("()=>!document.getElementById('acctDialog').open", timeout=15000); M.wait_for_timeout(600)
    M.goto(F.GROUPS_URL); M.wait_for_selector('#grpCode', timeout=15000); M.fill('#grpCode', code); M.click('#grpJoin'); M.wait_for_selector('#grpHonor'); M.check('#grpHonor'); M.click('#grpJoinGo'); key_dialog(M); wait_group(M)
    M.wait_for_selector('.grp-tile', timeout=30000)
    check('a mobile-number member joins a Google-owned group and opens its files', M.locator('.grp-tile').count() == 1)

    # a Google account can also JOIN a group made by a mobile account
    tab(G, 'invites'); G.click('#grpMkInvite'); G.wait_for_selector('#grpCodeText'); G.wait_for_timeout(300)
    ctxK, K = new_page(b); K.evaluate("()=>localStorage.setItem('fbstub-google','1')")
    K.goto(F.GROUPS_URL); K.wait_for_selector('#gpGoogle', timeout=15000)
    check('the signed-out Groups page offers both mobile and Google sign-in', K.locator('#gpSignIn').count() == 1 and K.locator('#gpGoogle').count() == 1)
    K.click('#gpGoogle'); K.wait_for_selector('#grpCode', timeout=20000)
    check('"Continue with Google" on the Groups page signs in and shows the create/join page', K.locator('#grpNewName').count() == 1 and K.locator('#grpCode').count() == 1)
    check('no uncaught page errors', not (G.errors + M.errors + K.errors), str((G.errors + M.errors + K.errors)[:3]))
    b.close()
print(f'{sum(res)}/{len(res)} passed'); sys.exit(0 if all(res) else 1)
