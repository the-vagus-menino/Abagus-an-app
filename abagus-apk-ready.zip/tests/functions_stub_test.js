// Runs the Cloud Functions and the Netlify function against stand-ins for the Firebase packages (no network needed).
const Module = require('module'), path = require('path'), assert = require('assert');
const calls = { sets: [], decoded: null };
const FV = { serverTimestamp: () => 'TS', increment: (n) => ({ inc: n }) };
const fakeDoc = { set: async (d, o) => { calls.sets.push(d); }, get: async () => ({ exists: false, data: () => ({}) }), delete: async () => {} };
const col = { doc: () => fakeDoc, where: () => col, orderBy: () => col, limit: () => col, get: async () => ({ docs: [] }), count: () => ({ get: async () => ({ data: () => ({ count: 0 }) }) }) };
const fakeDb = { collection: () => col, doc: () => fakeDoc };
let corsSeen = [];
const stubs = {
  'firebase-functions/v2/https': { onRequest: (opts, fn) => { if (opts && opts.cors) corsSeen.push(opts.cors); return fn || opts; } },
  'firebase-functions/v2/scheduler': { onSchedule: (o, fn) => fn },
  'firebase-functions/v2/firestore': { onDocumentWritten: (p, fn) => fn },
  'firebase-functions/params': { defineSecret: (n) => ({ value: () => 'secret-' + n }) },
  'firebase-admin/app': { initializeApp: () => {}, getApps: () => [1] },
  'firebase-admin/auth': { getAuth: () => ({ verifyIdToken: async (t) => { if (t === 'bad') throw new Error('x'); return calls.decoded; }}) },
  'firebase-admin/firestore': { getFirestore: () => fakeDb, FieldValue: FV },
};
const orig = Module._load;
Module._load = function (req, parent, isMain) { return stubs[req] || orig.apply(this, arguments); };
const ownerFns = require(path.join(__dirname, '..', 'functions', 'owner.js'));
const res = () => { const r = { code: 200, body: null, status(c) { r.code = c; return r; }, json(b) { r.body = b; return r; }, set() { return r; } }; return r; };
const req = (token, body) => ({ headers: token ? { authorization: 'Bearer ' + token } : {}, body: body || {}, method: 'POST' });
(async () => {
  let r = res(); await ownerFns.ownerStats(req(null), r); assert.strictEqual(r.code, 401, 'no token must be 401');
  r = res(); await ownerFns.ownerStats(req('bad'), r); assert.strictEqual(r.code, 401, 'bad token must be 401');
  calls.decoded = { email: 'someone@else.com', email_verified: true };
  r = res(); await ownerFns.ownerStats(req('t'), r); assert.strictEqual(r.code, 403, 'other account must be 403');
  calls.decoded = { email: 'partha9178712507@gmail.com', email_verified: false };
  r = res(); await ownerFns.ownerStats(req('t'), r); assert.strictEqual(r.code, 403, 'unverified owner must be 403');
  calls.decoded = { email: 'partha9178712507@gmail.com', email_verified: true };
  r = res(); await ownerFns.ownerStats(req('t'), r); assert.strictEqual(r.code, 200, 'verified owner is allowed'); assert.strictEqual(r.body.pageViews, 0);
  r = res(); await ownerFns.trackEvent(req(null, { field: 'hack' }), r); assert.strictEqual(r.code, 400, 'unknown counter must be 400');
  r = res(); await ownerFns.trackEvent(req(null, { field: 'pageViews' }), r); assert.strictEqual(r.code, 200); assert.deepStrictEqual(calls.sets.pop(), { pageViews: { inc: 1 } });
  // CORS lists: real domain present, old domain gone
  const flat = JSON.stringify(corsSeen); assert(flat.includes('https://abagus.netlify.app'), 'real domain in CORS'); assert(!flat.includes('abagusv53'), 'old domain removed');
  // the other modules load with the modular admin API
  require(path.join(__dirname, '..', 'functions', 'directory.js')); require(path.join(__dirname, '..', 'functions', 'dailyImprovement.js'));
  const idx = require(path.join(__dirname, '..', 'functions', 'index.js')); assert(typeof idx.geminiCover === 'function' && typeof idx.dailyImprovement === 'function' && typeof idx.directoryOnGroup === 'function');
  corsSeen = []; delete require.cache[require.resolve('../functions/index.js')]; require('../functions/index.js');
  assert(JSON.stringify(corsSeen).includes('https://abagus.netlify.app'), 'index.js CORS has real domain');
  // Netlify cover function origin check
  Module._load = orig; const nf = require(path.join(__dirname, '..', 'netlify', 'functions', 'geminiCover.js'));
  const t = async (origin) => (await nf.handler({ headers: origin ? { origin } : {}, httpMethod: 'POST', body: '{"topic":999}' })).statusCode;
  assert.strictEqual(await t('https://abagus.netlify.app'), 400, 'real site passes the origin check (then fails on topic)');
  assert.strictEqual(await t('https://evil.example'), 403); assert.strictEqual(await t('https://abagusv53.netlify.app'), 403);
  assert.strictEqual(await t('http://localhost:8888'), 400); assert.strictEqual(await t('https://deploy-preview-3--abagus.netlify.app'), 400);
  console.log('PASS functions: owner gating, counters, modular admin API, CORS, Netlify origin check'); console.log('1/1 passed');
})().catch((e) => { console.log('FAIL', e.message); process.exit(1); });
