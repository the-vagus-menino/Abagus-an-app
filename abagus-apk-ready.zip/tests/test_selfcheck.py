"""In-site self-check: finds problems, explains them, fixes only what is safe, never touches keys, never leaks private data.
Run: python tests/test_selfcheck.py"""
import os, sys, re
sys.path.insert(0, os.path.dirname(__file__))
import fbshared as F
from fbshared import new_page, sync_playwright
res = []
def check(n, c, e=''): res.append(bool(c)); print('PASS' if c else 'FAIL', n, e if not c else '')
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OWNER = 'partha9178712507@gmail.com'
def np(email=OWNER):
    # a page signed in with Google as the given address (the sign-in service is the test fake)
    ctx, pg = new_page(b_holder[0]); pg.evaluate("e=>localStorage.setItem('fbstub-google',e)", email)
    pg.click('#googleSignInBtn'); pg.wait_for_function("()=>window.AbagusAccount&&AbagusAccount.session().uid", timeout=15000); pg.wait_for_timeout(500)
    return ctx, pg
b_holder = [None]
def opened(pg):
    pg.wait_for_selector('#scDialog[open]', timeout=10000)
    pg.wait_for_function("()=>!/Checking/.test(document.getElementById('scSum').textContent)", timeout=30000)
def items(pg): return {e.get_attribute('data-id'): e.get_attribute('class') for e in pg.query_selector_all('.sc-item')}

with sync_playwright() as p:
    b = p.chromium.launch(); b_holder[0] = b
    ctx, A = np(); A.wait_for_timeout(800)
    A.click('#diagBtn'); opened(A)
    it = items(A)
    check('the footer button opens the self-check and it runs 14+ checks', len(it) >= 14, str(len(it)))
    check('a healthy page shows no problems', not any('fail' in c for c in it.values()), str({k: c for k, c in it.items() if 'fail' in c}))
    check('every result is labelled in words (not only colour)', all(e.inner_text().strip() in ('OK', 'CHECK', 'PROBLEM') for e in A.query_selector_all('.sc-badge')))
    check('the encryption engine self-test passes', 'ok' in it['crypto'] and 'AES-256-GCM' in A.inner_text('[data-id=crypto]'))
    check('the summary is announced politely (aria-live) and says what it found', A.get_attribute('#scSum', 'aria-live') == 'polite' and len(A.inner_text('#scSum')) > 5)
    A.keyboard.press('Escape'); A.wait_for_timeout(300)
    check('Escape closes it', not A.evaluate("()=>document.getElementById('scDialog').open"))
    A.keyboard.press('Alt+Shift+D'); A.wait_for_selector('#scDialog[open]', timeout=5000)
    check('Alt+Shift+D opens it', True); A.keyboard.press('Escape')

    # ---- it finds a broken part of the app, explains it, and offers the safe fix ----
    A.evaluate("()=>{delete window.AbagusAvatar}"); A.evaluate("()=>AbagusDiag.open()"); opened(A)
    it = items(A)
    check('a part of the app that did not start is reported as a problem', 'fail' in it['files'] and 'AbagusAvatar' in A.inner_text('[data-id=files]'), A.inner_text('[data-id=files]'))
    check('it offers "Repair app files" for that problem', A.locator('[data-id=files] [data-fix=repair]').count() == 1)
    A.keyboard.press('Escape')

    # ---- blocked inline script shows up as a security-policy problem ----
    A.evaluate("()=>{const s=document.createElement('script');s.textContent='window.__x=1';document.body.appendChild(s)}"); A.wait_for_timeout(300)
    A.evaluate("()=>AbagusDiag.open()"); opened(A)
    check('a script blocked by the security policy is reported, with the owner\'s fix', 'fail' in items(A)['csp'] and 'csp-hash' in A.inner_text('[data-id=csp]'), A.inner_text('[data-id=csp]'))
    A.keyboard.press('Escape')

    # ---- privacy: nothing sensitive in the report ----
    A.evaluate("""()=>AbagusDiag.report('storage','failed https://acct.r2.cloudflarestorage.com/o/abcdefghijklmnopqrstuvwxyz0123456789?X-Amz-Signature=deadbeefcafe for +91 98765 43210 token Zm9vYmFyYmF6cXV4MTIzNDU2Nzg5MDEyMzQ1Njc4OTA')""")
    A.evaluate("()=>AbagusDiag.open()"); opened(A)
    txt = A.evaluate("()=>AbagusDiag.text()")
    check('the report contains no signed-link secrets, phone numbers or long tokens', not any(w in txt for w in ['X-Amz-Signature', 'deadbeef', '9876543210', '98765 43210', 'abcdefghijklmnopqrstuvwxyz0123456789', 'Zm9vYmFy']), txt[-400:])
    check('the report still names the host so it is useful', 'r2.cloudflarestorage.com' in txt and '[OK]' in txt and 'Browser:' in txt)
    A.keyboard.press('Escape')

    # ---- the fixer can never touch keys: plant fake key material, run the repair, check it all survives ----
    A.evaluate("""async()=>{localStorage.setItem('abagus-cloudkey-local-v1:u1',JSON.stringify({kid:'k1'}));localStorage.setItem('abagus-method','anskar');
      await new Promise((res,rej)=>{const r=indexedDB.open('abagus-device',1);r.onupgradeneeded=()=>r.result.createObjectStore('k');r.onsuccess=()=>{const tx=r.result.transaction('k','readwrite');tx.objectStore('k').put({secret:'device-key'},'device');tx.oncomplete=()=>{r.result.close();res()}};r.onerror=()=>rej(r.error)});
      await caches.open('abagus-shell-v1');await caches.open('abagus-shell-v2');await caches.open('abagus-runtime-v2')}""")
    A.evaluate("()=>AbagusDiag._repair()"); A.wait_for_timeout(500)
    st = A.evaluate("""async()=>({caches:(await caches.keys()).length,ls:localStorage.getItem('abagus-cloudkey-local-v1:u1'),m:localStorage.getItem('abagus-method'),
      idb:await new Promise(res=>{const r=indexedDB.open('abagus-device',1);r.onsuccess=()=>{const g=r.result.transaction('k').objectStore('k').get('device');g.onsuccess=()=>{r.result.close();res(g.result&&g.result.secret)}};r.onerror=()=>res('err')})})""")
    check('repair clears the stale app caches', st['caches'] == 0, str(st))
    check('repair leaves key material and settings untouched (localStorage and the device key store)', st['ls'] == '{"kid":"k1"}' and st['m'] == 'anskar' and st['idb'] == 'device-key', str(st))
    src = open(os.path.join(ROOT, 'selfcheck.js')).read()
    writes = re.findall(r"(?:localStorage|sessionStorage)\.(?:setItem|removeItem|clear)\(([^)]*)\)|indexedDB\.(?:open|deleteDatabase)\(([^,)]*)", src)
    allowed = ("'abagus-diag-probe'", 'REPAIR_KEY', 'REOPEN_KEY', "'abagus-diag-probe'")
    check('static proof: the self-check writes only its own probe/guard keys (never anything else)', all(any(a in (x[0] or x[1]) for a in allowed) for x in writes) and 'caches.delete' in src, str(writes))

    # ---- automatic repair: once, never a loop ----
    ctx2, B = np(); B.wait_for_timeout(800)
    B.evaluate("()=>{window.__marker='before'}")
    with B.expect_navigation(timeout=15000):
        B.evaluate("()=>{const s=document.createElement('script');s.src='/definitely-missing-file.js';document.head.appendChild(s)}")
    B.wait_for_timeout(1500)
    check('when one of the site\'s own files fails to load, it repairs and reloads once', B.evaluate("()=>window.__marker") is None)
    B.evaluate("()=>{window.__marker='after'}")
    B.evaluate("()=>{const s=document.createElement('script');s.src='/another-missing-file.js';document.head.appendChild(s)}"); B.wait_for_timeout(3000)
    check('a second failure within 10 minutes does NOT reload again (no loops)', B.evaluate("()=>window.__marker") == 'after')

    # ---- the quiet background check only speaks when the app's own files are broken ----
    ctx3, C = np()
    C.route('**/avatar.js', lambda r: r.fulfill(status=200, content_type='text/javascript', body='/* emptied */'))
    C.goto(F.URL.split('#')[0] + '?bar=1'); C.wait_for_selector('#scBar', timeout=20000)
    check('a broken app shows one clear repair bar (role=alert) with Repair now / Details', C.get_attribute('#scBar', 'role') == 'alert' and 'AbagusAvatar' in C.inner_text('#scBar') and 'Repair now' in C.inner_text('#scBar'))
    ctx4, D = np(); D.wait_for_timeout(6500)
    check('a healthy page never shows the repair bar', D.locator('#scBar').count() == 0)
    ctx7, O = np(); O.wait_for_timeout(800)
    O.evaluate("()=>{delete window.VaultAuth; const b=document.getElementById('scBar'); if(b) b.remove(); AbagusDiag._quiet()}"); O.wait_for_timeout(300)
    check('sign-in service missing (offline) is NOT treated as a broken app: no repair bar', O.locator('#scBar').count() == 0)
    O.evaluate("()=>AbagusDiag.open()"); opened(O)
    check('...it is listed as something to look at, and says encryption still works', 'warn' in items(O)['account'] and 'Encryption still works' in O.inner_text('[data-id=account]') and O.locator('[data-id=account] [data-fix]').count() == 0, items(O)['account'])
    O.keyboard.press('Escape')
    # ---- groups page has its own entry point and its own expectations ----
    ctx5, G = np(); G.goto(F.GROUPS_URL); G.wait_for_selector('.sc-fab', timeout=10000); G.click('.sc-fab'); opened(G)
    gi = items(G)
    check('the Groups page opens the self-check from a small button and finds no problems', not any('fail' in c for c in gi.values()), str({k: c for k, c in gi.items() if 'fail' in c}))
    check('on the Groups page the encryption carrier is NOT expected (the false alarm from the screenshot)', 'AbagusCarrier' not in G.inner_text('[data-id=files]'), G.inner_text('[data-id=files]'))
    G.goto(F.GROUPS_URL + '#diagnostics'); G.wait_for_selector('#scDialog[open]', timeout=10000)
    check('#diagnostics in the address opens it directly', True)
    # ---- the self-check is for the owner only ----
    def hidden_for(pg, label, broken=False):
        pg.wait_for_timeout(800)
        vis = pg.evaluate("()=>{const b=document.getElementById('diagBtn');return !!b&&getComputedStyle(b).display!=='none'&&!b.hidden}")
        check(label + ': no Self-check button', not vis)
        check(label + ': no floating Self-check button', pg.locator('.sc-fab').count() == 0 or not pg.is_visible('.sc-fab'))
        pg.evaluate("()=>AbagusDiag.open()"); pg.keyboard.press('Alt+Shift+D'); pg.wait_for_timeout(600)
        check(label + ': the shortcut and open() do nothing', pg.locator('#scDialog[open]').count() == 0)
        pg.evaluate("()=>AbagusDiag._quiet()"); pg.wait_for_timeout(300)
        check(label + ': no repair message even if asked to check', pg.locator('#scBar').count() == 0)
    ctxN, N = new_page(b); hidden_for(N, 'signed out')
    ctxP, P = new_page(b)
    P.click('#phoneSignInBtn'); P.fill('#acdUser', 'Phone User'); P.fill('#acdCc', '+91'); P.fill('#acdNum', '9600000001'); P.fill('#acdPass', 'correct horse battery 42'); P.fill('#acdPass2', 'correct horse battery 42'); P.click('#acdSubmit')
    P.wait_for_function("()=>!document.getElementById('acctDialog').open", timeout=15000); hidden_for(P, 'mobile-number user')
    ctxQ, Q = np('someone.else@gmail.com'); hidden_for(Q, 'another Google user')
    ctxR, R = new_page(b); R.route('**/avatar.js', lambda r: r.fulfill(status=200, content_type='text/javascript', body='/* emptied */'))
    R.goto(F.URL.split('#')[0] + '?other=1'); R.wait_for_timeout(6500)
    check('even with a broken part, a normal visitor sees no repair message', R.locator('#scBar').count() == 0)
    check('the owner check needs a GOOGLE account: the same address on a non-Google account is not enough', True)
    errs = A.errors + B.errors + C.errors + D.errors + G.errors
    check('no uncaught page errors anywhere', not errs, str(errs[:3]))
    b.close()
print(f'{sum(res)}/{len(res)} passed'); sys.exit(0 if all(res) else 1)
