import os, sys
from playwright.sync_api import sync_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..')); ok = 0; n = 0
def check(name, c):
    global ok, n; n += 1; ok += bool(c); print(('PASS ' if c else 'FAIL ') + name)
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_context(viewport={'width': 1280, 'height': 800}).new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)[:160])); pg.goto('file://' + ROOT + '/index.html'); pg.wait_for_timeout(500)
    for t in ('shangchi', 'moonknight'):
        pg.evaluate("id=>AbagusThemes.set(id)", t); pg.wait_for_timeout(700)
        check(t + ': film + vignette layers mounted', pg.evaluate("!!document.getElementById('vFilm') && !!document.getElementById('vVig')"))
        pg.mouse.click(500, 400); pg.wait_for_timeout(400)
        pg.mouse.move(600, 420); pg.mouse.down(); pg.wait_for_timeout(700); pg.mouse.up(); pg.wait_for_timeout(500)
        check(t + ': tap and hold-release run clean', not errs)
    pg.evaluate("AbagusThemes.set('')"); pg.wait_for_timeout(1500)  # the view transition swaps the DOM before the reveal ends
    check('Default removes film + vignette', pg.evaluate("!document.getElementById('vFilm') && !document.getElementById('vVig')"))
    b.close()
print(ok, '/', n); sys.exit(0 if ok == n else 1)
