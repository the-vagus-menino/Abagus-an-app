"""Groups: the standalone page, pictures, settings, member uploads, 120 MB files, name tag modes, and the Vault 'Group' method
(encrypt in the Vault, it lands in the group, every member opens it with their fingerprint). Run: python tests/test_groups2.py"""
import os, sys, json, base64, re, time
sys.path.insert(0, os.path.dirname(__file__))
import fbshared as F
from fbshared import new_page, sync_playwright
res = []
def check(n, c, e=''): res.append(bool(c)); print('PASS' if c else 'FAIL', n, e)
PW = 'correct horse battery 42'
IMG_JS = """async()=>{const c=document.createElement('canvas');c.width=48;c.height=48;const x=c.getContext('2d');x.fillStyle='#36c';x.fillRect(0,0,48,48);x.fillStyle='#fc3';x.fillRect(10,10,20,20);
 const b=await new Promise(r=>c.toBlob(r,'image/png'));const a=new Uint8Array(await b.arrayBuffer());let s='';for(const v of a)s+=String.fromCharCode(v);return btoa(s)}"""
def signup(pg, user, num):
    pg.click('#phoneSignInBtn'); pg.fill('#acdUser', user); pg.fill('#acdCc', '+91'); pg.fill('#acdNum', num)
    pg.fill('#acdPass', PW); pg.fill('#acdPass2', PW); pg.click('#acdSubmit')
    pg.wait_for_function("()=>!document.getElementById('acctDialog').open", timeout=15000); pg.wait_for_timeout(600)
def key_dialog(pg): pg.wait_for_selector('#ckCode', timeout=20000); pg.check('#ckSaved'); pg.click('#ckGo')
def to_groups(pg): pg.goto(F.GROUPS_URL); pg.wait_for_function('()=>window.__authReady===true', timeout=15000); pg.wait_for_selector('#grpNewName,#gpSignIn', timeout=15000)
def tab(pg, n): pg.click(f'[data-tab="{n}"]'); pg.wait_for_timeout(500)
def wait_group(pg):
    pg.wait_for_selector('[data-tab="files"]', timeout=30000)
    if pg.get_attribute('[data-tab="files"]', 'aria-selected') != 'true': pg.click('[data-tab="files"]')
    pg.wait_for_timeout(500)
def reopen(pg): pg.evaluate("AbagusGroups._lock()"); pg.wait_for_selector('.grp-row'); pg.click('.grp-row >> nth=0'); wait_group(pg)
def denied(pg, js): return pg.evaluate("async()=>{try{await (" + js + ");return 'ok'}catch(e){return e.code||e.message}}")
def flat(): return json.dumps(F.DB)

with sync_playwright() as p:
    b = p.chromium.launch()
    # ---------------- the page itself ----------------
    src = open(os.path.join(F.ROOT, 'groups.html'), encoding='utf-8').read()
    check('groups page has its own strict policy and no inline script', 'Content-Security-Policy' in src and "script-src 'self' https://www.gstatic.com" in src and not re.search(r'<script(?![^>]*src=)[^>]*>', src))
    ctxA, A = new_page(b); signup(A, 'Owner One', '9200000001')
    A.click('#groupsBtn'); A.wait_for_function("()=>location.pathname.endsWith('groups.html')", timeout=10000); A.wait_for_selector('#grpNewName', timeout=15000)
    check('the Groups button opens the new independent page', True)
    check('signed in on the new page without signing in again', 'Owner One' in A.inner_text('#gpWho'))
    ctxS, S = new_page(b); S.goto(F.GROUPS_URL); S.wait_for_selector('#gpSignIn', timeout=15000)
    check('signed out: the page asks to sign in', S.is_visible('#gpSignIn')); ctxS.close()

    # ---------------- profile picture ----------------
    IMG = base64.b64decode(A.evaluate(IMG_JS))
    A.click('#gpAvatarBtn'); A.wait_for_selector('.pf-dialog[open]'); A.set_input_files('.pf-dialog input[type=file]:not([capture])', [{'name': 'me.png', 'mimeType': 'image/png', 'buffer': IMG}]); A.wait_for_function("()=>!document.querySelector('[data-pf=save]').disabled"); A.click('[data-pf=save]'); A.wait_for_selector('.gp-profile .gp-av img', timeout=15000)
    uidA = [u for u in F.DB['users'].values() if u['displayName'] == 'Owner One'][0]['uid']
    check('profile picture is saved small and shown', F.DB['docs'][f'users/{uidA}'].get('avatar') and A.locator('.gp-profile .gp-av img').count() == 1)

    # ---------------- group + settings ----------------
    A.fill('#grpNewName', 'Family'); A.click('#grpCreate'); key_dialog(A); wait_group(A)
    gid = [k.split('/')[1] for k in F.DB['docs'] if k.startswith('groups/') and k.count('/') == 1][0]
    check('new groups start with sensible settings', F.DB['docs'][f'groups/{gid}']['settings'] == {'memberUpload': False, 'vaultShare': True, 'watermark': 'corner', 'idleMin': 3})
    mrec = F.DB['docs'][f'groups/{gid}/members/{uidA}']
    check('my picture is in the group, encrypted with the group key', set(mrec.get('avatar', {})) == {'iv', 'ct'} and mrec.get('avatarV') == F.DB['docs'][f'users/{uidA}']['avatarV'])
    tab(A, 'settings')
    A.click('#grpAvatarBtn'); A.wait_for_selector('.pf-dialog[open]'); A.set_input_files('.pf-dialog input[type=file]:not([capture])', [{'name': 'g.png', 'mimeType': 'image/png', 'buffer': IMG}]); A.wait_for_function("()=>!document.querySelector('[data-pf=save]').disabled"); A.click('[data-pf=save]'); A.wait_for_selector('.gp-banner .gp-av img', timeout=15000)
    check('group picture saved encrypted and shown in the header', set(F.DB['docs'][f'groups/{gid}']['avatar']) == {'iv', 'ct'})
    tab(A, 'settings'); A.fill('#grpRename', 'Family Vault'); A.fill('#grpDesc', 'Our secret holiday plans'); A.click('#grpSaveProfile'); A.wait_for_timeout(900)
    check('rename and description are saved', 'Family Vault' in A.inner_text('.gp-banner') and 'secret holiday' in A.inner_text('.gp-banner'))
    check('the description is encrypted on the server', 'secret holiday' not in flat() and 'descEnc' in F.DB['docs'][f'groups/{gid}'])
    tab(A, 'members'); check('members list shows the encrypted picture decrypted', A.locator('.grp-member .gp-av img').count() == 1)

    # ---------------- name tag modes ----------------
    A.set_input_files('#grpUpload', [{'name': 'photo.png', 'mimeType': 'image/png', 'buffer': IMG}]) if A.locator('#grpUpload').count() else None
    tab(A, 'files'); A.set_input_files('#grpUpload', [{'name': 'photo.png', 'mimeType': 'image/png', 'buffer': IMG}])
    A.wait_for_function("()=>document.querySelectorAll('.grp-tile').length>=1", timeout=40000); A.wait_for_timeout(600)
    A.click(".grp-tile:has-text('photo.png')"); A.wait_for_selector('#grpViewer img', timeout=20000)
    check('default name tag is one small corner tag, not a pattern', A.locator('.grp-wm.corner').count() == 1 and A.locator('.grp-wm span').count() == 1 and 'Owner One' in A.inner_text('.grp-wm'))
    A.click('.grp-vclose'); tab(A, 'settings'); A.select_option('#grpWm', 'full'); A.wait_for_timeout(700)
    tab(A, 'files'); A.click(".grp-tile:has-text('photo.png')"); A.wait_for_selector('#grpViewer img', timeout=20000)
    check('"full pattern" is available when an admin chooses it', A.locator('.grp-wm.full').count() == 1 and A.locator('.grp-wm.full span').count() > 5)
    A.click('.grp-vclose'); tab(A, 'settings'); A.select_option('#grpWm', 'off'); A.wait_for_timeout(700)
    tab(A, 'files'); A.click(".grp-tile:has-text('photo.png')"); A.wait_for_selector('#grpViewer img', timeout=20000)
    check('name tag can be switched off', A.locator('.grp-wm').count() == 0)
    A.click('.grp-vclose'); tab(A, 'settings'); A.select_option('#grpWm', 'corner'); A.wait_for_timeout(600)
    A.select_option('#grpIdle', '1'); A.wait_for_timeout(600)
    check('auto-lock time is a saved setting', F.DB['docs'][f'groups/{gid}']['settings']['idleMin'] == 1 and F.DB['docs'][f'groups/{gid}']['settings']['watermark'] == 'corner')
    A.select_option('#grpIdle', '3'); A.wait_for_timeout(500)

    # ---------------- 120 MB limit and multi-piece files ----------------
    tab(A, 'files')
    A.evaluate("""()=>{const dt=new DataTransfer();dt.items.add(new File([new Blob([new ArrayBuffer(121*1024*1024)])],'toobig.mp4',{type:'video/mp4'}));const i=document.getElementById('grpUpload');i.files=dt.files;i.dispatchEvent(new Event('change'))}""")
    A.wait_for_function("()=>/over 120 MB/.test(document.getElementById('grpProg').textContent)", timeout=20000)
    check('a file over 120 MB is refused before anything is read or sent', not any('toobig' in k for k in F.DB['docs']) and 'over 120 MB' in A.inner_text('#grpProg'))
    A.evaluate("""()=>{const a=new Uint8Array(3*1024*1024);for(let i=0;i<a.length;i+=65536)crypto.getRandomValues(a.subarray(i,Math.min(a.length,i+65536)));const dt=new DataTransfer();dt.items.add(new File([a],'long.mp4',{type:'video/mp4'}));const i=document.getElementById('grpUpload');i.files=dt.files;i.dispatchEvent(new Event('change'))}""")
    A.wait_for_function("()=>document.querySelectorAll('.grp-tile').length>=2", timeout=60000); A.wait_for_timeout(800)
    lf = [v for k, v in F.DB['docs'].items() if k.startswith(f'groups/{gid}/files/') and k.count('/') == 3 and v['size'] == 3 * 1024 * 1024][0]
    check('a 3 MB file is stored as several encrypted pieces', lf['chunks'] == 5, str(lf['chunks']))
    A.click(".grp-tile:has-text('long.mp4')"); A.wait_for_selector('#grpViewer video', timeout=60000)
    last = A.evaluate("AbagusGroups._last")
    check('all pieces decrypt back to the exact size', last and last['size'] == 3 * 1024 * 1024 and last['chunks'] == 5, str(last))
    A.click('.grp-vclose')
    check('the limit is 120 MB in the engine and the rules', A.evaluate("AbagusGroups._limits.MAX_FILE") == 120 * 1024 * 1024 and 'request.resource.data.size <= 125829120' in open(os.path.join(F.ROOT, 'firestore.rules')).read())

    # ---------------- invite + member, member uploads ----------------
    tab(A, 'invites'); A.click('#grpMkInvite'); A.wait_for_selector('#grpCodeText'); code = A.inner_text('#grpCodeText').strip()
    ctxB, B = new_page(b); signup(B, 'Member Two', '9200000002'); to_groups(B)
    B.fill('#grpCode', code); B.click('#grpJoin'); B.wait_for_selector('#grpHonor'); B.check('#grpHonor'); B.click('#grpJoinGo'); key_dialog(B); wait_group(B)
    uidB = [u for u in F.DB['users'].values() if u['displayName'] == 'Member Two'][0]['uid']
    check('members cannot upload while the setting is off', B.locator('#grpUpBtn').count() == 0)
    fid_a = [k.split('/')[3] for k, v in F.DB['docs'].items() if k.startswith(f'groups/{gid}/files/') and k.count('/') == 3][0]
    check('...and the server refuses it too', denied(B, f"VaultDB.set('groups/{gid}/files/zz', {{kind:'image',mime:'image/png',size:1,chunks:1,nameEnc:{{}},uploadedBy:'{uidB}',uploaderName:'x',createdAt:'x',hasThumb:false,v:1}})") == 'permission-denied')
    tab(A, 'settings'); A.check('#setMemberUpload') if not A.is_checked('#setMemberUpload') else None; A.wait_for_timeout(800)
    check('admin switches on "members can upload"', F.DB['docs'][f'groups/{gid}']['settings']['memberUpload'] is True)
    reopen(B)
    check('members now see the upload button', B.locator('#grpUpBtn').count() == 1)
    B.set_input_files('#grpUpload', [{'name': 'from-member.png', 'mimeType': 'image/png', 'buffer': IMG}]); B.wait_for_function("()=>document.querySelectorAll('.grp-tile').length>=3", timeout=40000); B.wait_for_timeout(700)
    check('a member uploads a photo', B.locator(".grp-tile:has-text('from-member.png')").count() == 1)
    check('a member can delete their own upload', B.locator(".grp-tile:has-text('from-member.png') .grp-del").count() == 1)
    check('...but not other people\'s', B.locator(".grp-tile:has-text('photo.png') .grp-del").count() == 0 and denied(B, f"VaultDB.del('groups/{gid}/files/{fid_a}')") == 'permission-denied')
    B.click(".grp-tile:has-text('from-member.png') .grp-del"); B.wait_for_timeout(1500)
    check('own upload deleted', B.locator(".grp-tile:has-text('from-member.png')").count() == 0)

    # ---------------- Vault 'Group' method ----------------
    A.goto(F.URL); A.wait_for_function('()=>window.__authReady===true', timeout=15000); A.wait_for_timeout(800)
    A.click('#methodGroup'); A.wait_for_function("()=>document.querySelectorAll('#lockGroupSel option').length>1", timeout=15000)
    check('the Vault offers Group as a third way to unlock', A.is_visible('#lockGroupBlock') and not A.is_visible('#lockPwBlock') and A.inner_text('#lockBtn') == 'Encrypt for the group')
    A.select_option('#lockGroupSel', gid)
    SECRET = b'Vault file for the whole group. ' * 300
    A.set_input_files('#lockFileInput', [{'name': 'plan.txt', 'mimeType': 'text/plain', 'buffer': SECRET}])
    with A.expect_download(timeout=60000) as d: A.click('#lockBtn')
    A.wait_for_timeout(1500)
    vf = [(k, v) for k, v in F.DB['docs'].items() if k.startswith(f'groups/{gid}/files/') and k.count('/') == 3 and v['kind'] == 'vault']
    check('encrypting for a group also sends it to the group, as a locked file', len(vf) == 1)
    check('the server sees neither its name nor its contents', 'plan.txt' not in flat() and ','.join(map(str, SECRET[:8])) not in flat())
    # a member opens it with their fingerprint
    to_groups(B); B.click('.grp-row >> nth=0'); wait_group(B)
    check('members see it as a locked file', B.locator(".grp-tile:has-text('plan.txt.locked')").count() == 1 and 'Locked file' in B.inner_text(".grp-tile:has-text('plan.txt.locked')"))
    B.click(".grp-tile:has-text('plan.txt.locked')")
    B.wait_for_function("()=>location.pathname.endsWith('index.html')", timeout=60000); B.wait_for_selector('#unlockGroupNote:not(.hidden)', timeout=20000)
    check('the Vault opens with the file loaded, no passphrase asked', not B.is_visible('#unlockPwBlock') and B.inner_text('#unlockBtn') == 'Unlock with AnskarKey')
    B.click('#unlockBtn'); B.wait_for_function("()=>!document.getElementById('previewArea').classList.contains('hidden')", timeout=60000)
    with B.expect_download(timeout=30000) as dd: B.click('#downloadBtn')
    check('the member decrypts it with their fingerprint: identical bytes', open(dd.value.path(), 'rb').read() == SECRET)
    # someone outside the group cannot
    ctxC, C = new_page(b); signup(C, 'Stranger Three', '9200000003')
    tmp = [v for k, v in F.DB['docs'].items() if k.startswith(f'groups/{gid}/files/') and k.count('/') == 3 and v['kind'] == 'vault'][0]
    raw = b''.join(bytes(F.DB['docs'][f'groups/{gid}/files/' + [k.split('/')[3] for k, v in vf][0] + f'/chunks/{i}']['data']['__bytes']) for i in range(tmp['chunks']))
    check('(sanity) the stored pieces are not the plain file', SECRET[:16] not in raw)
    # native wrapper hook
    ctxN, N = new_page(b); N.add_init_script("window.Capacitor={Plugins:{PrivacyScreen:{enable(){window.__ps=(window.__ps||0)+1},disable(){}}}}"); signup(N, 'Native Four', '9200000004')
    N.goto(F.GROUPS_URL); N.wait_for_function('()=>window.__authReady===true'); N.fill('#grpNewName', 'Native'); N.click('#grpCreate'); key_dialog(N); wait_group(N)
    check('inside the native wrapper the OS capture block is switched on when a group opens', N.evaluate("window.__ps||0") >= 1)
    errs = A.errors + B.errors + C.errors + N.errors
    check('no uncaught page errors', not errs, str(errs[:2]))
    b.close()
print(f'{sum(res)}/{len(res)} passed'); sys.exit(0 if all(res) else 1)
