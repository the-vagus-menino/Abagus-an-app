"""Decrypted video plays inside the page, with no download and no save dialog. Run: python tests/test_play.py"""
import os, sys, base64
sys.path.insert(0, os.path.dirname(__file__))
from harness import *
INDEX = os.environ.get('ABAGUS_INDEX', os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'index.html')))
res = []
def check(n, c, e=''): res.append(bool(c)); print('PASS' if c else 'FAIL', n, e)
MAKE = """async()=>{const c=document.createElement('canvas');c.width=64;c.height=48;const x=c.getContext('2d');
 const st=c.captureStream(15);const r=new MediaRecorder(st,{mimeType:'video/webm'});const ch=[];r.ondataavailable=e=>ch.push(e.data);
 r.start();for(let i=0;i<12;i++){x.fillStyle='hsl('+i*30+',80%,50%)';x.fillRect(0,0,64,48);await new Promise(q=>setTimeout(q,80));}
 await new Promise(q=>{r.onstop=q;r.stop()});const a=new Uint8Array(await new Blob(ch).arrayBuffer());let s='';for(const b of a)s+=String.fromCharCode(b);return btoa(s)}"""
with sync_playwright() as p:
    b = p.chromium.launch()
    ctx, pg = setup(b); open_page(pg, INDEX)
    video = base64.b64decode(pg.evaluate(MAKE)); check('test video created', len(video) > 500, str(len(video)))
    PW = 'correct horse battery staple 42'
    name, locked = encrypt(pg, [('clip.webm', video)], PW, 'none')
    # pretend a desktop browser that would normally stream a single file to disk
    pg.evaluate("window.__saveCalled=false; window.showSaveFilePicker=async()=>{window.__saveCalled=true;throw new Error('no')}; undefined")
    pg.click('#tabUnlockBtn'); pg.wait_for_timeout(200)
    pg.set_input_files('#unlockFileInput', {'name': name, 'mimeType': 'application/octet-stream', 'buffer': locked})
    pg.fill('#unlockPassword', PW); pg.click('#unlockBtn')
    pg.wait_for_selector('#previewContent video', timeout=60000)
    check('no save dialog was opened for a playable video', not pg.evaluate('window.__saveCalled'))
    pg.wait_for_function("()=>{const v=document.querySelector('#previewContent video');return v&&v.readyState>=1}", timeout=15000)
    info = pg.evaluate("()=>{const v=document.querySelector('#previewContent video');return {w:v.videoWidth,src:v.src.slice(0,5),type:window.__recoveredEntries[0].mime}}")
    check('video loads from a blob inside the page', info['src'] == 'blob:' and info['w'] == 64, str(info))
    check('type was inferred although the file had none', info['type'] == 'video/webm')
    check('the page says nothing was saved', 'Nothing was saved' in pg.inner_text('#previewContent'))
    check('download is still offered', pg.is_visible('#downloadBtn'))
    check('no uncaught page errors', not pg.errors, str(pg.errors[:2]))
    ctx.close(); b.close()
print(f'{sum(res)}/{len(res)} passed'); sys.exit(0 if all(res) else 1)
