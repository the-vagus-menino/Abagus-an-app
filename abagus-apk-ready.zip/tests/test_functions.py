"""Cloud Functions + Netlify function against stand-ins for the Firebase packages. Run: python tests/test_functions.py"""
import os, subprocess, sys
here = os.path.dirname(os.path.abspath(__file__))
r = subprocess.run(['node', os.path.join(here, 'functions_stub_test.js')], capture_output=True, text=True)
print(r.stdout.strip(), r.stderr.strip()); sys.exit(r.returncode)
