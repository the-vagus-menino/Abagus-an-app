"""The ten v3 themes: each loads, draws, reacts to taps/holds/moves without errors, leaves no effects behind after a switch, art + thumb exist."""
import os, sys, threading, functools, http.server
from playwright.sync_api import sync_playwright
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NEW = ['dodge', 'dragonrider', 'baymax', 'doraemon', 'deadpool2', 'scarletwitch', 'shangchi', 'agent', 'ghostrider', 'wonderwoman']
ok = bad = 0
def check(n, c, i=''):
    global ok, bad
    if c: ok += 1; print('PASS', n)
    else: bad += 1; print('FAIL', n, i)
for t in NEW:
    check('art+thumb exist ' + t, os.path.getsize(f'{ROOT}/themes/art/{t}.webp') > 2000 and os.path.getsize(f'{ROOT}/themes/thumb/{t}.webp') > 500)
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), functools.partial(http.server.SimpleHTTPRequestHandler, directory=ROOT)); srv.RequestHandlerClass.log_message = lambda *a: None
threading.Thread(target=srv.serve_forever, daemon=True).start(); BASE = 'http://127.0.0.1:%d/' % srv.server_address[1]
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_context(viewport={'width': 1280, 'height': 800}).new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)[:160]))
    pg.add_init_script("try{localStorage.setItem('vault_sound_muted_v1','1');localStorage.setItem('abagus-vibe-motion','full')}catch(e){}")
    pg.goto(BASE + 'index.html'); pg.wait_for_timeout(500)
    for pw in ['soft', 'normal', 'max']:
        pg.evaluate("v=>AbagusThemes.power(v)", pw)
        for t in NEW:
            pg.evaluate("id=>AbagusThemes.set(id)", t); pg.wait_for_timeout(250)
            for i in range(7):
                pg.mouse.move(300 + i * 90, 250 + i * 30); pg.mouse.down(); pg.wait_for_timeout(60); pg.mouse.up(); pg.wait_for_timeout(40)
            pg.mouse.move(40, 780); pg.mouse.move(1240, 20); pg.wait_for_timeout(120)
    check('10 new themes x 3 power levels x taps/moves: no page errors', not errs, errs[:4])
    pg.evaluate("AbagusThemes.power('normal')")
    pg.evaluate("AbagusThemes.set('shangchi')"); pg.mouse.click(600, 400); pg.wait_for_timeout(120)
    pg.evaluate("AbagusThemes.set('agent')"); pg.wait_for_timeout(50)
    check('switching theme clears the previous theme effects', pg.evaluate("(function(){var c=document.getElementById('vTop');var d=c.getContext('2d').getImageData(0,0,c.width,c.height).data;for(var i=3;i<d.length;i+=4)if(d[i]>0)return false;return true})()"))
    pg.evaluate("AbagusThemes.set('baymax')"); pg.wait_for_timeout(300)
    check('light mode forced for a light theme', pg.evaluate("document.documentElement.getAttribute('data-theme')") == 'light')
    pg.evaluate("AbagusThemes.set('ghostrider')"); pg.wait_for_timeout(300)
    check('dark mode forced for a dark theme', pg.evaluate("document.documentElement.getAttribute('data-theme')") == 'dark')
    b.close()
print(ok, '/', ok + bad); sys.exit(1 if bad else 0)
