"""End-to-end tests for index.html (real Chromium, real WebCrypto). Run: python tests/test_app.py
The two CDN cipher libraries are replaced by deterministic test doubles so the full 3-layer + Argon2 code
path runs offline; everything else is the app's own code."""
import os, sys, hashlib
sys.path.insert(0, os.path.dirname(__file__))
from harness import *
INDEX = os.environ.get('ABAGUS_INDEX', os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'index.html')))
PW = 'correct horse battery staple 42'
data = os.urandom(200_000) + b'Abagus test payload ' * 300
res = []
def check(n, c, e=''): res.append(bool(c)); print('PASS' if c else 'FAIL', n, e)
with sync_playwright() as p:
    b = p.chromium.launch()
    ctx, pg = setup(b); open_page(pg, INDEX)
    name, locked = encrypt(pg, [('report.pdf', data)], PW, 'triple')
    check('3-layer v6 payload produced (Abagusment flag set)', locked[:4] == b'SVL3' and locked[4] == 6 and locked[5] == 2 and locked[42] & 8)
    pg.wait_for_timeout(600)
    check('SHA-256 of original shown at encrypt time', hashlib.sha256(data).hexdigest() in pg.inner_text('#lockChecksum').lower())
    rec, msg = decrypt(pg, locked, PW, name)
    check('round trip is byte-identical', rec and rec[0][1] == data and rec[0][0] == 'report.pdf', msg[:60])
    ctx.close()
    ctx, pg = setup(b); open_page(pg, INDEX)
    files = [('a.txt', b'alpha' * 500), ('b.bin', os.urandom(3000)), ('c.md', b'# hi')]
    kf = ('key.dat', os.urandom(64))
    n, l = encrypt(pg, files, PW, 'double', keyfile=kf)
    rec, _ = decrypt(pg, l, PW, n); check('missing keyfile refused', rec is None)
    ctx.close(); ctx, pg = setup(b); open_page(pg, INDEX); n, l = encrypt(pg, files, PW, 'double', keyfile=kf)
    rec, _ = decrypt(pg, l, 'wrong passphrase here!!', n, keyfile=kf); check('wrong passphrase refused', rec is None)
    ctx.close(); ctx, pg = setup(b); open_page(pg, INDEX); n, l = encrypt(pg, files, PW, 'double', keyfile=kf)
    rec, _ = decrypt(pg, l, PW, n, keyfile=kf)
    check('batch + keyfile round trip', rec and [r[1] for r in rec] == [f[1] for f in files])
    ctx.close()
    ctx, pg = setup(b, stubs=False); open_page(pg, INDEX); n, l = encrypt(pg, [('f.txt', data)], PW, 'triple')
    rec, _ = decrypt(pg, l, PW, n); check('offline fallback round trip (honest header)', rec and rec[0][1] == data and l[5] == 0)
    ctx.close()
    evil = '<img src=x onerror="window.__xss=1">.txt'
    ctx, pg = setup(b); open_page(pg, INDEX); n, l = encrypt(pg, [(evil, b'hi')], PW, 'none')
    rec, _ = decrypt(pg, l, PW, n); pg.wait_for_timeout(500)
    check('hostile filename cannot run script', rec and not pg.evaluate('window.__xss === 1'))
    pg.click('#clearSessionBtn'); pg.wait_for_timeout(200)
    check('Clear Session wipes recovered files', pg.evaluate("(window.__recoveredEntries||[]).length===0 && document.getElementById('previewContent').children.length===0"))
    check('no uncaught page errors', not pg.errors, str(pg.errors[:2]))
    ctx.close(); b.close()
print(f'{sum(res)}/{len(res)} passed'); sys.exit(0 if all(res) else 1)
