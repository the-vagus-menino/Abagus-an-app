"""Private groups end to end: owner, admins, members, invite codes, encrypted uploads, capture flag and the middle-finger block.
Several separate 'phones' share one fake backend that models firestore.rules. Run: python tests/test_groups.py"""
import os, sys, json, base64, time
sys.path.insert(0, os.path.dirname(__file__))
import fbshared as F
from fbshared import new_page, sync_playwright
res = []
def check(n, c, e=''): res.append(bool(c)); print('PASS' if c else 'FAIL', n, e)
PW = 'correct horse battery 42'
FLAG = '\U0001F595'

def signup(pg, user, num):
    pg.click('#phoneSignInBtn'); pg.fill('#acdUser', user); pg.fill('#acdCc', '+91'); pg.fill('#acdNum', num)
    pg.fill('#acdPass', PW); pg.fill('#acdPass2', PW); pg.click('#acdSubmit')
    pg.wait_for_function("()=>!document.getElementById('acctDialog').open", timeout=15000); pg.wait_for_timeout(600)
def key_dialog(pg):
    pg.wait_for_selector('#ckCode', timeout=20000); pg.check('#ckSaved'); pg.click('#ckGo')
def open_groups(pg):
    pg.goto(F.GROUPS_URL); pg.wait_for_function('()=>window.__authReady===true', timeout=15000); pg.wait_for_selector('#grpNewName', timeout=15000)
def tab(pg, name): pg.click(f'[data-tab="{name}"]'); pg.wait_for_timeout(500)
def wait_group(pg):
    pg.wait_for_selector('[data-tab="files"]', timeout=30000)
    if pg.get_attribute('[data-tab="files"]', 'aria-selected') != 'true': pg.click('[data-tab="files"]')
    pg.wait_for_timeout(500)
def make_group(pg, name):
    pg.fill('#grpNewName', name); pg.click('#grpCreate'); key_dialog(pg); wait_group(pg)
def make_code(pg):
    tab(pg, 'invites'); pg.click('#grpMkInvite'); pg.wait_for_selector('#grpCodeText', timeout=10000)
    return pg.inner_text('#grpCodeText').strip()
def join(pg, code, first_key=True):
    pg.fill('#grpCode', code); pg.click('#grpJoin'); pg.wait_for_selector('#grpHonor', timeout=10000)
    pg.check('#grpHonor'); pg.click('#grpJoinGo')
    if first_key: key_dialog(pg)
    wait_group(pg)
def denied(pg, js):
    return pg.evaluate("async()=>{try{await (" + js + ");return 'ok'}catch(e){return e.code||e.message}}")
def flat(): return json.dumps(F.DB)

IMG_JS = """async()=>{const c=document.createElement('canvas');c.width=40;c.height=30;const x=c.getContext('2d');x.fillStyle='#c33';x.fillRect(0,0,40,30);x.fillStyle='#fff';x.fillRect(8,8,12,10);
 const b=await new Promise(r=>c.toBlob(r,'image/png'));const a=new Uint8Array(await b.arrayBuffer());let s='';for(const v of a)s+=String.fromCharCode(v);return btoa(s)}"""
VID_JS = """async()=>{const c=document.createElement('canvas');c.width=64;c.height=48;const x=c.getContext('2d');const st=c.captureStream(15);const r=new MediaRecorder(st,{mimeType:'video/webm'});const ch=[];r.ondataavailable=e=>ch.push(e.data);
 r.start();for(let i=0;i<12;i++){x.fillStyle='hsl('+i*30+',80%,50%)';x.fillRect(0,0,64,48);await new Promise(q=>setTimeout(q,80));}
 await new Promise(q=>{r.onstop=q;r.stop()});const a=new Uint8Array(await new Blob(ch).arrayBuffer());let s='';for(const b of a)s+=String.fromCharCode(b);return btoa(s)}"""

with sync_playwright() as p:
    b = p.chromium.launch()
    # ================= owner phone =================
    ctxA, A = new_page(b); signup(A, 'Owner One', '9100000001')
    check('Groups button appears for a signed-in mobile account', A.is_visible('#groupsBtn'))
    open_groups(A)
    make_group(A, 'Family')
    check('creator is the owner and can upload', A.is_visible('#grpUpBtn') and 'owner' in A.inner_text('.grp-top'))
    gid = [k.split('/')[1] for k in F.DB['docs'] if k.startswith('groups/') and k.count('/') == 1][0]
    mem = F.DB['docs'][f'groups/{gid}/members/' + [u for u in F.DB['users'].values() if u['displayName'] == 'Owner One'][0]['uid']]
    check('owner record holds only a wrapped key, never the group key', mem['role'] == 'owner' and set(mem['wrappedKey']) == {'iv', 'ct'})
    IMG = base64.b64decode(A.evaluate(IMG_JS)); VID = base64.b64decode(A.evaluate(VID_JS))
    A.set_input_files('#grpUpload', [{'name': 'photo.png', 'mimeType': 'image/png', 'buffer': IMG}, {'name': 'clip.webm', 'mimeType': 'video/webm', 'buffer': VID}])
    A.wait_for_function("()=>document.querySelectorAll('.grp-tile').length===2", timeout=40000); A.wait_for_timeout(800)
    check('both uploads listed with their real names (decrypted on this phone)', A.is_visible(".grp-tile:has-text('photo.png')") and A.is_visible(".grp-tile:has-text('clip.webm')"))
    check('image thumbnail was made and decrypts', A.evaluate("()=>!!document.querySelector(\".grp-tile:has-text('photo.png') img\")") if False else A.locator(".grp-tile:has-text('photo.png') img").count() == 1)
    blob = flat()
    check('server never sees file names', 'photo.png' not in blob and 'clip.webm' not in blob)
    check('server never sees plaintext file bytes', ','.join(map(str, IMG[:8])) not in blob and ','.join(map(str, VID[:8])) not in blob)
    code = make_code(A)
    check('invite code is 8 groups of 4', len(code.split('-')) == 8, code)
    inv_docs = {k: v for k, v in F.DB['docs'].items() if k.startswith('invites/')}
    iv = list(inv_docs.values())[0]
    check('invite stores the group key only locked by the code, and the code is not stored', set(iv['wrapped']) == {'iv', 'ct'} and code.replace('-', '') not in blob.upper().replace('-', ''))

    # ================= member phone =================
    ctxB, B = new_page(b); signup(B, 'Member Two', '9100000002'); open_groups(B)
    B.fill('#grpCode', 'AAAA-AAAA-AAAA-AAAA-AAAA-AAAA-AAAA-AAAA'); B.click('#grpJoin'); B.wait_for_timeout(1000)
    check('a wrong code is refused', not B.is_visible('#grpHonor'))
    B.fill('#grpCode', 'short'); B.click('#grpJoin'); B.wait_for_timeout(300)
    check('a malformed code is refused', not B.is_visible('#grpHonor'))
    B.fill('#grpCode', code); B.click('#grpJoin'); B.wait_for_selector('#grpHonor')
    check('the honor code is shown and Join is locked until it is accepted', B.is_disabled('#grpJoinGo') and 'honor code' in B.inner_text('#grpBody').lower())
    B.check('#grpHonor'); B.click('#grpJoinGo'); key_dialog(B); wait_group(B)
    check('member can see the files but not upload or invite', B.is_visible('.grp-tile') and not B.is_visible('#grpUpBtn') and B.locator('[data-tab="invites"]').count() == 0)
    B.click(".grp-tile:has-text('photo.png')"); B.wait_for_selector('#grpViewer img', timeout=20000); B.wait_for_timeout(500)
    check('member decrypts and sees the photo', B.evaluate("()=>{const i=document.querySelector('#grpViewer img');return i.naturalWidth===40&&i.naturalHeight===30}"))
    check('every view carries the viewer\'s name', 'Member Two' in B.inner_text('.grp-wm'))
    B.click('.grp-vclose'); B.click(".grp-tile:has-text('clip.webm')"); B.wait_for_selector('#grpViewer video', timeout=20000)
    B.wait_for_function("()=>{const v=document.querySelector('#grpViewer video');return v&&v.readyState>=1}", timeout=15000)
    check('member plays the video', B.evaluate("()=>document.querySelector('#grpViewer video').videoWidth===64"))
    check('video offers no download or picture-in-picture', 'nodownload' in (B.get_attribute('#grpViewer video', 'controlslist') or '') and B.get_attribute('#grpViewer video', 'disablepictureinpicture') is not None)
    B.click('.grp-vclose')

    # ---------- members cannot do admin things (rules model) ----------
    uidB = [u for u in F.DB['users'].values() if u['displayName'] == 'Member Two'][0]['uid']
    uidA = [u for u in F.DB['users'].values() if u['displayName'] == 'Owner One'][0]['uid']
    check('member cannot upload', denied(B, f"VaultDB.set('groups/{gid}/files/zzz', {{kind:'image',mime:'image/png',size:1,chunks:1,nameEnc:{{}},uploadedBy:'{uidB}',uploaderName:'x',createdAt:'x',hasThumb:false,v:1}})") == 'permission-denied')
    check('member cannot make an invite', denied(B, f"VaultDB.set('invites/abc', {{gid:'{gid}',gname:'x',active:true,expiresAt:{int(time.time()*1000)+1000},createdBy:'{uidB}',createdAt:'x',wrapped:{{}},v:1}})") == 'permission-denied')
    check('member cannot promote themselves', denied(B, f"VaultDB.set('groups/{gid}/members/{uidB}', {{role:'admin'}}, true)") == 'permission-denied')
    check('member cannot clear their own flag or read the log', denied(B, f"VaultDB.list('groups/{gid}/log')") == 'permission-denied')

    # ================= capture attempt =================
    B.click(".grp-tile:has-text('photo.png')"); B.wait_for_selector('#grpViewer img', timeout=20000)
    B.keyboard.press('PrintScreen'); B.wait_for_timeout(1500)
    check('a screenshot key replaces the photo with the middle finger, only', FLAG in B.inner_text('#grpViewer') and B.locator('#grpViewer img').count() == 0)
    mrec = F.DB['docs'][f'groups/{gid}/members/{uidB}']
    check('the member is flagged on the server and the attempt is counted', mrec['flagged'] is True and mrec['violations'] == 1)
    check('the attempt is in the admins\' log', any(v.get('type') == 'violation' and v.get('uid') == uidB for k, v in F.DB['docs'].items() if k.startswith(f'groups/{gid}/log/')))
    B.wait_for_timeout(500)
    check('flagged member: every tile shows only the middle finger', B.locator('.grp-flag').count() == 2 and B.locator('.grp-tile img').count() == 0)
    fid = [k.split('/')[3] for k in F.DB['docs'] if k.startswith(f'groups/{gid}/files/') and k.count('/') == 3][0]
    check('the SERVER refuses chunk data to a flagged member', denied(B, f"VaultDB.list('groups/{gid}/files/{fid}/chunks')") == 'permission-denied')
    check('the SERVER refuses thumbnails to a flagged member', denied(B, f"VaultDB.get('groups/{gid}/thumbs/{fid}')") == 'permission-denied')
    check('a flagged member cannot clear their own flag', denied(B, f"VaultDB.set('groups/{gid}/members/{uidB}', {{flagged:false}}, true)") == 'permission-denied')
    check('a flagged member cannot leave and rejoin to shed the flag', denied(B, f"VaultDB.del('groups/{gid}/members/{uidB}')") == 'permission-denied')
    B.evaluate("AbagusGroups._lock()"); B.wait_for_selector('.grp-row'); B.click('.grp-row'); wait_group(B)
    B.click(".grp-tile >> nth=0"); B.wait_for_timeout(800)
    check('after re-opening the group, opening any file still shows only the middle finger', FLAG in B.inner_text('#grpViewer') and B.locator('#grpViewer img,#grpViewer video').count() == 0)
    B.click('.grp-vclose')

    # ================= admin handles it =================
    tab(A, 'members')
    check('owner sees who is paused', A.is_visible("[data-uid='%s'] .ak-chip.warn" % uidB))
    A.click("[data-uid='%s'] button:has-text('Clear')" % uidB); A.wait_for_timeout(900)
    check('owner clears the flag', F.DB['docs'][f'groups/{gid}/members/{uidB}']['flagged'] is False)
    B.evaluate("AbagusGroups._lock()"); B.wait_for_selector('.grp-row'); B.click('.grp-row'); wait_group(B)
    B.click(".grp-tile:has-text('photo.png')"); B.wait_for_selector('#grpViewer img', timeout=20000)
    check('a cleared member sees the photo again', B.evaluate("()=>document.querySelector('#grpViewer img').naturalWidth===40"))
    B.click('.grp-vclose')

    # ---------- warn-only policy ----------
    tab(A, 'settings'); A.select_option('#grpPolicy', 'warn'); A.click("#grpPolicy ~ button:has-text('Save')"); A.wait_for_timeout(700)
    B.evaluate("AbagusGroups._lock()"); B.wait_for_selector('.grp-row'); B.click('.grp-row'); wait_group(B)
    B.click(".grp-tile:has-text('photo.png')"); B.wait_for_selector('#grpViewer img'); B.keyboard.press('PrintScreen'); B.wait_for_timeout(1200)
    check('warn-only policy logs but does not flag', F.DB['docs'][f'groups/{gid}/members/{uidB}']['flagged'] is False and B.locator('#grpViewer img').count() == 1)
    B.click('.grp-vclose')
    tab(A, 'settings'); A.select_option('#grpPolicy', 'block'); A.click("#grpPolicy ~ button:has-text('Save')"); A.wait_for_timeout(700)

    # ---------- window focus hides content (no flag) ----------
    B.click(".grp-tile:has-text('photo.png')"); B.wait_for_selector('#grpViewer img')
    B.evaluate("window.dispatchEvent(new Event('blur'))"); B.wait_for_timeout(200)
    check('losing focus covers the content', B.evaluate("()=>document.getElementById('groupsDialog').classList.contains('grp-cover')"))
    B.evaluate("window.dispatchEvent(new Event('focus'))"); B.wait_for_timeout(200)
    check('regaining focus uncovers it', not B.evaluate("()=>document.getElementById('groupsDialog').classList.contains('grp-cover')"))
    B.click('.grp-vclose')

    # ---------- sharing admin power ----------
    tab(A, 'members'); A.click("[data-uid='%s'] button:has-text('Make admin')" % uidB); A.wait_for_timeout(900)
    check('owner promotes a member to admin', F.DB['docs'][f'groups/{gid}/members/{uidB}']['role'] == 'admin')
    B.evaluate("AbagusGroups._lock()"); B.wait_for_selector('.grp-row'); B.click('.grp-row'); wait_group(B)
    check('the new admin can upload and invite', B.is_visible('#grpUpBtn') and B.locator('[data-tab="invites"]').count() == 1)
    check('an admin cannot remove or demote the owner', denied(B, f"VaultDB.del('groups/{gid}/members/{uidA}')") == 'permission-denied' and denied(B, f"VaultDB.set('groups/{gid}/members/{uidA}', {{role:'member'}}, true)") == 'permission-denied')
    check('an admin cannot create another owner or delete the group', denied(B, f"VaultDB.set('groups/{gid}/members/{uidB}', {{role:'owner'}}, true)") == 'permission-denied' and denied(B, f"VaultDB.del('groups/{gid}')") == 'permission-denied')
    tab(A, 'members'); A.click("[data-uid='%s'] button:has-text('Remove admin')" % uidB); A.wait_for_timeout(800)
    check('owner can take admin power back', F.DB['docs'][f'groups/{gid}/members/{uidB}']['role'] == 'member')

    # ================= invites: expiry and turning off =================
    code2 = make_code(A)
    for k, v in F.DB['docs'].items():
        if k.startswith('invites/') and v['active'] and k != 'x': last = k
    ctxC, C = new_page(b); signup(C, 'Late Three', '9100000003'); open_groups(C)
    F.DB['docs'][last]['expiresAt'] = int(time.time() * 1000) - 1000
    C.fill('#grpCode', code2); C.click('#grpJoin'); C.wait_for_timeout(1200)
    check('an expired code is refused', not C.is_visible('#grpHonor'))
    F.DB['docs'][last]['expiresAt'] = int(time.time() * 1000) + 86400000
    tab(A, 'invites'); A.wait_for_timeout(300)
    A.click("button:has-text('Turn off') >> nth=0"); A.wait_for_timeout(900)
    C.fill('#grpCode', code2); C.click('#grpJoin'); C.wait_for_timeout(1200)
    check('a code that was turned off is refused', not C.is_visible('#grpHonor'))
    code3 = make_code(A)
    C.fill('#grpCode', code3); C.click('#grpJoin'); C.wait_for_selector('#grpHonor'); C.check('#grpHonor'); C.click('#grpJoinGo'); key_dialog(C); wait_group(C)
    check('a fresh code lets a new person in', C.is_visible('.grp-tile'))

    # ---------- removal ----------
    uidC = [u for u in F.DB['users'].values() if u['displayName'] == 'Late Three'][0]['uid']
    tab(A, 'members'); A.click("[data-uid='%s'] button:has-text('Remove')" % uidC); A.wait_for_timeout(900)
    check('owner removes a member', f'groups/{gid}/members/{uidC}' not in F.DB['docs'])
    check('a removed member can no longer fetch anything', denied(C, f"VaultDB.list('groups/{gid}/files/{fid}/chunks')") == 'permission-denied' and denied(C, f"VaultDB.list('groups/{gid}/files')") == 'permission-denied')
    C.evaluate("AbagusGroups._lock()"); C.wait_for_selector('.grp-row'); C.click('.grp-row'); C.wait_for_timeout(1200)
    check('removed member is told they are no longer in the group', C.is_visible('#grpCreate') and not C.is_visible('[data-tab="files"]'))

    # ---------- outsider ----------
    ctxD, D = new_page(b); signup(D, 'Outsider Four', '9100000004')
    check('an outsider cannot read any group data', all(denied(D, js) == 'permission-denied' for js in [f"VaultDB.get('groups/{gid}')", f"VaultDB.list('groups/{gid}/files')", f"VaultDB.list('groups/{gid}/members')", f"VaultDB.list('invites')"]))
    check('an outsider cannot create themselves as a member without a code', denied(D, f"VaultDB.set('groups/{gid}/members/{[u for u in F.DB['users'].values() if u['displayName']=='Outsider Four'][0]['uid']}', {{uid:'x',name:'x',role:'member',wrappedKey:{{}},joinedAt:'x',inviteId:'nope',flagged:false,violations:0}})") == 'permission-denied')

    # ---------- admin deletes ----------
    tab(A, 'files'); A.click("[aria-label='Delete clip.webm']"); A.wait_for_timeout(1500)
    check('admin deletes a file and its encrypted data', A.locator(".grp-tile:has-text('clip.webm')").count() == 0 and not any('/files/' in k and k.endswith('/chunks/0') and 'clip' in k for k in F.DB['docs']))
    check('log records uploads and violations for admins', any(v.get('type') == 'upload' for k, v in F.DB['docs'].items() if k.startswith(f'groups/{gid}/log/')))

    # ---------- names are text, never markup ----------
    A.evaluate("AbagusGroups._lock()"); A.wait_for_selector('#grpNewName')
    A.fill('#grpNewName', '<img src=x onerror=window.__xss=1>'); A.click('#grpCreate'); wait_group(A); A.wait_for_timeout(500)
    A.evaluate("AbagusGroups._lock()"); A.wait_for_selector('.grp-row'); A.wait_for_timeout(600)
    check('a hostile group name is shown as text and runs nothing', A.locator('#grpMine img').count() == 0 and A.evaluate('window.__xss') is None and '<img' in A.inner_text('#grpMine'))

    # ---------- idle lock + owner deletes the group ----------
    A.click(".grp-row:has-text('Family')"); wait_group(A)
    A.evaluate("AbagusGroups._lock()"); A.wait_for_timeout(300)
    check('locking returns to the list and drops the key from memory', A.is_visible('#grpNewName'))
    A.click(".grp-row:has-text('Family')"); wait_group(A); tab(A, 'settings')
    A.click('#grpDeleteGroup'); A.wait_for_selector('#grpNewName', timeout=30000); A.wait_for_timeout(500)
    check('owner deletes the group and everything in it', not any(k.startswith(f'groups/{gid}') for k in F.DB['docs']) and not any(k.startswith('invites/') and v.get('gid') == gid for k, v in F.DB['docs'].items()))
    errs = A.errors + B.errors + C.errors + D.errors
    check('no uncaught page errors', not errs, str(errs[:2]))
    b.close()
print(f'{sum(res)}/{len(res)} passed'); sys.exit(0 if all(res) else 1)
