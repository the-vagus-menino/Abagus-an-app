"""Project doctor tests: it must pass on the real project, catch each kind of breakage, and --fix only the safe ones.
Run: python tests/test_doctor.py"""
import os, sys, shutil, subprocess, tempfile, re, json
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
res = []
def check(n, c, e=''): res.append(bool(c)); print('PASS' if c else 'FAIL', n, e if not c else '')
def fresh():
    d = tempfile.mkdtemp(prefix='doc-')
    shutil.copytree(ROOT, d + '/p', ignore=shutil.ignore_patterns('node_modules', '__pycache__', 'native', 'tests', '.git'))
    return d + '/p'
def doctor(p, *a):
    r = subprocess.run(['node', os.path.join(p, 'scripts/doctor.mjs'), *a], capture_output=True, text=True, env={**os.environ, 'DOCTOR_ROOT': p}, cwd=p)
    return r.returncode, r.stdout
def edit(p, f, fn):
    t = open(os.path.join(p, f)).read(); open(os.path.join(p, f), 'w').write(fn(t))

p = fresh(); code, out = doctor(p)
check('a healthy project passes with no problems', code == 0 and ' 0 problems' in out, out[-300:])

p = fresh(); os.remove(p + '/avatar.js'); code, out = doctor(p)
check('a missing file is found (page reference and offline shell)', code == 1 and 'do not exist' in out and 'avatar.js' in out, out[-400:])

p = fresh(); edit(p, 'avatar.js', lambda t: t + '\n;;(((\n'); code, out = doctor(p)
check('a JavaScript syntax error is found', code == 1 and 'does not parse' in out and 'avatar.js' in out, out[-300:])

p = fresh(); edit(p, 'index.html', lambda t: t.replace('<script type="module">', '<script type="module">\n/* edited */', 1) if '<script type="module">' in t else t.replace('<script>', '<script>\n/* edited */', 1))
code, out = doctor(p)
check('an edited inline script (hash no longer matches) is found, and says the browser will block it', code == 1 and 'BLOCK' in out and '[fixable' in out, out[-400:])
code, out = doctor(p, '--fix')
check('--fix rewrites the CSP hashes', 'FIXED rewrote CSP script hashes' in out and 'every inline script is allowed by hash' in out, out[-500:])
check('but the guard pin still demands a human review (never auto-updated)', code == 1 and 'node scripts/guard.mjs --update' in out, out[-300:])

p = fresh(); edit(p, 'index.html', lambda t: re.sub(r"(script-src 'self')", r"\1 'unsafe-inline'", t, count=1)); code, out = doctor(p)
check('unsafe-inline coming back into script-src is a hard failure', code == 1 and 'unsafe-inline' in out and 'any injected script would run' in out, out[-300:])
code, out = doctor(p, '--fix'); check('--fix removes it again', 'allowed by hash, no unsafe-inline' in out, out[-300:])

p = fresh(); open(p + '/newthing.js', 'w').write('window.x=1;\n'); edit(p, 'index.html', lambda t: t.replace('<script src="vt-guard.js"></script>', '<script src="vt-guard.js"></script>\n<script src="newthing.js"></script>', 1))
code, out = doctor(p); v0 = int(re.search(r'SHELL_VERSION\s*=\s*(\d+)', open(p + '/sw.js').read()).group(1))
check('a new script missing from the offline shell is a warning', 'not in the offline shell: newthing.js' in out, out[-300:])
code, out = doctor(p, '--fix'); v1 = int(re.search(r'SHELL_VERSION\s*=\s*(\d+)', open(p + '/sw.js').read()).group(1))
check('--fix adds it to the shell and bumps the version', "'./newthing.js'" in open(p + '/sw.js').read() and v1 == v0 + 1 and 'offline shell lists every' in out, out[-300:])

p = fresh(); edit(p, 'groups.html', lambda t: t.replace('<main', '<div id="grpBody"></div><main', 1)); code, out = doctor(p)
check('a duplicate id is found', 'duplicate ids' in out and 'grpBody' in out, out[-300:])

p = fresh(); edit(p, 'readme.md', lambda t: t + '\nAWS key AKIAABCDEFGHIJKLMNOP\n'); code, out = doctor(p)
check('a leaked cloud key in a project file is a failure', code == 1 and 'secret-looking' in out and 'readme.md' in out, out[-300:])

p = fresh(); edit(p, 'firestore.rules', lambda t: t.replace('match /databases/{database}/documents {', 'match /databases/{database}/documents {\n  match /open/{x} { allow read: if true; }', 1)); code, out = doctor(p)
check('an open "if true" Firestore rule is a failure', code == 1 and 'if true' in out, out[-300:])

p = fresh(); edit(p, '_headers', lambda t: t.replace('X-Frame-Options: DENY', '')); code, out = doctor(p)
check('a missing security header is found', code == 1 and 'X-Frame-Options' in out, out[-200:])

p = fresh(); code, out = doctor(p, '--json'); j = json.loads(out)
check('--json output is machine readable', isinstance(j['results'], list) and all(r['level'] in ('PASS', 'WARN', 'FAIL') for r in j['results']))
print(f'{sum(res)}/{len(res)} passed'); sys.exit(0 if all(res) else 1)
