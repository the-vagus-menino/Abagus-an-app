"""AnskarKey with the Abagus account key (no Google/Apple passkey sync): create, use, and add a second phone
that shares nothing with the first except the account and the recovery code. Run: python tests/test_cloudkey.py"""
import os, sys, json, base64, re
sys.path.insert(0, os.path.dirname(__file__))
from fbstub import *
res = []
def check(n, c, e=''): res.append(bool(c)); print('PASS' if c else 'FAIL', n, e)
PW = 'correct horse battery 42'; DATA = b'Account-key payload. ' * 500
def fb(pg): return pg.evaluate('JSON.parse(JSON.stringify(window.__fb))')
def signup(pg, user='Anu Kumar', num='9178712507'):
    pg.click('#phoneSignInBtn'); pg.fill('#acdUser', user); pg.fill('#acdCc', '+91'); pg.fill('#acdNum', num)
    pg.fill('#acdPass', PW); pg.fill('#acdPass2', PW); pg.click('#acdSubmit')
    pg.wait_for_function("()=>!document.getElementById('acctDialog').open", timeout=15000); pg.wait_for_timeout(500)
def signin(pg, num='9178712507'):
    pg.click('#phoneSignInBtn'); pg.click('#acdTabIn'); pg.fill('#acdCc', '+91'); pg.fill('#acdNum', num); pg.fill('#acdPass', PW)
    pg.click('#acdSubmit')
    pg.wait_for_function("()=>!document.getElementById('acctDialog').open", timeout=15000); pg.wait_for_timeout(500)
def unwrap(pg, raw):
    if raw[:8] != b'\x89PNG\r\n\x1a\n': return raw
    out = pg.evaluate("""async b64 => { const u = Uint8Array.from(atob(b64), c => c.charCodeAt(0)); const r = await AbagusCarrier.extract(new File([u], 'x.png'));
      let s=''; for (let i=0;i<r.length;i+=32768) s += String.fromCharCode.apply(null, r.subarray(i,i+32768)); return btoa(s); }""", base64.b64encode(raw).decode())
    return base64.b64decode(out)
def pick_account_key(pg):
    pg.click('#methodAnskar'); pg.click('#akWhere [data-where="account"]'); pg.wait_for_timeout(200)
def lock(pg, handle_create=None):
    pg.set_input_files('#lockFileInput', [{'name': 'n.txt', 'mimeType': 'text/plain', 'buffer': DATA}])
    with pg.expect_download(timeout=60000) as d:
        pg.click('#lockBtn')
        if handle_create: handle_create()
    return unwrap(pg, open(d.value.path(), 'rb').read())
def unlock_start(pg, locked):
    pg.click('#tabUnlockBtn'); pg.wait_for_timeout(150)
    pg.set_input_files('#unlockFileInput', {'name': 'x.locked', 'mimeType': 'application/octet-stream', 'buffer': locked}); pg.wait_for_timeout(500)
def finish_unlock(pg):
    pg.wait_for_function("()=>!document.getElementById('previewArea').classList.contains('hidden')", timeout=60000)
    with pg.expect_download(timeout=30000) as d: pg.click('#downloadBtn')
    return open(d.value.path(), 'rb').read()

with sync_playwright() as p:
    b = p.chromium.launch()
    # ---------- phone A: create the key ----------
    ctx, pg = new_page(b); signup(pg)
    pick_account_key(pg)
    check('the "My Abagus account" choice is offered inside AnskarKey', pg.get_attribute('#akWhere [data-where="account"]', 'aria-checked') == 'true' and pg.is_visible('#akAccountInfo') and not pg.is_visible('#akPasskeyInfo'))
    code = {}
    def create():
        pg.wait_for_selector('#ckCode', timeout=10000)
        code['v'] = pg.inner_text('#ckCode').strip()
        check('Continue is locked until the user confirms they saved the code', pg.is_disabled('#ckGo'))
        pg.check('#ckSaved'); pg.click('#ckGo')
    locked = lock(pg, create)
    check('recovery code is 8 groups of 4', re.fullmatch(r'([0-9A-Z]{4}-){7}[0-9A-Z]{4}', code['v']) is not None, code['v'])
    check('file uses flag 64 (account key), version 7, no passphrase', locked[4] == 7 and (locked[42] & 0x40) and not (locked[42] & 0x10), str(locked[:50].hex()))
    s = fb(pg); uid = s['users']['m919178712507@abagus-bd19f.firebaseapp.com']['uid']; prof = s['docs']['users/' + uid]
    ck = prof.get('cloudKey') or {}
    check('server holds only the wrapped key', set(ck) == {'v', 'id', 'salt', 'iv', 'ct'} and ck['v'] == 1 and len(ck['id']) == 16)
    flat = json.dumps(s['docs']).replace('-', '').upper()
    check('the recovery code is nowhere on the server', code['v'].replace('-', '') not in flat)
    def ck_ok(c):   # mirror of validCloudKey() in firestore.rules
        return isinstance(c, dict) and set(c) <= {'v','id','salt','iv','ct'} and c.get('v') == 1 and isinstance(c.get('id'), str) and len(c['id']) == 16 \
            and all(isinstance(c.get(k), str) and 0 < len(c[k]) <= m for k, m in (('salt', 64), ('iv', 32), ('ct', 128)))
    check('the saved cloudKey record passes the Firestore rules (mirrored)', ck_ok(ck) and not ck_ok(dict(ck, extra=1)) and not ck_ok(dict(ck, ct='x' * 200)), str(ck)[:80])
    check('the public key id is in the file', ck['id'] in locked.hex())
    # unlock on the same phone: biometric only
    unlock_start(pg, locked)
    check('unlock screen: no passphrase box, account-key note shown', not pg.is_visible('#unlockPwBlock') and pg.is_visible('#unlockCloudNote'))
    pg.click('#unlockBtn')
    check('same phone opens it with biometric only, no dialog, identical bytes', finish_unlock(pg) == DATA and not pg.is_visible('#ckIn'))
    check('this phone now says the key is ready (account dialog)', 'Ready' in pg.evaluate("window.CloudKey.status().localReady ? 'Ready' : 'no'"))
    state = dict(fb(pg), cur=None, ls=[])
    errs = list(pg.errors); ctx.close()

    # ---------- phone B: nothing shared except account + recovery code ----------
    ctx2, pg2 = new_page(b, state)
    unlock_start(pg2, locked)
    pg2.click('#unlockBtn'); pg2.wait_for_timeout(900)
    check('not signed in: told to sign in, sign-in opens', pg2.is_visible('#acctDialog') and 'Sign in' in pg2.inner_text('#unlockMsg'), pg2.inner_text('#unlockMsg')[:80])
    pg2.evaluate("document.getElementById('acctDialog').close()")
    signin(pg2); pg2.wait_for_timeout(500)
    pg2.click('#unlockBtn'); pg2.wait_for_selector('#ckIn', timeout=10000)
    check('signed in: asks for the recovery code once', pg2.is_visible('#ckIn'))
    pg2.fill('#ckIn', 'AAAA-AAAA-AAAA-AAAA-AAAA-AAAA-AAAA-AAAA'); pg2.click('#ckGo'); pg2.wait_for_timeout(400)
    check('wrong recovery code refused inline', 'not right' in pg2.inner_text('#ckErr'))
    pg2.fill('#ckIn', 'short'); pg2.click('#ckGo'); pg2.wait_for_timeout(200)
    check('malformed code explained', '32 letters' in pg2.inner_text('#ckErr'))
    typed = code['v'].lower().replace('-', ' ')           # lowercase, spaces instead of dashes: still accepted
    pg2.fill('#ckIn', typed); pg2.click('#ckGo')
    check('correct code (any case, any spacing) opens it on the new phone, identical bytes', finish_unlock(pg2) == DATA)
    check('phone B made its own passkey (nothing synced from phone A)', pg2.evaluate("Object.keys(localStorage).some(k=>k.startsWith('abagus-cloudkey-local-v1')) && !!localStorage.getItem('abagus-anskarkey-v1')"))
    # second time on phone B: biometric only
    pg2.click('#clearSessionBtn'); pg2.wait_for_timeout(200)
    unlock_start(pg2, locked); pg2.click('#unlockBtn')
    check('phone B needs no code the second time', finish_unlock(pg2) == DATA)
    # encrypting on phone B with the same key
    pg2.click('#tabLockBtn'); pg2.wait_for_timeout(200); pick_account_key(pg2)
    locked_b = lock(pg2)
    check('phone B can lock with the same key, no new code', locked_b[42] & 0x40 and locked_b[4] == 7 and not pg2.is_visible('#ckCode'))
    check('both phones produce files with the same key id', bytes.fromhex(ck['id']) in locked_b)
    errs += pg2.errors; state2 = dict(fb(pg2), cur=None, ls=[]); ctx2.close()

    # ---------- a different account cannot open it ----------
    ctx3, pg3 = new_page(b, state2); signup(pg3, 'Other Person', '9000000001')
    unlock_start(pg3, locked); pg3.click('#unlockBtn'); pg3.wait_for_timeout(1500)
    check('another account has no key for this file', 'no Abagus key' in pg3.inner_text('#unlockMsg') or 'different' in pg3.inner_text('#unlockMsg'), pg3.inner_text('#unlockMsg')[:90])
    check('and no dialog or key was created by trying', not pg3.is_visible('#ckCode') and not pg3.evaluate("Object.keys(localStorage).some(k=>k.startsWith('abagus-cloudkey-local-v1'))"))
    errs += pg3.errors; ctx3.close()

    # ---------- cancel paths ----------
    ctx4, pg4 = new_page(b); signup(pg4, 'Cancel Case', '9000000002'); pick_account_key(pg4)
    pg4.set_input_files('#lockFileInput', [{'name': 'n.txt', 'mimeType': 'text/plain', 'buffer': b'x'}])
    pg4.click('#lockBtn'); pg4.wait_for_selector('#ckCode'); pg4.click('#ckNo'); pg4.wait_for_timeout(600)
    check('cancelling the recovery-code step creates nothing and saves nothing', 'Cancelled' in pg4.inner_text('#lockMsg') and not (fb(pg4)['docs'].get('users/' + [u for u in fb(pg4)['users'].values()][0]['uid'], {}).get('cloudKey')) and pg4.is_enabled('#lockBtn'))
    errs += pg4.errors; ctx4.close()

    # ---------- signed out: clear instruction ----------
    ctx5, pg5 = new_page(b); pick_account_key(pg5)
    check('signed out: the panel says sign-in is needed', 'Sign in' in pg5.inner_text('#lockAkChip') and pg5.is_visible('#akSignInBtn'))
    pg5.set_input_files('#lockFileInput', [{'name': 'n.txt', 'mimeType': 'text/plain', 'buffer': b'x'}]); pg5.click('#lockBtn'); pg5.wait_for_timeout(900)
    check('signed out: encrypting explains it and opens sign-in', 'Sign in' in pg5.inner_text('#lockMsg') and pg5.is_visible('#acctDialog'))
    errs += pg5.errors; ctx5.close()

    # ---------- state bugs reported by the owner ----------
    # (1) Firestore unreachable: the dialog must not claim a key exists
    ctx6, pg6 = new_page(b); signup(pg6, 'State Case', '9000000003')
    pg6.evaluate("window.__fb.fsFail = true")
    pg6.click('#acctChip .acct-id'); pg6.wait_for_timeout(400)
    pg6.click('#acdCkBtn'); pg6.wait_for_timeout(1500)
    lab = pg6.inner_text('#acdCkBtn')
    check('account unreachable: button never says "Add this device" for a key that does not exist', 'Add this device' not in lab, lab)
    pg6.evaluate("window.__fb.fsFail = false"); errs += pg6.errors; ctx6.close()

    # (2) one phone, two accounts: the second account must get its own key, not silently reuse the first
    ctx7, pg7 = new_page(b); signup(pg7, 'First Owner', '9000000004'); pick_account_key(pg7)
    c1 = {}
    def make1():
        pg7.wait_for_selector('#ckCode'); c1['v'] = pg7.inner_text('#ckCode').strip(); pg7.check('#ckSaved'); pg7.click('#ckGo')
    f1 = lock(pg7, make1)
    pg7.evaluate("document.getElementById('signOutBtn').click()"); pg7.wait_for_timeout(500)
    signup(pg7, 'Second Owner', '9000000005'); pg7.click('#tabLockBtn'); pick_account_key(pg7)
    check('second account on the same phone is told to set up its own key', 'Set up' in pg7.inner_text('#lockAkChip') or 'first use' in pg7.inner_text('#lockAkChip'), pg7.inner_text('#lockAkChip'))
    c2 = {}
    def make2():
        pg7.wait_for_selector('#ckCode', timeout=8000); c2['v'] = pg7.inner_text('#ckCode').strip(); pg7.check('#ckSaved'); pg7.click('#ckGo')
    f2 = lock(pg7, make2)
    d7 = fb(pg7)
    uid2 = d7['users']['m919000000005@abagus-bd19f.firebaseapp.com']['uid'] if 'm919000000005@abagus-bd19f.firebaseapp.com' in d7['users'] else None
    check('second account got a new key and recovery code', c2.get('v') and c2['v'] != c1['v'] and uid2 and d7['docs']['users/' + uid2].get('cloudKey'))
    # the first account's file still opens by the key it was made with, even signed out of that account
    pg7.evaluate("document.getElementById('signOutBtn').click()"); pg7.wait_for_timeout(500)
    unlock_start(pg7, f1); pg7.click('#unlockBtn')
    check('a file opens by its own key id while signed out, no account needed on its phone', finish_unlock(pg7) == DATA)
    errs += pg7.errors; ctx7.close()

    # (3) the account lost its server record but the phone still has the key: it is repaired with a new recovery code
    ctx8, pg8 = new_page(b); signup(pg8, 'Heal Case', '9000000006'); pick_account_key(pg8)
    def make3():
        pg8.wait_for_selector('#ckCode'); pg8.check('#ckSaved'); pg8.click('#ckGo')
    lock(pg8, make3)
    d8 = fb(pg8); u8 = d8['users']['m919000000006@abagus-bd19f.firebaseapp.com']['uid']
    pg8.evaluate("(u)=>{ delete window.__fb.docs['users/'+u].cloudKey }", u8)
    heal = {}
    def make4():
        pg8.wait_for_selector('#ckCode', timeout=8000); heal['v'] = pg8.inner_text('#ckCode').strip(); pg8.check('#ckSaved'); pg8.click('#ckGo')
    lock(pg8, make4)
    d8 = fb(pg8)
    check('missing server key is re-published with a new recovery code', heal.get('v') and d8['docs']['users/' + u8].get('cloudKey'), str(heal))
    errs += pg8.errors; ctx8.close()

    # (4) a phone that cannot do PRF must not leave a half-made key on the server
    ctx9, pg9 = new_page(b, prf=False); signup(pg9, 'No Prf', '9000000007'); pick_account_key(pg9)
    pg9.set_input_files('#lockFileInput', [{'name': 'n.txt', 'mimeType': 'text/plain', 'buffer': b'x'}])
    pg9.click('#lockBtn'); pg9.wait_for_timeout(3500)
    check('no recovery code is shown for a key that could never work on this phone', not pg9.is_visible('#ckCode'))
    d9 = fb(pg9); u9 = d9['users']['m919000000007@abagus-bd19f.firebaseapp.com']['uid']
    check('failed passkey step leaves NO key on the server', not d9['docs'].get('users/' + u9, {}).get('cloudKey'), str(d9['docs'].get('users/' + u9)))
    check('and the user is told why', 'PRF' in pg9.inner_text('#lockMsg') or 'passkey' in pg9.inner_text('#lockMsg').lower(), pg9.inner_text('#lockMsg')[:90])
    errs += pg9.errors; ctx9.close()

    # ---------- the exact flow reported: set up from the Account dialog, then add a second phone ----------
    ctxA, pgA = new_page(b); signup(pgA, 'Dialog Flow', '9000000008')
    pgA.click('#acctChip .acct-id'); pgA.wait_for_timeout(400)
    check('no key yet: the dialog offers Set up (not Add this device)', pgA.inner_text('#acdCkBtn') == 'Set up Abagus key' and 'Not created' in pgA.inner_text('#acdCkChip'))
    pgA.click('#acdCkBtn'); pgA.wait_for_selector('#ckCode', timeout=15000)
    codeD = pgA.inner_text('#ckCode').strip(); pgA.check('#ckSaved'); pgA.click('#ckGo')
    pgA.wait_for_function("()=>/Ready/.test(document.getElementById('acdCkChip').textContent)", timeout=20000)
    dA = fb(pgA); uA = dA['users']['m919000000008@abagus-bd19f.firebaseapp.com']['uid']
    check('Set up creates the key: server has it and this phone says ready', dA['docs']['users/' + uA].get('cloudKey') and pgA.inner_text('#acdCkBtn') == 'Test it')
    stateA = dict(dA, cur=None, ls=[]); errs += pgA.errors; ctxA.close()
    ctxB, pgB = new_page(b, stateA); signin(pgB, '9000000008')
    pgB.click('#acctChip .acct-id'); pgB.wait_for_timeout(500)
    check('key exists: the second phone now offers Add this device', pgB.inner_text('#acdCkBtn') == 'Add this device', pgB.inner_text('#acdCkBtn'))
    pgB.click('#acdCkBtn'); pgB.wait_for_selector('#ckIn'); pgB.fill('#ckIn', '  ' + codeD + '\n'); pgB.click('#ckGo')
    pgB.wait_for_function("()=>/Ready/.test(document.getElementById('acdCkChip').textContent)", timeout=20000)
    check('pasting the code (with stray spaces) adds the second phone', pgB.inner_text('#acdCkBtn') == 'Test it')
    errs += pgB.errors; ctxB.close()
    check('no uncaught page errors', not errs, str(errs[:2]))
    b.close()
print(f'{sum(res)}/{len(res)} passed'); sys.exit(0 if all(res) else 1)
