"""Group security upgrade (simple Firebase storage): Google sign-in, single-use invites, safety presets, emergency freeze, step-up.
Run: python tests/test_groups3.py"""
import os, sys, json, re
sys.path.insert(0, os.path.dirname(__file__))
import fbshared as F
from fbshared import new_page, sync_playwright
res = []
def check(n, c, e=''): res.append(bool(c)); print('PASS' if c else 'FAIL', n, e if not c else '')
PW = 'correct horse battery 42'
def signup(pg, user, num):
    pg.click('#phoneSignInBtn'); pg.fill('#acdUser', user); pg.fill('#acdCc', '+91'); pg.fill('#acdNum', num); pg.fill('#acdPass', PW); pg.fill('#acdPass2', PW); pg.click('#acdSubmit')
    pg.wait_for_function("()=>!document.getElementById('acctDialog').open", timeout=15000); pg.wait_for_timeout(600)
def key_dialog(pg): pg.wait_for_selector('#ckCode', timeout=20000); pg.check('#ckSaved'); pg.click('#ckGo')
def to_groups(pg): pg.goto(F.GROUPS_URL); pg.wait_for_selector('#grpNewName,#gpSignIn,[data-groups-open]', timeout=15000); pg.wait_for_timeout(700)
def tab(pg, n): pg.click(f'[data-tab="{n}"]'); pg.wait_for_timeout(600)
def wait_group(pg):
    pg.wait_for_selector('[data-tab="files"]', timeout=30000)
    if pg.get_attribute('[data-tab="files"]', 'aria-selected') != 'true': pg.click('[data-tab="files"]')
    pg.wait_for_timeout(500)
def reopen(pg): pg.evaluate("AbagusGroups._lock()"); pg.wait_for_selector('.grp-row'); pg.click('.grp-row >> nth=0'); wait_group(pg)
def invite(pg, uses=None, days=None):
    tab(pg, 'invites')
    if uses is not None: pg.select_option('#grpUses', str(uses))
    if days is not None: pg.select_option('#grpDays', str(days))
    pg.click('#grpMkInvite'); pg.wait_for_selector('#grpCodeText'); return pg.inner_text('#grpCodeText').strip()
def try_join(pg, code):
    pg.fill('#grpCode', code); pg.click('#grpJoin'); pg.wait_for_timeout(2500)
    if pg.locator('#grpHonor').count(): pg.check('#grpHonor'); pg.click('#grpJoinGo'); return True
    return False
def gdoc(gid): return F.DB['docs'][f'groups/{gid}']
def members(gid): return {k.split('/')[3]: v for k, v in F.DB['docs'].items() if k.startswith(f'groups/{gid}/members/') and k.count('/') == 3}
IMG_JS = """async()=>{const c=document.createElement('canvas');c.width=40;c.height=30;const x=c.getContext('2d');x.fillStyle='#c33';x.fillRect(0,0,40,30);const b=await new Promise(r=>c.toBlob(r,'image/png'));const a=new Uint8Array(await b.arrayBuffer());let s='';for(const v of a)s+=String.fromCharCode(v);return btoa(s)}"""

with sync_playwright() as p:
    b = p.chromium.launch()
    ctxA, A = new_page(b); signup(A, 'Owner One', '9400000001'); to_groups(A)
    A.fill('#grpNewName', 'Vault Club'); A.click('#grpCreate'); key_dialog(A); wait_group(A)
    gid = [k.split('/')[1] for k in F.DB['docs'] if k.startswith('groups/') and k.count('/') == 1][0]
    import base64
    IMG = base64.b64decode(A.evaluate(IMG_JS))
    A.set_input_files('#grpUpload', [{'name': 'p.png', 'mimeType': 'image/png', 'buffer': IMG}]); A.wait_for_selector('.grp-tile', timeout=30000)
    fid = [k.split('/')[3] for k in F.DB['docs'] if k.startswith(f'groups/{gid}/files/') and k.count('/') == 3][0]

    # ---------- single-use invites ----------
    tab(A, 'invites')
    check('invites default to ONE person and ONE day (the safest choice)', A.input_value('#grpUses') == '1' and A.input_value('#grpDays') == '1')
    code = invite(A)
    iid = [k.split('/')[1] for k in F.DB['docs'] if k.startswith('invites/')][0]
    check('the invite is stored with a use limit of 1', F.DB['docs'][f'invites/{iid}'].get('maxUses') == 1)
    ctxB, B = new_page(b); signup(B, 'Member Two', '9400000002'); to_groups(B)
    B.fill('#grpCode', code); B.click('#grpJoin'); B.wait_for_selector('#grpHonor'); B.check('#grpHonor'); B.click('#grpJoinGo'); key_dialog(B); wait_group(B)
    uidB = [u for u in F.DB['users'].values() if u['displayName'] == 'Member Two'][0]['uid']
    m = members(gid)[uidB]
    check('the new member is an unflagged plain member', m['role'] == 'member' and m['flagged'] is False and m['violations'] == 0)
    check('the one-person code switched itself off and counted its use', F.DB['docs'][f'invites/{iid}']['active'] is False and F.DB['docs'][f'invites/{iid}']['uses'] == 1)
    ctxC, C = new_page(b); signup(C, 'Late Three', '9400000003'); to_groups(C)
    joined = try_join(C, code)
    check('a second person using the same one-person code is turned away', not joined or not any(v.get('name') == 'Late Three' for v in members(gid).values()))
    uidC = [u for u in F.DB['users'].values() if u['displayName'] == 'Late Three'][0]['uid']
    denied = C.evaluate(f"async()=>{{try{{await VaultDB.set('groups/{gid}/members/{uidC}',{{uid:'{uidC}',name:'Late Three',role:'member',wrappedKey:{{}},joinedAt:'x',inviteId:'{iid}',flagged:false,violations:0}});return 'ok'}}catch(e){{return e.code}}}}")
    check('even a hand-made request with the used-up code is refused by the database rules', denied == 'permission-denied', str(denied))
    tab(A, 'invites'); A.wait_for_timeout(600); check('the used-up code no longer appears as active', 'No active codes' in A.inner_text('#grpInvList'))
    invite(A, uses=5, days=7); tab(A, 'invites'); A.wait_for_timeout(600)
    check('a limited code shows how many uses it has', 'used 0 of 5' in A.inner_text('#grpInvList'), A.inner_text('#grpInvList')[:200])

    # ---------- safety presets ----------
    tab(A, 'settings')
    check('three safety levels are offered and the new group is on Standard', A.locator('.gp-preset').count() == 3 and A.get_attribute('[data-preset=standard]', 'aria-checked') == 'true')
    A.click('[data-preset=strict]'); A.wait_for_function("()=>document.querySelector('[data-preset=strict]')&&document.querySelector('[data-preset=strict]').getAttribute('aria-checked')==='true'", timeout=20000); A.wait_for_timeout(500)
    st = gdoc(gid)['settings']
    check('Strict applies every protection at once', st['watermark'] == 'full' and st['idleMin'] == 1 and st['vaultShare'] is False and st['memberUpload'] is False, str(st))
    tab(A, 'settings'); check('the fine-tune controls follow the preset', A.input_value('#grpIdle') == '1' and A.input_value('#grpWm') == 'full')
    check('the change is in the activity log', any(k.startswith(f'groups/{gid}/log/') and v.get('type') == 'policy' for k, v in F.DB['docs'].items()))
    A.select_option('#grpIdle', '3'); A.wait_for_timeout(900)
    check('changing one control by hand moves the group to "custom"', gdoc(gid)['settings']['idleMin'] == 3 and A.locator('.gp-preset.on').count() == 0)
    A.click('[data-preset=relaxed]'); A.wait_for_function("()=>document.querySelector('[data-preset=relaxed]')&&document.querySelector('[data-preset=relaxed]').getAttribute('aria-checked')==='true'", timeout=20000); A.wait_for_timeout(400)
    check('Relaxed lets members upload, loosens the lock and only warns on a capture', gdoc(gid)['settings']['memberUpload'] is True and gdoc(gid)['settings']['idleMin'] == 10 and gdoc(gid)['policy'] == 'warn')
    check('the database rules refuse a settings value outside the allowed list', A.evaluate(f"async()=>{{try{{await VaultDB.set('groups/{gid}',{{settings:{{idleMin:7}}}},true);return 'ok'}}catch(e){{return e.code}}}}") == 'permission-denied')
    A.click('[data-preset=standard]'); A.wait_for_function("()=>document.querySelector('[data-preset=standard]').getAttribute('aria-checked')==='true'", timeout=20000)

    # ---------- step-up: fingerprint again for sensitive actions ----------
    A.evaluate("()=>{window.__gk=0;const o=CloudKey.getKey;window.__origGk=o;CloudKey.getKey=function(){window.__gk++;return o.apply(this,arguments)}}")
    tab(A, 'members'); A.wait_for_timeout(800)
    A.click(f"[data-uid='{uidB}'] button:has-text('Make admin')"); A.wait_for_timeout(2500)
    check('making someone an admin asks for the fingerprint again', A.evaluate("()=>window.__gk") >= 1 and members(gid)[uidB]['role'] == 'admin', str(A.evaluate("()=>window.__gk")))
    A.evaluate("()=>{CloudKey.getKey=function(){return Promise.reject({code:'cancelled'})}}")
    tab(A, 'members'); A.wait_for_timeout(800)
    A.click(f"[data-uid='{uidB}'] button:has-text('Remove')"); A.wait_for_timeout(2000)
    check('if the fingerprint check is cancelled, the member is NOT removed', uidB in members(gid))
    A.evaluate("()=>{CloudKey.getKey=window.__origGk}")

    # ---------- emergency freeze (enforced by the database rules) ----------
    tab(A, 'settings'); A.click('#grpFreeze'); A.wait_for_selector('.gp-frozen', timeout=20000)
    check('the owner can freeze the group and sees the banner', gdoc(gid).get('frozen') is True and 'frozen' in A.inner_text('.gp-frozen').lower())
    reopen(B); B.wait_for_timeout(800)
    check('a member sees the frozen banner and no files', B.locator('.gp-frozen').count() == 1 and B.locator('.grp-tile').count() == 0)
    rd = lambda pg: pg.evaluate(f"async()=>{{try{{await VaultDB.get('groups/{gid}/files/{fid}/chunks/0');return 'ok'}}catch(e){{return e.code}}}}")
    check('the database refuses a frozen group\'s file data to an admin member', rd(B) == 'permission-denied', rd(B))
    check('the owner can still read it', rd(A) == 'ok')
    code2 = invite(A, uses=1, days=1)
    to_groups(C); joined = try_join(C, code2); C.wait_for_timeout(2000)
    check('nobody can join a frozen group', not any(v.get('name') == 'Late Three' for v in members(gid).values()))
    to_groups(A); A.wait_for_selector('.grp-row'); A.click('.grp-row >> nth=0'); wait_group(A); tab(A, 'settings'); A.click('#grpFreeze'); A.wait_for_function("()=>!document.querySelector('.gp-frozen')", timeout=20000)
    check('unfreezing restores access', gdoc(gid).get('frozen') is False and rd(B) == 'ok')
    check('freeze and unfreeze are in the activity log', {v.get('type') for k, v in F.DB['docs'].items() if k.startswith(f'groups/{gid}/log/')} >= {'freeze', 'unfreeze'})
    check('only the owner can freeze (an admin member is refused)', B.evaluate(f"async()=>{{try{{await VaultDB.set('groups/{gid}',{{frozen:true}},true);return 'ok'}}catch(e){{return e.code}}}}") == 'permission-denied')
    errs = A.errors + B.errors + C.errors
    check('no uncaught page errors', not errs, str(errs[:3]))
    b.close()
print(f'{sum(res)}/{len(res)} passed'); sys.exit(0 if all(res) else 1)
