# Private groups (own page: groups.html)

Needs a mobile-number account (see `ACCOUNTS.md`) and the updated `firestore.rules` published. Nothing else to set up.
The **Groups** button in the Vault header opens the page. It has its own strict security policy and shares your sign-in.

## What it does
- **Create a group** and you are its **owner**. The owner can make others **admins** (shared power) and take it back.
- **Invite codes:** an admin creates a code (valid 1, 7 or 30 days). A new person enters it, accepts the honor code and joins. Admins can turn a code off. A code is shown only when it is made.
- **Admins** upload, delete anything, remove members, clear flags, manage invites and change settings. **Members** view, and can upload too if an admin allows it.
- **Files up to 120 MB**, photos and videos, kept in 700 KB encrypted pieces.
- **Profile pictures:** yours (Groups page) and the group's (Settings). Members' pictures and the group picture and description are encrypted with the group key; the server cannot read them.
- **Settings (admins):** group name, description and picture; members can upload (off by default); share locked files from the Vault (on by default); what happens on a capture attempt (pause access, or warn and log); name tag on photos and videos (small corner tag, full pattern, or off); how long until the group locks on a device (1, 3 or 10 minutes); invite codes; activity log.
- **Passkey-protected:** each member keeps the group key locked by their own Abagus key. Opening a group asks for fingerprint, face or PIN. The key lives in memory only.
- **Encrypted before upload:** the server holds ciphertext only: files, thumbnails, names, descriptions, pictures, and file names in the log.

## Send a locked file from the Vault to the group
On the Vault page, choose **Group** as the way to unlock, pick the group, and encrypt. The file is locked with the group's key and sent to the group. Every member opens it with their own fingerprint, face or PIN (they tap the file in the group, the Vault opens with it loaded, press Unlock). People outside the group cannot open it. Only admins can do this, or members if "members can upload" is on, and only if the group allows locked files from the Vault. Header flag 128 (v7), with the group's 8-byte id hash after the header.

## Screenshots and screen recording
**No website can stop a screenshot or a screen recording**, and nothing can change a capture that was already taken. Browsers cannot see the phone's own capture tools. What the web page does:
- Hides everything when the window loses focus or the tab is hidden.
- Catches the common capture shortcuts (Print Screen, Win+Shift+S, Shift+Cmd+3/4/5, print) and cancels them.
- Adds a **small name tag** in a corner of every photo and video (switchable, or a full pattern if an admin prefers), so a leak can be traced.
- No right-click menu, no drag, no download button, no picture-in-picture.
- **When a capture attempt is caught the member is flagged.** The open photo turns into the middle-finger emoji, every tile shows only that emoji, and the **server refuses to send that member any photo or video data** until an admin clears them. They cannot clear themselves or leave and rejoin to shed the flag.
- **Gaps:** a hardware-button screenshot on a phone raises no event in a browser, and filming the screen with another phone cannot be seen.

**The only real block is a native app.** `native/` is a small Android/iOS wrapper (Capacitor). On Android it sets the operating system's own secure flag while a group is open, so screenshots fail and recordings are black. iOS cannot block screenshots at all. It was not built or tested in the environment this was written in: see `native/README.md`.

## Limits
- **Removing someone** stops everything further (the server refuses). It cannot take back files they already saved. A flagged member can still decrypt a locked Vault file they already hold, because the key is theirs. For a hard reset, make a new group.
- **Storage** is Firestore. A 120 MB file is about 172 writes and, each time it is viewed, 172 reads, plus its share of the 1 GiB free storage. Your project is on Blaze, so overage is billed (cents). Videos are fully decrypted in memory before they play, so very large ones can be heavy on a phone.
- **Lose the Abagus key** (recovery code and every device) and you lose access to the groups it protects.
- **Moderation:** the content is encrypted, so Abagus cannot see or remove it. Group admins are responsible for what they upload and allow.

## Data layout (all in Firestore)
`groups/<gid>` (name, owner, policy, settings, encrypted description and picture) with `members/<uid>`, `files/<fid>` (+ `chunks/`), `thumbs/<fid>`, `invites/<id>` and `log/<id>`. Top-level `invites/<id>` is what a new person uses to join. `users/<uid>/groups/<gid>` is each person's own list. `users/<uid>.avatar` is your profile picture (readable only by you).

## Rules were not run against the real engine
`tests/test_groups.py` (55 checks) and `tests/test_groups2.py` (36 checks) run against a fake backend that models the key rules. After publishing `firestore.rules`, try the Rules Playground in the Firebase console with an owner, an admin, a member, a flagged member and an outsider.


## Added in the twenty-fifth pass
- **Google accounts can use groups too**, not only mobile-number accounts. Sign in with a mobile number or "Continue with Google" on the Groups page. A mobile member can join a Google-owned group and the other way round.
- **Safety level**: Relaxed / Standard / Strict presets (Settings). One tap sets member uploads, Vault sharing, name-tag style, auto-lock and what happens on a caught capture. Changing a single control by hand shows the level as "custom".
- **Invites**: default is ONE person and ONE day. A one-person code switches itself off the moment someone joins; limited codes show "used 2 of 5". Without a server this is enforced by the database rules plus the joiner's own request, so a determined person with a valid code and a modified browser could in theory reuse a one-person code once or twice before an admin notices. Admins can see and revoke codes any time.
- **Emergency freeze** (owner, Settings): the database rules immediately refuse every other member's file reads and uploads and block joining. Nothing is deleted; unfreeze any time.
- **Step-up**: removing a member, changing an admin, changing the safety level, freezing and deleting the group ask for the fingerprint / face / PIN again.
- **Profile pictures** (yours and the group's): a small editor to pick or take a photo, drag, zoom and save a 256 x 256 picture. Hidden photo data (location, camera) is removed, sideways phone photos are straightened, and only still images up to 15 MB are accepted. In a group your picture is encrypted with the group key.
- **Motion**: groups rise in one after another, the unlock screen shows a spinning lock, loading shows placeholders. Everything respects "reduce motion".
- Files are stored in Firestore (as before), up to 120 MB each in 700 KB encrypted pieces, so there is no extra server or storage account to set up.

## Added in Upgrade V2 (navigation, Discover, gallery)
- **Navigation:** Home, Groups and Dashboard links on every page (a bottom tab bar on phones). The Home page has a Groups button with a "New" badge in its main bar. The Dashboard link is shown to Google sign-ins, as before.
- **Discover groups (Groups page):** a ranked directory with search and the Top Ranked, Newest and My Groups views. Gold, silver and bronze mark ranks 1 to 3. Each card shows the group letter avatar, public line, member count and file count, and Open Group or Join Group. Joining is still by invite code: Join Group takes you to the code box.
- **Private stays private.** A new group is not listed. The **owner** can switch on *Discoverability* in Settings (fingerprint, face or PIN asked first) and write one public line (140 characters). Only then does the server publish `publicGroups/<gid>` with exactly: `name, publicDesc, memberCount, mediaCount, createdAt, v`. Never copied: members, files, file names, invite codes, the private description, the group picture, settings or keys.
- **Counts cannot be faked.** `functions/directory.js` (Cloud Functions) writes the summary from the real `members/` and `files/` collections. `firestore.rules` lets signed-in people read `publicGroups` and lets nobody write it. Only the owner can change `discoverable`.
- **Gallery:** All / Photos / Videos / Documents filters with counts, Grid or Compact layout (remembered), play badge on videos, drag-and-drop upload with a progress bar and Retry, and a lightbox with previous/next, a counter, arrow keys, Esc and swipe. "Documents" are locked files sent from the Vault with the Group method, so they stay encrypted for members. **There is still no download button**, because the group's capture policy is unchanged.
- **Fix:** the entrance-animation observer used to be started inside the photo viewer (one extra copy every time a photo was opened, and no animation until the first photo was opened). It now starts once.

### To switch Discover on
1. Publish `firestore.rules`.
2. `firebase deploy --only functions:directoryOnGroup,functions:directoryOnMember,functions:directoryOnFile` (Blaze plan, already in use).
3. In a group: Settings, Discoverability. The entry appears after a few seconds. Until the functions are deployed the directory simply shows its empty state.
