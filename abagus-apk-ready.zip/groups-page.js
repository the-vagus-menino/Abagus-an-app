/* Groups page glue: toast, theme, header account button. Plain script (the page's security policy forbids inline scripts). */
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var timer = null;
  window.showToast = function (type, message, ms) {
    var t = $('gpToast'); if (!t) return;
    t.textContent = message; t.className = 'gp-toast show ' + (type || 'info'); t.setAttribute('role', type === 'error' ? 'alert' : 'status');
    clearTimeout(timer); timer = setTimeout(function () { t.className = 'gp-toast'; }, ms || 4200);
  };
  // theme: follows the system, same preference key as the Vault page when present
  var root = document.documentElement;
  function apply(m) { root.setAttribute('data-theme', m); var b = $('gpTheme'); if (b) b.setAttribute('aria-pressed', m === 'dark' ? 'true' : 'false'); }
  var saved = null; try { saved = localStorage.getItem('abagus-gp-theme'); } catch (_) {}
  apply(saved || (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));
  document.addEventListener('DOMContentLoaded', function () {
    var b = $('gpTheme'); if (b) b.addEventListener('click', function () { var n = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark'; apply(n); try { localStorage.setItem('abagus-gp-theme', n); } catch (_) {} });
    window.addEventListener('abagus:user', function (e) {
      var d = e.detail || {}, who = $('gpWho'), av = $('gpAcct'); window.__gpSigned = !!d.uid;
      if (who) who.textContent = d.uid ? (d.name || 'Account') : 'Sign in';
      var dn = $('gpNavDash'); if (dn) { dn.classList.toggle('hidden', !d.uid); dn.setAttribute('href', d.google ? 'dashboard.html' : 'me.html'); }   // the owner panel link, shown to Google sign-ins like on the Home page
      if (av) av.setAttribute('aria-label', d.uid ? 'Your account' : 'Sign in');
    });
    var a = $('gpAcct'); if (a) a.addEventListener('click', function () { if (window.AbagusAccount) window.AbagusAccount.open(window.__gpSigned ? undefined : 'signin'); });
  });
})();
