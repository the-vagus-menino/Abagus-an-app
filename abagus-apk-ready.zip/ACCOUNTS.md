# Mobile-number accounts: one-time setup (about 5 minutes, all free)

1. **Firebase console -> Authentication -> Sign-in method -> Email/Password -> Enable.**
   (Mobile accounts use it behind the scenes; nobody ever types an email.)
2. **Firebase console -> Firestore Database -> Create database** (production mode, any region).
3. **Firestore -> Rules**: paste the contents of `firestore.rules` and **Publish** (or run `firebase deploy --only firestore:rules`). The publish step checks the syntax; if it reports an error, send me the message.
4. Deploy the site. The Content-Security-Policy now also allows `https://firestore.googleapis.com`.

## How it behaves
- Sign up with username + mobile number (+ country code) + password. Sign in with mobile number + password.
- **One account per mobile number.** The sign-in ID is derived from `+<country><number>` (e.g.
  `m919178712507@abagus-bd19f.firebaseapp.com`), so Firebase itself rejects a second account.
  Leading zeros are dropped, so `09178712507` and `9178712507` are the same number.
- **The number is not verified.** SMS codes are a paid service, so they are not used. Anyone can register a
  number that is not theirs. If you later want proof of ownership, Firebase Phone Auth can be added.
- **No password reset** (there is no real mailbox). A forgotten password means a new account with a new number.
- The profile record (`users/<uid>`) holds: `username`, `mobile`, `provider`, `createdAt`, `updatedAt`,
  `faceAuth` (true once AnskarKey is linked) and `authMethods` (`password: true`, `anskarKey: {credentialId, createdAt}`).
  The credential id is not a secret. **No photo, fingerprint, face data, password or key is stored.**
- After signing in on a new phone, Abagus finds the AnskarKey credential id on the account, so unlocking a file
  there asks for that phone's face, fingerprint or PIN (the passkey must have synced to it through the Google or Apple account).
- Drive import and the dashboard stay Google-only.

## AnskarKey with your Abagus account (no Google or Apple needed)
In the AnskarKey panel choose **My Abagus account** (needs a mobile-number account).
- The first time you get a **recovery code** (8 groups of 4). Save it away from the phone. Abagus cannot show it again.
- The account stores only your master key **encrypted by that code** (`users/<uid>.cloudKey`). Abagus never has the code or the key, so it cannot open any file.
- Each phone keeps the master key locked by its **own** passkey (fingerprint, face or PIN). Nothing is synced by Google or Apple.
- **New phone:** sign in with mobile number and password, then type the recovery code once. After that, biometric only.
- A file made this way has header flag 64 and the key's public id (8 bytes derived from the key) after the header.
- **If you lose the recovery code and every device, the files cannot be opened by anyone**, Abagus included. That is the price of Abagus not being able to read them.
- Anyone who steals your account password still needs the recovery code, or your unlocked phone, to get the key.

