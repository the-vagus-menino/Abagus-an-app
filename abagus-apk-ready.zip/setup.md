# Setup: daily Gemini → PR pipeline, Drive import, owner panel

This adds three things to Abagus, all reviewed code but **none of it is live until you
finish the steps below** — I can't create your GitHub repo, Google Cloud project, or API
keys for you.

1. A scheduled Cloud Function that asks Gemini to propose one small improvement a day and
   opens a **pull request** for it. It never merges anything by itself.
2. "Import from Google Drive" buttons on the encrypt/decrypt screens.
3. An **owner panel** on `dashboard.html`, visible only to `partha9178712507@gmail.com`,
   where you can approve/reject Gemini's proposed PRs and see basic stats.

Read the whole thing once before running anything — a couple of steps (branch protection,
the CSP change) matter for safety, not just for it to work.

## 0. Prerequisites

- The project must be on **GitHub** (the daily job opens PRs there). If it isn't yet,
  `git init`, push it to a new repo, and note the owner/repo name.
- Firebase project must be on the **Blaze (pay-as-you-go) plan** — Cloud Scheduler and
  outbound network calls from Functions both require it. You already use Gemini from
  `functions/index.js`, so this is likely already true.

## 1. GitHub token

Create a GitHub **fine-grained personal access token**, scoped to just this repo, with:
- Contents: Read and write
- Pull requests: Read and write

Store it as a Firebase secret:

```
firebase functions:secrets:set GITHUB_TOKEN
```

## 2. Repo + schedule config

Set the plain (non-secret) function config so the pipeline knows which repo to open PRs
against:

```
firebase functions:config:set github.owner="YOUR_GH_USERNAME" github.repo="YOUR_REPO_NAME"
```

Then in `functions/lib/github.js`, `repoSlug()` reads `process.env.GITHUB_OWNER` /
`GITHUB_REPO` — with `firebase-functions` v7 + Node 22, set these directly as environment
variables in `functions/.env` instead (config: set is being retired):

```
# functions/.env
GITHUB_OWNER=YOUR_GH_USERNAME
GITHUB_REPO=YOUR_REPO_NAME
```

Edit the schedule in `functions/dailyImprovement.js` if 8pm UTC isn't when you want it to
run — the `schedule` field takes a standard cron string, and you can add a `timeZone` option
(see the `onSchedule` docs).

## 3. Branch protection (recommended)

So the CI workflow actually means something: in GitHub → Settings → Branches, add a rule
for `main` requiring the `basic-checks` status check (from `.github/workflows/ci.yml`) to
pass before merging. That check now does three real things: structure checks, `scripts/guard.mjs`
(fails a PR that alters the crypto core, changes either page's CSP, adds a new script host, or
introduces `eval`), and the end-to-end encrypt/decrypt tests in `tests/`. If *you* deliberately
change one of those, run `node scripts/guard.mjs --update` in the same commit to re-pin. The owner panel's "Approve & merge" button calls GitHub's merge API,
which will then refuse to merge a PR whose checks haven't passed — so a red PR simply can't
be approved through the panel until it's green. 

## 4. Firestore

Enable Firestore (if not already) and deploy the rules added here (`firestore.rules` — it
denies all direct client access except one narrow exception: a signed-in person's own
`users/<uid>` profile record for mobile-number accounts (see `ACCOUNTS.md`). Everything else
goes through the Cloud Functions using the Admin SDK):

```
firebase deploy --only firestore:rules
```

## 5. Deploy the functions

```
firebase deploy --only functions
```

This deploys: the existing `geminiExperience`, plus the new `dailyImprovement`,
`ownerListChanges`, `ownerApproveChange`, `ownerRejectChange`, `ownerStats`, `trackEvent`.

Note the deployed URL base, e.g. `https://us-central1-abagus-bd19f.cloudfunctions.net`.

## 6. Point the dashboard at the new functions

In `dashboard.html`, set:

```js
const OWNER_API_BASE = "https://us-central1-abagus-bd19f.cloudfunctions.net";
```

(Use your actual region/project. Both pages' CSP already allow
`https://us-central1-abagus-bd19f.cloudfunctions.net`; if your region differs, edit the
`connect-src` line in both pages and run `node scripts/guard.mjs --update`.) The rest of the dashboard still calls
`/.netlify/functions/...` for the existing profile/stats endpoints — that's unrelated to
this change and untouched.

Optional, both off until you set them — near the top of the main script in `index.html`:

```js
const STATS_API_BASE = "https://us-central1-abagus-bd19f.cloudfunctions.net"; // feeds the owner-panel counters (trackEvent)
const GEMINI_EXPERIENCE_URL = "…/geminiExperience";                          // cosmetic tagline after an operation
```

Privacy note: `trackEvent` sends only an anonymous counter name. `geminiExperience` sends the
mode and the file **extension** to your function (and on to Gemini) — leave it blank if you
want the strict "nothing about your files leaves the tab" story.

Also add your real deployed frontend origin to `ALLOWED_ORIGINS` in `functions/owner.js`
(and `functions/index.js`'s `geminiExperience`, if not already there).

## 7. Google Drive Picker (file import)

The "Import from Google Drive" buttons need a **browser API key** restricted to the Picker
API only (separate from anything secret — this key is public in the page by design, its
safety comes entirely from the restriction):

1. Google Cloud Console → APIs & Services → Credentials → Create API key.
2. Restrict it: "API restrictions" → limit to **Google Picker API**. Also add an
   "Application restriction" of HTTP referrers, listing your real domain(s).
3. Make sure **Google Picker API** is enabled for the project (APIs & Services → Library).
4. Paste the key into `index.html`:
   ```js
   const GOOGLE_PICKER_API_KEY = "YOUR_KEY_HERE";
   ```

No new OAuth scope was added — importing reuses the existing `drive.file` token the app
already requests for the Drive vault, plus Google's Picker "just-in-time" access, so users
aren't asked to grant broader Drive access than before.

## 8. What Gemini can and can't touch

By design, `functions/dailyImprovement.js` only ever proposes changes to
`ALLOWED_FILES = ["dashboard.html", "index.html"]`. It cannot touch anything under
`functions/`, `firebase.json`, `firestore.rules`, or its own code — widen that list only
with care, and never add `functions/` to it. Every change still requires:
GitHub Actions passing → owner reviews the diff → owner taps "Approve & merge" → your
host's normal deploy-on-push-to-main pipeline (Firebase Hosting / Cloudflare Pages /
Netlify, whichever you use) picks it up from there. Nothing here bypasses that.

## 9. Try it end to end

- Trigger `dailyImprovement` manually once (Cloud Console → Cloud Scheduler → Run now, or
  `firebase functions:shell`) to confirm a PR appears in GitHub.
- Sign into the dashboard as `partha9178712507@gmail.com` — the owner panel should show the
  pending change with Approve/Reject buttons.
- Try the Drive import buttons on the main page.

## Mobile-number accounts, AnskarKey and device lock

See `ACCOUNTS.md` for the three console steps (enable Email/Password, create Firestore, publish `firestore.rules`).
AnskarKey and the device lock need no setup beyond serving the site over https. `account.js` and `anskarkey.js` are
plain static files and are already in the service worker's cache list.
