/* =====================================================================
   ABAGUS self-check: finds problems on this device and fixes the ones that are safe to fix.

   FINDS (on demand, plus a quiet background check): secure context, Web Crypto round trip, IndexedDB / localStorage, the service
   worker and its caches, missing or blocked app files, blocked scripts (CSP), JavaScript errors, connectivity, clock skew, sign-in token, Abagus key, passkey support, free space.
   FIXES: repair app files (unregister the service worker and clear its caches, then reload), ask the browser to keep storage,
   re-run checks. A background repair runs at most ONCE per 10 minutes, and only when one of Abagus's own files failed to load.

   WHAT IT NEVER TOUCHES: keys, passkeys, IndexedDB (including the device key store), localStorage, your files, your account.
   The fixer only touches the Cache Storage and service workers, so it cannot lose key material by construction.
   WHAT IT NEVER RECORDS OR SHARES: file names, passwords, keys, phone numbers, signed links (URLs are cut down to host + path, long
   tokens are masked). Nothing is sent anywhere; "Copy report" only copies text to your clipboard.
   ===================================================================== */
(function () {
  'use strict';
  if (window.AbagusDiag) return;
  var MAX_EVENTS = 60, events = [], dialog = null, results = [], running = false;
  var PAGE = /groups\.html/.test(location.pathname) ? 'groups' : /dashboard/.test(location.pathname) ? 'dashboard' : 'vault';
  // EXPECT = this site's own scripts (a repair can cure these). Sign-in (VaultAuth) comes from Firebase, an outside service: offline it is simply absent, so it is checked separately and never triggers the repair bar.
  // Only parts this page actually loads are expected (the Groups page does not load the encryption carrier, the Vault page does).
  var GLOBAL_FOR = { CloudKey: 'cloudkey.js', AbagusCarrier: 'carrier.js', AbagusGroups: 'groups.js', AbagusAvatar: 'avatar.js' };
  function expected() {
    return Object.keys(GLOBAL_FOR).filter(function (g) { return !!document.querySelector('script[src$="' + GLOBAL_FOR[g] + '"]'); });
  }
  // The self-check screen and its warnings are for the site owner only: nobody else is ever shown them.
  var OWNER_EMAIL = 'partha9178712507@gmail.com', allowed = false;
  var REPAIR_KEY = 'abagus-diag-repair', REOPEN_KEY = 'abagus-diag-reopen';

  /* ---------- privacy: what may be recorded ---------- */
  function clean(s) {
    s = String(s == null ? '' : s);
    s = s.replace(/https?:\/\/[^\s"')<>]+/gi, function (u) { try { var p = new URL(u); return p.origin + p.pathname.replace(/[A-Za-z0-9_-]{20,}/g, '\u2026'); } catch (_) { return '[link]'; } });
    s = s.replace(/[A-Za-z0-9+\/_=-]{32,}/g, '[token]').replace(/\+?\d[\d\s-]{8,}\d/g, '[number]');
    return s.slice(0, 200);
  }
  function pathOf(u) { try { var p = new URL(u, location.href); return (p.origin === location.origin ? '' : p.host) + p.pathname; } catch (_) { return '[file]'; } }
  function record(type, msg, where) {
    msg = clean(msg); if (!msg) return;
    for (var i = 0; i < events.length; i++) if (events[i].type === type && events[i].msg === msg) { events[i].n++; events[i].t = Date.now(); return; }
    events.push({ type: type, msg: msg, where: where ? clean(where) : '', n: 1, t: Date.now() });
    if (events.length > MAX_EVENTS) events.shift();
  }
  var NOISE = /ResizeObserver loop|chrome-extension:|moz-extension:|Script error\.?$|apis\.google\.com|ERR_NAME_NOT_RESOLVED/i;

  window.addEventListener('error', function (e) {
    var t = e.target;
    if (t && t !== window && t.tagName) {                                  // a resource failed to load
      var src = t.src || t.href || ''; if (!src || NOISE.test(src)) return;
      var same = false; try { same = new URL(src, location.href).origin === location.origin; } catch (_) {}
      // a failed file of THIS site can be cured by a repair; a failed outside library (CDN) cannot, so it is only listed, never nagged about
      record(same ? 'file' : 'extfile', t.tagName.toLowerCase() + ' failed to load: ' + pathOf(src));
      if (same && /^(SCRIPT|LINK)$/.test(t.tagName)) autoRepair('a file of this site failed to load');
      return;
    }
    if (NOISE.test(String(e.message || '') + ' ' + String(e.filename || ''))) return;
    record('error', e.message, pathOf(e.filename || '') + (e.lineno ? ':' + e.lineno : ''));
  }, true);
  window.addEventListener('unhandledrejection', function (e) {
    var r = e.reason, m = r && (r.message || r.code || r.name) ? (r.code && r.storage ? 'storage: ' + r.code : (r.message || r.code || r.name)) : String(r);
    if (!NOISE.test(m)) record('promise', m);
  });
  document.addEventListener('securitypolicyviolation', function (e) {
    if (NOISE.test(e.blockedURI || '')) return;
    record('csp', 'blocked by the security policy: ' + e.violatedDirective + (e.blockedURI ? ' (' + (e.blockedURI === 'inline' ? 'inline script' : pathOf(e.blockedURI)) + ')' : ''));
  });

  /* ---------- repair (Cache Storage + service workers ONLY) ---------- */
  async function repairFiles() {
    try { if (navigator.serviceWorker) { var regs = await navigator.serviceWorker.getRegistrations(); await Promise.all(regs.map(function (r) { return r.unregister(); })); } } catch (_) {}
    try { if (window.caches) { var ks = await caches.keys(); await Promise.all(ks.map(function (k) { return caches.delete(k); })); } } catch (_) {}
  }
  function autoRepair(why) {
    try {
      if (!navigator.onLine) return;
      var last = Number(sessionStorage.getItem(REPAIR_KEY) || 0); if (Date.now() - last < 10 * 60 * 1000) return;     // never loop
      sessionStorage.setItem(REPAIR_KEY, String(Date.now()));
    } catch (_) { return; }
    record('repair', 'automatic repair: ' + why);
    repairFiles().then(function () { location.reload(); });
  }

  /* ---------- the checks ---------- */
  function ok(d) { return { status: 'ok', detail: d || '' }; }
  function warn(d, fix) { return { status: 'warn', detail: d, fix: fix }; }
  function fail(d, fix) { return { status: 'fail', detail: d, fix: fix }; }
  var FIX = { repair: { label: 'Repair app files', run: async function () { try { sessionStorage.setItem(REOPEN_KEY, '1'); } catch (_) {} await repairFiles(); location.reload(); return 'reload'; } },
    persist: { label: 'Keep my storage', run: async function () { try { var g = await navigator.storage.persist(); return g ? 'ok' : 'declined'; } catch (_) { return 'declined'; } } } };

  var CHECKS = [
    { id: 'secure', title: 'Secure connection', run: async function () { return window.isSecureContext ? ok('This page is served over https.') : fail('This page is not secure, so encryption and sign-in are switched off by the browser. Open the https address.'); } },
    { id: 'crypto', title: 'Encryption engine', run: async function () {
        try {
          var k = await crypto.subtle.generateKey({ name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']), iv = crypto.getRandomValues(new Uint8Array(12)), d = new Uint8Array([1, 2, 3, 4]);
          var ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv: iv }, k, d), pt = new Uint8Array(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: iv }, k, ct));
          var hk = await crypto.subtle.importKey('raw', new Uint8Array(32), 'HKDF', false, ['deriveBits']); await crypto.subtle.deriveBits({ name: 'HKDF', hash: 'SHA-256', salt: new Uint8Array(16), info: new Uint8Array(1) }, hk, 256);
          return pt.length === 4 && pt[3] === 4 ? ok('AES-256-GCM, HKDF and secure random all work.') : fail('Encryption returned wrong data. Do not encrypt files on this browser.');
        } catch (e) { return fail('This browser cannot run the encryption Abagus needs (' + clean(e && e.name) + '). Update the browser.'); }
      } },
    { id: 'idb', title: 'Device storage (IndexedDB)', run: async function () {
        try {
          var db = await new Promise(function (res, rej) { var r = indexedDB.open('abagus-diag-probe', 1); r.onupgradeneeded = function () { r.result.createObjectStore('p'); }; r.onsuccess = function () { res(r.result); }; r.onerror = function () { rej(r.error); }; r.onblocked = function () { rej(new Error('blocked')); }; });
          await new Promise(function (res, rej) { var tx = db.transaction('p', 'readwrite'); tx.objectStore('p').put(1, 'k'); tx.oncomplete = res; tx.onerror = function () { rej(tx.error); }; });
          db.close(); await new Promise(function (res) { var r = indexedDB.deleteDatabase('abagus-diag-probe'); r.onsuccess = r.onerror = r.onblocked = res; });
          return ok('Read and write work (used to pass encrypted files between pages).');
        } catch (e) { return fail('The browser blocks device storage (private mode, or storage is full). Opening a group file in the Decrypt tab needs it.'); }
      } },
    { id: 'ls', title: 'Saved settings (localStorage)', run: async function () { try { localStorage.setItem('abagus-diag-probe', '1'); localStorage.removeItem('abagus-diag-probe'); return ok('Settings can be saved.'); } catch (_) { return warn('Settings cannot be saved on this browser (private mode?). Everything still works, but choices are forgotten.'); } } },
    { id: 'files', title: 'App files', run: async function () {
        var bad = [], urls = [];
        document.querySelectorAll('script[src],link[rel=stylesheet][href]').forEach(function (e) { var u = e.src || e.href; try { if (new URL(u, location.href).origin === location.origin) urls.push(u); } catch (_) {} });
        urls = urls.filter(function (u, i) { return urls.indexOf(u) === i; });
        await Promise.all(urls.map(async function (u) { try { var r = await fetch(u, { method: 'HEAD', cache: 'no-store' }); if (!r.ok) bad.push(pathOf(u) + ' (' + r.status + ')'); } catch (_) { bad.push(pathOf(u) + ' (unreachable)'); } }));
        var missing = expected().filter(function (n) { return !window[n]; });
        var failed = events.filter(function (e) { return e.type === 'file'; }).map(function (e) { return e.msg; });
        var ext = events.filter(function (e) { return e.type === 'extfile'; }).map(function (e) { return e.msg; });
        if (!(bad.length || missing.length || failed.length) && ext.length) return warn('An outside library did not load: ' + ext.slice(0, 2).join('; ') + '. Check your connection or try again; repairing app files will not help.');
        if (bad.length || missing.length || failed.length) return fail([bad.length ? 'Missing or unreachable: ' + bad.join(', ') + '.' : '', missing.length ? 'Did not start: ' + missing.join(', ') + '.' : '', failed.length ? failed.slice(0, 2).join('; ') + '.' : ''].filter(Boolean).join(' ') + ' This is usually an old cached copy after an update.', 'repair');
        return ok(urls.length + ' files reachable and every part of this page started.');
      } },
    { id: 'csp', title: 'Blocked scripts', run: async function () {
        var v = events.filter(function (e) { return e.type === 'csp'; });
        return v.length ? fail(v.slice(0, 2).map(function (e) { return e.msg; }).join('; ') + '. If you run this site: after editing an inline script run "node scripts/csp-hash.mjs".') : ok('Nothing was blocked by the security policy.');
      } },
    { id: 'errors', title: 'Errors on this page', run: async function () {
        var e = events.filter(function (x) { return x.type === 'error' || x.type === 'promise'; });
        return e.length ? warn(e.slice(-3).map(function (x) { return x.msg + (x.n > 1 ? ' (x' + x.n + ')' : ''); }).join('; ')) : ok('No script errors since this page opened.');
      } },
    { id: 'sw', title: 'Offline copy (service worker)', run: async function () {
        if (!('serviceWorker' in navigator)) return warn('This browser has no service workers, so offline use and install are unavailable.');
        try {
          var reg = await navigator.serviceWorker.getRegistration();
          if (!reg) return warn('Not installed yet. It is set up after the first visit over https.');
          if (reg.waiting) return warn('An update is waiting. Reload the page to use it.', 'repair');
          var names = window.caches ? (await caches.keys()).filter(function (k) { return /^abagus-shell-v/.test(k); }) : [];
          return names.length > 1 ? warn('Old app copies are still stored (' + names.length + ').', 'repair') : ok('Installed' + (names[0] ? ' (' + names[0].replace('abagus-shell-', '') + ')' : '') + '.');
        } catch (_) { return warn('Could not read the service worker state.', 'repair'); }
      } },
    { id: 'net', title: 'Connection', run: async function () {
        if (!navigator.onLine) return warn('You are offline. Encryption and decryption still work; cloud features and sign-in need a connection.');
        try { var r = await fetch(location.pathname, { method: 'HEAD', cache: 'no-store' }); return r.ok ? ok('This site is reachable.') : warn('This site answered with ' + r.status + '.'); } catch (_) { return warn('Could not reach this site. Check your connection.'); }
      } },
    { id: 'clock', title: 'Device clock', run: async function () {
        try {
          var r = await fetch(location.pathname, { method: 'HEAD', cache: 'no-store' }), d = r.headers.get('date'); if (!d) return ok('Could not compare (no server time).');
          var skew = Math.abs(Date.now() - new Date(d).getTime()) / 1000;
          return skew > 600 ? fail('Your clock is off by about ' + Math.round(skew / 60) + ' minutes. Sign-in and cloud links will fail until you set the time automatically.') : skew > 120 ? warn('Your clock is off by about ' + Math.round(skew / 60) + ' minutes. Set the time automatically.') : ok('Your clock matches the server.');
        } catch (_) { return ok('Skipped (offline).'); }
      } },
    { id: 'account', title: 'Sign-in', run: async function () {
        if (PAGE === 'dashboard') return ok('Not used on this page.');
        if (!window.VaultAuth) return warn(navigator.onLine ? 'The sign-in service did not load. Check your connection or any blocker for gstatic.com / firebase, then reload. Encryption still works without it.' : 'The sign-in service could not load because you are offline. Encryption still works.');
        var s = window.AbagusAccount && window.AbagusAccount.session ? window.AbagusAccount.session() : {};
        return s && s.uid ? ok('You are signed in.') : ok('You are not signed in (only needed for groups and your Abagus key).');
      } },
    { id: 'key', title: 'Abagus key on this device', run: async function () {
        if (!window.CloudKey || !window.CloudKey.status) return ok('Not used on this page.');
        var s; try { s = window.CloudKey.status(); } catch (_) { return warn('Could not read the key state.'); }
        return !s.signedIn ? ok('Sign in to use your Abagus key.') : s.localReady ? ok('Your Abagus key is ready on this device.') : warn('Your Abagus key is not set up on this device yet. Set it up in your account to use My Files and automatic cloud copies.');
      } },
    { id: 'passkey', title: 'Passkeys (fingerprint / face / PIN)', run: async function () {
        if (!window.PublicKeyCredential) return warn('This browser has no passkey support, so AnskarKey and the Abagus key are unavailable. Passphrases still work.');
        try { var a = await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable(); return a ? ok('This device can unlock with fingerprint, face or PIN.') : warn('No fingerprint, face or PIN lock is set up on this device. Set a screen lock to use passkeys.'); } catch (_) { return warn('Could not check passkey support.'); }
      } },
    { id: 'space', title: 'Free space', run: async function () {
        if (!navigator.storage || !navigator.storage.estimate) return ok('Cannot measure on this browser.');
        try {
          var e = await navigator.storage.estimate(), free = (e.quota || 0) - (e.usage || 0), persisted = navigator.storage.persisted ? await navigator.storage.persisted() : true;
          if (e.quota && free < 50 * 1048576) return warn('Only about ' + Math.max(0, Math.round(free / 1048576)) + ' MB of browser storage is free.');
          return persisted ? ok('Plenty of space, and the browser will keep it.') : warn('The browser may clear this site\u2019s saved data when the phone is low on space.', 'persist');
        } catch (_) { return ok('Cannot measure.'); }
      } },
    { id: 'features', title: 'Browser features', run: async function () {
        var need = { 'CompressionStream': window.CompressionStream, 'Blob.arrayBuffer': window.Blob && Blob.prototype.arrayBuffer, 'structuredClone': window.structuredClone, 'AbortController': window.AbortController };
        var miss = Object.keys(need).filter(function (k) { return !need[k]; });
        return miss.length ? warn('Missing in this browser: ' + miss.join(', ') + '. Some features may not work; update the browser.') : ok('All needed browser features are present.');
      } },
  ];

  async function run(only) {
    if (running) return results; running = true; var out = [];
    try {
      for (var i = 0; i < CHECKS.length; i++) {
        var c = CHECKS[i]; if (only && only.indexOf(c.id) < 0) continue;
        var r; try { r = await c.run(); } catch (e) { r = warn('This check could not finish (' + clean(e && e.message) + ').'); }
        out.push({ id: c.id, title: c.title, status: r.status, detail: r.detail, fix: r.fix || null });
      }
      if (!only) results = out; return out;
    } finally { running = false; }
  }
  async function fixAll() {
    var did = [], order = ['persist', 'repair'];                         // repair reloads the page, so it goes last
    var need = {}; (results || []).forEach(function (r) { if (r.fix && r.status !== 'ok') need[r.fix] = true; });
    for (var i = 0; i < order.length; i++) { var k = order[i]; if (!need[k]) continue; if (k === 'repair') { did.push('repair'); await FIX.repair.run(); return did; } did.push(k + ':' + await FIX[k].run()); }
    return did;
  }

  /* ---------- report (text only, copied to the clipboard on request) ---------- */
  function report() {
    var L = ['Abagus self-check', new Date().toISOString() + '  page=' + PAGE, ''];
    results.forEach(function (r) { L.push('[' + r.status.toUpperCase() + '] ' + r.title + (r.detail ? ' - ' + r.detail : '')); });
    if (events.length) { L.push('', 'Recent events (cleaned: no names, keys, numbers or links with secrets):'); events.slice(-20).forEach(function (e) { L.push('- ' + e.type + ': ' + e.msg + (e.where ? ' @ ' + e.where : '') + (e.n > 1 ? ' x' + e.n : '')); }); }
    L.push('', 'Browser: ' + clean(navigator.userAgent));
    return L.join('\n');
  }

  /* ---------- the panel ---------- */
  function el(tag, props) { var e = document.createElement(tag); if (props) for (var k in props) { if (k === 'text') e.textContent = props[k]; else if (k === 'class') e.className = props[k]; else if (k.slice(0, 2) === 'on') e.addEventListener(k.slice(2), props[k]); else if (props[k] != null && props[k] !== false) e.setAttribute(k, props[k] === true ? '' : props[k]); } for (var i = 2; i < arguments.length; i++) if (arguments[i]) e.appendChild(arguments[i]); return e; }
  function loadCss() { if (document.getElementById('scCss')) return; var l = el('link', { id: 'scCss', rel: 'stylesheet', href: 'selfcheck.css' }); document.head.appendChild(l); }
  var LABEL = { ok: 'OK', warn: 'Check', fail: 'Problem' };
  function draw() {
    var list = document.getElementById('scList'), sum = document.getElementById('scSum'); if (!list) return; list.textContent = '';
    var bad = results.filter(function (r) { return r.status === 'fail'; }).length, w = results.filter(function (r) { return r.status === 'warn'; }).length;
    sum.textContent = !results.length ? 'Checking\u2026' : bad ? bad + ' problem' + (bad > 1 ? 's' : '') + (w ? ' and ' + w + ' to look at' : '') + ' found.' : w ? 'No problems. ' + w + ' thing' + (w > 1 ? 's' : '') + ' worth a look.' : 'Everything is working.';
    sum.className = 'sc-sum ' + (bad ? 'fail' : w ? 'warn' : 'ok');
    results.forEach(function (r) {
      var li = el('li', { class: 'sc-item ' + r.status, 'data-id': r.id }, el('span', { class: 'sc-badge', text: LABEL[r.status] }), el('div', { class: 'sc-txt' }, el('b', { text: r.title }), el('small', { text: r.detail || '' })));
      if (r.fix && r.status !== 'ok' && FIX[r.fix]) li.appendChild(el('button', { class: 'sc-btn', type: 'button', 'data-fix': r.fix, onclick: async function (ev) { ev.target.disabled = true; var o = await FIX[r.fix].run(); if (o !== 'reload') { await go(); } } , text: FIX[r.fix].label }));
      list.appendChild(li);
    });
  }
  async function go() { var s = document.getElementById('scSum'); if (s) { s.textContent = 'Checking\u2026'; s.className = 'sc-sum'; } await run(); draw(); }
  function build() {
    if (dialog) return dialog; loadCss();
    var msg = el('small', { id: 'scMsg', role: 'status', 'aria-live': 'polite' });
    dialog = el('dialog', { id: 'scDialog', class: 'sc-dialog', 'aria-labelledby': 'scTitle' },
      el('div', { class: 'sc-head' }, el('h2', { id: 'scTitle', text: 'Self-check' }), el('button', { class: 'sc-x', type: 'button', 'aria-label': 'Close', onclick: function () { dialog.close(); }, text: '\u00d7' })),
      el('p', { id: 'scSum', class: 'sc-sum', role: 'status', 'aria-live': 'polite', text: 'Checking\u2026' }),
      el('ul', { id: 'scList', class: 'sc-list' }),
      el('p', { class: 'sc-priv', text: 'Runs on this device only. It never reads or changes your keys, files or settings, and the report never contains file names, passwords, keys or signed links.' }),
      el('div', { class: 'sc-actions' },
        el('button', { class: 'sc-btn', id: 'scRun', type: 'button', onclick: go, text: 'Run checks again' }),
        el('button', { class: 'sc-btn primary', id: 'scFix', type: 'button', onclick: async function () { var did = await fixAll(); msg.textContent = did.length ? 'Fixed: ' + did.join(', ') + '.' : 'Nothing needed fixing automatically.'; if (did.indexOf('repair') < 0) await go(); }, text: 'Fix automatically' }),
        el('button', { class: 'sc-btn', id: 'scCopy', type: 'button', onclick: async function () { try { await navigator.clipboard.writeText(report()); msg.textContent = 'Report copied.'; } catch (_) { var ta = el('textarea', { class: 'sc-ta', readonly: true }); ta.value = report(); dialog.appendChild(ta); ta.select(); msg.textContent = 'Select and copy the text below.'; } }, text: 'Copy report' })), msg);
    document.body.appendChild(dialog); return dialog;
  }
  async function open() { if (!allowed) return; var d = build(); if (!d.open) { if (d.showModal) d.showModal(); else d.setAttribute('open', ''); } results = []; draw(); await go(); var b = document.getElementById('scRun'); if (b) b.focus(); }

  /* ---------- quiet background check: only speaks up when Abagus's own files are broken ---------- */
  function bar(text) {
    if (!allowed || document.getElementById('scBar')) return; loadCss();
    var b = el('div', { id: 'scBar', class: 'sc-bar', role: 'alert' }, el('span', { text: text }),
      el('button', { class: 'sc-btn primary', type: 'button', onclick: function () { FIX.repair.run(); }, text: 'Repair now' }),
      el('button', { class: 'sc-btn', type: 'button', onclick: function () { b.remove(); open(); }, text: 'Details' }),
      el('button', { class: 'sc-btn', type: 'button', 'aria-label': 'Dismiss', onclick: function () { b.remove(); }, text: '\u00d7' }));
    document.body.appendChild(b);
  }
  function quiet() {
    if (!allowed) return;
    var missing = expected().filter(function (n) { return !window[n]; });
    var bad = events.filter(function (e) { return e.type === 'file' || e.type === 'csp'; });
    if (missing.length || bad.length) bar(missing.length ? 'Part of Abagus did not start (' + missing.join(', ') + '). This is usually an old cached copy.' : 'Abagus could not load part of itself. A repair usually fixes it.');
  }

  function applyAccess() {
    document.querySelectorAll('[data-diag-open]').forEach(function (b) { b.style.display = allowed ? '' : 'none'; b.hidden = !allowed; });
    var fab = document.getElementById('scFab');
    if (allowed && !document.querySelector('[data-diag-open]:not(#scFab)') && !fab) {
      fab = el('button', { id: 'scFab', class: 'sc-fab', type: 'button', 'data-diag-open': '', text: 'Self-check', onclick: function () { open(); } }); document.body.appendChild(fab); loadCss();
    }
    if (fab) fab.style.display = allowed ? '' : 'none';
    if (!allowed) { var bar0 = document.getElementById('scBar'); if (bar0) bar0.remove(); if (dialog && dialog.open) dialog.close(); }
  }
  function setUser(d) {
    d = d || {};
    var now = !!(d.uid && d.google && String(d.email || '').trim().toLowerCase() === OWNER_EMAIL);
    if (now !== allowed) { allowed = now; applyAccess(); if (allowed) setTimeout(quiet, 4000); }
  }
  function wire() {
    document.querySelectorAll('[data-diag-open]').forEach(function (b) { b.addEventListener('click', function (e) { e.preventDefault(); open(); }); });
    window.addEventListener('abagus:user', function (e) { setUser(e.detail); });
    addEventListener('hashchange', function () { if (location.hash === '#diagnostics') open(); });
    document.addEventListener('keydown', function (e) { if (allowed && e.altKey && e.shiftKey && (e.key === 'D' || e.key === 'd')) { e.preventDefault(); open(); } });
    try { if (sessionStorage.getItem(REOPEN_KEY)) { sessionStorage.removeItem(REOPEN_KEY); setTimeout(open, 900); } } catch (_) {}
    applyAccess();
  }
  window.AbagusDiag = { _repair: repairFiles, _quiet: quiet, _allowed: function () { return allowed; }, run: function () { return run(); }, fixAll: fixAll, open: open, report: function (kind, msg) { record(kind || 'note', msg); }, events: function () { return events.slice(); }, text: report, _clean: clean };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', wire); else wire();
})();
