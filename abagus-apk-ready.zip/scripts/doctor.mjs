#!/usr/bin/env node
// Abagus project doctor: finds problems in the project files and (with --fix) repairs the safe ones.
//   node scripts/doctor.mjs            check everything, exit 1 on any FAIL
//   node scripts/doctor.mjs --fix      also repair what is safe: CSP script hashes, missing service-worker shell entries (+ version bump)
//   node scripts/doctor.mjs --tests    also run the server-logic tests (functions/test)
//   node scripts/doctor.mjs --json     machine-readable output
// It NEVER edits the crypto core, the guard pins (those are a human review gate), keys, or Firestore rules.
import { readFileSync, writeFileSync, existsSync, readdirSync, statSync, mkdtempSync, rmSync } from 'node:fs';
import { join, dirname, extname } from 'node:path';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { tmpdir } from 'node:os';
import { fileURLToPath } from 'node:url';

const ROOT = process.env.DOCTOR_ROOT || join(dirname(fileURLToPath(import.meta.url)), '..');
const SCRIPTS = dirname(fileURLToPath(import.meta.url));
const args = new Set(process.argv.slice(2));
const R = (p) => join(ROOT, p), read = (p) => readFileSync(R(p), 'utf8'), has = (p) => existsSync(R(p));
const results = [];
const add = (level, id, msg, fix) => results.push({ level, id, msg, fix: !!fix });
const PAGES = ['index.html', 'dashboard.html', 'groups.html'].filter(has);

function walk(dir, out = []) {
  for (const n of readdirSync(R(dir))) {
    if (['node_modules', '.git', 'native', '__pycache__'].includes(n)) continue;
    const rel = dir ? dir + '/' + n : n, st = statSync(R(rel));
    if (st.isDirectory()) walk(rel, out); else out.push(rel);
  }
  return out;
}
const inlineScripts = (html) => {
  const out = [], re = /<script(?![^>]*\bsrc=)([^>]*)>([\s\S]*?)<\/script>/gi;
  for (let m; (m = re.exec(html));) {
    if (/type\s*=\s*["'](application\/ld\+json|application\/json)["']/i.test(m[1])) continue;
    const text = m[2].replace(/\r\n?/g, '\n'); if (text.trim()) out.push({ attrs: m[1], text });
  }
  return out;
};
const metaCsp = (html) => { const m = /http-equiv=["']Content-Security-Policy["']\s+content=(["'])([\s\S]*?)\1/i.exec(html); return m ? m[2] : null; };

function checkAll() {
  results.length = 0;
  /* 1. every referenced local file exists */
  for (const p of PAGES) {
    const html = read(p), missing = [];
    for (const m of html.matchAll(/<(?:script|link)\b[^>]*?\b(?:src|href)=["']([^"'#?]+)["']/gi)) {
      const u = m[1]; if (/^(https?:|data:|mailto:|tel:|javascript:|\/\/)/i.test(u) || u.startsWith('/')) continue;
      if (!has(u)) missing.push(u);
    }
    missing.length ? add('FAIL', 'files:' + p, p + ' references files that do not exist: ' + [...new Set(missing)].join(', ')) : add('PASS', 'files:' + p, p + ': every local script/stylesheet exists');
  }
  /* 2. JavaScript syntax (external files and inline scripts) */
  const jsFiles = walk('').filter((f) => /\.(js|mjs)$/.test(f) && !f.startsWith('tests/') && !/\.min\./.test(f));
  const bad = [];
  for (const f of jsFiles) { const r = spawnSync(process.execPath, ['--check', R(f)], { encoding: 'utf8' }); if (r.status !== 0) bad.push(f + ': ' + (r.stderr.split('\n').find((l) => /Error/.test(l)) || 'syntax error')); }
  const tmp = mkdtempSync(join(tmpdir(), 'abdoc-'));
  for (const p of PAGES) inlineScripts(read(p)).forEach((s, i) => {
    const f = join(tmp, p.replace(/\W/g, '_') + i + (/module/.test(s.attrs) ? '.mjs' : '.js')); writeFileSync(f, s.text);
    const r = spawnSync(process.execPath, ['--check', f], { encoding: 'utf8' }); if (r.status !== 0) bad.push(p + ' inline script #' + (i + 1) + ': ' + (r.stderr.split('\n').find((l) => /Error/.test(l)) || 'syntax error'));
  });
  rmSync(tmp, { recursive: true, force: true });
  bad.length ? add('FAIL', 'syntax', 'JavaScript does not parse: ' + bad.join(' | ')) : add('PASS', 'syntax', 'all ' + jsFiles.length + ' scripts and every inline script parse');
  /* 3. CSP hashes match the inline scripts; the policy is as strict as intended */
  for (const p of ['index.html', 'dashboard.html'].filter(has)) {
    const html = read(p), csp = metaCsp(html); if (!csp) { add('FAIL', 'csp:' + p, p + ' has no Content-Security-Policy meta tag'); continue; }
    const ss = (/script-src([^;]*)/.exec(csp) || [, ''])[1], want = new Set(inlineScripts(html).map((s) => "'sha256-" + createHash('sha256').update(s.text, 'utf8').digest('base64') + "'"));
    const have = new Set(ss.match(/'sha256-[^']+'/g) || []);
    const missing = [...want].filter((h) => !have.has(h)), extra = [...have].filter((h) => !want.has(h));
    if (ss.includes("'unsafe-inline'")) add('FAIL', 'csp-inline:' + p, p + ': script-src still allows unsafe-inline (any injected script would run)', 'csp');
    else if (missing.length) add('FAIL', 'csp-hash:' + p, p + ': ' + missing.length + ' inline script(s) have no hash in the CSP, so the browser will BLOCK them', 'csp');
    else if (extra.length) add('WARN', 'csp-hash:' + p, p + ': ' + extra.length + ' stale hash(es) in the CSP (harmless, but re-run csp-hash to tidy)', 'csp');
    else add('PASS', 'csp-hash:' + p, p + ': every inline script is allowed by hash, no unsafe-inline');
    if (/unsafe-eval/.test(csp)) add('FAIL', 'csp-eval:' + p, p + ': CSP allows unsafe-eval');
    if (/frame-ancestors/.test(csp)) add('WARN', 'csp-fa:' + p, p + ': frame-ancestors in a meta tag is ignored by browsers (use _headers)');
    if (p === 'index.html' && has('storage.js') && !/r2\.cloudflarestorage\.com/.test(csp)) add('WARN', 'csp-storage', 'index.html connect-src does not list the storage hosts, so cloud uploads will be blocked');
  }
  /* 4. guard pins (a human review gate: reported, never auto-fixed) */
  if (has('scripts/guard.mjs')) { const g = spawnSync(process.execPath, [join(SCRIPTS, 'guard.mjs')], { cwd: ROOT, encoding: 'utf8' }); g.status === 0 ? add('PASS', 'guard', 'guard: crypto core and CSP match their pins') : add('FAIL', 'guard', 'guard: ' + (g.stderr || g.stdout).trim().replace(/\n/g, ' ') + '  -> review the change, then run: node scripts/guard.mjs --update'); }
  /* 5. service worker shell covers the app's own files */
  if (has('sw.js')) {
    const sw = read('sw.js'), shell = (/APP_SHELL\s*=\s*\[([\s\S]*?)\]/.exec(sw) || [, ''])[1].match(/'\.\/[^']+'/g)?.map((s) => s.slice(3, -1)) || [];
    const need = new Set(); for (const p of PAGES) for (const m of read(p).matchAll(/<(?:script|link)\b[^>]*?\b(?:src|href)=["']([^"'#?]+)["']/gi)) { const u = m[1]; if (!/^(https?:|data:|\/)/i.test(u) && /\.(js|css)$/.test(u)) need.add(u); }
    const miss = [...need].filter((u) => !shell.includes(u) && !/^(groups-page|native)/.test(u));
    const gone = shell.filter((u) => u && !has(u) && u !== '');
    if (gone.length) add('FAIL', 'sw-gone', 'sw.js caches files that do not exist (the install would fail): ' + gone.join(', '));
    if (miss.length) add('WARN', 'sw-miss', 'not in the offline shell: ' + miss.join(', '), 'sw'); else if (!gone.length) add('PASS', 'sw', 'offline shell lists every script and stylesheet');
    if (!/SHELL_VERSION\s*=\s*\d+/.test(sw)) add('FAIL', 'sw-version', 'sw.js has no SHELL_VERSION');
  }
  /* 6. duplicate ids in markup */
  for (const p of PAGES) {
    const html = read(p).replace(/<script[\s\S]*?<\/script>/gi, '').replace(/<style[\s\S]*?<\/style>/gi, ''), seen = {}, dup = [];
    for (const m of html.matchAll(/\sid=["']([^"']+)["']/g)) { if (seen[m[1]]) dup.push(m[1]); seen[m[1]] = 1; }
    dup.length ? add('FAIL', 'ids:' + p, p + ': duplicate ids: ' + [...new Set(dup)].join(', ')) : add('PASS', 'ids:' + p, p + ': no duplicate ids');
    if (!/<meta[^>]+name=["']viewport["']/i.test(html)) add('FAIL', 'viewport:' + p, p + ': no viewport meta tag');
    if (!/<html[^>]*\slang=/i.test(read(p))) add('WARN', 'lang:' + p, p + ': <html> has no lang attribute');
  }
  /* 7. Firestore rules sanity */
  if (has('firestore.rules')) {
    const rules = read('firestore.rules'), o = (rules.match(/{/g) || []).length, c = (rules.match(/}/g) || []).length;
    const problems = [o !== c ? 'unbalanced braces' : '', /if\s+true\s*;/.test(rules) ? 'an "if true" rule opens data to everyone' : '', !/service cloud\.firestore/.test(rules) ? 'no service block' : '', /allow\s+[^:]*:\s*if\s+request\.auth\s*!=\s*null\s*;/.test(rules) && !/signedIn\(\)/.test(rules) ? 'rule allows any signed-in user' : ''].filter(Boolean);
    problems.length ? add('FAIL', 'rules', 'firestore.rules: ' + problems.join('; ')) : add('PASS', 'rules', 'firestore.rules: balanced, no open "if true" rules');
    if (has('functions/storage/core.js') && !/storagePrivate/.test(rules) === false && /match \/storagePrivate/.test(rules)) add('FAIL', 'rules-private', 'rules expose storagePrivate (object keys) to clients');
  }
  /* 8. secrets in project files */
  const sec = [], pats = [[/AKIA[0-9A-Z]{16}/, 'AWS access key id'], [/-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/, 'private key'], [/S3_SECRET_ACCESS_KEY\s*[=:]\s*['"]?[A-Za-z0-9\/+]{20,}/, 'storage secret'], [/sk_live_[0-9a-zA-Z]{16,}/, 'live secret key']];
  for (const f of walk('')) { if (!/\.(js|mjs|html|json|md|txt|toml|env|rules|yml|yaml)$/.test(f) || /^tests\//.test(f)) continue; const t = read(f); for (const [re, name] of pats) if (re.test(t)) sec.push(name + ' in ' + f); }
  has('functions/.env') && add('WARN', 'env-file', 'functions/.env exists in the project folder: make sure it is never uploaded or committed');
  sec.length ? add('FAIL', 'secrets', 'secret-looking values found: ' + sec.join('; ')) : add('PASS', 'secrets', 'no keys or secrets found in project files');
  /* 9. storage configuration is coherent */
  if (has('functions/storage/core.js')) {
    const src = read('functions/storage/core.js') + read('functions/storage/s3adapter.js'), keys = new Set([...src.matchAll(/env\.([A-Z][A-Z0-9_]+)/g)].map((m) => m[1]).concat([...src.matchAll(/required\(env, '([A-Z0-9_]+)'\)/g)].map((m) => m[1])));
    const docs = (has('STORAGE_SETUP.md') ? read('STORAGE_SETUP.md') : '') + (has('functions/.env.example') ? read('functions/.env.example') : '');
    const undocumented = [...keys].filter((k) => !docs.includes(k));
    undocumented.length ? add('WARN', 'env-docs', 'server settings not documented in STORAGE_SETUP.md / .env.example: ' + undocumented.join(', ')) : add('PASS', 'env-docs', 'every server setting is documented');
    if (has('storage-config.js')) { const api = (/api:\s*'([^']+)'/.exec(read('storage-config.js')) || [, ''])[1], pid = (/https:\/\/[a-z0-9-]+-([a-z0-9-]+)\.cloudfunctions\.net/.exec(api) || [, ''])[1], any = PAGES.concat(['firebase-lite.js'].filter(has)).some((p) => pid && read(p).includes(pid)); !api ? add('WARN', 'api-url', 'storage-config.js has no api URL') : pid && !any ? add('WARN', 'api-url', 'storage-config.js points at project "' + pid + '" which no page uses') : add('PASS', 'api-url', 'storage API URL matches the Firebase project'); }
    const fp = has('functions/package.json') ? JSON.parse(read('functions/package.json')).dependencies || {} : {};
    ['@aws-sdk/client-s3', '@aws-sdk/s3-request-presigner', 'firebase-admin', 'firebase-functions'].filter((d) => !fp[d]).forEach((d) => add('FAIL', 'dep:' + d, 'functions/package.json is missing ' + d));
  }
  /* 10. response headers */
  if (has('_headers')) { const h = read('_headers'), need = ['X-Frame-Options', 'X-Content-Type-Options', 'Referrer-Policy', 'Strict-Transport-Security', 'Permissions-Policy', "frame-ancestors"]; const miss = need.filter((n) => !h.includes(n)); miss.length ? add('FAIL', 'headers', '_headers is missing: ' + miss.join(', ')) : add('PASS', 'headers', '_headers sets the security headers'); }
  /* 11. optional: server tests */
  if (args.has('--tests') && has('functions/test/storage.test.js')) { const t = spawnSync(process.execPath, ['--test', R('functions/test/storage.test.js')], { cwd: R('functions'), encoding: 'utf8' }); t.status === 0 ? add('PASS', 'tests', 'server-logic tests pass') : add('FAIL', 'tests', 'server-logic tests fail:\n' + (t.stdout.split('\n').filter((l) => /not ok|Error|expected|actual/.test(l)).slice(0, 8).join('\n'))); }
}

/* ---------- safe fixes ---------- */
function applyFixes() {
  const did = [];
  if (results.some((r) => r.fix && r.id.startsWith('csp'))) { const r = spawnSync(process.execPath, [join(SCRIPTS, 'csp-hash.mjs')], { cwd: ROOT, encoding: 'utf8' }); if (r.status === 0) did.push('rewrote CSP script hashes (review, then: node scripts/guard.mjs --update)'); }
  const sw = results.find((r) => r.id === 'sw-miss' && r.fix);
  if (sw) {
    let t = read('sw.js'); const missing = sw.msg.split(': ')[1].split(', ');
    t = t.replace(/(APP_SHELL\s*=\s*\[)([\s\S]*?)(\])/, (_, a, b, c) => a + b.replace(/\s*$/, '') + (b.trim().endsWith(',') ? ' ' : ', ') + missing.map((m) => "'./" + m + "'").join(', ') + c);
    t = t.replace(/SHELL_VERSION\s*=\s*(\d+)/, (_, n) => 'SHELL_VERSION = ' + (Number(n) + 1)); writeFileSync(R('sw.js'), t); did.push('added ' + missing.length + ' file(s) to the offline shell and bumped SHELL_VERSION');
  }
  return did;
}

checkAll();
let fixed = [];
if (args.has('--fix') && results.some((r) => r.fix)) { fixed = applyFixes(); checkAll(); }
const count = (l) => results.filter((r) => r.level === l).length;
if (args.has('--json')) console.log(JSON.stringify({ results, fixed }, null, 1));
else {
  for (const r of results) console.log((r.level === 'PASS' ? 'PASS ' : r.level === 'WARN' ? 'WARN ' : 'FAIL ') + r.msg + (r.fix && r.level !== 'PASS' && !args.has('--fix') ? '   [fixable: --fix]' : ''));
  fixed.forEach((f) => console.log('FIXED ' + f));
  console.log('\n' + count('PASS') + ' ok, ' + count('WARN') + ' warnings, ' + count('FAIL') + ' problems');
}
process.exit(count('FAIL') ? 1 : 0);
