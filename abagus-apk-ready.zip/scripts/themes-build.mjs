#!/usr/bin/env node
// Builds themes.js from scripts/themes-src/*.js and themes.css from the generated palettes + scripts/themes-base.css.
// Run:  python3 scripts/themes-gen.py && node scripts/themes-build.mjs
import { readFileSync, writeFileSync, readdirSync } from 'node:fs';
const dir = new URL('./themes-src/', import.meta.url);
const js = readdirSync(dir).filter(f => f.endsWith('.part')).sort().map(f => readFileSync(new URL(f, dir), 'utf8')).join('\n');
writeFileSync(new URL('../themes.js', import.meta.url), js);
const css = readFileSync(new URL('../themes-palettes.css', import.meta.url), 'utf8') + '\n' + readFileSync(new URL('./themes-base.css', import.meta.url), 'utf8');
writeFileSync(new URL('../themes.css', import.meta.url), css);
console.log('themes.js ' + js.length + ' bytes, themes.css ' + css.length + ' bytes');
