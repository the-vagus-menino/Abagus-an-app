// Guard for pull requests (including the daily Gemini ones). Fails if a change:
//   1. alters the crypto core in index.html (between the CRYPTO CORE markers),
//   2. changes either page's Content-Security-Policy,
//   3. loads scripts from a host outside the allowlist, or
//   4. introduces eval / new Function / document.write.
// Legitimate, human-authored changes to any of these: run `node scripts/guard.mjs --update`
// in the same commit to re-pin. The pin file lives outside ALLOWED_FILES, so Gemini cannot touch it.
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';

const sha = (s) => createHash('sha256').update(s).digest('hex');
const read = (f) => readFileSync(f, 'utf8');
const ALLOWED_HOSTS = new Set(['apis.google.com', 'www.gstatic.com', 'cdn.jsdelivr.net']);
const START = '/* ==================== CRYPTO CORE';
const END = '/* ==================== END CRYPTO CORE';

function cryptoCore(html) {
  const a = html.indexOf(START), b = html.indexOf(END);
  if (a < 0 || b < 0 || b < a) throw new Error('CRYPTO CORE markers are missing or out of order in index.html');
  return html.slice(a, b);
}
const csp = (html) => {
  const m = html.match(/http-equiv="Content-Security-Policy"\s+content="([^"]*)"/);
  if (!m) throw new Error('No Content-Security-Policy meta tag found');
  return m[1].replace(/\s+/g, ' ').trim();
};

const index = read('index.html'), dash = read('dashboard.html');
const current = { crypto_core: sha(cryptoCore(index)), csp_index: sha(csp(index)), csp_dashboard: sha(csp(dash)) };

if (process.argv.includes('--update')) {
  writeFileSync('.guard/pins.json', JSON.stringify(current, null, 2) + '\n');
  console.log('Pins updated:', current); process.exit(0);
}

const pins = JSON.parse(read('.guard/pins.json'));
const problems = [];
if (pins.crypto_core !== current.crypto_core) problems.push('The crypto core in index.html changed. This code protects users\' files — review it by hand.');
if (pins.csp_index !== current.csp_index) problems.push('index.html: Content-Security-Policy changed.');
if (pins.csp_dashboard !== current.csp_dashboard) problems.push('dashboard.html: Content-Security-Policy changed.');

for (const [name, src] of [['index.html', index], ['dashboard.html', dash]]) {
  const hosts = new Set();
  for (const m of src.matchAll(/<script[^>]+src="https:\/\/([^\/"]+)/g)) hosts.add(m[1]);
  for (const m of src.matchAll(/(?:from|import\()\s*["']https:\/\/([^\/"']+)/g)) hosts.add(m[1]);
  for (const h of hosts) if (!ALLOWED_HOSTS.has(h)) problems.push(`${name}: script loaded from a new host: ${h}`);
  if (/\beval\s*\(|new\s+Function\s*\(|document\.write\s*\(/.test(src)) problems.push(`${name}: uses eval / new Function / document.write`);
}
if (problems.length) { console.error('GUARD FAILED:\n - ' + problems.join('\n - ')); process.exit(1); }
console.log('Guard passed: crypto core and CSP unchanged, script hosts allowed.');
