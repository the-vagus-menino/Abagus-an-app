#!/usr/bin/env python3
"""Generates the palette block of themes.css from one table and checks WCAG contrast.
   python3 scripts/themes-gen.py        -> rewrites themes-palettes.css (concatenate into themes.css by the build step below)
   The hand-written part lives in scripts/themes-base.css; themes.css = palettes + base."""
import re, sys, os
# id: mode, paper, sheet, sunk, ink, ink2, ink3, accent, onAccent, accentText, violet(second colour), hi(glow), heading font, extras
T = {
'spiderman':   ('dark','#080810','#12121E','#0C0C16','#F2F3FA','#B4B8CC','#8D93AB','#FF3B3F','#14040A','#FF6B6E','#3D6BFF','#FF3B3F','Impact,"Arial Narrow Bold","Haettenschweiler",system-ui,sans-serif'),
'ironman':     ('dark','#090203','#1B0709','#120405','#FFEDEA','#EAB9B3','#B98782','#E01E2B','#FFFFFF','#FF6A66','#FF7A33','#FF3B30','Bahnschrift,"DIN Alternate","Arial Narrow",system-ui,sans-serif'),
'ultron':      ('light','#E6E2DB','#F4F1EC','#D9D4CB','#15110F','#4A423D','#5F5650','#B3121F','#FFFFFF','#A00F1B','#3B3B3B','#B3121F','"Segoe Print","Bradley Hand","Marker Felt","Comic Sans MS",cursive'),
'thanos':      ('dark','#170608','#240B10','#1D080C','#FBEAE0','#D6B2A6','#A98378','#F0B24A','#2A1500','#FFC76A','#8E4DFF','#F0B24A','Georgia,"Times New Roman",serif'),
'loki':        ('light','#E9E1B9','#F6F0D3','#DDD4A6','#1B2415','#444B33','#555B3C','#1E6B3B','#FFFFFF','#175A30','#C98A18','#2FA35B','Georgia,"Book Antiqua",Palatino,serif'),
'deadpool':    ('dark','#120709','#210B10','#190A0D','#FFEDEE','#E0B4B8','#B38A8F','#FF2B3E','#1A0204','#FF6B78','#8F97A8','#FF2B3E','Impact,"Arial Narrow Bold","Haettenschweiler",system-ui,sans-serif'),
'blackpanther':('dark','#0C0919','#181233','#110D26','#EFEAFF','#BDB3E0','#968CC0','#B497FF','#140A33','#CBB6FF','#7C5CFF','#B497FF','"Trebuchet MS","Segoe UI",system-ui,sans-serif'),
'moonknight':  ('dark','#0A0A0C','#16161A','#101013','#F1EFE8','#BDBAB0','#95928A','#E9E4D2','#121210','#F4EFDC','#8C93A0','#C9B26B','Georgia,"Times New Roman",serif'),
'punisher':    ('dark','#050505','#121212','#0A0A0A','#F4F4F4','#BDBDBD','#909090','#EDEDED','#0A0A0A','#FFFFFF','#D01832','#D01832','Impact,"Arial Narrow Bold","Haettenschweiler",system-ui,sans-serif'),
'johnwick':    ('dark','#06080E','#10151F','#0B0F17','#ECEFF6','#AEB6C8','#8791A8','#D8B24A','#1B1403','#E8C766','#2F7BFF','#2F7BFF','"Didot","Bodoni 72",Georgia,serif'),
'batman':      ('dark','#07080B','#12141A','#0C0D11','#F0F0EA','#B8B9B2','#8E9089','#FFD21F','#141000','#FFDD55','#4B5568','#FFD21F','Impact,"Arial Narrow Bold","Haettenschweiler",system-ui,sans-serif'),
'joker':       ('dark','#130B1E','#1F1330','#180F26','#F4ECFF','#C7B5E0','#9E8BBD','#A6E22E','#0F1A02','#BBF04E','#A24BE0','#A6E22E','Georgia,"Times New Roman",serif'),
'drstrange':   ('dark','#0B0A14','#17142A','#100E1E','#FFF1E3','#E0C6AE','#AE957F','#FF8A1F','#1F0D00','#FFA650','#E23B4A','#FFC64D','Palatino,"Book Antiqua",Georgia,serif'),
'shinchan':    ('light','#FFF6DC','#FFFFFF','#FBEBC0','#1F1B16','#4F463A','#6B6050','#D42A25','#FFFFFF','#C0231E','#1FA64B','#FFD21F','"Comic Sans MS","Chalkboard SE","Marker Felt",ui-rounded,sans-serif'),
'ghibli':      ('light','#E6F6D8','#F6FFEC','#D4EDC2','#14301C','#3E5A44','#4E694E','#23783A','#FFFFFF','#1B6430','#4BA3D8','#FFD76B','ui-rounded,"SF Pro Rounded","Hiragino Maru Gothic ProN","Segoe UI",system-ui,sans-serif'),
'kungfupanda': ('light','#CDEBF8','#EAF7FD','#B7DFF0','#0E1A24','#33495A','#46607A','#0B66A8','#FFFFFF','#09548A','#F08A24','#FFD166','ui-rounded,"SF Pro Rounded","Segoe UI",system-ui,sans-serif'),
'walle':       ('dark','#0A1230','#131D45','#0E1738','#FFF4DA','#D1C8A8','#A39C86','#FFC93C','#231A00','#FFD76A','#6BE675','#FFC93C','ui-rounded,"SF Pro Rounded","Trebuchet MS",system-ui,sans-serif'),
'freedom':     ('light','#DCEEFF','#F3F9FF','#C8E2FA','#0A1A33','#34506F','#415D7A','#1560D6','#FFFFFF','#0F4FB4','#5BB6FF','#FFFFFF','ui-rounded,"SF Pro Rounded","Segoe UI",system-ui,sans-serif'),
'dinomoon':    ('dark','#020204','#0E0E14','#07070A','#F5F7FF','#BFC5D8','#8F96AD','#D6E4FF','#050A18','#E6EEFF','#7F8CB5','#D6E4FF','ui-rounded,"SF Pro Rounded","Segoe UI",system-ui,sans-serif'),
'hogwarts':    ('dark','#0B0C0F','#16181D','#101216','#EFEBDD','#BDB8A6','#918D7C','#D9B45B','#1B1403','#E8C676','#A62B35','#D9B45B','Palatino,"Book Antiqua",Georgia,serif'),
'interstellar':('dark','#06080B','#11161C','#0B0F14','#E9EEF3','#A9B4BF','#838E9A','#FFB347','#1C1000','#FFC46E','#8FB5D6','#FFB347','"Helvetica Neue",Helvetica,Arial,system-ui,sans-serif'),
'matrix':      ('dark','#020A04','#07140A','#040E06','#D8FFE2','#8FD6A2','#6AAF7D','#19F26B','#01140A','#4DFF8D','#0FB15A','#19F26B','ui-monospace,"SF Mono","Cascadia Mono",Menlo,Consolas,monospace'),
'strangerthings':('dark','#0A0306','#170810','#10050B','#FFE9EC','#E0AEB6','#B07F88','#FF2D4D','#1A0108','#FF6F85','#3AA0FF','#FF2D4D','Georgia,"Times New Roman",serif'),
'dune':        ('light','#EFD9AE','#FAEBCB','#E3C78F','#2A1706','#5A3C1F','#6E4F2B','#A9440F','#FFFFFF','#8F3808','#3C6E8F','#E08A2E','Optima,Candara,"Gill Sans","Trebuchet MS",system-ui,sans-serif'),
'dodge':       ('light','#F1E6D2','#FBF4E6','#E6D8BE','#1A1210','#4A3A33','#6A5249','#D9141E','#FFFFFF','#B00F18','#2B2B2E','#D9141E','Impact,\"Arial Narrow Bold\",\"Haettenschweiler\",system-ui,sans-serif'),
'dragonrider': ('light','#EEEEEA','#FAFAF8','#E1E1DC','#0E0E10','#3F3F44','#5B5B61','#111111','#FFFFFF','#111111','#6F7B88','#2B2F36','Palatino,\"Book Antiqua\",Georgia,serif'),
'baymax':      ('light','#D3E7F8','#F4FAFF','#BEDBF1','#0C2340','#31506F','#415D7A','#0B6FCB','#FFFFFF','#085AA6','#F25C54','#FFFFFF','ui-rounded,\"SF Pro Rounded\",\"Hiragino Maru Gothic ProN\",\"Segoe UI\",system-ui,sans-serif'),
'doraemon':    ('light','#DFF1FC','#FFFFFF','#C9E6F6','#102A3D','#3A566B','#476379','#0F78C8','#FFFFFF','#0B5FA3','#E0312F','#FFD84A','ui-rounded,\"SF Pro Rounded\",\"Hiragino Maru Gothic ProN\",\"Segoe UI\",system-ui,sans-serif'),
'deadpool2':   ('light','#EFEFF2','#FFFFFF','#E0E0E5','#14090B','#4A3A3D','#665558','#C8102E','#FFFFFF','#B00D28','#1A1A1D','#C8102E','\"Marker Felt\",\"Chalkboard SE\",\"Comic Sans MS\",Impact,system-ui,sans-serif'),
'scarletwitch':('dark','#12060A','#200A10','#18070C','#FFEAEA','#E3B0B3','#B88488','#FF2A4A','#1A0106','#FF6B82','#8B1E3F','#FF3355','Palatino,\"Book Antiqua\",Georgia,serif'),
'shangchi':    ('dark','#120905','#21110A','#190C07','#FFF1DF','#E3C4A0','#B49574','#FFB21E','#2A1600','#FFC857','#E2461C','#FFC947','Optima,Candara,\"Gill Sans\",\"Trebuchet MS\",system-ui,sans-serif'),
'agent':       ('light','#DDD8D1','#EFEBE5','#CFC9C0','#1A1412','#4A403B','#5A4F49','#9E1B20','#FFFFFF','#8E171C','#2C3A4C','#B3202A','\"Courier New\",Courier,ui-monospace,monospace'),
'ghostrider':  ('dark','#07100F','#0F1B1D','#0A1415','#FFF0DC','#D9B999','#A88C70','#FF7A12','#1F0C00','#FF9A3D','#3E8FA3','#FF8A1F','Impact,\"Arial Narrow Bold\",\"Haettenschweiler\",system-ui,sans-serif'),
'wonderwoman': ('light','#F3E3C2','#FFF6E2','#E8D3A6','#1C0F10','#4F3436','#6B4B47','#B3121F','#FFFFFF','#A0101C','#1D4E9E','#E8B53C','\"Futura\",\"Century Gothic\",\"Trebuchet MS\",system-ui,sans-serif'),
}
def lum(h):
    r,g,b=[int(h[i:i+2],16)/255 for i in (1,3,5)]
    f=lambda c: c/12.92 if c<=.03928 else ((c+.055)/1.055)**2.4
    return .2126*f(r)+.7152*f(g)+.0722*f(b)
def cr(a,b):
    x,y=lum(a),lum(b); x,y=max(x,y),min(x,y); return (x+.05)/(y+.05)
def rgb(h): return ','.join(str(int(h[i:i+2],16)) for i in (1,3,5))
bad=0; out=['/* GENERATED by scripts/themes-gen.py from its table. Do not edit by hand. */']
for k,(mode,paper,sheet,sunk,ink,i2,i3,acc,onacc,acct,vio,hi,font) in T.items():
    checks=[('ink/paper',ink,paper,4.5),('ink/sheet',ink,sheet,4.5),('ink2/paper',i2,paper,4.5),('ink2/sheet',i2,sheet,4.5),('ink3/paper',i3,paper,4.5),('ink3/sheet',i3,sheet,4.5),
            ('accentText/paper',acct,paper,4.5),('accentText/sheet',acct,sheet,4.5),('onAccent/accent',onacc,acc,4.5),('ink/sunk',ink,sunk,4.5),
            ('accent/paper (UI 3:1)',acc,paper,3.0),('accent/sheet (UI 3:1)',acc,sheet,3.0),('ink3/sunk',i3,sunk,4.5),('accentText/sunk',acct,sunk,4.5)]
    for n,a,b,m in checks:
        c=cr(a,b)
        if c<m: bad+=1; print(f'LOW {k:14} {n:18} {c:.2f}  ({a} on {b})')
    sel=f'html[data-vibe="{k}"][data-theme]'
    a1,a2=('.09','.22')
    out.append(f'{sel}{{color-scheme:{mode};--paper:{paper};--sheet:{sheet};--sunk:{sunk};--ink:{ink};--ink-2:{i2};--ink-3:{i3};'
      f'--rule:rgba({rgb(ink)},{a1});--rule-2:rgba({rgb(ink)},{a2});--accent:{acc};--accent-text:{acct};--on-accent:{onacc};--violet:{vio};--hi:{hi};'
      f'--scrim:rgba({rgb(paper)},.8);--shadow:rgba({rgb("#000000" if mode=="dark" else acc)},{".6" if mode=="dark" else ".28"});--serif:{font};--v-glow:{hi};--v-2:{vio};--accent-soft:rgba({rgb(acc)},{'.16' if mode=='dark' else '.12'});--focus:{acct};--focus-halo:{paper};--thumb:rgba({rgb(ink)},.32)}}')
    out.append(f'[data-pv="{k}"]{{--pa:{acc};--pb:{vio};--pp:{paper}}}')
boot=os.path.join(os.path.dirname(__file__),'..','themes-boot.js')
if os.path.exists(boot):
    b=open(boot).read()
    pap='var paper = { '+', '.join(f"{k}: '{v[1]}'" for k,v in T.items())+' };  /* GENERATED by themes-gen.py */'
    if 'var paper = {' in b: b=re.sub(r"var paper = \{.*?\\};  /\* GENERATED by themes-gen.py \*/",pap,b,flags=re.S)
    else: b=b.replace("    var pw = localStorage","    "+pap+"\n    var mc = document.querySelector('meta[name=\"theme-color\"]'); if (mc && paper[id]) mc.setAttribute('content', paper[id]);\n    var pw = localStorage",1)
    open(boot,'w').write(b)
open(os.path.join(os.path.dirname(__file__),'..','themes-palettes.css'),'w').write('\n'.join(out)+'\n')
print(len(T),'themes;',bad,'contrast failures'); sys.exit(1 if bad else 0)
