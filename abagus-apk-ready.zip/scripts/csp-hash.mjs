#!/usr/bin/env node
// Replaces 'unsafe-inline' in script-src with the exact SHA-256 hash of every inline <script> in index.html and dashboard.html.
// With hashes, the browser runs ONLY the scripts that shipped in the file; a script injected through an XSS hole has no matching hash and is blocked.
// Run this after ANY edit to an inline script, then `node scripts/guard.mjs --update`:
//     node scripts/csp-hash.mjs && node scripts/guard.mjs --update
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';

for (const file of ['index.html', 'dashboard.html']) {
  let html = readFileSync(file, 'utf8');
  const hashes = [];
  const re = /<script(?![^>]*\bsrc=)([^>]*)>([\s\S]*?)<\/script>/gi;
  for (let m; (m = re.exec(html));) {
    const attrs = m[1] || '';
    if (/type\s*=\s*["'](application\/ld\+json|application\/json|importmap-ignore)["']/i.test(attrs)) continue;   // data blocks are never executed
    const text = m[2].replace(/\r\n?/g, '\n');                       // the HTML parser normalises line endings before hashing
    if (!text.trim()) continue;
    hashes.push("'sha256-" + createHash('sha256').update(text, 'utf8').digest('base64') + "'");
  }
  const uniq = [...new Set(hashes)];
  const rule = /(script-src\s+'self')((?:\s+'(?:unsafe-inline|sha256-[A-Za-z0-9+/=]+)')*)/;
  if (!rule.test(html)) { console.error(file + ': no script-src found'); process.exit(1); }
  html = html.replace(rule, (_, a) => a + ' ' + uniq.join(' '));
  writeFileSync(file, html);
  console.log(file + ': ' + uniq.length + ' inline script hashes written; unsafe-inline removed from script-src.');
}
