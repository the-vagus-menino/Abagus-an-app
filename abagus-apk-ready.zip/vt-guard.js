/* Cross-page fades: if the browser skips or aborts one (for example the next page loaded too slowly), swallow the rejected promises
   so nothing is logged as an uncaught error. The page itself is unaffected. */
(function () {
  'use strict';
  function quiet(t) { if (!t) return; ['ready', 'finished', 'updateCallbackDone'].forEach(function (k) { try { if (t[k] && t[k].catch) t[k].catch(function () {}); } catch (_) {} }); }
  addEventListener('pagereveal', function (e) { quiet(e.viewTransition); });
  addEventListener('pageswap', function (e) { quiet(e.viewTransition); });
})();
