// Bump SHELL_VERSION on every deploy that changes index.html/manifest so old
// clients pick up the new shell instead of serving a stale cached copy.
const SHELL_VERSION = 44;
const CACHE = `abagus-shell-v${SHELL_VERSION}`;
// Only complete 200 responses are cached (a 206 partial response, e.g. from a media range request, makes cache.put throw).
const cacheable = r => r && r.status === 200 && (r.type === 'basic' || r.type === 'cors');
const put = (name, req, res) => caches.open(name).then(c => c.put(req, res)).catch(() => null);
const RUNTIME_CACHE = `abagus-runtime-v${SHELL_VERSION}`;
const APP_SHELL = ['./', './index.html', './dashboard.html', './manifest.webmanifest', './carrier.js', './covers.js', './anskarkey.js', './account.js', './cloudkey.js', './groups.js', './avatar.js', './avatar.css', './vt-guard.js', './selfcheck.js', './ux-safety.js', './selfcheck.css',  './groups.html', './chat.js', './chat.css', './me.html', './me.js', './groups.css', './groups-page.js', './ui-plus.css', './ui-pro.css', './ui-human.css', './themes.css', './themes.js', './themes-boot.js', './firebase-lite.js', './icons/favicon-48.png', './icons/apple-touch-icon.png', './icons/icon-192.png', './icons/abagus-wordmark.png', './icons/abagus-mark.png', './icons/icon-512.png', './icons/maskable-192.png', './icons/maskable-512.png'];

// Cross-origin hosts the app is already allowed (CSP script-src/connect-src) to
// load from. Only these get opportunistically cached, and only the two exact
// cipher/KDF library files — nothing else cross-origin is ever cached, and
// this file never touches or re-serves anything inside the CRYPTO CORE region
// of index.html (see scripts/guard.mjs).
const RUNTIME_ALLOWLIST = [
  'https://cdn.jsdelivr.net/npm/@noble/hashes@1.5.0/argon2.js',
  'https://cdn.jsdelivr.net/npm/@noble/ciphers@1.0.0/chacha.js'
];

self.addEventListener('install', event => {
  // Add files one by one so a single missing or failed file cannot abort the whole install
  // (cache.addAll rejects everything if any one request fails).
  event.waitUntil(caches.open(CACHE)
    .then(cache => Promise.all(APP_SHELL.map(u => cache.add(u).catch(() => null))))
    .then(() => self.skipWaiting()));
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== CACHE && k !== RUNTIME_CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);

  // Same-origin app shell: network-first for pages and scripts so a new deploy
  // shows up immediately; falls back to the cache when offline.
  if (url.origin === location.origin) {
    const fresh = event.request.mode === 'navigate' || /\.(html|js|mjs)$/.test(url.pathname) || url.pathname === '/';
    if (fresh) {
      event.respondWith(fetch(event.request).then(response => {
        if (cacheable(response)) event.waitUntil(put(CACHE, event.request, response.clone()));
        return response;
      }).catch(() => caches.match(event.request, { ignoreSearch: true }).then(c => c || (event.request.mode === 'navigate' ? caches.match('./index.html') : Response.error()))));
      return;
    }
    event.respondWith(caches.match(event.request).then(cached => cached || fetch(event.request).then(response => {
      if (cacheable(response)) event.waitUntil(put(CACHE, event.request, response.clone()));
      return response;
    }).catch(() => (event.request.mode === 'navigate' ? caches.match('./index.html') : Response.error()))));
    return;
  }

  // Cipher/KDF libraries: cache-first so a device that has opened the app
  // online once can still encrypt/decrypt offline afterward. Revalidate in
  // the background so a version bump upstream is picked up on the next
  // online visit rather than pinned forever.
  if (RUNTIME_ALLOWLIST.includes(event.request.url)) {
    event.respondWith(
      caches.open(RUNTIME_CACHE).then(async cache => {
        const cached = await cache.match(event.request);
        const network = fetch(event.request).then(response => {
          if (cacheable(response)) cache.put(event.request, response.clone()).catch(() => null);
          return response;
        }).catch(() => null);
        // Keep the worker alive long enough for the background refresh to
        // finish writing to the cache, even after we've already responded.
        event.waitUntil(network);
        return cached || (await network) || Response.error();
      })
    );
    return;
  }
  // Everything else cross-origin (auth, Drive, Cloud Functions, etc.): untouched.
});
