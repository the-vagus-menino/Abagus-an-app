/* Abagus picture carrier. Wraps the finished ciphertext (SVL3 container) in a PNG.
   Small payloads are hidden in the picture's pixel low bits (RGB LSB); large ones go in a
   private PNG chunk. This runs AFTER encryption and BEFORE decryption: it never touches keys. */
(function () {
  'use strict';
  var enc = new TextEncoder();
  var SIG = [137, 80, 78, 71, 13, 10, 26, 10], CHK = 0xA5C3E1B7, LSB_MAX_PIXELS = 16e6, CHUNK = 'abGs';
  var T = new Uint32Array(256);
  for (var n = 0; n < 256; n++) { var c = n; for (var k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; T[n] = c >>> 0; }
  function crc(b) { var c = ~0; for (var i = 0; i < b.length; i++) c = T[(c ^ b[i]) & 255] ^ (c >>> 8); return ~c >>> 0; }
  function u32(v) { return new Uint8Array([v >>> 24, (v >>> 16) & 255, (v >>> 8) & 255, v & 255]); }
  function rd32(b, o) { return ((b[o] << 24) | (b[o + 1] << 16) | (b[o + 2] << 8) | b[o + 3]) >>> 0; }
  function concat(list) { var t = 0; list.forEach(function (a) { t += a.length; }); var o = new Uint8Array(t), p = 0; list.forEach(function (a) { o.set(a, p); p += a.length; }); return o; }
  function chunk(type, data) { var td = concat([enc.encode(type), data]); return concat([u32(data.length), td, u32(crc(td))]); }
  function rnd() { return crypto.getRandomValues(new Uint32Array(1))[0] / 4294967296; }
  function fillRandom(buf) { for (var i = 0; i < buf.length; i += 65536) crypto.getRandomValues(buf.subarray(i, Math.min(i + 65536, buf.length))); return buf; }
  async function deflate(u8) { return new Uint8Array(await new Response(new Blob([u8]).stream().pipeThrough(new CompressionStream('deflate'))).arrayBuffer()); }
  async function inflate(u8) { return new Uint8Array(await new Response(new Blob([u8]).stream().pipeThrough(new DecompressionStream('deflate'))).arrayBuffer()); }

  /* ---- a picture that matches the kind of file ---- */
  function kindOf(name) {
    var e = (String(name).split('.').pop() || '').toLowerCase();
    if (/^(pdf|docx?|txt|md|rtf|odt|xlsx?|csv|pptx?)$/.test(e)) return 'doc';
    if (/^(jpe?g|png|gif|webp|bmp|heic|svg|tiff?)$/.test(e)) return 'photo';
    if (/^(mp3|wav|flac|m4a|aac|ogg)$/.test(e)) return 'audio';
    if (/^(mp4|mov|mkv|avi|webm)$/.test(e)) return 'video';
    return 'abstract';
  }
  function col() { return [40 + rnd() * 180 | 0, 40 + rnd() * 180 | 0, 40 + rnd() * 180 | 0]; }
  function mix(a, b, t) { return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]; }
  function makeScene(kind) {
    var c1 = col(), c2 = col(), ph = [rnd() * 6, rnd() * 6, rnd() * 6], dark = [18, 20, 26];
    if (kind === 'photo') return function (u, v) {
      var px = mix(c1, [235, 225, 200], v);
      if (Math.hypot(u - .7, (v - .3) * .75) < .08) px = [255, 235, 160];
      if (v > .62 + .06 * Math.sin(u * 7 + ph[0]) + .03 * Math.sin(u * 17 + ph[1])) px = mix([60, 110, 70], [30, 70, 50], (v - .6) * 2.5);
      if (v > .78 + .05 * Math.sin(u * 5 + ph[2])) px = [24, 52, 38];
      return px;
    };
    if (kind === 'doc') { var lines = []; for (var i = 0; i < 16; i++) lines.push(.3 + rnd() * .7);
      return function (u, v) {
        var px = mix(c1, c2, v);
        if (u > .22 && u < .78 && v > .1 && v < .9) { px = [245, 242, 235];
          if (v > .13 && v < .16 && u > .28 && u < .5) px = c1;
          var r = (v - .2) / .045, row = Math.floor(r);
          if (row >= 0 && row < lines.length && r - row < .3 && u > .28 && u < .28 + lines[row] * .44) px = [150, 150, 150]; }
        return px; }; }
    if (kind === 'audio') { var bars = []; for (var j = 0; j < 48; j++) bars.push(.1 + rnd() * .7);
      return function (u, v) { var i2 = Math.floor(u * 48), bu = u * 48 - i2;
        return (bu < .6 && Math.abs(v - .5) < bars[i2] / 2) ? c1 : mix(dark, c2, v * .5); }; }
    if (kind === 'video') return function (u, v) {
      if (v < .08 || v > .92) return ((u * 24) % 1 < .5) ? [225, 225, 225] : [30, 30, 30];
      if (u > .42 && u < .6 && Math.abs(v - .5) < (.6 - u) * .9) return [240, 240, 240];
      return mix(dark, c1, v * .6); };
    return function (u, v) { return mix(c1, c2, (Math.sin(Math.hypot(u - .5, v - .5) * 30 + ph[0]) + 1) / 2); };
  }

  async function build(payload, kind, cover) {
    var framed = concat([u32(payload.length), u32((payload.length ^ CHK) >>> 0), payload]);
    var pixelsNeeded = Math.ceil(framed.length * 8 / 3), useLsb = pixelsNeeded <= LSB_MAX_PIXELS;
    var w = useLsb ? Math.max(480, Math.ceil(Math.sqrt(pixelsNeeded * 4 / 3))) : 960;
    var h = useLsb ? Math.max(360, Math.ceil(pixelsNeeded / w)) : 720;
    var img = null;
    if (cover) { var cv = document.createElement('canvas'); cv.width = w; cv.height = h; var cx = cv.getContext('2d'), s = Math.max(w / cover.width, h / cover.height);
      cx.drawImage(cover, (w - cover.width * s) / 2, (h - cover.height * s) / 2, cover.width * s, cover.height * s); img = cx.getImageData(0, 0, w, h).data; }
    var scene = makeScene(kind), stride = w * 3, raw = new Uint8Array(h * (stride + 1));
    var cap = Math.floor(w * h * 3 / 8), bits = null;
    if (useLsb) { bits = fillRandom(new Uint8Array(cap)); bits.set(framed); }   // unused capacity = random, so no tell-tale boundary
    var p = 0, j = 0;
    for (var y = 0; y < h; y++) {
      raw[p++] = 0;
      for (var x = 0; x < w; x++) {
        var px = img ? [img[(y * w + x) * 4], img[(y * w + x) * 4 + 1], img[(y * w + x) * 4 + 2]] : scene(x / w, y / h);
        for (var ch = 0; ch < 3; ch++) {
          var val = Math.max(0, Math.min(255, (px[ch] + (rnd() * 6 - 3)) | 0));
          if (useLsb) { var bit = j < cap * 8 ? (bits[j >> 3] >> (7 - (j & 7))) & 1 : (rnd() < .5 ? 1 : 0); val = (val & 254) | bit; j++; }
          raw[p++] = val;
        }
      }
    }
    var ihdr = concat([u32(w), u32(h), new Uint8Array([8, 2, 0, 0, 0])]);
    var parts = [new Uint8Array(SIG), chunk('IHDR', ihdr), chunk('IDAT', await deflate(raw))];
    if (!useLsb) parts.push(chunk(CHUNK, framed));
    parts.push(chunk('IEND', new Uint8Array(0)));
    return new Blob(parts, { type: 'image/png' });
  }

  function unfilter(raw, w, h, bpp) {
    var stride = w * bpp, out = new Uint8Array(stride * h), p = 0;
    for (var y = 0; y < h; y++) { var f = raw[p++], o = y * stride;
      for (var i = 0; i < stride; i++) {
        var x = raw[p++], a = i >= bpp ? out[o + i - bpp] : 0, b = y ? out[o - stride + i] : 0, c = (y && i >= bpp) ? out[o - stride + i - bpp] : 0, v;
        if (f === 0) v = x; else if (f === 1) v = x + a; else if (f === 2) v = x + b; else if (f === 3) v = x + ((a + b) >> 1);
        else if (f === 4) { var pp = a + b - c, pa = Math.abs(pp - a), pb = Math.abs(pp - b), pc = Math.abs(pp - c); v = x + ((pa <= pb && pa <= pc) ? a : (pb <= pc ? b : c)); }
        else throw new Error('bad filter');
        out[o + i] = v & 255; } }
    return out;
  }

  async function extract(file) {
    var b = new Uint8Array(await file.arrayBuffer());
    for (var s = 0; s < 8; s++) if (b[s] !== SIG[s]) return null;
    var pos = 8, ihdr = null, idat = [], priv = null;
    while (pos + 12 <= b.length) {
      var len = rd32(b, pos), type = String.fromCharCode(b[pos + 4], b[pos + 5], b[pos + 6], b[pos + 7]), d = b.subarray(pos + 8, pos + 8 + len);
      if (type === 'IHDR') ihdr = d; else if (type === 'IDAT') idat.push(d); else if (type === CHUNK) priv = d;
      if (type === 'IEND') break; pos += 12 + len;
    }
    var framed = priv;
    if (!framed) {
      if (!ihdr || ihdr[8] !== 8 || ihdr[12] !== 0 || (ihdr[9] !== 2 && ihdr[9] !== 6)) return null;
      var w = rd32(ihdr, 0), h = rd32(ihdr, 4), bpp = ihdr[9] === 2 ? 3 : 4;
      var pix = unfilter(await inflate(concat(idat)), w, h, bpp), total = w * h * 3;
      var readBytes = function (start, count) { var o = new Uint8Array(count);
        for (var i = 0; i < count; i++) { var v = 0; for (var k = 0; k < 8; k++) { var bi = (start + i) * 8 + k; v = (v << 1) | (pix[((bi / 3) | 0) * bpp + (bi % 3)] & 1); } o[i] = v; } return o; };
      var head = readBytes(0, 8), plen = rd32(head, 0);
      if (rd32(head, 4) !== ((plen ^ CHK) >>> 0) || (plen + 8) * 8 > total) return null;
      framed = readBytes(0, plen + 8);
    }
    var L = rd32(framed, 0);
    if (rd32(framed, 4) !== ((L ^ CHK) >>> 0) || L + 8 > framed.length) return null;
    return framed.slice(8, 8 + L);
  }

  async function save(parts, files) {
    var payload = new Uint8Array(await new Blob(parts).arrayBuffer());
    var name = files && files.length === 1 ? files[0].name : 'batch';
    var cov = window.AbagusCovers ? await window.AbagusCovers.next() : null;
    var png = await build(payload, kindOf(name), cov && cov.bitmap);
    if (cov) document.dispatchEvent(new CustomEvent('abagus:cover', { detail: cov }));
    var d = new Date(), pad = function (n) { return String(n).padStart(2, '0'); };
    var fname = 'IMG_' + d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + '_' + (1000 + Math.floor(rnd() * 9000)) + '.png';
    var url = URL.createObjectURL(png), a = document.createElement('a');
    a.href = url; a.download = fname; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
  }
  var api = { build: build, extract: extract, save: save, kindOf: kindOf };
  if (typeof window !== 'undefined') window.AbagusCarrier = api; else module.exports = api;
})();
