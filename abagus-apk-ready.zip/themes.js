/* Abagus Themes: 34 character / film looks (v2: Power levels, theme-reveal transition, card tilt, spotlight, combo bursts), each with its own animated background, click effect,
   page transition and card / button motion. Loaded on every page after themes-boot.js.
   No network, no eval, no inline script. Everything is drawn on two canvases and removed when the theme is "Default".
   Source parts live in scripts/themes-src; build with: node scripts/themes-build.mjs */
(function () {
  'use strict';
  var root = document.documentElement;
  var TAU = Math.PI * 2, M = Math, R = M.random;
  var rr = function (a, b) { return a + R() * (b - a); };
  var pick = function (a) { return a[(R() * a.length) | 0]; };
  function get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function put(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* private mode */ } }
  function drop(k) { try { localStorage.removeItem(k); } catch (e) { /* private mode */ } }

  /* ---------------- catalogue ----------------
     scene: background animation · click: tap effect · wipe: page transition · trail: pointer sparkle colour source
     art: artwork file (themes/art/<id>.webp) · op: artwork opacity · pos: where the artwork sits */
  var CAT = [
    { id: 'spiderman', n: 'Spider-Man', from: 'Marvel', g: 'Marvel', m: 'dark', tag: 'Web, wall-crawl and spidey-sense', scene: 'spiderman', click: 'web', wipe: 'iris', art: 1, op: .34 },
    { id: 'ironman', n: 'Iron Man', from: 'Marvel', g: 'Marvel', m: 'dark', tag: 'Arc reactor HUD and repulsors', scene: 'ironman', click: 'repulsor', wipe: 'iris', trail: 1, art: 1, op: .38 },
    { id: 'ultron', n: 'Ultron', from: 'Avengers', g: 'Marvel', m: 'light', tag: 'Cold steel, red ink, glitch', scene: 'ultron', click: 'splat', wipe: 'slash', art: 1, op: .32 },
    { id: 'thanos', n: 'Thanos', from: 'Marvel', g: 'Marvel', m: 'dark', tag: 'Six stones and the Snap', scene: 'thanos', click: 'snap', wipe: 'fade', art: 1, op: .3 },
    { id: 'loki', n: 'Loki', from: 'Marvel', g: 'Marvel', m: 'light', tag: 'Glorious purpose, TVA time loops', scene: 'loki', click: 'magic', wipe: 'slash', trail: 1, art: 1, op: .3 },
    { id: 'deadpool', n: 'Deadpool', from: 'Marvel', g: 'Marvel', m: 'dark', tag: 'Katana slashes, maximum effort', scene: 'deadpool', click: 'comic', wipe: 'slash', art: 1, op: .3 },
    { id: 'blackpanther', n: 'Black Panther', from: 'Marvel', g: 'Marvel', m: 'dark', tag: 'Vibranium grid, Wakanda forever', scene: 'blackpanther', click: 'vibranium', wipe: 'iris', art: 1, op: .3 },
    { id: 'moonknight', n: 'Moon Knight', from: 'Marvel', g: 'Marvel', m: 'dark', tag: 'Crescent blades and desert fog', scene: 'moonknight', click: 'crescent', wipe: 'iris', art: 1, op: .34 },
    { id: 'punisher', n: 'The Punisher', from: 'Marvel', g: 'Marvel', m: 'dark', tag: 'Laser sight, bullet holes', scene: 'punisher', click: 'bullet', wipe: 'slash', art: 1, op: .3 },
    { id: 'drstrange', n: 'Doctor Strange', from: 'Marvel', g: 'Marvel', m: 'dark', tag: 'Sling-ring mandalas and sparks', scene: 'drstrange', click: 'rune', wipe: 'iris', trail: 1, op: 0 },
    { id: 'batman', n: 'The Dark Knight', from: 'DC', g: 'DC', m: 'dark', tag: 'Bat-signal, fog, batarangs', scene: 'batman', click: 'batarang', wipe: 'iris', op: 0 },
    { id: 'joker', n: 'Joker', from: 'DC', g: 'DC', m: 'dark', tag: 'Why so serious? Cards and chaos', scene: 'joker', click: 'cards', wipe: 'slash', art: 1, op: .3 },
    { id: 'johnwick', n: 'John Wick', from: 'Movie', g: 'Movies', m: 'dark', tag: 'Neon rain, gold coins, gun-fu', scene: 'johnwick', click: 'gunshot', wipe: 'fade', art: 1, op: .32 },
    { id: 'interstellar', n: 'Interstellar', from: 'Movie', g: 'Movies', m: 'dark', tag: 'Gargantua, stars, time dilation', scene: 'interstellar', click: 'gravity', wipe: 'iris', art: 1, op: .34 },
    { id: 'hogwarts', n: 'Hogwarts Express', from: 'Harry Potter', g: 'Movies', m: 'dark', tag: 'Floating candles, snitch, steam', scene: 'hogwarts', click: 'wand', wipe: 'fade', trail: 1, art: 1, op: .34 },
    { id: 'matrix', n: 'The Matrix', from: 'Movie', g: 'Movies', m: 'dark', tag: 'Digital rain. Wake up.', scene: 'matrix', click: 'glyphs', wipe: 'rain', op: 0 },
    { id: 'strangerthings', n: 'Stranger Things', from: 'Series', g: 'Movies', m: 'dark', tag: 'Upside Down, string lights', scene: 'strangerthings', click: 'flicker', wipe: 'fade', op: 0 },
    { id: 'dune', n: 'Dune', from: 'Movie', g: 'Movies', m: 'light', tag: 'Sand, wind and a pale sun', scene: 'dune', click: 'sand', wipe: 'slash', op: 0 },
    { id: 'dinomoon', n: 'Moon Ride', from: 'E.T. style', g: 'Movies', m: 'dark', tag: 'A dino on a bike over the moon', scene: 'dinomoon', click: 'moonring', wipe: 'iris', art: 1, op: .36 },
    { id: 'walle', n: 'WALL·E', from: 'Pixar', g: 'Cosy', m: 'dark', tag: 'One small sprout, one big heart', scene: 'walle', click: 'sprout', wipe: 'rain', art: 1, op: .34 },
    { id: 'kungfupanda', n: 'Kung Fu Panda', from: 'DreamWorks', g: 'Cosy', m: 'light', tag: 'Inner peace. Skadoosh.', scene: 'panda', click: 'zen', wipe: 'fade', art: 1, op: .3 },
    { id: 'shinchan', n: 'Shinchan', from: 'Anime', g: 'Cosy', m: 'light', tag: 'Manga speed-lines and mischief', scene: 'shinchan', click: 'ora', wipe: 'iris', art: 1, op: .3 },
    { id: 'ghibli', n: 'Ghibli Meadow', from: 'Cosy', g: 'Cosy', m: 'light', tag: 'Wind, clouds and dandelions', scene: 'ghibli', click: 'seeds', wipe: 'fade', art: 1, op: .34 },
    { id: 'freedom', n: 'Freedom Sky', from: 'Anime', g: 'Cosy', m: 'light', tag: 'Arms wide open, clouds below', scene: 'freedom', click: 'feathers', wipe: 'rain', art: 1, op: .36 },
    { id: 'dodge', n: 'Dodge Hellcat', from: 'Muscle car', g: 'Cars', m: 'light', tag: 'Burnouts, a rev needle and speed lines', scene: 'dodge', click: 'burnout', wipe: 'slash', art: 1, op: .3 },
    { id: 'dragonrider', n: 'Dragon Rider', from: 'Ink art', g: 'Movies', m: 'light', tag: 'Ink wings, a rider and a ribbon of air', scene: 'dragonrider', click: 'inkswirl', wipe: 'fade', art: 1, op: .34 },
    { id: 'baymax', n: 'Baymax', from: 'Disney', g: 'Cosy', m: 'light', tag: 'Hello. I am here to help', scene: 'baymax', click: 'bump', wipe: 'iris', art: 1, op: .34 },
    { id: 'doraemon', n: 'Doraemon', from: 'Anime', g: 'Cosy', m: 'light', tag: 'Bamboo-copter, a bell and a big tree', scene: 'doraemon', click: 'bell', wipe: 'iris', art: 1, op: .34 },
    { id: 'deadpool2', n: 'Deadpool Light', from: 'Marvel', g: 'Marvel', m: 'light', tag: 'Fourth wall, katana and bad jokes', scene: 'deadpool2', click: 'katana', wipe: 'slash', art: 1, op: .3 },
    { id: 'scarletwitch', n: 'Scarlet Witch', from: 'Marvel', g: 'Marvel', m: 'dark', tag: 'Chaos magic and red wisps', scene: 'scarletwitch', click: 'chaos', wipe: 'iris', trail: 1, art: 1, op: .4 },
    { id: 'shangchi', n: 'Shang-Chi', from: 'Marvel', g: 'Marvel', m: 'dark', tag: 'Ten Rings and golden lightning', scene: 'shangchi', click: 'tenrings', wipe: 'iris', trail: 1, art: 1, op: .34 },
    { id: 'agent', n: 'Agent Noir', from: 'Spy film', g: 'Movies', m: 'light', tag: 'Laser tripwires and sealed files', scene: 'agent', click: 'classified', wipe: 'rain', art: 1, op: .3 },
    { id: 'ghostrider', n: 'Ghost Rider', from: 'Marvel', g: 'Marvel', m: 'dark', tag: 'Hellfire, chains and a burning skull', scene: 'ghostrider', click: 'hellchain', wipe: 'slash', art: 1, op: .36 },
    { id: 'wonderwoman', n: 'Wonder Woman', from: 'DC', g: 'DC', m: 'light', tag: 'Golden lasso and bracelets of victory', scene: 'wonderwoman', click: 'clash', wipe: 'iris', trail: 1, art: 1, op: .34 }
  ];
  var BY = {}; CAT.forEach(function (t) { BY[t.id] = t; });

  /* ---------------- state ---------------- */
  var S = {
    id: get('abagus-vibe') || '',
    motion: get('abagus-vibe-motion') || '',        /* full | calm | off | '' (auto) */
    art: get('abagus-vibe-art') !== '0',
    fx: get('abagus-vibe-fx') !== '0',
    power: get('abagus-vibe-power') || 'normal',   /* soft | normal | max: how loud the theme is */
    extras: get('abagus-vibe-extras') !== '0'      /* card tilt, pointer spotlight, progress bar, combo bursts */
  };
  var POWER = { soft: .6, normal: 1, max: 1.5 };
  if (!POWER[S.power]) S.power = 'normal';
  function pw() { return POWER[S.power] || 1; }
  if (!BY[S.id]) S.id = '';
  var mqReduce = window.matchMedia ? matchMedia('(prefers-reduced-motion: reduce)') : { matches: false };
  function motion() {
    if (S.motion === 'full' || S.motion === 'calm' || S.motion === 'off') return S.motion;
    if (mqReduce.matches) return 'off';
    var c = navigator.connection; if (c && c.saveData) return 'calm';
    if (window.matchMedia && matchMedia('(pointer: coarse)').matches) return 'calm';      /* phones: 30 fps keeps typing and sign-in smooth */
    return 'full';
  }

  /* ---------------- colour helpers ---------------- */
  var cache = {};
  function A(hex, a) {
    var k = hex + a; if (cache[k]) return cache[k];
    var h = hex.replace('#', ''); if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
    var s = 'rgba(' + parseInt(h.slice(0, 2), 16) + ',' + parseInt(h.slice(2, 4), 16) + ',' + parseInt(h.slice(4, 6), 16) + ',' + a + ')';
    if (Object.keys(cache).length > 4000) cache = {};
    return (cache[k] = s);
  }
  var SPR = {}, SPRN = 0;
  function sprite(col) {                       /* one soft round light per colour, drawn with drawImage: faster and smoother than a new gradient per call */
    if (SPR[col]) return SPR[col];
    if (SPRN > 90) { SPR = {}; SPRN = 0; }
    var cv = document.createElement('canvas'); cv.width = cv.height = 128; var g = cv.getContext('2d'), gr = g.createRadialGradient(64, 64, 0, 64, 64, 64);
    gr.addColorStop(0, A(col, 1)); gr.addColorStop(.16, A(col, .6)); gr.addColorStop(.38, A(col, .24)); gr.addColorStop(.62, A(col, .07)); gr.addColorStop(.85, A(col, .012)); gr.addColorStop(1, A(col, 0));   /* inverse-square-like falloff, not a flat linear ramp */
    g.fillStyle = gr; g.fillRect(0, 0, 128, 128); SPRN++; return (SPR[col] = cv);
  }
  function glow(c, x, y, r, col, a) {
    if (a <= 0.002 || r <= 0.5) return; var ga = c.globalAlpha; c.globalAlpha = ga * (a > 1 ? 1 : a); c.drawImage(sprite(col), x - r, y - r, r * 2, r * 2); c.globalAlpha = ga;
  }
  function cssv(name, fb) { var v = getComputedStyle(root).getPropertyValue(name).trim(); return /^#[0-9a-f]{3,6}$/i.test(v) ? v : fb; }

  /* ---------------- motion helpers: easing, frame-rate independent damping, smooth noise, wind ---------------- */
  var ease = {
    oc: function (x) { x = x < 0 ? 0 : x > 1 ? 1 : x; return 1 - M.pow(1 - x, 3); },
    oe: function (x) { x = x < 0 ? 0 : x > 1 ? 1 : x; return x >= 1 ? 1 : 1 - M.pow(2, -10 * x); },
    io: function (x) { x = x < 0 ? 0 : x > 1 ? 1 : x; return x < .5 ? 4 * x * x * x : 1 - M.pow(-2 * x + 2, 3) / 2; },
    ob: function (x) { x = x < 0 ? 0 : x > 1 ? 1 : x; var c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * M.pow(x - 1, 3) + c1 * M.pow(x - 1, 2); },
    ss: function (x) { x = x < 0 ? 0 : x > 1 ? 1 : x; return x * x * (3 - 2 * x); }
  };
  function damp(a, b, rate, dt) { return a + (b - a) * (1 - M.exp(-rate * dt)); }          /* same feel at 30, 60 or 144 fps */
  function nz(t, s) { return M.sin(t + s) * .5 + M.sin(t * 2.17 + s * 1.7 + 1.3) * .3 + M.sin(t * 4.31 + s * 2.9 + 2.1) * .2; }   /* smooth organic noise, -1..1 */
  function wnd(t) { return M.sin(t * .21) * .6 + M.sin(t * .53 + 1.7) * .3 + M.sin(t * 1.3 + .4) * .1; }                          /* slow shared wind gusts */


  /* ================= background scenes =================
     Each scene gets the engine E {c,w,h,px,py,mx,my,q,a,b,hi,light} and returns a frame function (t seconds, dt seconds). */
  var SC = {};
  function drip(E, col, n, maxA) {            /* paint drips running down from the top edge */
    var d = []; for (var i = 0; i < n; i++) d.push({ x: rr(0, E.w), y: -rr(0, E.h * .4), v: rr(14, 40), l: rr(30, 160), w: rr(1.5, 4), t: rr(0, 9) });
    return function (c, dt) {
      d.forEach(function (p) {
        p.v = M.min(p.v + 16 * dt, 150); p.y += p.v * dt; if (p.y - p.l > E.h) { p.x = rr(0, E.w); p.y = -rr(0, 80); p.v = rr(14, 40); p.l = rr(30, 160); }
        var g = c.createLinearGradient(0, p.y - p.l, 0, p.y); g.addColorStop(0, A(col, 0)); g.addColorStop(1, A(col, maxA));
        c.fillStyle = g; c.fillRect(p.x - p.w / 2, p.y - p.l, p.w, p.l);
        c.fillStyle = A(col, maxA); c.beginPath(); c.arc(p.x, p.y, p.w * 1.25, 0, TAU); c.fill();
      });
    };
  }
  function dust(E, n, col, o) {                /* generic drifting motes */
    o = o || {}; var p = [], i;
    function mk(first) { return { f: first ? 1 : 0, x: rr(0, E.w), y: first ? rr(0, E.h) : (o.vy < 0 ? E.h + 10 : -10), r: rr(o.r0 || .6, o.r1 || 2), vx: rr(o.vx0 === undefined ? -8 : o.vx0, o.vx1 === undefined ? 8 : o.vx1), vy: o.vy === undefined ? rr(-14, -4) : o.vy * rr(.6, 1.4), ph: rr(0, TAU) }; }
    for (i = 0; i < n; i++) p.push(mk(1));
    return function (c, t, dt) {
      p.forEach(function (m, i) {
        m.x += (m.vx + M.sin(t * .6 + m.ph) * 6) * dt; m.y += m.vy * dt;
        if (m.y < -12 || m.y > E.h + 12 || m.x < -12 || m.x > E.w + 12) p[i] = mk(0);
        m.f = M.min(1, (m.f === undefined ? 1 : m.f) + dt * 1.1);
        var a = (o.a || .5) * (.55 + .45 * M.sin(t * 2 + m.ph)) * ease.ss(m.f);          /* soft birth, tiny depth parallax: bigger motes sit closer */
        c.fillStyle = A(col, a); c.beginPath(); c.arc(m.x - E.px * m.r * 3, m.y - E.py * m.r * 2, m.r, 0, TAU); c.fill();
      });
    };
  }
  function cloud(c, x, y, s, col, a) {
    var g = c.createRadialGradient(x, y, 0, x, y, s); g.addColorStop(0, A(col, a)); g.addColorStop(1, A(col, 0));
    c.fillStyle = g; c.save(); c.translate(x, y); c.scale(1.9, .7); c.translate(-x, -y); c.beginPath(); c.arc(x, y, s, 0, TAU); c.fill(); c.restore();
  }
  function stars(E, n, col) {
    var s = []; for (var i = 0; i < n; i++) s.push({ x: rr(0, 1), y: rr(0, 1), r: rr(.4, 1.5), p: rr(0, TAU), z: rr(.2, 1) });
    return function (c, t, par) {
      s.forEach(function (o) { c.fillStyle = A(col, .25 + .6 * (.5 + .5 * M.sin(t * (.8 + o.z) + o.p)) * o.z); c.fillRect(o.x * E.w - E.px * par * o.z, o.y * E.h - E.py * par * o.z, o.r, o.r); });
    };
  }

  SC.spiderman = function (E) {
    var rings = [], next = 3, dr = dust(E, 18 * E.q | 0, '#ffffff', { a: .22, vy: -6, r0: .5, r1: 1.4 });
    return function (t, dt) {
      var c = E.c, w = E.w, h = E.h, n = 8, R0 = M.min(w, h) * .46, i, k;
      c.lineWidth = 1; c.strokeStyle = A('#ffffff', .09);
      for (i = 0; i <= n; i++) { var a = i / n * M.PI / 2; c.beginPath(); c.moveTo(0, 0); c.lineTo(M.cos(a) * R0 * 1.08, M.sin(a) * R0 * 1.08); c.stroke(); }
      for (k = 1; k <= 6; k++) {
        var r = R0 * k / 6; c.beginPath();
        for (i = 0; i <= n; i++) { var a2 = i / n * M.PI / 2, x = M.cos(a2) * r, y = M.sin(a2) * r;
          if (!i) c.moveTo(x, y); else { var am = a2 - M.PI / n / 2, sag = r * (.9 - .02 * M.sin(t * 1.4 + k)); c.quadraticCurveTo(M.cos(am) * sag, M.sin(am) * sag, x, y); } }
        c.stroke();
      }
      dr(c, t, dt);
      /* the spider drops and climbs on its thread */
      var sx = w * (w < 700 ? .84 : .9) + E.px * 8, len = h * (.17 + .1 * M.sin(t * .45) + .05 * M.sin(t * 1.3)), sw = M.sin(t * .9) * 7, bx = sx + sw, by = len;
      c.strokeStyle = A('#ffffff', .38); c.lineWidth = 1; c.beginPath(); c.moveTo(sx, 0); c.lineTo(bx, by - 6); c.stroke();
      c.strokeStyle = A(E.a, .95); c.lineWidth = 1.6;
      for (i = 0; i < 4; i++) for (var sd = -1; sd <= 1; sd += 2) { var lf = (i - 1.5) * 5, wob = M.sin(t * 6 + i) * 2.2; c.beginPath(); c.moveTo(bx, by); c.lineTo(bx + sd * (10 + i % 2 * 3), by + lf + wob - 4); c.lineTo(bx + sd * 17, by + lf * 1.8 + 6 + wob); c.stroke(); }
      c.fillStyle = A(E.a, 1); c.beginPath(); c.ellipse(bx, by + 3, 5.5, 7.5, 0, 0, TAU); c.fill();
      c.fillStyle = A(E.b, 1); c.beginPath(); c.arc(bx, by - 5, 3.6, 0, TAU); c.fill();
      /* spidey-sense */
      next -= dt; if (next <= 0) { rings.push(0); next = rr(6, 10); }
      for (i = rings.length - 1; i >= 0; i--) { rings[i] += dt; var p = rings[i] / 1.6; if (p >= 1) { rings.splice(i, 1); continue; }
        c.strokeStyle = A(E.a, .55 * (1 - p)); c.lineWidth = 2; c.beginPath(); c.arc(bx, by, 10 + p * 90, 0, TAU); c.stroke(); }
    };
  };

  SC.ironman = function (E) {
    var w = E.w, h = E.h, mob = w < 700, i, k;
    var em = dust(E, 54 * E.q | 0, '#FF5A3C', { a: .65, vy: -30, r0: .6, r1: 2, vx0: -12, vx1: 12 });
    var tags = ['PWR 100%', 'REPULSOR OK', 'ALT 12,400', 'JARVIS ONLINE', 'MK-85', 'SCAN ▸ 3.2s'];
    var DIR = ['N', '·', 'NE', '·', 'E', '·', 'SE', '·', 'S', '·', 'SW', '·', 'W', '·', 'NW', '·'];
    var LOG = ['JARVIS ▸ Welcome home, sir.', 'JARVIS ▸ All systems nominal.', 'JARVIS ▸ Repulsors charged and ready.', 'JARVIS ▸ Suit integrity 100 percent.', 'JARVIS ▸ Shall I prepare the Mark 85?', 'JARVIS ▸ Hold anywhere to charge a blast.'];
    var hexC = document.createElement('canvas'); hexC.width = w; hexC.height = h;          /* the hex grid is drawn once, then just copied each frame */
    (function (g) {
      g.strokeStyle = 'rgba(255,70,60,.085)'; g.lineWidth = 1; var hs = mob ? 40 : 48;
      for (var gy = 0; gy < h + hs; gy += hs * .87) for (var gx = ((gy / (hs * .87)) | 0) % 2 ? hs / 2 : 0; gx < w + hs; gx += hs) { g.beginPath(); for (var j = 0; j < 6; j++) { var an = j * TAU / 6 + M.PI / 6; g.lineTo(gx + M.cos(an) * hs * .5, gy + M.sin(an) * hs * .5); } g.closePath(); g.stroke(); }
    })(hexC.getContext('2d'));
    var pulses = [], nextP = 1.2, fly = null, nextF = 5, li = 0, lt = 0, rx = -1, ry = -1;
    function bracket(c, x, y, s, len) { for (var sx = -1; sx <= 1; sx += 2) for (var sy = -1; sy <= 1; sy += 2) { c.beginPath(); c.moveTo(x + sx * s, y + sy * (s - len)); c.lineTo(x + sx * s, y + sy * s); c.lineTo(x + sx * (s - len), y + sy * s); c.stroke(); } }
    return function (t, dt) {
      var c = E.c, pwr = E.pw, cx = w * (mob ? .76 : .82) - E.px * 10, cy = h * (mob ? .17 : .26) - E.py * 8, r = M.min(w, h) * (mob ? .12 : .105), beat = .5 + .5 * M.pow(M.sin(t * 2.2), 2);
      c.drawImage(hexC, 0, 0);
      /* energy pulses roll out of the reactor across the grid */
      nextP -= dt; if (nextP <= 0) { pulses.push(0); nextP = rr(3.5, 6); }
      for (i = pulses.length - 1; i >= 0; i--) { pulses[i] += dt; var pp = pulses[i] / 2.8; if (pp >= 1) { pulses.splice(i, 1); continue; } c.strokeStyle = A(E.hi, .3 * (1 - pp) * pwr); c.lineWidth = 2 + 6 * (1 - pp); c.beginPath(); c.arc(cx, cy, pp * M.max(w, h) * .95, 0, TAU); c.stroke(); }
      /* arc reactor */
      glow(c, cx, cy, r * 3.6, E.hi, (.15 + .1 * beat) * pwr); glow(c, cx, cy, r * 1.2, '#ffffff', .5 + .3 * beat);
      c.lineCap = 'butt'; c.lineWidth = r * .2; c.strokeStyle = A(E.hi, .22); c.beginPath(); c.arc(cx, cy, r * 1.5, 0, TAU); c.stroke();
      c.strokeStyle = A(E.hi, .9); for (i = 0; i < 10; i++) { var a0 = t * .2 + i * TAU / 10; c.beginPath(); c.arc(cx, cy, r * 1.5, a0, a0 + TAU / 10 * .64); c.stroke(); }   /* ten coil blocks */
      c.lineWidth = 1.2; for (i = 0; i < 60; i++) { var ta = -t * .12 + i * TAU / 60, l0 = r * 1.82, l1 = r * (i % 5 ? 1.92 : 2.04); c.strokeStyle = A(i % 5 ? E.hi : E.a, i % 5 ? .45 : .85); c.beginPath(); c.moveTo(cx + M.cos(ta) * l0, cy + M.sin(ta) * l0); c.lineTo(cx + M.cos(ta) * l1, cy + M.sin(ta) * l1); c.stroke(); }
      c.lineWidth = 1.6; c.setLineDash([9, 7]); c.strokeStyle = A(E.a, .6); c.beginPath(); c.arc(cx, cy, r * 2.3, t * .35, t * .35 + TAU * .8); c.stroke(); c.setLineDash([]);
      c.strokeStyle = A(E.hi, .85); c.lineWidth = 2; c.beginPath(); c.arc(cx, cy, r * .66, 0, TAU); c.stroke();
      [[.5, .5, 1], [.5, -.35, -1]].forEach(function (q, n) { c.strokeStyle = A(n ? E.a : E.hi, .8); c.beginPath(); for (var j = 0; j < 3; j++) { var a3 = t * q[1] + j * TAU / 3 + n * M.PI / 3; c.lineTo(cx + M.cos(a3) * r * (n ? .5 : .58), cy + M.sin(a3) * r * (n ? .5 : .58)); } c.closePath(); c.stroke(); });
      glow(c, cx, cy, r * .5, '#ffffff', .95);
      /* orbiting readouts */
      c.font = '600 11px ui-monospace,Menlo,monospace'; var nt = mob ? 3 : tags.length;
      for (k = 0; k < nt; k++) { var ang = t * .3 + k * 1.05, tx = cx + M.cos(ang) * r * 2.9, ty = cy + M.sin(ang) * r * 2.9 * .72; c.fillStyle = A(E.hi, .6); c.fillText(tags[k], tx, ty); c.strokeStyle = A(E.hi, .22); c.lineWidth = 1; c.beginPath(); c.moveTo(cx + M.cos(ang) * r * 2.45, cy + M.sin(ang) * r * 2.45 * .72); c.lineTo(tx, ty); c.stroke(); }
      /* scan sweep */
      var sy = ((t * .12) % 1) * h, g = c.createLinearGradient(0, sy - 70, 0, sy); g.addColorStop(0, A(E.hi, 0)); g.addColorStop(1, A(E.hi, .11 * pwr)); c.fillStyle = g; c.fillRect(0, sy - 70, w, 70);
      if (!mob) {
        /* altitude ladder (left) */
        var lx = 26, y0 = h * .26, y1 = h * .74, span = 420; c.font = '600 10px ui-monospace,Menlo,monospace'; c.lineWidth = 1;
        for (k = 0; k < 22; k++) { var pos = (k * 20 + t * 14) % span, yy = y0 + pos * (y1 - y0) / span, fa = M.sin(pos / span * M.PI), long = k % 5 === 0; c.strokeStyle = A(E.hi, .55 * fa); c.beginPath(); c.moveTo(lx, yy); c.lineTo(lx + (long ? 16 : 8), yy); c.stroke(); if (long) { c.fillStyle = A(E.hi, .6 * fa); c.fillText(String(12400 - (k * 20 + (t * 14 | 0)) % 440), lx + 22, yy + 3); } }
        c.strokeStyle = A(E.a, .9); c.beginPath(); c.moveTo(lx - 8, (y0 + y1) / 2); c.lineTo(lx + 2, (y0 + y1) / 2 - 5); c.lineTo(lx + 2, (y0 + y1) / 2 + 5); c.closePath(); c.stroke();
        /* compass tape (top) */
        var sp = 64, off = (t * 12) % (sp * 16), base = (off / sp) | 0, fr = off % sp; c.textAlign = 'center'; c.font = '700 11px ui-monospace,Menlo,monospace';
        for (k = -6; k <= 6; k++) { var xx = w / 2 + k * sp - fr, fb = 1 - M.abs(xx - w / 2) / (sp * 6.2); if (fb <= 0) continue; c.fillStyle = A(E.hi, .6 * fb); c.fillText(DIR[(base + k + 160) % 16], xx, 92); c.strokeStyle = A(E.hi, .35 * fb); c.beginPath(); c.moveTo(xx, 98); c.lineTo(xx, 104); c.stroke(); }
        c.fillStyle = A(E.a, .95); c.beginPath(); c.moveTo(w / 2 - 5, 110); c.lineTo(w / 2 + 5, 110); c.lineTo(w / 2, 104); c.closePath(); c.fill(); c.textAlign = 'left';
        /* JARVIS typing */
        lt += dt; var msg = LOG[li % LOG.length], typed = M.min(msg.length, (lt * 26) | 0); if (lt > msg.length / 26 + 3.4) { li++; lt = 0; }
        c.font = '600 12px ui-monospace,Menlo,monospace'; c.fillStyle = A(E.hi, .72); c.fillText(msg.slice(0, typed) + (M.sin(t * 8) > 0 ? '▌' : ''), 22, h - 24);
      }
      /* Iron Man flies past */
      nextF -= dt; if (nextF <= 0 && !fly) { fly = { x: -80, y: rr(h * .14, h * .6), vx: rr(560, 800), vy: rr(-50, 50) }; nextF = rr(12, 20); }
      if (fly) { fly.x += fly.vx * dt; fly.y += fly.vy * dt; var tg = c.createLinearGradient(fly.x - 260, fly.y, fly.x, fly.y); tg.addColorStop(0, A(E.a, 0)); tg.addColorStop(.7, A(E.a, .45)); tg.addColorStop(1, A(E.hi, .95)); c.strokeStyle = tg; c.lineWidth = 3; c.beginPath(); c.moveTo(fly.x - 260, fly.y - fly.vy * .32); c.lineTo(fly.x, fly.y); c.stroke(); glow(c, fly.x, fly.y, 28, '#ffffff', .9); glow(c, fly.x, fly.y, 80, E.hi, .35 * pwr); if (fly.x > w + 320) fly = null; }
      /* targeting reticle: follows the mouse, or lingers where you last touched */
      var tx2 = -1, ty2 = -1, ra = 1, now = performance.now();
      if (E.fine && E.mx >= 0) { tx2 = E.mx; ty2 = E.my; } else if (E.tapT && now - E.tapT < 3200) { tx2 = E.tapX; ty2 = E.tapY; ra = 1 - M.max(0, (now - E.tapT - 2200) / 1000); }
      if (tx2 >= 0) {
        if (rx < 0) { rx = tx2; ry = ty2; } var kk = M.min(1, dt * 11); rx += (tx2 - rx) * kk; ry += (ty2 - ry) * kk;
        var s = 24 + 3 * M.sin(t * 5); c.lineWidth = 1.5; c.strokeStyle = A(E.hi, .85 * ra); bracket(c, rx, ry, s, 9);
        c.setLineDash([3, 5]); c.beginPath(); c.arc(rx, ry, s * .55, t * 2.4, t * 2.4 + TAU * .85); c.stroke(); c.setLineDash([]);
        c.fillStyle = A(E.a, ra); c.beginPath(); c.arc(rx, ry, 2, 0, TAU); c.fill();
        c.font = '600 10px ui-monospace,Menlo,monospace'; c.fillStyle = A(E.hi, .8 * ra); c.fillText('LOCK ' + (M.hypot(rx - cx, ry - cy) / r).toFixed(1) + 'R', rx + s + 6, ry - s + 8);
      }
      em(c, t, dt);
    };
  };

  SC.ultron = function (E) {
    var dr = drip(E, '#B3121F', 9 * E.q + 2 | 0, .55), glitch = [], nx = 2;
    return function (t, dt) {
      var c = E.c, w = E.w, h = E.h, i;
      dr(c, dt);
      var ex = w * (.5 + .38 * M.sin(t * .35)), ey = h * .06;                                   /* scanning eye */
      glow(c, ex, ey, 120, '#B3121F', .28); c.fillStyle = A('#B3121F', .9); c.beginPath(); c.arc(ex, ey, 3.5, 0, TAU); c.fill();
      c.strokeStyle = A('#B3121F', .16); c.beginPath(); c.moveTo(ex, ey); c.lineTo(ex + M.sin(t) * 40, h); c.stroke();
      nx -= dt; if (nx <= 0) { for (i = 0; i < (3 + R() * 4 | 0); i++) glitch.push({ y: rr(0, h), h: rr(2, 22), x: rr(0, w * .6), w: rr(w * .1, w * .7), l: rr(.08, .25) }); nx = rr(2, 5); }
      for (i = glitch.length - 1; i >= 0; i--) { var gl = glitch[i]; gl.l -= dt; if (gl.l <= 0) { glitch.splice(i, 1); continue; } c.fillStyle = A(i % 2 ? '#B3121F' : '#15110F', .14); c.fillRect(gl.x, gl.y, gl.w, gl.h); }
    };
  };

  SC.thanos = function (E) {
    var ash = [], cols = ['#3A7BFF', '#F0C23A', '#E23B3B', '#9B59F0', '#35C46B', '#FF8A1F'], i, wave = 0;
    for (i = 0; i < 90 * E.q; i++) ash.push({ x: rr(0, E.w), y: rr(0, E.h), r: rr(.8, 2.4), v: rr(6, 26), d: rr(-8, 8), a: rr(.15, .5) });
    return function (t, dt) {
      var c = E.c, w = E.w, h = E.h, cx = w * (w < 700 ? .5 : .82) - E.px * 10, cy = h * (w < 700 ? .14 : .3), r = M.min(w, h) * .1;
      glow(c, cx, cy, r * 3, '#F0B24A', .13);
      cols.forEach(function (col, k) {                                                         /* the six stones orbit */
        var an = t * .6 + k * TAU / 6, x = cx + M.cos(an) * r * 1.5, y = cy + M.sin(an) * r * .75, z = .75 + .25 * M.sin(an);
        glow(c, x, y, 26 * z, col, .55); c.fillStyle = A(col, 1); c.beginPath(); c.moveTo(x, y - 6 * z); c.lineTo(x + 5 * z, y); c.lineTo(x, y + 6 * z); c.lineTo(x - 5 * z, y); c.closePath(); c.fill();
      });
      wave += dt * .07; if (wave > 1.3) wave = 0;
      ash.forEach(function (p) {
        var near = M.abs(p.x / w - wave * 1.2 + .1) < .12 ? 3 : 1;                               /* the Snap wave crumbles dust faster */
        p.x += p.v * dt * near * .6; p.y += (p.d - 10) * dt * .5 * near; if (p.x > w + 10 || p.y < -10) { p.x = rr(-30, w * .3); p.y = rr(0, h); }
        c.fillStyle = A(near > 1 ? '#F0B24A' : '#BDA9A0', p.a); c.fillRect(p.x, p.y, p.r, p.r);
      });
    };
  };

  SC.loki = function (E) {
    var d = dust(E, 55 * E.q | 0, '#C98A18', { a: .7, vy: -9, r0: .6, r1: 2.1 }), rip = [], nx = 0;
    return function (t, dt) {
      var c = E.c, w = E.w, h = E.h, i;
      nx -= dt; if (nx <= 0) { rip.push({ x: rr(w * .2, w * .9), y: rr(h * .1, h * .8), t: 0 }); nx = rr(2.2, 4.5); }
      for (i = rip.length - 1; i >= 0; i--) { var o = rip[i]; o.t += dt; var p = o.t / 5; if (p >= 1) { rip.splice(i, 1); continue; }
        for (var k = 0; k < 3; k++) { var q = M.max(0, p - k * .09); c.strokeStyle = A(k ? '#C98A18' : '#1E6B3B', .28 * (1 - p) * (1 - q)); c.lineWidth = 1.5; c.beginPath(); c.ellipse(o.x, o.y, 20 + q * 330, (20 + q * 330) * .5, 0, 0, TAU); c.stroke(); } }
      c.strokeStyle = A('#1E6B3B', .14); c.lineWidth = 1.2;                                     /* sacred timeline branches */
      for (i = 0; i < 4; i++) { var by = h * (.25 + i * .18), ph = t * .15 + i; c.beginPath(); c.moveTo(0, by); c.bezierCurveTo(w * .3, by + M.sin(ph) * 40, w * .55, by - M.cos(ph) * 50, w, by + M.sin(ph * 1.3) * 60); c.stroke(); }
      d(c, t, dt);
      if (((t * .8) | 0) % 9 === 0 && (t % 1) < .1) { c.fillStyle = A('#1E6B3B', .08); c.fillRect(0, h * .4, w, 6); }
    };
  };

  SC.deadpool = function (E) {
    var sl = [], nx = 2, taco = [], i, d = dust(E, 40 * E.q | 0, '#FF2B3E', { a: .45, vy: 14, r0: 1, r1: 3, vx0: -12, vx1: 12 });
    for (i = 0; i < 4; i++) taco.push({ x: rr(0, 1), y: rr(0, 1), s: rr(18, 30), v: rr(8, 18), r: rr(0, TAU) });
    return function (t, dt) {
      var c = E.c, w = E.w, h = E.h; d(c, t, dt);
      c.font = '26px serif'; taco.forEach(function (o) { o.y += o.v * dt / h; o.r += dt * .6; if (o.y > 1.05) { o.y = -.05; o.x = R(); } c.save(); c.translate(o.x * w, o.y * h); c.rotate(o.r); c.globalAlpha = .55; c.font = o.s + 'px serif'; c.fillText('🌮', 0, 0); c.restore(); });
      nx -= dt; if (nx <= 0) { var y0 = rr(0, h * .6), dir = R() < .5 ? 1 : -1; sl.push({ x0: dir > 0 ? -50 : w + 50, y0: y0, x1: dir > 0 ? w + 50 : -50, y1: y0 + rr(h * .2, h * .6) * (R() < .5 ? 1 : -1), t: 0 }); nx = rr(3.5, 7); }
      for (i = sl.length - 1; i >= 0; i--) { var s = sl[i]; s.t += dt; var p = s.t / .9; if (p >= 1) { sl.splice(i, 1); continue; }
        var hd = M.min(1, p * 3), tl = M.max(0, p * 3 - 1), ax = s.x0 + (s.x1 - s.x0) * tl, ay = s.y0 + (s.y1 - s.y0) * tl, bx = s.x0 + (s.x1 - s.x0) * hd, by = s.y0 + (s.y1 - s.y0) * hd;
        c.strokeStyle = A('#ffffff', .85 * (1 - p)); c.lineWidth = 3; c.lineCap = 'round'; c.beginPath(); c.moveTo(ax, ay); c.lineTo(bx, by); c.stroke();
        c.strokeStyle = A('#FF2B3E', .55 * (1 - p)); c.lineWidth = 9; c.beginPath(); c.moveTo(ax, ay); c.lineTo(bx, by); c.stroke(); c.lineCap = 'butt'; }
    };
  };

  SC.blackpanther = function (E) {
    var d = dust(E, 50 * E.q | 0, '#B497FF', { a: .6, vy: -7, r0: .5, r1: 1.7 }), src = [{ x: .8, y: .2, t: 0 }], hs = 34 * (E.q < .7 ? 1.4 : 1);
    return function (t, dt) {
      var c = E.c, w = E.w, h = E.h, i; if (!((t * 10 | 0) % 40) && src.length < 4 && R() < .05) src.push({ x: R(), y: R() * .8, t: 0 });
      for (i = src.length - 1; i >= 0; i--) { src[i].t += dt; if (src[i].t > 7) src.splice(i, 1); }
      var row = 0;
      for (var gy = 0; gy < h + hs; gy += hs * .87, row++) for (var gx = row % 2 ? hs / 2 : 0; gx < w + hs; gx += hs) {
        var b = 0; for (i = 0; i < src.length; i++) { var s = src[i], dd = M.hypot(gx - s.x * w, gy - s.y * h), f = M.abs(dd - s.t * 170); if (f < 70) b = M.max(b, (1 - f / 70) * (1 - s.t / 7)); }
        if (b > .08) { c.strokeStyle = A('#B497FF', b * .8); c.lineWidth = 1.3; c.beginPath(); for (i = 0; i < 6; i++) { var an = i * TAU / 6 + M.PI / 6; c.lineTo(gx + M.cos(an) * hs * .46, gy + M.sin(an) * hs * .46); } c.closePath(); c.stroke(); if (b > .5) { c.fillStyle = A('#7C5CFF', (b - .5) * .35); c.fill(); } }
        else { c.fillStyle = A('#B497FF', .1); c.fillRect(gx - 1, gy - 1, 2, 2); }
      }
      d(c, t, dt);
    };
  };

  SC.punisher = function (E) {
    var dr = drip(E, '#F4F4F4', 7 * E.q + 2 | 0, .22), ash = dust(E, 45 * E.q | 0, '#BDBDBD', { a: .4, vy: 10, r0: .6, r1: 1.7 }), lx = E.w * .5, ly = E.h * .5;
    return function (t, dt) {
      var c = E.c, w = E.w, h = E.h; dr(c, dt); ash(c, t, dt);
      var tx = E.mx > 0 ? E.mx : w * (.5 + .3 * M.sin(t * .4)), ty = E.my > 0 ? E.my : h * (.5 + .25 * M.sin(t * .31));
      lx += (tx - lx) * M.min(1, dt * 2.2); ly += (ty - ly) * M.min(1, dt * 2.2);
      var g = c.createLinearGradient(w * .06, h, lx, ly); g.addColorStop(0, A('#D01832', 0)); g.addColorStop(1, A('#D01832', .3));
      c.strokeStyle = g; c.lineWidth = 1.2; c.beginPath(); c.moveTo(w * .06, h); c.lineTo(lx, ly); c.stroke();
      glow(c, lx, ly, 26, '#D01832', .65); c.fillStyle = '#FF3347'; c.beginPath(); c.arc(lx, ly, 2.6, 0, TAU); c.fill();
    };
  };

  SC.johnwick = function (E) {
    var rain = [], i, fl = 0; for (i = 0; i < 120 * E.q; i++) rain.push({ x: rr(0, E.w), y: rr(0, E.h), l: rr(10, 28), v: rr(500, 900) });
    return function (t, dt) {
      var c = E.c, w = E.w, h = E.h;
      c.lineWidth = 1; rain.forEach(function (r) { r.y += r.v * dt; r.x -= r.v * .12 * dt; if (r.y > h) { r.y = -30; r.x = rr(0, w * 1.1); } c.strokeStyle = A('#AEB6C8', .22); c.beginPath(); c.moveTo(r.x, r.y); c.lineTo(r.x + r.l * .12, r.y - r.l); c.stroke(); });
      var g = c.createLinearGradient(0, h * .8, 0, h); g.addColorStop(0, A('#2F7BFF', 0)); g.addColorStop(1, A('#2F7BFF', .16)); c.fillStyle = g; c.fillRect(0, h * .8, w, h * .2);
      for (i = 0; i < 6; i++) { var gx = ((i * .21 + t * .01) % 1.1) * w; glow(c, gx, h * .96, 90, i % 2 ? '#2F7BFF' : '#D8B24A', .14); }
      var cx = w * (w < 700 ? .16 : .1), cy = h * .2 + M.sin(t * .8) * 6, sx = M.abs(M.cos(t * 1.4));                                        /* Continental coin */
      glow(c, cx, cy, 60, '#D8B24A', .15); c.save(); c.translate(cx, cy); c.scale(M.max(.12, sx), 1);
      var cg = c.createLinearGradient(-22, -22, 22, 22); cg.addColorStop(0, '#F3DA8A'); cg.addColorStop(1, '#8F6B1A'); c.fillStyle = cg; c.beginPath(); c.arc(0, 0, 22, 0, TAU); c.fill();
      c.strokeStyle = A('#4A3408', .7); c.lineWidth = 2; c.beginPath(); c.arc(0, 0, 16, 0, TAU); c.stroke(); c.restore();
      fl -= dt; if (fl <= 0 && R() < dt * .08) fl = .18; if (fl > 0) { c.fillStyle = A('#ECEFF6', .05 * fl / .18); c.fillRect(0, 0, w, h); }
    };
  };

  function bat(c, x, y, s, fl) {            /* small bat silhouette */
    c.save(); c.translate(x, y); c.scale(s, s); var f = M.sin(fl) * .5 + .5; c.beginPath();
    c.moveTo(0, 2); c.quadraticCurveTo(-10, -10 - f * 8, -26, -4 - f * 6); c.quadraticCurveTo(-18, 0, -16, 6); c.quadraticCurveTo(-10, 2, -6, 8); c.quadraticCurveTo(-3, 3, 0, 8);
    c.quadraticCurveTo(3, 3, 6, 8); c.quadraticCurveTo(10, 2, 16, 6); c.quadraticCurveTo(18, 0, 26, -4 - f * 6); c.quadraticCurveTo(10, -10 - f * 8, 0, 2); c.closePath(); c.fill(); c.restore();
  }
  SC.batman = function (E) {
    var bats = [], nx = 1, fog = [], i; for (i = 0; i < 6; i++) fog.push({ x: rr(0, E.w), y: rr(E.h * .5, E.h), s: rr(200, 400), v: rr(4, 12) });
    return function (t, dt) {
      var c = E.c, w = E.w, h = E.h, ox = w * .08, oy = h + 20, an = -M.PI / 2 + M.sin(t * .22) * .5 + .45, L = h * 1.35, sx = ox + M.cos(an) * L, sy = oy + M.sin(an) * L;
      var g = c.createLinearGradient(ox, oy, sx, sy); g.addColorStop(0, A('#FFD21F', .22)); g.addColorStop(1, A('#FFD21F', .02)); c.fillStyle = g;
      c.beginPath(); c.moveTo(ox - 30, oy); c.lineTo(ox + 30, oy); c.lineTo(sx + M.cos(an + 1.57) * 150, sy + M.sin(an + 1.57) * 150); c.lineTo(sx - M.cos(an + 1.57) * 150, sy - M.sin(an + 1.57) * 150); c.closePath(); c.fill();
      var spx = ox + M.cos(an) * L * .8, spy = oy + M.sin(an) * L * .8; glow(c, spx, spy, 120, '#FFD21F', .2); c.fillStyle = A('#07080B', .9); bat(c, spx, spy, 1.6, t * 2);
      fog.forEach(function (f) { f.x += f.v * dt; if (f.x > w + f.s) f.x = -f.s; cloud(c, f.x, f.y, f.s, '#B8B9B2', .06); });
      nx -= dt; if (nx <= 0) { bats.push({ x: w + 40, y: rr(h * .08, h * .6), v: rr(120, 260), s: rr(.5, 1.1), p: rr(0, 9) }); nx = rr(2.2, 5); }
      c.fillStyle = A('#000000', .8); for (i = bats.length - 1; i >= 0; i--) { var b = bats[i]; b.x -= b.v * dt; b.y += M.sin(t * 2 + b.p) * 18 * dt; if (b.x < -60) { bats.splice(i, 1); continue; } bat(c, b.x, b.y, b.s, t * 14 + b.p); }
    };
  };

  SC.joker = function (E) {
    var cards = [], i, suits = ['♠', '♥', '♦', '♣']; for (i = 0; i < 16 * E.q + 4; i++) cards.push({ x: rr(0, E.w), y: rr(-E.h, E.h), v: rr(26, 70), s: rr(.7, 1.3), r: rr(0, TAU), vr: rr(-1, 1), f: rr(0, TAU), su: pick(suits) });
    return function (t, dt) {
      var c = E.c, w = E.w, h = E.h;
      cards.forEach(function (k) {
        k.y += k.v * dt; k.r += k.vr * dt * .5; if (k.y > h + 60) { k.y = -60; k.x = rr(0, w); }
        c.save(); c.translate(k.x + M.sin(t * .6 + k.f) * 20, k.y); c.rotate(k.r); c.scale(M.max(.15, M.abs(M.cos(t * .9 + k.f))) * k.s, k.s);
        c.fillStyle = A('#F4ECFF', .85); c.strokeStyle = A('#A24BE0', .8); c.lineWidth = 2; c.beginPath(); c.roundRect ? c.roundRect(-20, -28, 40, 56, 5) : c.rect(-20, -28, 40, 56); c.fill(); c.stroke();
        c.fillStyle = k.su === '♥' || k.su === '♦' ? '#D01832' : '#2A1A3D'; c.font = '700 22px serif'; c.textAlign = 'center'; c.fillText(k.su, 0, 8); c.restore();
      });
      var sx = w * .5, sy = h * .93, sw = M.min(w * .8, 640), pul = 1 + .04 * M.sin(t * 2.2);                       /* the smile */
      glow(c, sx, sy, sw * .55, '#A6E22E', .06);
      c.strokeStyle = A('#A6E22E', .35); c.lineWidth = 6; c.lineCap = 'round'; c.beginPath(); c.moveTo(sx - sw / 2, sy - 40); c.quadraticCurveTo(sx, sy + 60 * pul, sx + sw / 2, sy - 40); c.stroke();
      c.lineWidth = 3; c.beginPath(); c.moveTo(sx - sw / 2, sy - 40); c.lineTo(sx - sw / 2 - 16, sy - 66); c.moveTo(sx + sw / 2, sy - 40); c.lineTo(sx + sw / 2 + 16, sy - 66); c.stroke(); c.lineCap = 'butt';
    };
  };

  SC.drstrange = function (E) {
    var sp = []; return function (t, dt) {
      var c = E.c, w = E.w, h = E.h, cx = w * (w < 700 ? .7 : .84) - E.px * 12, cy = h * (w < 700 ? .72 : .66) - E.py * 8, r = M.min(w, h) * .2, i;
      glow(c, cx, cy, r * 2.4, '#FF8A1F', .14); c.lineWidth = 2;
      [[1, .5, TAU * .9, 0], [.82, -.7, TAU * .55, 2], [.64, 1.1, TAU * .75, 1], [.4, -1.6, TAU * .5, 4]].forEach(function (q, k) {
        c.strokeStyle = A(k % 2 ? '#FFC64D' : '#FF8A1F', .75); c.setLineDash(k === 1 ? [3, 9] : []); c.beginPath(); var s0 = q[3] + t * q[1]; c.arc(cx, cy, r * q[0], s0, s0 + q[2]); c.stroke();
      });
      c.setLineDash([]); c.strokeStyle = A('#FF8A1F', .5);
      for (i = 0; i < 12; i++) { var a = t * .5 + i * TAU / 12; c.beginPath(); c.moveTo(cx + M.cos(a) * r * 1.02, cy + M.sin(a) * r * 1.02); c.lineTo(cx + M.cos(a) * r * 1.12, cy + M.sin(a) * r * 1.12); c.stroke(); }
      c.beginPath(); for (i = 0; i < 6; i++) { var b = -t * .8 + i * TAU / 6 * 2; c.lineTo(cx + M.cos(b) * r * .7, cy + M.sin(b) * r * .7); } c.closePath(); c.stroke();
      if (sp.length < 90 * E.q) { var ang = R() * TAU; sp.push({ x: cx + M.cos(ang) * r, y: cy + M.sin(ang) * r, vx: M.cos(ang) * rr(20, 120) + rr(-30, 30), vy: M.sin(ang) * rr(20, 120) + 40, l: 1 }); }
      for (i = sp.length - 1; i >= 0; i--) { var p = sp[i]; p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 120 * dt; p.l -= dt * .8; if (p.l <= 0) { sp.splice(i, 1); continue; } c.fillStyle = A('#FFC64D', p.l); c.fillRect(p.x, p.y, 2, 2); }
    };
  };

  SC.shinchan = function (E) {
    var th = [], i, cols = ['#D42A25', '#FFD21F', '#1FA64B', '#2D7BFF'];
    for (i = 0; i < 9; i++) th.push({ x: rr(.05, .95), y: rr(.1, .9), s: rr(14, 26), c: pick(cols), p: rr(0, TAU), k: i % 3 });
    return function (t, dt) {
      var c = E.c, w = E.w, h = E.h, cx = w * .5, cy = h * .35, rot = t * .03;
      c.strokeStyle = A('#1F1B16', .07); c.lineWidth = 1.4;
      for (i = 0; i < 70; i++) { var a = rot + i / 70 * TAU, i0 = M.hypot(w, h) * (.18 + .1 * ((i * 7) % 5) / 5), i1 = M.hypot(w, h) * .8; c.beginPath(); c.moveTo(cx + M.cos(a) * i0, cy + M.sin(a) * i0); c.lineTo(cx + M.cos(a) * i1, cy + M.sin(a) * i1); c.stroke(); }
      th.forEach(function (o) {
        var bounce = M.abs(M.sin(t * 1.8 + o.p)), x = o.x * w, y = o.y * h - bounce * 26, sq = 1 + (1 - bounce) * .12;
        c.save(); c.translate(x, y); c.scale(1 / sq, sq); c.fillStyle = A(o.c, .5); c.strokeStyle = A('#1F1B16', .4); c.lineWidth = 2;
        c.beginPath();
        if (o.k === 0) { for (var j = 0; j < 10; j++) { var rad = j % 2 ? o.s * .45 : o.s, an = j * M.PI / 5 - M.PI / 2 + t * .4; c.lineTo(M.cos(an) * rad, M.sin(an) * rad); } c.closePath(); }
        else if (o.k === 1) { c.arc(0, 0, o.s * .6, 0, TAU); } else { c.moveTo(0, o.s * .5); c.bezierCurveTo(-o.s, -o.s * .1, -o.s * .4, -o.s * .8, 0, -o.s * .25); c.bezierCurveTo(o.s * .4, -o.s * .8, o.s, -o.s * .1, 0, o.s * .5); }
        c.fill(); c.stroke(); c.restore();
        c.fillStyle = A('#1F1B16', .08); c.beginPath(); c.ellipse(x, o.y * h + 30, o.s * .6 * (1 - bounce * .4), 4, 0, 0, TAU); c.fill();
      });
    };
  };

  SC.ghibli = function (E) {
    var cl = [], i, seeds = [], bl = []; for (i = 0; i < 8; i++) cl.push({ x: rr(0, E.w), y: rr(E.h * .05, E.h * .45), s: rr(80, 190), v: rr(3, 11) });
    for (i = 0; i < 18 * E.q + 5; i++) seeds.push({ x: rr(0, E.w), y: rr(0, E.h), p: rr(0, TAU), v: rr(10, 26) });
    var nb = M.ceil(E.w / 9); for (i = 0; i < nb; i++) bl.push({ x: i * 9 + rr(-3, 3), h: rr(22, 60), p: rr(0, TAU) });
    return function (t, dt) {
      var c = E.c, w = E.w, h = E.h;
      var g = c.createLinearGradient(0, 0, w * .4, h * .5); g.addColorStop(0, A('#FFF4B0', .22)); g.addColorStop(1, A('#FFF4B0', 0)); c.fillStyle = g; c.beginPath(); c.moveTo(w * .1, 0); c.lineTo(w * .4, 0); c.lineTo(w * .75, h * .7); c.lineTo(w * .3, h * .7); c.fill();
      cl.forEach(function (o) { o.x += o.v * dt; if (o.x > w + o.s * 2) o.x = -o.s * 2; cloud(c, o.x - E.px * 6, o.y, o.s, '#FFFFFF', .55); });
      seeds.forEach(function (s) { s.x += s.v * dt + M.sin(t + s.p) * 8 * dt; s.y -= (s.v * .4) * dt; if (s.x > w + 10 || s.y < -10) { s.x = rr(-30, w * .5); s.y = rr(h * .5, h + 10); }
        c.strokeStyle = A('#FFFFFF', .8); c.lineWidth = 1; c.beginPath(); c.moveTo(s.x, s.y); c.lineTo(s.x - 6, s.y + 7); c.stroke(); c.fillStyle = A('#FFFFFF', .75); c.beginPath(); c.arc(s.x, s.y, 2.2, 0, TAU); c.fill(); });
      c.strokeStyle = A('#23783A', .55); c.lineWidth = 2; c.beginPath();
      bl.forEach(function (b) { var sw = M.sin(t * 1.6 + b.p + b.x * .01) * 8 + M.sin(t * .5 + b.x * .004) * 6 + E.px * -4; c.moveTo(b.x, h); c.quadraticCurveTo(b.x + sw * .3, h - b.h * .6, b.x + sw, h - b.h); }); c.stroke();
    };
  };

  SC.panda = function (E) {
    var pt = [], i, rip = [], nx = 0; for (i = 0; i < 26 * E.q + 6; i++) pt.push({ x: rr(0, E.w), y: rr(-E.h, E.h), v: rr(18, 40), r: rr(0, TAU), vr: rr(-1.5, 1.5), s: rr(5, 11), leaf: R() < .3, p: rr(0, TAU) });
    return function (t, dt) {
      var c = E.c, w = E.w, h = E.h;
      nx -= dt; if (nx <= 0) { rip.push({ x: rr(w * .1, w * .9), y: h * rr(.82, .97), t: 0 }); nx = rr(1.6, 3.4); }
      for (i = rip.length - 1; i >= 0; i--) { var o = rip[i]; o.t += dt; var p = o.t / 4; if (p >= 1) { rip.splice(i, 1); continue; } c.strokeStyle = A('#0B66A8', .28 * (1 - p)); c.lineWidth = 1.5; c.beginPath(); c.ellipse(o.x, o.y, 8 + p * 110, (8 + p * 110) * .3, 0, 0, TAU); c.stroke(); }
      pt.forEach(function (o) {
        o.y += o.v * dt; o.x += M.sin(t * .8 + o.p) * 22 * dt; o.r += o.vr * dt; if (o.y > h + 20) { o.y = -20; o.x = rr(0, w); }
        c.save(); c.translate(o.x, o.y); c.rotate(o.r); c.fillStyle = o.leaf ? A('#2E8B3E', .6) : A('#F6A5B8', .85); c.beginPath(); c.ellipse(0, 0, o.s, o.s * (o.leaf ? .28 : .55), 0, 0, TAU); c.fill(); c.restore();
      });
    };
  };

  SC.walle = function (E) {
    var st = stars(E, 90 * E.q | 0, '#FFF4DA'), d = dust(E, 40 * E.q | 0, '#E68A2E', { a: .4, vx0: 10, vx1: 40, vy: -2, r0: .8, r1: 2 }), blink = 0, nb = 2;
    return function (t, dt) {
      var c = E.c, w = E.w, h = E.h; st(c, t, 10); d(c, t, dt);
      var cyc = (t % 36) / 36, gr = M.min(1, cyc * 2.2), sx = w * (w < 700 ? .12 : .09), base = h, ht = h * .26 * gr, sw = M.sin(t * .9) * 5 * gr;   /* the sprout grows and sways */
      c.strokeStyle = A('#6BE675', .9); c.lineWidth = 3; c.beginPath(); c.moveTo(sx, base); c.quadraticCurveTo(sx + sw, base - ht * .5, sx + sw * 1.6, base - ht); c.stroke();
      if (gr > .35) { var lg = M.min(1, (gr - .35) * 1.6); [[-1, .55], [1, .8]].forEach(function (L) { var lx = sx + sw * 1.2 * L[1], ly = base - ht * L[1]; c.fillStyle = A('#6BE675', .85); c.beginPath(); c.ellipse(lx + L[0] * 13 * lg, ly - 4 * lg, 14 * lg, 6 * lg, L[0] * -.6, 0, TAU); c.fill(); }); }
      glow(c, sx + sw * 1.6, base - ht, 70, '#6BE675', .12 * gr);
      var ex = w * (w < 700 ? .84 : .9), ey = h * .9, dx = E.mx > 0 ? (E.mx - ex) : 0, dy = E.my > 0 ? (E.my - ey) : 0, dl = M.hypot(dx, dy) || 1, k = M.min(5, dl * .02);   /* WALL·E's eyes follow the pointer */
      nb -= dt; if (nb <= 0) { blink = .16; nb = rr(2.5, 6); } blink = M.max(0, blink - dt);
      c.fillStyle = A('#2A3050', .95); c.fillRect(ex - 40, ey + 6, 80, 30); c.fillRect(ex - 6, ey + 30, 12, 26);
      [-22, 22].forEach(function (o) { c.fillStyle = A('#8A8F9C', .95); c.beginPath(); c.roundRect ? c.roundRect(ex + o - 17, ey - 22, 34, 38, 7) : c.rect(ex + o - 17, ey - 22, 34, 38); c.fill();
        c.fillStyle = '#10142B'; c.beginPath(); c.arc(ex + o, ey - 3, 12, 0, TAU); c.fill(); c.fillStyle = blink ? '#10142B' : '#FFC93C'; c.beginPath(); c.ellipse(ex + o + dx / dl * k, ey - 3 + dy / dl * k, 7, blink ? 1 : 7, 0, 0, TAU); c.fill();
        c.fillStyle = A('#FFC93C', .95); c.fillRect(ex + o - 17, ey - 28, 34, 6); });
    };
  };

  SC.freedom = function (E) {
    var cl = [], i, fe = [], birds = []; for (i = 0; i < 10; i++) cl.push({ x: rr(0, E.w), y: rr(E.h * .35, E.h * 1.0), s: rr(120, 260), v: rr(6, 20), z: rr(.3, 1) });
    for (i = 0; i < 14 * E.q + 4; i++) fe.push({ x: rr(0, E.w), y: rr(0, E.h), v: rr(14, 36), p: rr(0, TAU), r: rr(.4, 1) });
    for (i = 0; i < 4; i++) birds.push({ x: rr(0, E.w), y: rr(E.h * .08, E.h * .4), v: rr(26, 60), p: rr(0, 9), s: rr(.6, 1.2) });
    return function (t, dt) {
      var c = E.c, w = E.w, h = E.h;
      var g = c.createRadialGradient(w * .5, -h * .1, 10, w * .5, -h * .1, h * 1.1); g.addColorStop(0, A('#FFFFFF', .5)); g.addColorStop(1, A('#FFFFFF', 0)); c.fillStyle = g; c.fillRect(0, 0, w, h);
      cl.forEach(function (o) { o.x += o.v * dt * o.z; if (o.x > w + o.s * 2) o.x = -o.s * 2; cloud(c, o.x - E.px * 20 * o.z, o.y - E.py * 10 * o.z, o.s, '#FFFFFF', .5 * o.z + .2); });
      c.strokeStyle = A('#0A1A33', .5); c.lineWidth = 1.8; c.lineCap = 'round';
      birds.forEach(function (b) { b.x += b.v * dt; if (b.x > w + 30) { b.x = -30; b.y = rr(h * .08, h * .4); } var f = M.sin(t * 7 + b.p) * 5 * b.s; c.beginPath(); c.moveTo(b.x - 11 * b.s, b.y - f); c.quadraticCurveTo(b.x - 4 * b.s, b.y - 3 * b.s, b.x, b.y); c.quadraticCurveTo(b.x + 4 * b.s, b.y - 3 * b.s, b.x + 11 * b.s, b.y - f); c.stroke(); }); c.lineCap = 'butt';
      fe.forEach(function (f) { f.y -= f.v * dt; f.x += M.sin(t + f.p) * 16 * dt; if (f.y < -20) { f.y = h + 20; f.x = rr(0, w); } c.save(); c.translate(f.x, f.y); c.rotate(M.sin(t * .8 + f.p) * .8); c.fillStyle = A('#FFFFFF', .85); c.beginPath(); c.ellipse(0, 0, 9 * f.r, 2.6 * f.r, 0, 0, TAU); c.fill(); c.restore(); });
    };
  };

  SC.dinomoon = function (E) {
    var st = stars(E, 80 * E.q | 0, '#D6E4FF'), rideT = -4;
    function trex(c, s, ph) {                      /* black T-rex on a bike, pedalling */
      c.fillStyle = '#000'; c.strokeStyle = '#000'; c.lineWidth = 2.6 * s;
      c.beginPath(); c.arc(-34 * s, 24 * s, 17 * s, 0, TAU); c.stroke(); c.beginPath(); c.arc(34 * s, 24 * s, 17 * s, 0, TAU); c.stroke();
      for (var k = 0; k < 6; k++) { var a = ph + k * TAU / 6; c.lineWidth = 1 * s; [-34, 34].forEach(function (x) { c.beginPath(); c.moveTo(x * s, 24 * s); c.lineTo(x * s + M.cos(a) * 16 * s, 24 * s + M.sin(a) * 16 * s); c.stroke(); }); }
      c.lineWidth = 2.6 * s; c.beginPath(); c.moveTo(-34 * s, 24 * s); c.lineTo(-4 * s, 4 * s); c.lineTo(34 * s, 24 * s); c.moveTo(-4 * s, 4 * s); c.lineTo(26 * s, 0); c.stroke();
      c.beginPath(); c.moveTo(-30 * s, -10 * s); c.quadraticCurveTo(-52 * s, -2 * s, -62 * s, 8 * s); c.quadraticCurveTo(-40 * s, -6 * s, -18 * s, -16 * s);           /* tail */
      c.quadraticCurveTo(0, -34 * s, 12 * s, -30 * s); c.lineTo(20 * s, -44 * s); c.quadraticCurveTo(30 * s, -52 * s, 40 * s, -48 * s); c.lineTo(44 * s, -40 * s); c.lineTo(34 * s, -34 * s); c.lineTo(24 * s, -26 * s);
      c.quadraticCurveTo(18 * s, -6 * s, 4 * s, 2 * s); c.lineTo(-20 * s, 2 * s); c.closePath(); c.fill();
      c.lineWidth = 2.2 * s; c.beginPath(); c.moveTo(-6 * s, 2 * s); c.lineTo(M.cos(ph) * 9 * s - 4 * s, 12 * s + M.sin(ph) * 9 * s); c.stroke();
      c.beginPath(); c.moveTo(18 * s, -24 * s); c.lineTo(26 * s, -12 * s); c.lineTo(24 * s, -2 * s); c.stroke();
    }
    return function (t, dt) {
      var c = E.c, w = E.w, h = E.h, mr = M.min(w * .34, h * .26), mx = w * (w < 700 ? .5 : .66) - E.px * 6, my = h * .64 - E.py * 4;
      st(c, t, 8); glow(c, mx, my, mr * 2.2, '#D6E4FF', .12 + .02 * M.sin(t));
      c.fillStyle = A('#F6F8FF', .6); c.beginPath(); c.arc(mx, my, mr, 0, TAU); c.fill();
      c.fillStyle = A('#B9C4E6', .28); [[.3, -.2, .17], [-.35, .1, .1], [.1, .35, .13], [-.1, -.45, .08]].forEach(function (k) { c.beginPath(); c.arc(mx + k[0] * mr, my + k[1] * mr, k[2] * mr, 0, TAU); c.fill(); });
      c.fillStyle = '#000'; for (var i = 0; i < 14; i++) { var tx = i / 13 * w, th = (h * .1 + ((i * 37) % 7) * 9) * (i % 3 ? .8 : 1.2); if (i < 4 || i > 9) { c.beginPath(); c.moveTo(tx - th * .22, h); c.lineTo(tx, h - th * 1.6); c.lineTo(tx + th * .22, h); c.fill(); } }
      c.fillRect(0, h - 6, w, 6);
      rideT += dt; var cyc = 16, u = (rideT % cyc) / 7; if (rideT > 0 && u < 1) { var x = -90 + u * (w + 180), yy = my - mr * .15 - M.sin(u * M.PI) * mr * .75; c.save(); c.translate(x, yy); c.rotate(-.12 + u * .24); trex(c, M.max(.7, M.min(1.5, mr / 120)), t * 7); c.restore(); }
    };
  };

  SC.hogwarts = function (E) {
    var can = [], i, sn = { x: E.w * .3, y: E.h * .3, tx: E.w * .6, ty: E.h * .2, tr: [] }, sm = [];
    for (i = 0; i < 9 * E.q + 3; i++) can.push({ x: rr(.04, .96), y: rr(.08, .6), p: rr(0, TAU), s: rr(.7, 1.2) });
    var d = dust(E, 30 * E.q | 0, '#E8C676', { a: .35, vy: -5, r0: .5, r1: 1.4 });
    return function (t, dt) {
      var c = E.c, w = E.w, h = E.h; d(c, t, dt);
      can.forEach(function (o) {
        var x = o.x * w - E.px * 6 * o.s, y = o.y * h + M.sin(t * .7 + o.p) * 10, fl = 1 + .1 * M.sin(t * 9 + o.p * 3) + .06 * M.sin(t * 17 + o.p);
        glow(c, x, y - 18 * o.s, 70 * o.s * fl, '#FFD27A', .2); c.fillStyle = A('#EFEBDD', .9); c.fillRect(x - 4 * o.s, y - 4, 8 * o.s, 26 * o.s);
        c.fillStyle = A('#FFB347', .95); c.beginPath(); c.ellipse(x, y - 10 * o.s, 3.2 * o.s * fl, 7.5 * o.s * fl, 0, 0, TAU); c.fill(); c.fillStyle = A('#FFFFFF', .9); c.beginPath(); c.ellipse(x, y - 8 * o.s, 1.3 * o.s, 3.5 * o.s, 0, 0, TAU); c.fill();
      });
      var dx = sn.tx - sn.x, dy = sn.ty - sn.y, dl = M.hypot(dx, dy); if (dl < 24) { sn.tx = rr(w * .1, w * .9); sn.ty = rr(h * .1, h * .6); }
      var sp = 110 + 60 * M.sin(t * 2); sn.x += dx / dl * sp * dt; sn.y += dy / dl * sp * dt + M.sin(t * 14) * .8; sn.tr.push({ x: sn.x, y: sn.y, l: 1 }); if (sn.tr.length > 40) sn.tr.shift();
      sn.tr.forEach(function (p) { p.l -= dt * 1.4; if (p.l > 0) { c.fillStyle = A('#E8C676', p.l * .6); c.fillRect(p.x + rr(-2, 2), p.y + rr(-2, 2), 2, 2); } });
      var f = M.sin(t * 40) * .6; c.fillStyle = A('#FFFFFF', .8); c.beginPath(); c.ellipse(sn.x - 9, sn.y - 3, 10, 3 + f * 2, -.5 + f * .3, 0, TAU); c.ellipse(sn.x + 9, sn.y - 3, 10, 3 + f * 2, .5 - f * .3, 0, TAU); c.fill();
      glow(c, sn.x, sn.y, 24, '#E8C676', .5); c.fillStyle = '#E8C676'; c.beginPath(); c.arc(sn.x, sn.y, 4.5, 0, TAU); c.fill();
      if (R() < dt * 3) sm.push({ x: rr(0, w * .25), y: h + 10, r: rr(18, 40), l: 1 });                       /* steam from the Express */
      for (i = sm.length - 1; i >= 0; i--) { var s = sm[i]; s.y -= 40 * dt; s.x += 22 * dt; s.r += 8 * dt; s.l -= dt * .25; if (s.l <= 0) { sm.splice(i, 1); continue; } cloud(c, s.x, s.y, s.r, '#EFEBDD', .1 * s.l); }
    };
  };

  SC.interstellar = function (E) {
    var st = stars(E, 150 * E.q | 0, '#E9EEF3'), d = dust(E, 30 * E.q | 0, '#FFB347', { a: .3, vy: -3, vx0: -3, vx1: 3, r0: .4, r1: 1.2 });
    return function (t, dt) {
      var c = E.c, w = E.w, h = E.h, cx = w * (w < 700 ? .7 : .8) - E.px * 14, cy = h * (w < 700 ? .2 : .32) - E.py * 8, r = M.min(w, h) * .09;
      st(c, t, 14); d(c, t, dt);
      glow(c, cx, cy, r * 5, '#FFB347', .1);
      c.save(); c.translate(cx, cy); c.rotate(-.18);
      for (var k = 0; k < 14; k++) { c.strokeStyle = A(k % 3 ? '#FFB347' : '#FFE2A8', .5 - k * .03); c.lineWidth = 3.4 - k * .2; c.beginPath(); c.ellipse(0, 0, r * (1.6 + k * .1), r * (.28 + k * .02), 0, 0, TAU); c.stroke(); }
      var sa = t * 1.2; c.fillStyle = A('#FFFFFF', .9); c.beginPath(); c.arc(M.cos(sa) * r * 1.9, M.sin(sa) * r * .38, 3, 0, TAU); c.fill();
      c.restore();
      c.strokeStyle = A('#FFE2A8', .55); c.lineWidth = 3; c.beginPath(); c.arc(cx, cy, r * 1.05, M.PI * 1.1, M.PI * 1.9); c.stroke(); c.beginPath(); c.arc(cx, cy, r * 1.05, M.PI * .1, M.PI * .9); c.stroke();     /* lensed halo */
      c.fillStyle = '#000'; c.beginPath(); c.arc(cx, cy, r, 0, TAU); c.fill();
      var ex = w * .1, ey = h * .88, ra = t * .5;                                                                /* the Endurance ring */
      c.strokeStyle = A('#A9B4BF', .25); c.lineWidth = 2; c.beginPath(); c.ellipse(ex, ey, 30, 9, -.3, 0, TAU); c.stroke(); for (var j = 0; j < 12; j++) { var a = ra + j * TAU / 12; c.fillStyle = A('#A9B4BF', .3); c.fillRect(ex + M.cos(a) * 30 * M.cos(-.3) - M.sin(a) * 9 * M.sin(-.3) - 1.5, ey + M.cos(a) * 30 * M.sin(-.3) + M.sin(a) * 9 * M.cos(-.3) - 1.5, 3, 3); }
    };
  };

  SC.matrix = function (E) {
    var sz = E.w < 700 ? 14 : 18, cols = M.ceil(E.w / sz), dr = [], ch = 'ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜﾝ0123456789ABCDEF', i;
    for (i = 0; i < cols; i++) dr.push({ y: rr(-E.h / sz, 0), v: rr(5, 16), t: rr(10, 24) | 0, s: [] });
    return function (t, dt) {
      var c = E.c, w = E.w, h = E.h; c.globalAlpha = .55; c.font = '700 ' + sz + 'px ui-monospace,Menlo,monospace'; c.textAlign = 'center';
      for (i = 0; i < cols; i++) {
        if (E.q < 1 && i % 2) continue; var d = dr[i]; d.y += d.v * dt; var hy = d.y | 0;
        while (d.s.length < hy - (-10)) d.s.push(ch[(R() * ch.length) | 0]);
        for (var k = 0; k < d.t; k++) { var yy = hy - k; if (yy < 0 || yy * sz > h + sz) continue; if (k > 2 && R() < .02) { d.s[yy + 10] = ch[(R() * ch.length) | 0]; }
          c.fillStyle = k === 0 ? A('#E8FFEE', .95) : A('#19F26B', M.max(0, .7 - k / d.t * .7)); c.fillText(d.s[yy + 10] || '0', i * sz + sz / 2, yy * sz); }
        if ((hy - d.t) * sz > h) { d.y = rr(-12, 0); d.v = rr(5, 16); d.t = rr(10, 24) | 0; d.s = []; }
      }
      c.textAlign = 'start'; c.globalAlpha = 1;
    };
  };

  SC.strangerthings = function (E) {
    var sp = dust(E, 60 * E.q | 0, '#FF6F85', { a: .55, vy: -10, r0: .8, r1: 2.6, vx0: -4, vx1: 4 }), cols = ['#FF2D4D', '#3AA0FF', '#FFC83D', '#38D16E', '#FF2D4D', '#B46BFF'], fl = 0, bulbs = [], n = M.max(10, M.ceil(E.w / 54)), i;
    for (i = 0; i < n; i++) bulbs.push({ c: cols[i % cols.length], p: rr(0, TAU), off: 0 });
    return function (t, dt) {
      var c = E.c, w = E.w, h = E.h, v = c.createRadialGradient(w / 2, h / 2, h * .2, w / 2, h / 2, h * .9); v.addColorStop(0, A('#FF2D4D', 0)); v.addColorStop(1, A('#FF2D4D', .12 + .05 * M.sin(t * 1.3))); c.fillStyle = v; c.fillRect(0, 0, w, h);
      sp(c, t, dt);
      c.strokeStyle = A('#1a1a1a', .9); c.lineWidth = 2; c.beginPath(); for (i = 0; i <= n; i++) { var x = i / n * w, y = 14 + M.sin(i / n * M.PI * 5) * 10 + 14; i ? c.lineTo(x, y) : c.moveTo(x, y); } c.stroke();
      bulbs.forEach(function (b, k) { var x = (k + .5) / n * w, y = 14 + M.sin((k + .5) / n * M.PI * 5) * 10 + 14, on = M.sin(t * 3 + b.p * 3) + M.sin(t * 7.3 + b.p) > -.6 ? 1 : .15; if (R() < dt * .8) b.off = .15; b.off = M.max(0, b.off - dt); if (b.off > 0) on = .1;
        glow(c, x, y + 8, 38, b.c, .55 * on); c.fillStyle = A(b.c, .4 + .6 * on); c.beginPath(); c.ellipse(x, y + 9, 4, 7, 0, 0, TAU); c.fill(); });
      fl -= dt; if (fl <= 0 && R() < dt * .12) fl = .35; if (fl > 0) { c.fillStyle = A('#FF2D4D', .08 * (R() < .5 ? 1 : .3) * fl / .35); c.fillRect(0, 0, w, h); }
    };
  };

  SC.dune = function (E) {
    var wind = [], i; for (i = 0; i < 70 * E.q; i++) wind.push({ x: rr(0, E.w), y: rr(0, E.h), l: rr(20, 120), v: rr(120, 420), a: rr(.06, .25) });
    return function (t, dt) {
      var c = E.c, w = E.w, h = E.h, sx = w * (w < 700 ? .75 : .8) - E.px * 8, sy = h * .22;
      glow(c, sx, sy, M.min(w, h) * .5, '#FFF1C8', .6); c.fillStyle = A('#FFF8E4', .95); c.beginPath(); c.arc(sx, sy, M.min(w, h) * .07, 0, TAU); c.fill();
      wind.forEach(function (o) { o.x += o.v * dt; if (o.x - o.l > w) { o.x = -20; o.y = rr(0, h); } c.strokeStyle = A('#A9440F', o.a * .6); c.lineWidth = 1; c.beginPath(); c.moveTo(o.x - o.l, o.y); c.lineTo(o.x, o.y + M.sin(o.x * .01 + t) * 2); c.stroke(); });
      [[.78, '#C9863A', .35, .3, .0045], [.86, '#A9440F', .28, .45, .006], [.94, '#6E2E0A', .22, .7, .0075]].forEach(function (L, k) {
        c.fillStyle = A(L[1], L[2]); c.beginPath(); c.moveTo(0, h); for (var x = 0; x <= w; x += 20) c.lineTo(x, h * L[0] + M.sin(x * L[4] + t * .12 * (k + 1) + k * 2) * 26 + M.sin(x * L[4] * 2.3 - t * .2) * 8 - E.px * 5 * (k + 1)); c.lineTo(w, h); c.fill();
      });
    };
  };


  /* ================= v3 scenes: the ten new looks =================
     Motion rules used everywhere below: every movement is driven by time (never by frame count), springs and exponential damping
     replace linear chasing, loops use organic noise instead of a single sine, and spawns / deaths fade with smoothstep so nothing pops. */
  function starPath(c, x, y, r, n, inner) { for (var i = 0; i < n * 2; i++) { var a = i * M.PI / n - M.PI / 2, rad = i % 2 ? r * inner : r; c.lineTo(x + M.cos(a) * rad, y + M.sin(a) * rad); } c.closePath(); }
  function puffy(c, x, y, s, col, a) {              /* a soft cumulus made of five overlapping glows */
    var B = [[-.9, .15, .7], [-.35, -.15, .95], [.25, -.25, 1], [.8, .05, .8], [.1, .2, .9]];
    for (var i = 0; i < 5; i++) glow(c, x + B[i][0] * s * 1.2, y + B[i][1] * s * .6, B[i][2] * s * .9, col, a);
  }
  function jag(c, x0, y0, x1, y1, off, amp) {       /* lightning between two moving points; off[] holds fixed random offsets */
    var dx = x1 - x0, dy = y1 - y0, len = M.hypot(dx, dy) || 1, nx = -dy / len, ny = dx / len, n = off.length - 1, k;
    c.beginPath(); c.moveTo(x0, y0);
    for (k = 1; k < n; k++) { var u = k / n, o = off[k] * amp * M.sin(u * M.PI); c.lineTo(x0 + dx * u + nx * o, y0 + dy * u + ny * o); }
    c.lineTo(x1, y1); c.stroke();
  }
  function offs(n) { var o = [0]; for (var i = 1; i < n; i++) o.push(rr(-1, 1)); o.push(0); return o; }

  /* ---------- Dodge Hellcat: speed lanes, a rev needle on a spring, tyre smoke drifting on the wind ---------- */
  SC.dodge = function (E) {
    var puffs = [], lines = [], i, rev = .16, rv = 0, target = .16, hold = 0, nxt = 2.2, lastTap = 0, acc = 0;
    for (i = 0; i < ((9 * E.q) | 0) + 3; i++) lines.push({ y: rr(.06, .94), l: rr(.1, .38), v: rr(.04, .2), w: rr(1, 3.4), x: rr(0, 1.3), a: rr(.05, .13), red: R() < .55 });
    function puff(x, y, big) { puffs.push({ x: x, y: y, r: rr(12, 22) * (big ? 1.5 : 1), g: rr(38, 64) * (big ? 1.4 : 1), vx: rr(18, 52), vy: rr(-34, -10), age: 0, life: rr(3.2, 5.2) }); }
    return function (t, dt) {
      var c = E.c, w = E.w, h = E.h, k, o, p, R0 = M.max(64, M.min(120, M.min(w, h) * .17)), cx = w - R0 - 26, cy = h - R0 * .7 - 20;
      c.lineCap = 'round';
      for (k = 0; k < lines.length; k++) {
        o = lines[k]; o.x += o.v * dt * (1 + rv * .9);
        if (o.x - o.l > 1) { o.x = -.1; o.y = rr(.06, .94); o.l = rr(.1, .38); o.v = rr(.04, .2); }
        var sh = E.px * 140 * o.v, x0 = (o.x - o.l) * w + sh, x1 = o.x * w + sh, y = o.y * h + E.py * 6, g = c.createLinearGradient(x0, 0, x1, 0), col = o.red ? '#D9141E' : '#1A1210';
        g.addColorStop(0, A(col, 0)); g.addColorStop(.7, A(col, o.a * (.75 + rv * .5))); g.addColorStop(1, A(col, 0));
        c.strokeStyle = g; c.lineWidth = o.w; c.beginPath(); c.moveTo(x0, y); c.lineTo(x1, y); c.stroke();
      }
      /* the needle is a damped spring: it overshoots a little, then settles, like a real gauge */
      if (E.tapT > lastTap) { lastTap = E.tapT; target = .96; hold = .9; for (k = 0; k < 6; k++) puff(rr(w * .02, w * .16), h - 12, true); }
      hold -= dt; nxt -= dt;
      if (nxt <= 0) { if (hold <= 0 && R() < .65) { target = rr(.5, .88); hold = rr(.8, 1.4); nxt = rr(3.5, 7); } else nxt = rr(2, 4); }
      if (hold <= 0) target = .16 + .014 * nz(t * 2.2, 3);
      rv += ((target - rev) * 62 - rv * 9.4) * dt; rev = M.max(0, M.min(1.02, rev + rv * dt));
      var hot = M.max(0, (rev - .7) / .3), a0 = M.PI * .75, sw = M.PI * 1.5, an;
      c.save(); c.translate(cx - E.px * 6, cy - E.py * 4);
      glow(c, 0, 0, R0 * 1.5, '#D9141E', .06 + .1 * hot);
      c.lineCap = 'butt'; c.lineWidth = 3; c.strokeStyle = A('#1A1210', .22); c.beginPath(); c.arc(0, 0, R0, a0, a0 + sw); c.stroke();
      c.strokeStyle = A('#D9141E', .7); c.lineWidth = 5; c.beginPath(); c.arc(0, 0, R0 - 1, a0 + sw * .78, a0 + sw); c.stroke();
      for (k = 0; k <= 40; k++) { an = a0 + sw * k / 40; var mj = k % 5 === 0, ri = R0 - (mj ? 14 : 7); c.strokeStyle = A(k >= 31 ? '#D9141E' : '#1A1210', mj ? .55 : .28); c.lineWidth = mj ? 2 : 1; c.beginPath(); c.moveTo(M.cos(an) * ri, M.sin(an) * ri); c.lineTo(M.cos(an) * (R0 - 3), M.sin(an) * (R0 - 3)); c.stroke(); }
      an = a0 + sw * rev; c.lineCap = 'round'; c.strokeStyle = A('#D9141E', .95); c.lineWidth = 2.6; c.beginPath(); c.moveTo(-M.cos(an) * 12, -M.sin(an) * 12); c.lineTo(M.cos(an) * (R0 - 10), M.sin(an) * (R0 - 10)); c.stroke();
      c.fillStyle = A('#1A1210', .85); c.beginPath(); c.arc(0, 0, 6, 0, TAU); c.fill(); c.restore();
      /* tyre smoke: the idle puffs thicken as the revs climb; each puff swells, slows, and fades in and out smoothly */
      acc += (2 + rev * 14) * dt; while (acc >= 1) { acc -= 1; puff(rr(w * .02, w * .14), h - rr(6, 24), false); }
      for (k = puffs.length - 1; k >= 0; k--) {
        p = puffs[k]; p.age += dt / p.life; if (p.age >= 1) { puffs.splice(k, 1); continue; }
        p.x += (p.vx + wnd(t) * 24) * dt; p.y += p.vy * dt; p.vy *= M.exp(-.35 * dt); p.vx *= M.exp(-.2 * dt);
        glow(c, p.x - E.px * 10, p.y, p.r + p.g * ease.oc(p.age), '#5A4F48', ease.ss(p.age / .12) * M.pow(1 - p.age, 1.7) * .2);
      }
      if (puffs.length > 70) puffs.splice(0, puffs.length - 70);
    };
  };

  /* ---------- Dragon Rider: an ink dragon glides a slow lissajous, the rider trails on a ribbon of air ---------- */
  SC.dragonrider = function (E) {
    var T0 = rr(0, 40), N = 70, em = dust(E, (14 * E.q) | 0, '#000000', { a: .13, vy: -4, r0: .6, r1: 1.5 });
    function path(t) { return { x: E.w * (.5 + .34 * M.sin(t * .105 + 1) + .06 * M.sin(t * .31)), y: E.h * (.46 + .2 * M.sin(t * .077 + .5) + .04 * M.sin(t * .23 + 2)) }; }
    function dragon(c, fl) {                         /* top-down silhouette, head up; fl = wing beat -1..1 */
      var sx = .82 + .18 * fl, up = fl * 15, sd;
      c.beginPath();
      for (sd = -1; sd <= 1; sd += 2) {
        c.moveTo(sd * 5, -10); c.quadraticCurveTo(sd * 40 * sx, -30 - up * .8, sd * 94 * sx, -22 - up * 1.6);
        c.quadraticCurveTo(sd * 82 * sx, -4 - up * .5, sd * 76 * sx, 8 - up * .2); c.quadraticCurveTo(sd * 64 * sx, 2, sd * 58 * sx, 16);
        c.quadraticCurveTo(sd * 46 * sx, 8, sd * 38 * sx, 22); c.quadraticCurveTo(sd * 26 * sx, 14, sd * 7, 26); c.closePath();
      }
      c.fill();
      c.beginPath(); c.ellipse(0, 4, 8, 22, 0, 0, TAU); c.ellipse(0, -26, 5.4, 7.6, 0, 0, TAU); c.fill();
      c.beginPath(); c.moveTo(-3.2, -31); c.lineTo(-7, -41); c.lineTo(-1, -33); c.moveTo(3.2, -31); c.lineTo(7, -41); c.lineTo(1, -33); c.fill();
      c.beginPath(); c.moveTo(-5, 22); c.quadraticCurveTo(-3, 50, 0, 68); c.quadraticCurveTo(3, 50, 5, 22); c.fill();
      c.beginPath(); c.moveTo(0, 60); c.lineTo(-13, 74); c.lineTo(0, 92); c.lineTo(13, 74); c.closePath(); c.fill();
    }
    return function (t, dt) {
      var c = E.c, s = M.max(.55, M.min(1.1, M.min(E.w, E.h) / 700)), tt = t + T0, k, p, q, p0 = path(tt), p1 = path(tt + .05), rot = M.atan2(p1.y - p0.y, p1.x - p0.x) + M.PI / 2, pts = [];
      em(c, t, dt);
      for (k = 0; k < N; k++) pts.push(path(tt - k * .05));
      /* the ribbon: a long thin line that waves along the flight path and thins to nothing */
      c.lineCap = 'round'; c.lineJoin = 'round';
      for (k = 3; k < N - 1; k++) {
        p = pts[k]; q = pts[k + 1]; var u = k / N, dx = q.x - p.x, dy = q.y - p.y, ln = M.hypot(dx, dy) || 1, wv = M.sin(k * .38 - t * 2.6) * 11 * M.sin(u * M.PI) * s;
        c.strokeStyle = A('#111111', .5 * M.pow(1 - u, 1.2)); c.lineWidth = M.max(.5, 2.6 * (1 - u) * s);
        c.beginPath(); c.moveTo(p.x - dy / ln * wv, p.y + dx / ln * wv); c.lineTo(q.x - dy / ln * (M.sin((k + 1) * .38 - t * 2.6) * 11 * M.sin((k + 1) / N * M.PI) * s), q.y + dx / ln * (M.sin((k + 1) * .38 - t * 2.6) * 11 * M.sin((k + 1) / N * M.PI) * s)); c.stroke();
      }
      /* dragon: wings beat in a slow, uneven rhythm with a glide between flaps */
      var beat = M.sin(t * 2.2) * (.55 + .45 * M.sin(t * .6)), glide = M.max(0, M.sin(t * .6 + 1.4));
      c.save(); c.translate(p0.x - E.px * 6, p0.y - E.py * 4); c.rotate(rot); c.scale(s, s); c.fillStyle = A('#111111', .34); dragon(c, beat * (1 - glide * .7)); c.restore();
      /* rider: a small wingsuit figure on the same ribbon, a second behind */
      var r0 = pts[26], r1 = pts[24], rr0 = M.atan2(r1.y - r0.y, r1.x - r0.x) + M.PI / 2;
      c.save(); c.translate(r0.x - E.px * 9, r0.y - E.py * 6); c.rotate(rr0); c.scale(s, s); c.fillStyle = A('#111111', .4);
      c.beginPath(); c.ellipse(0, -8, 3.2, 3.4, 0, 0, TAU); c.fill();
      c.beginPath(); c.moveTo(-2.4, -4); c.lineTo(-17, 5 + M.sin(t * 3) * 1.5); c.lineTo(-6, 17); c.lineTo(0, 22); c.lineTo(6, 17); c.lineTo(17, 5 + M.sin(t * 3 + 1) * 1.5); c.lineTo(2.4, -4); c.closePath(); c.fill(); c.restore();
    };
  };

  /* ---------- Baymax: soft clouds, soap bubbles, a slow health scan and a calm heartbeat ---------- */
  SC.baymax = function (E) {
    var cl = [], bub = [], i, em = dust(E, (10 * E.q) | 0, '#FFFFFF', { a: .5, vy: -5, r0: .8, r1: 2.2 });
    for (i = 0; i < 7; i++) cl.push({ x: rr(0, 1), y: rr(.08, .86), s: rr(70, 170), d: rr(.3, 1), a: rr(.28, .5) });
    function mkB(first) { return { x: rr(0, E.w), y: first ? rr(E.h * .2, E.h) : E.h + 20, r: rr(4, 17), vy: rr(14, 30), ph: rr(0, TAU), pop: -1, top: rr(E.h * .08, E.h * .5) }; }
    for (i = 0; i < ((13 * E.q) | 0) + 3; i++) bub.push(mkB(1));
    function g(x, m, s) { var z = (x - m) / s; return M.exp(-z * z / 2); }
    function ecg(ph) { return .12 * g(ph, .15, .03) - .15 * g(ph, .29, .008) + g(ph, .32, .01) - .25 * g(ph, .35, .011) + .22 * g(ph, .55, .04); }
    return function (t, dt) {
      var c = E.c, w = E.w, h = E.h, k, o, p;
      glow(c, w * .18 + E.px * -14, h * .8, 190 + 16 * M.sin(t * 1.5), '#FFFFFF', .34);
      for (k = 0; k < cl.length; k++) {
        o = cl[k]; o.x += (7 + o.d * 14 + wnd(t) * 5) * dt / w; if (o.x * w - o.s * 2.4 > w) { o.x = -o.s * 2.4 / w; o.y = rr(.08, .86); }
        puffy(c, o.x * w - E.px * o.d * 26, o.y * h - E.py * o.d * 10, o.s, '#FFFFFF', o.a * (.7 + .3 * o.d));
      }
      em(c, t, dt);
      for (k = 0; k < bub.length; k++) {
        o = bub[k];
        if (o.pop >= 0) { o.pop += dt / .28; var pa = 1 - o.pop; if (o.pop >= 1) { bub[k] = mkB(0); continue; } c.strokeStyle = A('#FFFFFF', .7 * pa * pa); c.lineWidth = 1.2; c.beginPath(); c.arc(o.x, o.y, o.r * (1 + .7 * ease.oc(o.pop)), 0, TAU); c.stroke(); continue; }
        o.y -= o.vy * dt * (.8 + o.r / 30); o.x += (nz(t * .9, o.ph) * 14 + wnd(t) * 6) * dt; if (o.y < o.top) { o.pop = 0; continue; }
        var px = o.x - E.px * o.r * .8, fa = ease.ss((E.h - o.y) / 60), gr = c.createRadialGradient(px - o.r * .3, o.y - o.r * .3, o.r * .1, px, o.y, o.r);
        gr.addColorStop(0, A('#FFFFFF', .03 * fa)); gr.addColorStop(1, A('#FFFFFF', .26 * fa));
        c.fillStyle = gr; c.beginPath(); c.arc(px, o.y, o.r, 0, TAU); c.fill(); c.strokeStyle = A('#FFFFFF', .62 * fa); c.lineWidth = 1.1; c.stroke();
        c.strokeStyle = A('#FFFFFF', .9 * fa); c.lineWidth = 1.4; c.beginPath(); c.arc(px, o.y, o.r * .66, M.PI * 1.1, M.PI * 1.45); c.stroke();
      }
      /* scan: a pale band eases down the screen every eleven seconds, "+" marks light up as it passes */
      var q = ((t % 11) - 1) / 2.8;
      if (q >= 0 && q <= 1) {
        var y = ease.io(q) * (h + 160) - 80, bg = c.createLinearGradient(0, y - 80, 0, y + 80), fa2 = M.sin(q * M.PI);
        bg.addColorStop(0, A('#FFFFFF', 0)); bg.addColorStop(.5, A('#FFFFFF', .26 * fa2)); bg.addColorStop(1, A('#FFFFFF', 0)); c.fillStyle = bg; c.fillRect(0, y - 80, w, 160);
        c.strokeStyle = A('#FFFFFF', .7 * fa2); c.lineWidth = 1; c.beginPath(); c.moveTo(0, y); c.lineTo(w, y); c.stroke();
        for (k = 0; k < w / 150 + 1; k++) { var mx = k * 150 + 60 + (k % 2) * 40, ds = M.abs(mx * 0 + y - (y + (k % 3 - 1) * 26)), pa2 = M.max(0, 1 - ds / 60) * fa2; c.strokeStyle = A('#0B6FCB', .5 * pa2); c.lineWidth = 1.4; c.beginPath(); c.moveTo(mx - 5, y + (k % 3 - 1) * 26); c.lineTo(mx + 5, y + (k % 3 - 1) * 26); c.moveTo(mx, y + (k % 3 - 1) * 26 - 5); c.lineTo(mx, y + (k % 3 - 1) * 26 + 5); c.stroke(); }
      }
      /* heartbeat trace along the bottom, scrolling left at a steady 58 px/s */
      var by = h - 34, step = 3, x0 = -((t * 58) % 220), amp = 24, last = null; c.lineWidth = 1.5; c.lineJoin = 'round';
      for (var x = x0; x < w + 220; x += step) {
        var ph = (((x - x0) / 220) % 1), yy = by - ecg(ph) * amp, fx = ease.ss(x / (w * .25)) * (1 - ease.ss((x - w * .8) / (w * .2)));
        if (last) { c.strokeStyle = A('#0B6FCB', .34 * fx); c.beginPath(); c.moveTo(last[0], last[1]); c.lineTo(x, yy); c.stroke(); } last = [x, yy];
      }
    };
  };

  /* ---------- Doraemon: big sky, a bamboo-copter, falling leaves and grass moving on the wind ---------- */
  SC.doraemon = function (E) {
    var cl = [], lv = [], gr = [[], [], []], i, j, fly = { on: false, u: 0, next: 4 }, em = dust(E, (12 * E.q) | 0, '#FFFFFF', { a: .6, vy: -6, r0: .7, r1: 2 });
    for (i = 0; i < 6; i++) cl.push({ x: rr(0, 1), y: rr(.06, .6), s: rr(80, 190), d: rr(.3, 1) });
    function mkL(first) { return { x: rr(E.w * .3, E.w * 1.05), y: first ? rr(0, E.h) : -16, s: rr(5, 9), vy: rr(20, 40), ph: rr(0, TAU), c: pick(['#58B947', '#3E9B3A', '#7CCB4F', '#2F8A3A']), sp: rr(.8, 1.6) }; }
    for (i = 0; i < ((13 * E.q) | 0) + 4; i++) lv.push(mkL(1));
    var SP = [10, 13, 17], HT = [36, 27, 19];
    for (j = 0; j < 3; j++) for (i = 0; i < E.w / SP[j] + 2; i++) gr[j].push({ x: i * SP[j] + rr(-3, 3), h: HT[j] * rr(.7, 1.2) });
    return function (t, dt) {
      var c = E.c, w = E.w, h = E.h, k, o, wd = wnd(t);
      for (k = 0; k < cl.length; k++) { o = cl[k]; o.x += (5 + o.d * 12 + wd * 4) * dt / w; if (o.x * w - o.s * 2.4 > w) { o.x = -o.s * 2.4 / w; o.y = rr(.06, .6); } puffy(c, o.x * w - E.px * o.d * 28, o.y * h - E.py * o.d * 12, o.s, '#FFFFFF', .3 + .28 * o.d); }
      em(c, t, dt);
      /* the take-copter crosses the sky every so often, rotor spinning, bobbing on a gentle S-curve */
      fly.next -= dt;
      if (!fly.on && fly.next <= 0) { fly.on = true; fly.u = 0; fly.y = rr(.14, .34); }
      if (fly.on) {
        fly.u += dt / 12; if (fly.u >= 1) { fly.on = false; fly.next = rr(14, 26); }
        else {
          var u = fly.u, fx = -50 + (w + 100) * u, fy = h * fly.y + M.sin(u * TAU * 1.5) * h * .06, tl = M.cos(u * TAU * 1.5) * .12, fa = ease.ss(u / .06) * (1 - ease.ss((u - .94) / .06));
          c.save(); c.translate(fx, fy); c.rotate(tl); c.globalAlpha = fa;
          c.fillStyle = '#2F76C9'; c.fillRect(-1.6, -2, 3.2, 17); c.fillStyle = '#E0312F'; c.beginPath(); c.arc(0, 18, 4.6, 0, TAU); c.fill();
          var rw = 5 + M.abs(M.cos(t * 36)) * 26; c.fillStyle = A('#F5C518', .22); c.beginPath(); c.ellipse(0, -3, 30, 3.6, 0, 0, TAU); c.fill();
          c.fillStyle = '#F5C518'; c.beginPath(); c.ellipse(0, -3, rw, 2.4, 0, 0, TAU); c.fill(); c.restore();
        }
      }
      for (k = 0; k < lv.length; k++) {
        o = lv[k]; o.y += o.vy * dt; o.x += (nz(t * o.sp, o.ph) * 26 + wd * 14 - 6) * dt;
        if (o.y > h + 16) { lv[k] = mkL(0); continue; }
        c.save(); c.translate(o.x - E.px * 8, o.y); c.rotate(M.sin(t * o.sp * 1.6 + o.ph) * .9); c.scale(1, M.max(.25, M.abs(M.cos(t * o.sp * 1.1 + o.ph))));
        c.fillStyle = A(o.c, .78 * ease.ss(o.y / 40)); c.beginPath(); c.moveTo(0, -o.s); c.quadraticCurveTo(o.s * .9, -o.s * .1, 0, o.s); c.quadraticCurveTo(-o.s * .9, -o.s * .1, 0, -o.s); c.fill(); c.restore();
      }
      /* grass: three layers, each leaning with the shared wind plus its own ripple */
      var cols = ['#4FAE49', '#3E9B3A', '#2F8A3A'];
      c.lineCap = 'round';
      for (j = 0; j < 3; j++) {
        c.strokeStyle = A(cols[j], .55 + j * .1); c.lineWidth = 2.4 - j * .3; c.beginPath();
        for (i = 0; i < gr[j].length; i++) {
          var b = gr[j][i], sw = (wd * .55 + M.sin(b.x * .011 + t * 1.3 + j) * .4) * b.h * .42, px = E.mx >= 0 && h - E.my < 90 ? (b.x - E.mx) : 999, push = M.abs(px) < 70 ? (1 - M.abs(px) / 70) * M.sign(px) * b.h * .5 : 0;
          c.moveTo(b.x, h + 2); c.quadraticCurveTo(b.x + (sw + push) * .35, h - b.h * .62, b.x + sw + push, h - b.h + M.abs(sw + push) * .12);
        }
        c.stroke();
      }
    };
  };

  /* ---------- Deadpool Light: katana cuts with a real wind-up, tally marks drawn by hand, peeking eyes ---------- */
  SC.deadpool2 = function (E) {
    var sl = null, next = 2.2, caps = ['MAXIMUM EFFORT', 'CHIMICHANGAS', '*BREAKS THE 4TH WALL*', 'BANG', 'HI MOM', 'NOT A HERO'], cap = null, capT = 3, peek = 0, bl = 0, blT = 3, ex = 0, ey = 0;
    function stroke(c, x0, y0, x1, y1, seed) { c.beginPath(); for (var i = 0; i <= 6; i++) { var u = i / 6, jx = nz(seed + i * 1.9, seed) * 1.1, jy = nz(seed * 1.3 + i * 2.3, seed) * 1.1; i ? c.lineTo(x0 + (x1 - x0) * u + jx, y0 + (y1 - y0) * u + jy) : c.moveTo(x0 + jx, y0 + jy); } c.stroke(); }
    return function (t, dt) {
      var c = E.c, w = E.w, h = E.h, k, a;
      /* katana: glint (wind-up) -> cut (very fast) -> afterimage that thins and fades */
      next -= dt;
      if (!sl && next <= 0) { var ang = rr(.28, .62) * (R() < .5 ? 1 : -1), len = M.min(w, 1000) * rr(.5, .8), cx = rr(.25, .75) * w, cy = rr(.25, .7) * h; sl = { age: 0, dx: M.cos(ang), dy: M.sin(ang), len: len, sx: cx - M.cos(ang) * len / 2, sy: cy - M.sin(ang) * len / 2 }; }
      if (sl) {
        sl.age += dt; a = sl.age;
        if (a < .22) { var gl = M.sin(a / .22 * M.PI), r = 6 + 18 * gl; glow(c, sl.sx, sl.sy, 46 * gl + 6, '#C8102E', .4 * gl); c.strokeStyle = A('#FFFFFF', .9 * gl); c.lineWidth = 1.6; c.beginPath(); c.moveTo(sl.sx - r, sl.sy); c.lineTo(sl.sx + r, sl.sy); c.moveTo(sl.sx, sl.sy - r); c.lineTo(sl.sx, sl.sy + r); c.stroke(); }
        else {
          var g = ease.oe((a - .22) / .1), fa = 1 - ease.ss((a - .34) / .85), th = 1 - .75 * ease.ss((a - .34) / .85), ex2 = sl.sx + sl.dx * sl.len * g, ey2 = sl.sy + sl.dy * sl.len * g;
          c.lineCap = 'round'; c.strokeStyle = A('#C8102E', .38 * fa); c.lineWidth = 11 * th; c.beginPath(); c.moveTo(sl.sx, sl.sy); c.lineTo(ex2, ey2); c.stroke();
          c.strokeStyle = A('#FFFFFF', .95 * fa); c.lineWidth = 3.2 * th; c.beginPath(); c.moveTo(sl.sx, sl.sy); c.lineTo(ex2, ey2); c.stroke();
          c.strokeStyle = A('#14090B', .5 * fa); c.lineWidth = 1 * th; c.beginPath(); c.moveTo(sl.sx, sl.sy + 3); c.lineTo(ex2, ey2 + 3); c.stroke();
        }
        if (a > 1.25) { sl = null; next = rr(4.5, 8); }
      }
      /* tally marks: pen strokes drawn one after another, held, then wiped */
      var tp = t % 9, x0 = M.min(w * .05, 48), y0 = h * .34, fade = tp > 7 ? 1 - ease.ss((tp - 7) / 1.4) : 1;
      c.lineCap = 'round'; c.lineWidth = 3.2; c.strokeStyle = A('#C8102E', .5 * fade);
      for (k = 0; k < 5; k++) {
        var q = M.min(1, M.max(0, (tp - .5 - k * .28) / .24)); if (!q) continue; q = ease.oc(q);
        if (k < 4) stroke(c, x0 + k * 11, y0, x0 + k * 11 + 1.5, y0 + 34 * q, k + 1); else stroke(c, x0 - 6, y0 + 28, x0 - 6 + 56 * q, y0 + 28 - 22 * q, 9);
      }
      /* big outlined caption drifting upward: fades in, lingers, melts away */
      capT -= dt;
      if (!cap && capT <= 0) { cap = { s: pick(caps), x: rr(.15, .7) * w, y: rr(.4, .8) * h, r: rr(-.14, .14), age: 0 }; }
      if (cap) { cap.age += dt; cap.y -= 9 * dt; var ca = ease.ss(cap.age / .7) * (1 - ease.ss((cap.age - 3.2) / 1.3)) * .16; c.save(); c.translate(cap.x, cap.y); c.rotate(cap.r); c.font = 'italic 900 ' + M.round(M.min(60, w * .08)) + 'px Impact,"Arial Narrow Bold",system-ui,sans-serif'; c.lineWidth = 2; c.strokeStyle = A('#14090B', ca * 3); c.fillStyle = A('#C8102E', ca); c.fillText(cap.s, 0, 0); c.strokeText(cap.s, 0, 0); c.restore(); if (cap.age > 4.5) { cap = null; capT = rr(2.5, 5); } }
      /* eyes: peek up from the bottom edge, follow the pointer with eased pupils, blink now and then; duck if the pointer comes close */
      var bx = M.max(74, w * .09), near = E.mx >= 0 && M.hypot(E.mx - bx, E.my - h) < 120, want = t < 1.8 ? 0 : (near ? .3 : 1);
      peek = damp(peek, want, near ? 9 : 2.6, dt); blT -= dt; if (blT <= 0) { bl = .16; blT = rr(2.6, 6); }
      var tx = E.mx >= 0 ? E.mx : w * .6, ty = E.my >= 0 ? E.my : h * .4, ax = tx - bx, ay = ty - (h - 30), al = M.hypot(ax, ay) || 1;
      ex = damp(ex, ax / al * 5, 8, dt); ey = damp(ey, ay / al * 3.2, 8, dt);
      var by = h + 8 - peek * 50, bk = bl > 0 ? 1 - M.sin((1 - bl / .16) * M.PI) * .92 : 1; bl = M.max(-1, bl - dt);
      c.save(); c.translate(bx, by); c.fillStyle = A('#C8102E', .92); c.beginPath(); c.ellipse(0, 12, 64, 40, 0, 0, TAU); c.fill();
      for (var sd = -1; sd <= 1; sd += 2) {
        c.save(); c.translate(sd * 24, 0); c.rotate(sd * -.38); c.fillStyle = A('#111111', .96); c.beginPath(); c.ellipse(0, 0, 21, 12, 0, 0, TAU); c.fill(); c.restore();
        c.fillStyle = '#FFFFFF'; c.beginPath(); c.ellipse(sd * 24 + ex, ey, 11, 5.2 * bk, sd * -.38, 0, TAU); c.fill();
      }
      c.restore();
    };
  };

  /* ---------- Scarlet Witch: chaos magic as slow curling wisps around two floating hands ---------- */
  SC.scarletwitch = function (E) {
    var N = ((42 * E.q) | 0) + 8, ws = [], i, orbs = [{ ph: 1.2, bx: .27, x: 0, y: 0, tn: [], tt: 0 }, { ph: 4.1, bx: .73, x: 0, y: 0, tn: [], tt: 0 }], em = dust(E, (24 * E.q) | 0, E.hi, { a: .5, vy: -12, r0: .6, r1: 1.8 });
    function seed(p, first) { var o = orbs[(R() * 2) | 0], x = o.x || E.w * o.bx, y = o.y || E.h * .62, a = R() * TAU, d = first ? rr(0, 260) : rr(4, 24); p.x = x + M.cos(a) * d; p.y = y + M.sin(a) * d; p.hx = []; p.hy = []; p.lt = 0; p.age = 0; p.life = rr(2.2, 4.6); p.sp = rr(46, 96); p.o = o; }
    for (i = 0; i < N; i++) { var p0 = {}; seed(p0, 1); ws.push(p0); }
    return function (t, dt) {
      var c = E.c, w = E.w, h = E.h, k, o, p, n;
      /* the chaos sigil: slow, with a breathing glow */
      var sr = M.min(w, h) * .3, sa = .09 + .04 * M.sin(t * 1.1);
      c.save(); c.translate(w * .5 - E.px * 12, h * .38 - E.py * 8); c.rotate(t * .06); c.strokeStyle = A(E.a, sa); c.lineWidth = 1.2;
      c.beginPath(); c.arc(0, 0, sr, 0, TAU); c.moveTo(sr * .82, 0); c.arc(0, 0, sr * .82, 0, TAU); c.stroke();
      c.beginPath(); for (k = 0; k < 8; k++) { var an = k * TAU / 8, an2 = ((k + 3) % 8) * TAU / 8; c.moveTo(M.cos(an) * sr * .82, M.sin(an) * sr * .82); c.lineTo(M.cos(an2) * sr * .82, M.sin(an2) * sr * .82); c.moveTo(M.cos(an) * sr, M.sin(an) * sr); c.lineTo(M.cos(an) * sr * 1.07, M.sin(an) * sr * 1.07); } c.stroke(); c.restore();
      for (k = 0; k < 2; k++) {
        o = orbs[k]; var tx = w * o.bx + nz(t * .4, o.ph) * w * .05 + (E.mx >= 0 ? (E.mx - w * o.bx) * .06 : 0), ty = h * .62 + nz(t * .33, o.ph + 2) * h * .05 + (E.my >= 0 ? (E.my - h * .62) * .06 : 0);
        o.x = o.x ? damp(o.x, tx, 5, dt) : tx; o.y = o.y ? damp(o.y, ty, 5, dt) : ty;
      }
      c.globalCompositeOperation = 'lighter';
      for (k = 0; k < N; k++) {
        p = ws[k]; p.age += dt; o = p.o;
        if (p.age > p.life) { seed(p, 0); continue; }
        var ang = (M.sin(p.y * .0058 + t * .35) + M.cos(p.x * .0048 - t * .28) + M.sin((p.x + p.y) * .0031 + t * .2)) * 1.25, dx = o.x - p.x, dy = o.y - p.y, dl = M.hypot(dx, dy) || 1;
        p.x += (M.cos(ang) * p.sp + (-dy / dl) * 34 + dx / dl * (dl > 150 ? 22 : -6)) * dt; p.y += (M.sin(ang) * p.sp + (dx / dl) * 34 + dy / dl * (dl > 150 ? 22 : -6)) * dt;
        if (t - p.lt > .018) { p.lt = t; p.hx.push(p.x); p.hy.push(p.y); if (p.hx.length > 15) { p.hx.shift(); p.hy.shift(); } }
        var env = ease.ss(p.age / .35) * ease.ss((p.life - p.age) / .7);
        n = p.hx.length; if (n < 3) continue; c.lineCap = 'round'; c.lineWidth = 1.4;
        for (var ch = 0; ch < 3; ch++) { var i0 = M.floor(ch * (n - 1) / 3), i1 = M.floor((ch + 1) * (n - 1) / 3); c.strokeStyle = A(ch === 2 ? E.hi : E.a, env * (.14 + ch * .2)); c.beginPath(); c.moveTo(p.hx[i0], p.hy[i0]); for (var m = i0 + 1; m <= i1; m++) c.lineTo(p.hx[m], p.hy[m]); c.stroke(); }
      }
      for (k = 0; k < 2; k++) {
        o = orbs[k]; var pl = .85 + .15 * M.sin(t * 3.2 + o.ph) + .07 * nz(t * 6, o.ph);
        glow(c, o.x, o.y, 110 * pl, E.hi, .34); glow(c, o.x, o.y, 40 * pl, '#FFB0B8', .55); glow(c, o.x, o.y, 12 * pl, '#FFFFFF', .85);
        o.tt -= dt; if (o.tt <= 0) { o.tt = .07; o.tn = []; for (i = 0; i < 7; i++) o.tn.push({ a: rr(0, TAU), l: rr(26, 70), off: offs(5) }); }
        c.strokeStyle = A('#FF6B82', .4); c.lineWidth = 1.1; o.tn.forEach(function (tn) { jag(c, o.x, o.y, o.x + M.cos(tn.a) * tn.l, o.y + M.sin(tn.a) * tn.l, tn.off, 9); });
      }
      c.globalCompositeOperation = 'source-over'; em(c, t, dt);
    };
  };

  /* ---------- Shang-Chi: ten golden rings in a 3D orbit that follows your last tap, lightning between them ---------- */
  /* ---------- Agent Noir: window-blind light, laser tripwires, a slow sweep and a reticle that tracks you ---------- */
  SC.agent = function (E) {
    var motes = dust(E, (26 * E.q) | 0, '#FFFFFF', { a: .75, vy: -2, vx0: 2, vx1: 7, r0: .5, r1: 1.5 }), rx = -1, ry = -1;
    return function (t, dt) {
      var c = E.c, w = E.w, h = E.h, k, gap = M.max(120, w * .09), bw = gap * .42, slant = h * .55, bg = c.createLinearGradient(0, 0, 0, h);
      bg.addColorStop(0, A('#FFF6E0', .15)); bg.addColorStop(1, A('#FFF6E0', .02)); c.fillStyle = bg; c.globalAlpha = .8 + .2 * M.sin(t * .4);
      for (k = -5; k < w / gap + 8; k++) { var x = k * gap + ((t * 5) % gap) - E.px * 16 - slant * .5; c.beginPath(); c.moveTo(x, 0); c.lineTo(x + bw, 0); c.lineTo(x + bw + slant, h); c.lineTo(x + slant, h); c.closePath(); c.fill(); }
      c.globalAlpha = 1; motes(c, t, dt);
      var ys = [.27, .52, .77];
      for (k = 0; k < 3; k++) {
        var y = ys[k] * h + M.sin(t * .5 + k * 1.7) * h * .02 - E.py * 6, fl = nz(t * 3, k * 5) > .86 ? .35 : 1, lg = c.createLinearGradient(0, 0, w, 0);
        lg.addColorStop(0, A('#9E1B20', .0)); lg.addColorStop(.06, A('#9E1B20', .3 * fl)); lg.addColorStop(.94, A('#9E1B20', .3 * fl)); lg.addColorStop(1, A('#9E1B20', 0));
        c.strokeStyle = lg; c.lineWidth = 1.3; c.beginPath(); c.moveTo(0, y); c.lineTo(w, y); c.stroke();
        glow(c, ((t * .25 + k * .31) % 1) * w, y, 18, '#B3202A', .42 * fl);
        glow(c, 4, y, 16, '#B3202A', .5); glow(c, w - 4, y, 16, '#B3202A', .5);
      }
      var q = ((t % 12) - 2) / 3;
      if (q >= 0 && q <= 1) { var sx = ease.io(q) * w, sg = c.createLinearGradient(sx - 170, 0, sx, 0), sa = M.sin(q * M.PI); sg.addColorStop(0, A('#9E1B20', 0)); sg.addColorStop(1, A('#9E1B20', .16 * sa)); c.fillStyle = sg; c.fillRect(sx - 170, 0, 170, h); c.strokeStyle = A('#9E1B20', .55 * sa); c.lineWidth = 1.5; c.beginPath(); c.moveTo(sx, 0); c.lineTo(sx, h); c.stroke(); }
      var tx = E.mx >= 0 ? E.mx : w * .65 + nz(t * .3, 1) * w * .2, ty = E.my >= 0 ? E.my : h * .4 + nz(t * .37, 2) * h * .15;
      rx = rx < 0 ? tx : damp(rx, tx, 6, dt); ry = ry < 0 ? ty : damp(ry, ty, 6, dt);
      c.strokeStyle = A('#9E1B20', .7); c.lineWidth = 1.2; c.beginPath(); c.arc(rx, ry, 22, 0, TAU); c.stroke();
      c.beginPath(); c.moveTo(rx - 34, ry); c.lineTo(rx - 14, ry); c.moveTo(rx + 14, ry); c.lineTo(rx + 34, ry); c.moveTo(rx, ry - 34); c.lineTo(rx, ry - 14); c.moveTo(rx, ry + 14); c.lineTo(rx, ry + 34); c.stroke();
      c.fillStyle = A('#9E1B20', .85); c.beginPath(); c.arc(rx, ry, 1.8, 0, TAU); c.fill();
      c.font = '600 10px ui-monospace,Menlo,monospace'; c.fillText('X ' + (rx | 0) + '  Y ' + (ry | 0), rx + 30, ry - 28);
      var ss = t | 0; c.fillStyle = A('#9E1B20', .45 + .45 * M.max(0, M.sin(t * 4))); c.beginPath(); c.arc(24, h - 26, 4, 0, TAU); c.fill();
      c.fillStyle = A('#4A403B', .8); c.fillText('REC ' + ('0' + ((ss / 3600) | 0)).slice(-2) + ':' + ('0' + (((ss / 60) | 0) % 60)).slice(-2) + ':' + ('0' + (ss % 60)).slice(-2), 36, h - 22);
    };
  };

  /* ---------- Ghost Rider: two real chains (verlet physics) hang from the corners, hellfire licks the bottom edge ---------- */
  SC.ghostrider = function (E) {
    var N = 13, L = 24, chains, ft = [], i, lastTap = 0, em = dust(E, (34 * E.q) | 0, '#FF8A1F', { a: .7, vy: -34, r0: .7, r1: 2.2, vx0: -10, vx1: 10 });
    function mk(ax) { var pts = []; for (var k = 0; k <= N; k++) pts.push({ x: ax, y: k * L * .8, px: ax, py: k * L * .8 }); return { ax: ax, pts: pts }; }
    chains = [mk(E.w * .06), mk(E.w * .94)];
    for (i = 0; i < M.ceil(E.w / 44) + 2; i++) ft.push({ x: i * 44 + rr(-8, 8), h: rr(.6, 1), ph: rr(0, TAU), sp: rr(1.4, 2.6) });
    return function (t, dt) {
      var c = E.c, w = E.w, h = E.h, k, j, s, ch, p, a, b, hot;
      if (E.tapT > lastTap) { lastTap = E.tapT; ch = chains[E.tapX < w / 2 ? 0 : 1]; for (k = 1; k < ch.pts.length; k++) { p = ch.pts[k]; p.px -= (E.tapX - p.x) * .03 * (k / N); p.py -= (E.tapY - p.y) * .03 * (k / N); } }
      var sub = M.min(5, M.ceil(dt / .012)), sd = dt / sub;
      for (s = 0; s < sub; s++) chains.forEach(function (cn) {
        for (k = 1; k < cn.pts.length; k++) {
          p = cn.pts[k]; var vx = (p.x - p.px) * .992, vy = (p.y - p.py) * .992, ax = wnd(t) * 220 + M.sin(t * .9 + k) * 60, ay = 950;
          if (E.mx >= 0) { var dx = p.x - E.mx, dy = p.y - E.my, d = M.hypot(dx, dy); if (d < 110 && d > .1) { var f = M.pow(1 - d / 110, 2) * 9000; ax += dx / d * f; ay += dy / d * f; } }
          p.px = p.x; p.py = p.y; p.x += vx + ax * sd * sd; p.y += vy + ay * sd * sd;
        }
        cn.pts[0].x = cn.ax; cn.pts[0].y = -6;
        for (j = 0; j < 6; j++) for (k = 0; k < cn.pts.length - 1; k++) {
          a = cn.pts[k]; b = cn.pts[k + 1]; var ex = b.x - a.x, ey = b.y - a.y, el = M.hypot(ex, ey) || 1, df = (el - L) / el;
          if (k === 0) { b.x -= ex * df; b.y -= ey * df; } else { a.x += ex * df * .5; a.y += ey * df * .5; b.x -= ex * df * .5; b.y -= ey * df * .5; }
        }
      });
      glow(c, w * .5, h, M.max(w, h) * .55, '#FF7A12', .1 + .03 * nz(t * 1.4, 1));
      c.globalCompositeOperation = 'lighter';
      for (k = 0; k < ft.length; k++) {
        var f2 = ft[k], fl = .5 + .5 * nz(t * f2.sp, f2.ph), H = (h * .16 + 40) * f2.h * (.55 + .45 * fl), sw = nz(t * 1.3 + f2.ph, f2.ph) * 10 + wnd(t) * 8, x = f2.x - E.px * 10, fg = c.createLinearGradient(0, h, 0, h - H);
        fg.addColorStop(0, A('#FF7A12', .32)); fg.addColorStop(.5, A('#FFC24A', .14)); fg.addColorStop(1, A('#FF7A12', 0)); c.fillStyle = fg;
        c.beginPath(); c.moveTo(x - 22, h); c.quadraticCurveTo(x - 10 + sw, h - H * .55, x + sw * 2, h - H); c.quadraticCurveTo(x + 10 + sw, h - H * .55, x + 22, h); c.closePath(); c.fill();
      }
      c.globalCompositeOperation = 'source-over'; c.lineCap = 'round';
      chains.forEach(function (cn) {
        for (k = 0; k < cn.pts.length - 1; k++) {
          a = cn.pts[k]; b = cn.pts[k + 1]; var mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2, an = M.atan2(b.y - a.y, b.x - a.x); hot = k / N;
          c.strokeStyle = A('#B9CBD0', .5); c.lineWidth = 2.4;
          if (k % 2 === 0) { c.beginPath(); c.ellipse(mx, my, L * .56, 5.2, an, 0, TAU); c.stroke(); } else { c.lineWidth = 3.6; c.beginPath(); c.moveTo(mx - M.cos(an) * L * .26, my - M.sin(an) * L * .26); c.lineTo(mx + M.cos(an) * L * .26, my + M.sin(an) * L * .26); c.stroke(); }
          glow(c, mx, my, 16, '#FF7A12', .04 + .13 * hot);
        }
        var e = cn.pts[N]; glow(c, e.x, e.y, 28 + 5 * M.sin(t * 9), '#FF8A1F', .5); glow(c, e.x, e.y, 10, '#FFE2A8', .7);
      });
      em(c, t, dt);
    };
  };

  /* ---------- Wonder Woman: a golden lasso looping through a warm sky, stars twinkling, sunlight glinting ---------- */
  SC.wonderwoman = function (E) {
    var st = [], cl = [], i, em = dust(E, (18 * E.q) | 0, '#F7D77A', { a: .6, vy: -9, r0: .6, r1: 1.8 });
    for (i = 0; i < ((18 * E.q) | 0) + 4; i++) st.push({ x: rr(0, 1), y: rr(0, .5), r: rr(3, 8), p: rr(0, TAU), sp: rr(.8, 2) });
    for (i = 0; i < 5; i++) cl.push({ x: rr(0, 1), y: rr(.55, .9), s: rr(90, 190), d: rr(.3, 1) });
    return function (t, dt) {
      var c = E.c, w = E.w, h = E.h, k, o, sx = w * .82 - E.px * 14, sy = h * .16 - E.py * 8;
      glow(c, sx, sy, 190 + 14 * M.sin(t * .9), '#FFD27A', .3);
      for (k = 0; k < cl.length; k++) { o = cl[k]; o.x += (5 + o.d * 10 + wnd(t) * 4) * dt / w; if (o.x * w - o.s * 2.4 > w) { o.x = -o.s * 2.4 / w; o.y = rr(.55, .9); } puffy(c, o.x * w - E.px * o.d * 24, o.y * h, o.s, '#FFE3A8', .22 + .2 * o.d); }
      for (k = 0; k < st.length; k++) { o = st[k]; var tw = .6 + .4 * M.sin(t * o.sp + o.p); c.fillStyle = A('#E8B53C', .38 * tw); c.beginPath(); starPath(c, o.x * w - E.px * 8, o.y * h, o.r * (.85 + .15 * tw), 5, .45); c.fill(); }
      /* the lasso: a looping rope; the twist is two alternating golds, a bright bead and sparkles ride along it */
      var cx = w * (w < 700 ? .55 : .7) - E.px * 18, cy = h * .46 - E.py * 10, S = M.min(w, h) * .3, NP = 150, pts = [], px = [];
      for (k = 0; k <= NP; k++) { var ph = k / NP * TAU; pts.push([cx + S * (M.sin(ph + t * .16) * 1.05 + .35 * M.sin(2 * ph - t * .23)), cy + S * (.63 * M.sin(2 * ph + t * .19 + 1) + .5 * M.cos(ph - t * .12))]); }
      c.lineCap = 'round'; c.lineJoin = 'round';
      c.strokeStyle = A('#7A4E10', .16); c.lineWidth = 6.4; c.beginPath(); pts.forEach(function (q, i) { i ? c.lineTo(q[0], q[1]) : c.moveTo(q[0], q[1]); }); c.stroke();
      for (var pass = 0; pass < 2; pass++) { c.strokeStyle = pass ? A('#F7D77A', .6) : A('#C9922B', .55); c.lineWidth = 3.6; c.beginPath(); for (k = 0; k < NP; k++) if (((k >> 1) & 1) === pass) { c.moveTo(pts[k][0], pts[k][1]); c.lineTo(pts[k + 1][0], pts[k + 1][1]); } c.stroke(); }
      var bi = (((t * .07) % 1) * NP) | 0; glow(c, pts[bi][0], pts[bi][1], 26, '#FFF1B8', .6);
      for (k = 0; k < 6; k++) { var si = (((t * .05 + k / 6) % 1) * NP) | 0, tw2 = .5 + .5 * M.sin(t * 3 + k * 2); c.fillStyle = A('#FFF6D0', .8 * tw2); c.beginPath(); starPath(c, pts[si][0], pts[si][1], 5 * tw2 + 1, 4, .3); c.fill(); }
      em(c, t, dt);
      /* a long, soft lens streak when the light catches */
      var q2 = ((t % 13) - 1) / 3.2;
      if (q2 >= 0 && q2 <= 1) { var iv = M.pow(M.sin(q2 * M.PI), 2), lg = c.createLinearGradient(sx - w * .35, 0, sx + w * .35, 0); lg.addColorStop(0, A('#FFF1B8', 0)); lg.addColorStop(.5, A('#FFF1B8', .55 * iv)); lg.addColorStop(1, A('#FFF1B8', 0)); c.fillStyle = lg; c.fillRect(sx - w * .35, sy - 1.4, w * .7, 2.8); c.fillStyle = A('#FFFFFF', .7 * iv); c.beginPath(); starPath(c, sx, sy, 56 * iv + 4, 4, .12); c.fill(); }
    };
  };


  /* ================= click effects, pointer trails and the render loop ================= */
  var P = [], FX = [], DECALS = [];
  var E = { c: null, t: null, w: 0, h: 0, px: 0, py: 0, mx: -1, my: -1, sx: -1, sy: -1, ss: 0, fine: false, combo: 0, q: 1, qb: 1, pw: 1, a: '#ffffff', b: '#ffffff', hi: '#ffffff', frame: null, n: 0, hold: false, last: 0, ema: 16, bad: 0, tm: 0 };
  var cvB, cvT, artEl, prog, raf = 0, cur = null;

  function emit(x, y, o) {
    var n = (o.n * (E.qb < 1 ? .7 : 1) * E.pw) | 0, i;
    for (i = 0; i < n && P.length < 520; i++) {
      var a = o.dir === undefined ? R() * TAU : o.dir + rr(-(o.spread || .5), o.spread || .5), s = rr(o.s0 || 40, o.s1 || 220);
      P.push({ x: x, y: y, vx: M.cos(a) * s, vy: M.sin(a) * s + (o.up ? -o.up : 0), g: o.g === undefined ? 260 : o.g, d: o.d === undefined ? .9 : o.d, l: 1, life: rr(o.l0 || .6, o.l1 || 1.3), sz: rr(o.z0 || 2, o.z1 || 5), r: rr(0, TAU), vr: rr(-6, 6), c: pick(o.cols), sh: o.sh || 'dot', ch: o.ch, sw: R() * TAU });
    }
  }
  function drawP(c, p) {
    c.save(); var ag = M.min(1, (1 - p.l) * 16) * M.min(1, p.l * 2.4); c.globalAlpha = ag * ag * (3 - 2 * ag); c.translate(p.x, p.y); c.rotate(p.r); c.fillStyle = p.c; c.strokeStyle = p.c;
    switch (p.sh) {
      case 'spark': var sp = M.min(40, M.hypot(p.vx, p.vy) * .045 + p.sz * 1.5), sg; c.rotate(M.atan2(p.vy, p.vx) - p.r); sg = c.createLinearGradient(0, 0, -sp, 0); sg.addColorStop(0, p.c); sg.addColorStop(1, A(p.c.length === 7 ? p.c : '#ffffff', 0)); c.strokeStyle = sg; c.lineCap = 'round'; c.lineWidth = M.max(1, p.sz * .5); c.beginPath(); c.moveTo(0, 0); c.lineTo(-sp, 0); c.stroke(); if (cur && cur.m === 'dark') glow(c, 0, 0, p.sz * 3.2, p.c.length === 7 ? p.c : '#ffffff', .35); break;
      case 'star': c.beginPath(); for (var i = 0; i < 8; i++) { var rad = i % 2 ? p.sz * .35 : p.sz * 1.5, an = i * M.PI / 4; c.lineTo(M.cos(an) * rad, M.sin(an) * rad); } c.closePath(); c.fill(); break;
      case 'card': c.scale(M.max(.2, M.abs(M.cos(p.sw + p.l * 6))), 1); c.fillRect(-p.sz * 1.4, -p.sz * 2, p.sz * 2.8, p.sz * 4); break;
      case 'petal': c.beginPath(); c.ellipse(0, 0, p.sz * 1.6, p.sz * .8, 0, 0, TAU); c.fill(); break;
      case 'feather': c.beginPath(); c.ellipse(0, 0, p.sz * 2.4, p.sz * .6, 0, 0, TAU); c.fill(); break;
      case 'ash': c.fillRect(-p.sz / 2, -p.sz / 2, p.sz, p.sz * .6); break;
      case 'seed': c.lineWidth = 1; c.beginPath(); c.moveTo(0, 0); c.lineTo(0, p.sz * 3); c.stroke(); c.beginPath(); c.arc(0, 0, p.sz * .9, 0, TAU); c.fill(); break;
      case 'casing': c.fillRect(-p.sz, -p.sz * .5, p.sz * 2, p.sz); break;
      case 'glyph': c.font = '700 ' + (10 + p.sz * 2) + 'px ui-monospace,monospace'; c.fillText(p.ch || '0', 0, 0); break;
      case 'smoke': glow(c, 0, 0, p.sz * (3 + (1 - p.l) * 5), p.c, .5); break;
      case 'plus': c.lineWidth = 2; c.beginPath(); c.moveTo(-p.sz, 0); c.lineTo(p.sz, 0); c.moveTo(0, -p.sz); c.lineTo(0, p.sz); c.stroke(); break;
      case 'heart': var hs = p.sz * .55; c.beginPath(); c.moveTo(0, hs * .9); c.bezierCurveTo(-hs * 2, -hs * .4, -hs * .9, -hs * 1.8, 0, -hs * .7); c.bezierCurveTo(hs * .9, -hs * 1.8, hs * 2, -hs * .4, 0, hs * .9); c.fill(); break;
      case 'flame': c.globalCompositeOperation = 'lighter'; var fh = p.sz * (1.2 + p.l * 2.4), fw = p.sz * (.5 + p.l * .6); c.beginPath(); c.moveTo(0, -fh); c.quadraticCurveTo(fw * 1.4, -fh * .1, 0, fh * .5); c.quadraticCurveTo(-fw * 1.4, -fh * .1, 0, -fh); c.fill(); break;
      default: if (p.c.length === 7) glow(c, 0, 0, p.sz * 2.6, p.c, .5); c.beginPath(); c.arc(0, 0, p.sz * .5, 0, TAU); c.fill();
    }
    c.restore();
  }
  var bubble = function (c, x, y, s, rot, fill, txt, ink) {          /* comic burst + word */
    c.save(); c.translate(x, y); c.rotate(rot); c.scale(s, s); c.beginPath();
    for (var i = 0; i < 28; i++) { var r = i % 2 ? 46 : 78 + (i % 4) * 6, a = i * TAU / 28; c.lineTo(M.cos(a) * r * 1.35, M.sin(a) * r); }
    c.closePath(); c.fillStyle = fill; c.strokeStyle = ink; c.lineWidth = 5; c.lineJoin = 'round'; c.fill(); c.stroke();
    c.font = '900 30px Impact,"Arial Narrow Bold",system-ui,sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.lineWidth = 6; c.strokeStyle = '#fff'; c.strokeText(txt, 0, 2); c.fillStyle = ink; c.fillText(txt, 0, 2); c.restore();
  };
  function ringFx(x, y, cols, o) {
    FX.push({ t: 0, d: o.d || .8, f: function (c, p) {
      var dk = cur && cur.m === 'dark'; c.save(); if (dk) c.globalCompositeOperation = 'lighter';
      cols.forEach(function (col, k) {
        var q = M.max(0, p - k * (o.gap || .12)); if (!q) return; var qe = 1 - M.pow(1 - q, 2.4), rad = qe * (o.r || 140), al = M.pow(1 - q, 1.6), i, a;
        function path() { c.beginPath(); if (o.hex) { for (i = 0; i < 6; i++) { a = i * TAU / 6 + (o.rot || 0) + q; c.lineTo(x + M.cos(a) * rad, y + M.sin(a) * rad); } c.closePath(); } else if (o.ell) c.ellipse(x, y, rad, rad * o.ell, 0, 0, TAU); else c.arc(x, y, rad, 0, TAU); }
        c.lineJoin = 'round'; c.strokeStyle = A(col, al * .16); c.lineWidth = (o.w || 2.5) * (1 - q * .5) * 5 + 2; path(); c.stroke();           /* soft halo */
        c.strokeStyle = A(col, al * .95); c.lineWidth = (o.w || 2.5) * (1 - q * .5); path(); c.stroke();                                          /* lit edge */
      });
      c.restore();
    } });
  }
  var WORDS = { comic: ['BANG!', 'MAXIMUM EFFORT!', 'CHIMICHANGA!', 'BOOM!', '*SLASH*', 'KA-POW!'], ora: ['Ora~!', 'Buriburi!', 'Action Kamen!', 'Chocobi!', 'Hai hai!'] };

  var CLICK = {
    web: function (x, y) {
      var sx = x < E.w / 2 ? 0 : E.w, sy = E.h; FX.push({ t: 0, d: 1.5, f: function (c, p) {
        var s = M.min(1, p / .12), ex = sx + (x - sx) * s, ey = sy + (y - sy) * s; c.strokeStyle = A('#fff', .9 * (1 - p)); c.lineWidth = 1.6; c.beginPath(); c.moveTo(sx, sy); c.lineTo(ex, ey); c.stroke();
        if (p > .1) { var q = M.min(1, (p - .1) / .15), fa = 1 - M.max(0, (p - .5) / .5); c.strokeStyle = A('#fff', .85 * fa); c.lineWidth = 1.3;
          for (var i = 0; i < 8; i++) { var a = i * TAU / 8; c.beginPath(); c.moveTo(x, y); c.lineTo(x + M.cos(a) * 54 * q, y + M.sin(a) * 54 * q); c.stroke(); }
          for (var k = 1; k <= 3; k++) { c.beginPath(); for (i = 0; i <= 8; i++) { var a2 = i * TAU / 8, r = 54 * q * k / 3 * (i % 2 ? .93 : 1); c.lineTo(x + M.cos(a2) * r, y + M.sin(a2) * r); } c.stroke(); } } } });
    },
    repulsor: function (x, y) {                         /* Iron Man tap: charge, flash, hex shockwave, beams, lock-on */
      FX.push({ t: 0, d: .95, f: function (c, p) {
        var s2, i, q;
        if (p < .14) { q = p / .14; c.strokeStyle = A(E.hi, .9 * q); c.lineWidth = 2; c.beginPath(); c.arc(x, y, 80 * (1 - q) + 12, 0, TAU); c.stroke(); glow(c, x, y, 46 * q, E.hi, .6 * q); }
        else {
          q = (p - .14) / .86; glow(c, x, y, 130 * (1 - q) + 30, '#ffffff', .85 * (1 - q)); glow(c, x, y, 190 * (1 - q) + 40, E.hi, .35 * (1 - q));
          c.strokeStyle = A(E.hi, .95 * (1 - q)); c.lineWidth = 3.2 * (1 - q) + .6; c.beginPath();
          for (i = 0; i < 6; i++) { var a = i * TAU / 6 + q * .9, rad = 36 + q * 190; c.lineTo(x + M.cos(a) * rad, y + M.sin(a) * rad); } c.closePath(); c.stroke();
          c.strokeStyle = A(E.a, .7 * (1 - q)); c.lineWidth = 2; c.beginPath(); c.arc(x, y, q * 125, 0, TAU); c.stroke();
          c.strokeStyle = A(E.a, .85 * (1 - q)); c.lineWidth = 2.2; for (i = 0; i < 8; i++) { var b = i * TAU / 8 + .3; c.beginPath(); c.moveTo(x + M.cos(b) * (22 + q * 70), y + M.sin(b) * (22 + q * 70)); c.lineTo(x + M.cos(b) * (60 + q * 170), y + M.sin(b) * (60 + q * 170)); c.stroke(); }
        }
        var ra = p < .65 ? 1 : 1 - (p - .65) / .35; s2 = 30 + (1 - M.min(1, p * 4)) * 28; c.lineWidth = 1.8; c.strokeStyle = A(E.hi, .9 * ra);
        for (var sx = -1; sx <= 1; sx += 2) for (var sy = -1; sy <= 1; sy += 2) { c.beginPath(); c.moveTo(x + sx * s2, y + sy * (s2 - 10)); c.lineTo(x + sx * s2, y + sy * s2); c.lineTo(x + sx * (s2 - 10), y + sy * s2); c.stroke(); }
        c.font = '700 10px ui-monospace,Menlo,monospace'; c.fillStyle = A(E.a, ra); c.fillText('TARGET LOCKED', x + s2 + 6, y - s2 + 9);
      } });
      FX.push({ t: 0, d: .5, f: function (c, p) {   /* blood-red screen pulse + two chasing shock rings */
        var q = 1 - ease.oc(p); c.save(); c.globalCompositeOperation = 'lighter';
        var g2 = c.createRadialGradient(x, y, 0, x, y, M.max(E.w, E.h) * .8); g2.addColorStop(0, A(E.hi, .28 * q)); g2.addColorStop(.5, A(E.a, .08 * q)); g2.addColorStop(1, A(E.a, 0)); c.fillStyle = g2; c.fillRect(0, 0, E.w, E.h);
        for (var k = 0; k < 2; k++) { var qq = M.max(0, p * 1.2 - k * .18); if (qq <= 0 || qq >= 1) continue; c.strokeStyle = A(k ? E.b : E.hi, .8 * (1 - qq)); c.lineWidth = 4 * (1 - qq) + .6; c.beginPath(); c.arc(x, y, 12 + qq * 230, 0, TAU); c.stroke(); }
        c.restore(); } });
      emit(x, y, { n: 34, cols: [E.hi, '#ffffff', E.a, E.b], sh: 'spark', s0: 160, s1: 460, g: 90, l0: .35, l1: .9 }); emit(x, y, { n: 12, cols: [E.a, E.b], sh: 'dot', s0: 40, s1: 200, g: 280, l0: .6, l1: 1.3, z0: 1.5, z1: 3.2 });
      proKick(x, y, .9); if (navigator.vibrate && S.extras) { try { navigator.vibrate(14); } catch (e) { /* ignore */ } }
    },
    repulsorMax: function (x, y) {                      /* hold, then release: unibeam */
      FX.push({ t: 0, d: 1.3, f: function (c, p) {
        var q = M.min(1, p / .5), fa = 1 - M.max(0, (p - .3) / .7), bw = 34 * (1 - p * .6);
        var g = c.createLinearGradient(0, y, 0, 0); g.addColorStop(0, A('#ffffff', .95 * fa)); g.addColorStop(.35, A(E.hi, .7 * fa)); g.addColorStop(1, A(E.hi, 0));
        c.fillStyle = g; c.fillRect(x - bw / 2, 0, bw, y); glow(c, x, y, 220 * (1 - p * .5), E.hi, .6 * fa); glow(c, x, y, 100, '#ffffff', .9 * fa);
        for (var k = 0; k < 3; k++) { var qq = M.max(0, q - k * .16); if (!qq) continue; c.strokeStyle = A(k % 2 ? E.a : E.hi, .9 * (1 - qq) * fa); c.lineWidth = 3.4 * (1 - qq) + .6; c.beginPath(); for (var i = 0; i < 6; i++) { var a = i * TAU / 6 + qq * 1.2, rad = 30 + qq * 340; c.lineTo(x + M.cos(a) * rad, y + M.sin(a) * rad); } c.closePath(); c.stroke(); }
        c.fillStyle = A(E.hi, .18 * (1 - p) * (p < .15 ? 1.6 : 1)); c.fillRect(0, 0, E.w, E.h);
        c.font = '800 13px ui-monospace,Menlo,monospace'; c.textAlign = 'center'; c.fillStyle = A(E.a, fa); c.fillText('UNIBEAM', x, y + 44 + p * 20); c.textAlign = 'left';
      } });
      emit(x, y, { n: 70, cols: [E.hi, '#ffffff', E.a, E.b], sh: 'spark', s0: 200, s1: 620, g: 120, l0: .4, l1: 1.1 }); emit(x, y, { n: 14, cols: [E.a], sh: 'dot', s0: 60, s1: 260, g: 340, l0: .8, l1: 1.6, z0: 2, z1: 4 });
      if (navigator.vibrate && S.extras) { try { navigator.vibrate([10, 30, 24]); } catch (e) { /* ignore */ } }
    },
    splat: function (x, y) { var d = []; for (var i = 0; i < 16; i++) d.push({ a: R() * TAU, r: rr(6, 60), s: rr(2, 9) });
      FX.push({ t: 0, d: 3.2, f: function (c, p) { var fa = p < .6 ? 1 : 1 - (p - .6) / .4, q = M.min(1, p * 8); c.fillStyle = A('#B3121F', .85 * fa); c.beginPath(); c.arc(x, y, 16 * q, 0, TAU); c.fill(); d.forEach(function (o) { c.beginPath(); c.arc(x + M.cos(o.a) * o.r * q, y + M.sin(o.a) * o.r * q, o.s * q, 0, TAU); c.fill(); }); if (p < .12) { c.fillStyle = A('#B3121F', .25); c.fillRect(0, y - 4, E.w, 8); } } }); },
    snap: function (x, y) { emit(x, y, { n: 46, cols: ['#BDA9A0', '#F0B24A', '#8A7A72', '#9B59F0'], sh: 'ash', s0: 30, s1: 190, dir: -.4, spread: 1.4, g: -40, d: .96, l0: 1, l1: 2.2, z0: 2, z1: 6 }); ringFx(x, y, ['#9B59F0', '#F0B24A'], { d: .9, r: 150, w: 2 }); },
    magic: function (x, y) { emit(x, y, { n: 30, cols: ['#1E6B3B', '#2FA35B', '#C98A18', '#F3DA8A'], sh: 'star', s0: 40, s1: 220, g: 40, l0: .6, l1: 1.4, z0: 2, z1: 5 }); ringFx(x, y, ['#2FA35B', '#C98A18'], { d: 1, r: 130, ell: .5, w: 2.5 }); },
    comic: function (x, y) { var wd = pick(WORDS.comic); FX.push({ t: 0, d: .95, f: function (c, p) { var s = (p < .45 ? ease.ob(p / .45) : 1) * 1.05, fa = p < .7 ? 1 : 1 - (p - .7) / .3; c.globalAlpha = fa; bubble(c, x, y, s * (wd.length > 8 ? .8 : 1), -.12, '#FFD21F', wd, '#B3121F'); c.globalAlpha = 1; } }); emit(x, y, { n: 12, cols: ['#FF2B3E', '#FFD21F'], sh: 'spark', s0: 140, s1: 360, g: 0, l0: .3, l1: .5 }); },
    ora: function (x, y) { var wd = pick(WORDS.ora); FX.push({ t: 0, d: 1, f: function (c, p) { var s = (p < .45 ? ease.ob(p / .45) : 1) * 1.05, fa = p < .7 ? 1 : 1 - (p - .7) / .3; c.globalAlpha = fa; bubble(c, x, y - M.abs(M.sin(p * 9)) * 14 * (1 - p), s * .78, M.sin(p * 10) * .08, '#FFD21F', wd, '#D42A25'); c.globalAlpha = 1; } }); emit(x, y, { n: 16, cols: ['#D42A25', '#FFD21F', '#1FA64B', '#2D7BFF'], sh: 'star', s0: 90, s1: 260, g: 380, l0: .6, l1: 1.1, z0: 3, z1: 6 }); },
    vibranium: function (x, y) { ringFx(x, y, ['#B497FF', '#7C5CFF', '#EFEAFF'], { d: 1, r: 170, hex: 1, w: 2.5, gap: .1 }); emit(x, y, { n: 24, cols: ['#B497FF', '#EFEAFF'], sh: 'dot', s0: 30, s1: 190, g: -20, l0: .8, l1: 1.6, z0: 1.5, z1: 3 }); },
    bullet: function (x, y) { FX.push({ t: 0, d: .16, f: function (c, p) { glow(c, x, y, 70 * (1 - p), '#fff', .9 * (1 - p)); c.fillStyle = A('#FFE9A8', 1 - p); c.beginPath(); for (var i = 0; i < 12; i++) { var r = i % 2 ? 6 : 26 * (1 - p), a = i * TAU / 12; c.lineTo(x + M.cos(a) * r, y + M.sin(a) * r); } c.fill(); } });
      var cr = []; for (var i = 0; i < 7; i++) cr.push({ a: R() * TAU, l: rr(8, 26) }); DECALS.push({ x: x, y: y, t: 0, cr: cr }); emit(x, y, { n: 8, cols: ['#EDEDED', '#BDBDBD'], sh: 'spark', s0: 100, s1: 260, g: 200, l0: .3, l1: .6 }); },
    gunshot: function (x, y) { FX.push({ t: 0, d: .2, f: function (c, p) { glow(c, x, y, 80 * (1 - p), '#FFE9A8', .85 * (1 - p)); } }); ringFx(x, y, ['#2F7BFF', '#D8B24A'], { d: .5, r: 90, w: 2.5, gap: .08 }); emit(x, y, { n: 3, cols: ['#D8B24A'], sh: 'casing', s0: 80, s1: 160, dir: -1.2, spread: .6, g: 700, l0: .8, l1: 1, z0: 3, z1: 4 }); emit(x, y, { n: 16, cols: ['#D8B24A', '#F3DA8A', '#2F7BFF'], sh: 'spark', s0: 140, s1: 380, g: 200, l0: .3, l1: .6 }); },
    rune: function (x, y) { FX.push({ t: 0, d: 1.2, f: function (c, p) { var q = M.min(1, p * 3.5), fa = p < .6 ? 1 : 1 - (p - .6) / .4; c.save(); c.translate(x, y); c.lineWidth = 2; [[1, 1], [.72, -1.4], [.45, 2]].forEach(function (L, k) { c.strokeStyle = A(k % 2 ? '#FFC64D' : '#FF8A1F', .9 * fa); c.setLineDash(k === 1 ? [3, 7] : []); c.beginPath(); c.arc(0, 0, 90 * L[0] * q, p * L[1] * 3, p * L[1] * 3 + TAU * .85 * q); c.stroke(); }); c.setLineDash([]); c.strokeStyle = A('#FF8A1F', .8 * fa); c.beginPath(); for (var i = 0; i < 5; i++) { var a = p * 3 + i * TAU * 2 / 5; c.lineTo(M.cos(a) * 64 * q, M.sin(a) * 64 * q); } c.closePath(); c.stroke(); c.restore(); } }); emit(x, y, { n: 26, cols: ['#FFC64D', '#FF8A1F'], sh: 'dot', s0: 60, s1: 260, g: 160, l0: .5, l1: 1.1, z0: 1.5, z1: 3 }); },
    batarang: function (x, y) { var sx = E.w + 40, sy = E.h * .9; FX.push({ t: 0, d: 1.1, f: function (c, p) { var s = M.min(1, p / .28), px = sx + (x - sx) * s, py = sy + (y - sy) * s, fa = p < .7 ? 1 : 1 - (p - .7) / .3; c.save(); c.translate(px, py); c.rotate(s < 1 ? p * 40 : .4); c.fillStyle = A('#F0F0EA', fa); c.beginPath(); c.moveTo(0, -6); c.lineTo(10, -14); c.lineTo(34, -6); c.lineTo(20, 4); c.lineTo(0, 12); c.lineTo(-20, 4); c.lineTo(-34, -6); c.lineTo(-10, -14); c.closePath(); c.fill(); c.restore(); if (s >= 1) glow(c, x, y, 40, '#FFD21F', .25 * fa); } }); },
    cards: function (x, y) { emit(x, y, { n: 18, cols: ['#F4ECFF', '#A6E22E', '#A24BE0', '#D01832'], sh: 'card', s0: 80, s1: 320, g: 420, l0: .9, l1: 1.6, z0: 3, z1: 6, up: 160 }); FX.push({ t: 0, d: 1, f: function (c, p) { c.save(); c.globalAlpha = 1 - p; c.font = '900 34px Georgia,serif'; c.fillStyle = '#A6E22E'; c.strokeStyle = '#2A1A3D'; c.lineWidth = 4; c.textAlign = 'center'; c.strokeText('HA HA!', x, y - 20 - p * 50); c.fillText('HA HA!', x, y - 20 - p * 50); c.restore(); } }); },
    gravity: function (x, y) { ringFx(x, y, ['#FFB347', '#E9EEF3', '#8FB5D6', '#FFB347'], { d: 1.5, r: 220, w: 2, gap: .1, ell: .92 }); FX.push({ t: 0, d: .5, f: function (c, p) { c.fillStyle = '#000'; c.beginPath(); c.arc(x, y, 9 * (1 - p), 0, TAU); c.fill(); c.strokeStyle = A('#FFE2A8', 1 - p); c.lineWidth = 2; c.beginPath(); c.arc(x, y, 9 * (1 - p) + 2, 0, TAU); c.stroke(); } }); },
    wand: function (x, y) { emit(x, y, { n: 34, cols: ['#E8C676', '#FFFFFF', '#FFD27A'], sh: 'star', s0: 30, s1: 240, g: 90, l0: .8, l1: 1.6, z0: 2, z1: 4 }); FX.push({ t: 0, d: .4, f: function (c, p) { glow(c, x, y, 80 * (1 - p), '#FFD27A', .5 * (1 - p)); } }); },
    glyphs: function (x, y) { var g = 'ｱｲｳｴｵｶｷｸｹｺ01ﾅﾆﾇ'; for (var i = 0; i < 16; i++) emit(x + rr(-30, 30), y + rr(-10, 10), { n: 1, cols: ['#19F26B', '#E8FFEE', '#0FB15A'], sh: 'glyph', s0: 10, s1: 40, dir: M.PI / 2, spread: .2, g: 160, l0: .6, l1: 1.4, z0: 1, z1: 3 }); P.slice(-16).forEach(function (p) { p.ch = g[(R() * g.length) | 0]; p.vr = 0; p.r = 0; }); ringFx(x, y, ['#19F26B'], { d: .5, r: 60, w: 1.5 }); },
    flicker: function (x, y) { var pts = [[x, -10]], yy = 0; while (yy < y) { yy += rr(24, 50); pts.push([x + rr(-26, 26), M.min(yy, y)]); }
      FX.push({ t: 0, d: .5, f: function (c, p) { var on = p < .12 || (p > .2 && p < .3) || (p > .38 && p < .42); if (!on) return; c.strokeStyle = A('#FFFFFF', .9); c.lineWidth = 2.4; c.shadowColor = '#FF2D4D'; c.shadowBlur = 18; c.beginPath(); pts.forEach(function (q, i) { i ? c.lineTo(q[0], q[1]) : c.moveTo(q[0], q[1]); }); c.stroke(); c.shadowBlur = 0; c.fillStyle = A('#FF2D4D', .1); c.fillRect(0, 0, E.w, E.h); } }); emit(x, y, { n: 14, cols: ['#FF6F85', '#FF2D4D'], sh: 'dot', s0: 10, s1: 60, g: -20, l0: 1, l1: 2, z0: 2, z1: 4 }); },
    sand: function (x, y) { emit(x, y, { n: 60, cols: ['#C9863A', '#A9440F', '#E3C78F', '#6E2E0A'], sh: 'dot', s0: 20, s1: 260, g: 30, d: .92, l0: .7, l1: 1.6, z0: 1.5, z1: 4, dir: -.2, spread: 1.6 }); ringFx(x, y, ['#A9440F'], { d: 1, r: 110, ell: .3, w: 2 }); },
    moonring: function (x, y) { ringFx(x, y, ['#D6E4FF', '#F6F8FF', '#7F8CB5'], { d: 1.4, r: 150, w: 2, gap: .14 }); emit(x, y, { n: 10, cols: ['#F6F8FF', '#D6E4FF'], sh: 'star', s0: 20, s1: 110, g: -10, l0: 1, l1: 1.8, z0: 1.5, z1: 3 }); },
    sprout: function (x, y) { FX.push({ t: 0, d: 2.6, f: function (c, p) { var g = M.min(1, p / .35), fa = p < .75 ? 1 : 1 - (p - .75) / .25, ht = 46 * g, sw = M.sin(p * 8) * 2 * g; c.globalAlpha = fa; c.strokeStyle = '#6BE675'; c.lineWidth = 3; c.lineCap = 'round'; c.beginPath(); c.moveTo(x, y); c.quadraticCurveTo(x + sw, y - ht * .5, x + sw * 1.5, y - ht); c.stroke();
      if (g > .5) { var l = (g - .5) * 2; c.fillStyle = '#6BE675'; [-1, 1].forEach(function (d) { c.beginPath(); c.ellipse(x + sw * 1.5 + d * 11 * l, y - ht - 3 * l, 12 * l, 5.5 * l, d * -.6, 0, TAU); c.fill(); }); } glow(c, x, y - ht, 40, '#6BE675', .22 * g); c.globalAlpha = 1; c.lineCap = 'butt'; } }); },
    zen: function (x, y) { ringFx(x, y, ['#0B66A8', '#5BB6FF', '#FFFFFF'], { d: 1.8, r: 130, ell: .38, w: 2, gap: .18 }); emit(x, y, { n: 12, cols: ['#F6A5B8', '#FFFFFF'], sh: 'petal', s0: 20, s1: 120, g: 50, up: 60, l0: 1, l1: 1.8, z0: 3, z1: 5 });
      if (R() < .3) FX.push({ t: 0, d: 1.6, f: function (c, p) { c.save(); c.globalAlpha = 1 - p; c.font = 'italic 700 22px ui-rounded,system-ui,sans-serif'; c.fillStyle = '#0E1A24'; c.textAlign = 'center'; c.fillText(pick(['peace', 'skadoosh!', 'chill bro', 'inner peace']), x, y - 14 - p * 36); c.restore(); } }); },
    seeds: function (x, y) { emit(x, y, { n: 16, cols: ['#FFFFFF', '#FFF4B0'], sh: 'seed', s0: 20, s1: 110, g: -26, up: 70, d: .97, l0: 1.6, l1: 3, z0: 2, z1: 3 }); },
    feathers: function (x, y) { emit(x, y, { n: 16, cols: ['#FFFFFF', '#DCEEFF'], sh: 'feather', s0: 40, s1: 220, g: -30, up: 130, d: .96, l0: 1.2, l1: 2.4, z0: 3, z1: 5 }); }
  };

  function chargeFx(c) {                        /* Iron Man: holding a finger or the mouse charges the repulsor */
    var g = E.chg; if (!g) return; if (cur && cur.click === 'tenrings') { ringCharge(c, g); return; } var held = (performance.now() - g.t0) / 1000; if (held < .16) return;
    var q = M.min(1, held / .55), x = g.x, y = g.y, k, i;
    for (k = 0; k < 3; k++) { var ph = ((held * 1.6) + k / 3) % 1; c.strokeStyle = A(E.hi, .8 * (1 - ph)); c.lineWidth = 1.6; c.beginPath(); c.arc(x, y, 12 + (1 - ph) * 74 * (.4 + q * .6), 0, TAU); c.stroke(); }
    glow(c, x, y, 28 + 70 * q, E.hi, .35 + .4 * q); glow(c, x, y, 14 + 16 * q, '#ffffff', .5 + .4 * q);
    c.strokeStyle = A(q >= 1 ? E.a : E.hi, .95); c.lineWidth = 2.4; c.beginPath(); c.arc(x, y, 34, -M.PI / 2, -M.PI / 2 + TAU * q); c.stroke();
    if (q >= 1) { c.strokeStyle = A(E.a, .5 + .4 * M.sin(held * 18)); c.lineWidth = 1.5; c.beginPath(); for (i = 0; i < 6; i++) { var a = i * TAU / 6 + held * 2; c.lineTo(x + M.cos(a) * 46, y + M.sin(a) * 46); } c.closePath(); c.stroke(); }
    c.font = '700 10px ui-monospace,Menlo,monospace'; c.fillStyle = A(q >= 1 ? E.a : E.hi, .95); c.fillText(q >= 1 ? 'RELEASE' : 'CHARGING ' + ((q * 100) | 0) + '%', x + 42, y - 36);
  }
  function stepFx(c, dt) {
    var i; chargeFx(c); for (i = FX.length - 1; i >= 0; i--) { var f = FX[i]; f.t += dt; var p = f.t / f.d; if (p >= 1) { FX.splice(i, 1); continue; } f.f(c, p); }
    for (i = P.length - 1; i >= 0; i--) { var q = P[i]; q.l -= dt / q.life; if (q.l <= 0) { P.splice(i, 1); continue; } q.vx *= M.pow(q.d, dt * 60 / 3); q.vy = q.vy * M.pow(q.d, dt * 60 / 3) + q.g * dt; q.x += q.vx * dt + (q.sh === 'feather' || q.sh === 'seed' || q.sh === 'petal' ? M.sin(q.sw + q.l * 5) * 20 * dt : 0); q.y += q.vy * dt; q.r += q.vr * dt * .3; drawP(c, q); }
    for (i = DECALS.length - 1; i >= 0; i--) { var d = DECALS[i]; d.t += dt; var fa = d.t > 5 ? 1 - (d.t - 5) / 1.5 : 1; if (fa <= 0) { DECALS.splice(i, 1); continue; }
      c.save(); c.globalAlpha = fa; c.fillStyle = '#000'; c.strokeStyle = '#EDEDED'; c.lineWidth = 1; c.beginPath(); c.arc(d.x, d.y, 5, 0, TAU); c.fill(); c.stroke(); c.strokeStyle = A('#EDEDED', .6); d.cr.forEach(function (k) { c.beginPath(); c.moveTo(d.x + M.cos(k.a) * 6, d.y + M.sin(k.a) * 6); c.lineTo(d.x + M.cos(k.a) * (6 + k.l), d.y + M.sin(k.a) * (6 + k.l)); c.stroke(); }); c.restore(); }
  }
  function fxBusy() { return FX.length || P.length || DECALS.length || E.chg; }

  /* ---------------- engine ---------------- */
  function dims() { var d = M.min(window.devicePixelRatio || 1, E.qb < .8 ? 1 : 1.5); return d; }
  function size() {
    if (!cvB) return; var w = innerWidth, h = innerHeight, d = dims(); E.w = w; E.h = h; E.dpr = d;
    [cvB, cvT].forEach(function (cv) { cv.width = M.round(w * d); cv.height = M.round(h * d); });
    E.c.setTransform(d, 0, 0, d, 0, 0); E.t.setTransform(d, 0, 0, d, 0, 0);
  }
  function build() {
    if (!cur || !cvB) return; E.pw = pw(); E.q = E.qb * E.pw; E.a = cssv('--accent', '#ffffff'); E.b = cssv('--violet', E.a); E.hi = cssv('--hi', E.a);
    E.frame = SC[cur.scene] ? SC[cur.scene](E) : null; E.tm = E.tm || 0;
  }
  function loop(ts) {
    raf = requestAnimationFrame(loop);
    var mo = motion(), gap = mo === 'calm' ? 28 : 0; if (ts - E.last < gap) return; var dt = M.min(.05, (ts - E.last) / 1000 || .016); E.last = ts;
    E.ema += (dt * 1000 - E.ema) * .05; if (mo === 'full' && E.ema > 27 && ++E.bad > 90 && E.qb > .46) { E.qb = M.max(.45, E.qb * .72); E.bad = 0; E.ema = 16; size(); build(); }
    var tpx, tpy; if (E.mx >= 0) { tpx = E.mx / E.w * 2 - 1; tpy = E.my / E.h * 2 - 1; } else { tpx = M.sin(E.tm * .13) * .3 + M.sin(E.tm * .31 + 1) * .12; tpy = M.sin(E.tm * .11 + 2) * .2; }
    E.px = damp(E.px, tpx, 3.4, dt); E.py = damp(E.py, tpy, 3.4, dt);   /* eased, same feel at any frame rate; with no pointer the scene drifts on its own */
    if (++E.n % 12 === 0) { var ae = document.activeElement; E.hold = !!(document.querySelector('dialog[open]') || (ae && /^(INPUT|TEXTAREA|SELECT)$/.test(ae.tagName))); }
    var c = E.c; if (!E.hold) { E.tm += dt; c.clearRect(0, 0, E.w, E.h); }          /* sign-in forms and typing get the full CPU: the scene freezes on its last frame */
    if (E.frame && !E.hold) { try { E.frame(E.tm, dt); } catch (err) { E.frame = null; } }
    if (!E.hold) proAfter(c, E.tm, dt, mo);
    /* pointer spotlight: a soft pool of the theme's glow follows the cursor (mouse only, never on phones) */
    if (!E.hold && S.extras && E.fine && E.mx >= 0 && mo === 'full') {
      E.sx = E.sx < 0 ? E.mx : damp(E.sx, E.mx, 10, dt); E.sy = E.sy < 0 ? E.my : damp(E.sy, E.my, 10, dt);
      glow(c, E.sx, E.sy, 150 + 90 * E.pw, cur.m === 'dark' ? E.hi : E.a, (cur.m === 'dark' ? .1 : .075) * E.pw);
    }
    if (artEl && cur && cur.art) {
      E.ss = damp(E.ss, -M.min(window.pageYOffset || 0, 1400) * .045, 5, dt);          /* the artwork drifts slower than the page */
      artEl.style.transform = 'translate3d(' + (-E.px * 10 * E.pw + M.sin(E.tm * .22) * 3).toFixed(1) + 'px,' + (-E.py * 8 * E.pw + E.ss + M.sin(E.tm * .17 + 1) * 2.5).toFixed(1) + 'px,0) scale(' + (1.04 + .006 * M.sin(E.tm * .35)).toFixed(4) + ')';   /* slow breathing keeps the artwork alive */
    }
    if (fxBusy()) { E.t.clearRect(0, 0, E.w, E.h); stepFx(E.t, dt); E.cleared = 0; } else if (!E.cleared) { E.t.clearRect(0, 0, E.w, E.h); E.cleared = 1; }
  }
  function run() { if (!raf && !document.hidden) { E.last = performance.now(); raf = requestAnimationFrame(loop); } }
  function halt() { if (raf) cancelAnimationFrame(raf); raf = 0; }
  function still() {                            /* Motion "Off": one calm still frame */
    halt(); if (!E.frame) return; E.c.clearRect(0, 0, E.w, E.h); try { E.frame(3.2, .016); E.frame(3.25, .016); } catch (e) { /* ignore */ }
  }
  function mount() {
    if (cvB) return;
    artEl = document.createElement('div'); artEl.id = 'vArt'; artEl.setAttribute('aria-hidden', 'true');
    cvB = document.createElement('canvas'); cvB.id = 'vBack'; cvB.setAttribute('aria-hidden', 'true');
    cvT = document.createElement('canvas'); cvT.id = 'vTop'; cvT.setAttribute('aria-hidden', 'true');
    document.body.insertBefore(cvB, document.body.firstChild); document.body.insertBefore(artEl, document.body.firstChild); document.body.appendChild(cvT);
    E.c = cvB.getContext('2d'); E.t = cvT.getContext('2d'); E.q = E.qb = 1; E.pw = pw(); size(); mountProg(); proMount();
  }
  function unmount() { halt(); proUnmount(); [prog, artEl, cvB, cvT].forEach(function (n) { if (n && n.parentNode) n.parentNode.removeChild(n); }); prog = artEl = cvB = cvT = null; E.c = E.t = E.frame = null; P.length = FX.length = DECALS.length = 0; }
  function engine() {
    cur = S.id ? BY[S.id] : null;
    if (!cur) { unmount(); return; }
    P.length = FX.length = DECALS.length = 0; E.chg = null; E.combo = 0; E.tapT = 0;   /* nothing from the previous theme lingers */
    mount(); size(); E.qb = innerWidth < 700 ? .75 : 1; build();
    if (motion() === 'off') { still(); } else { run(); }
  }

  /* reading-progress line in the theme's two colours */
  function mountProg() {
    if (prog) return; prog = document.createElement('div'); prog.id = 'vProg'; prog.setAttribute('aria-hidden', 'true'); document.body.appendChild(prog); paintProg();
  }
  function paintProg() {
    if (!prog) return; var de = document.documentElement, max = (de.scrollHeight || 0) - innerHeight;
    prog.style.transform = 'scaleX(' + (max > 8 ? M.min(1, M.max(0, (window.pageYOffset || 0) / max)).toFixed(4) : 0) + ')';
  }
  var progT = 0; addEventListener('scroll', function () { if (!prog || progT) return; progT = requestAnimationFrame(function () { progT = 0; paintProg(); }); }, { passive: true });

  /* pointer + clicks + trails */
  var lastClick = 0, lastTrail = 0;
  addEventListener('pointermove', function (e) {
    E.mx = e.clientX; E.my = e.clientY; E.fine = e.pointerType === 'mouse' || e.pointerType === 'pen';
    if (E.chg) { E.chg.x = e.clientX; E.chg.y = e.clientY; }
    if (cur && cur.trail && S.fx && motion() !== 'off' && (e.pointerType !== 'touch' || E.chg)) { var n = performance.now(); if (n - lastTrail > 45) { lastTrail = n; emit(e.clientX, e.clientY, { n: 1, cols: [E.hi, E.a, '#ffffff'], sh: cur.id === 'ironman' ? 'spark' : 'star', s0: 6, s1: 40, g: 40, l0: .5, l1: .9, z0: 1.2, z1: 2.4 }); run(); } }
  }, { passive: true });
  function comboTap(f, x, y, n) {
    /* power: rapid taps build a combo. Max adds a ring on every tap; five quick taps (four on Max) set off a finale */
    E.combo = (n - (E.lastCombo || 0) < 480) ? E.combo + 1 : 1; E.lastCombo = n;
    if (E.pw >= 1.5) ringFx(x, y, [E.a], { d: .5, r: 52, w: 1.6 });
    if (S.extras && E.pw >= .99 && E.combo >= (E.pw >= 1.5 ? 4 : 5)) {
      E.combo = 0; for (var k = 0; k < 3; k++) f(x + rr(-110, 110), y + rr(-80, 80));
      FX.push({ t: 0, d: .5, f: function (c, p) { glow(c, x, y, M.max(E.w, E.h) * .55 * p + 40, E.hi, .22 * (1 - p)); } });
    }
  }
  function buzz(ms) { if (S.extras && navigator.vibrate) { try { navigator.vibrate(ms); } catch (e) { /* ignore */ } } }
  addEventListener('pointerdown', function (e) {
    if (!cur || !S.fx || motion() === 'off' || e.button > 0) return; var n = performance.now(); if (n - lastClick < 90) return; lastClick = n;
    if (e.target && e.target.closest && e.target.closest('input,textarea,select,#vPanel')) return;
    var f = CLICK[cur.click]; if (!f) return; var x = e.clientX, y = e.clientY, touch = e.pointerType === 'touch';
    E.tapX = x; E.tapY = y; E.tapT = n;
    proTap(x, y);
    if (touch) { ringFx(x, y, [E.a], { d: .45, r: 40 + 14 * E.pw, w: 2.2 }); buzz(E.pw >= 1.5 ? 14 : 8); }       /* every theme gets a visible, tactile touch */
    if (cur.click === 'repulsor' || cur.click === 'tenrings') {   /* Iron Man + Shang-Chi: press to start charging, lift to fire (a quick tap fires the normal blast) */
      E.chg = { x: x, y: y, t0: n }; ringFx(x, y, [E.hi], { d: .3, r: 34, w: 2 }); run(); return;
    }
    f(x, y); comboTap(f, x, y, n); run();
  }, { passive: true });
  function chgEnd(e, cancel) {
    var g = E.chg; if (!g) return; E.chg = null; if (cancel || !cur || (cur.click !== 'repulsor' && cur.click !== 'tenrings') || !S.fx || motion() === 'off') return;
    var n = performance.now(), held = (n - g.t0) / 1000, x = e.clientX || g.x, y = e.clientY || g.y;
    var tr = cur.click === 'tenrings'; if (held >= .55) { if (tr) { ringBlast(x, y, 1.7); proKick(x, y, 1.2); } else CLICK.repulsorMax(x, y); buzz([10, 30, 24]); } else { CLICK[cur.click](x, y); buzz(10); comboTap(CLICK[cur.click], x, y, n); }
    E.tapX = x; E.tapY = y; E.tapT = n; run();
  }
  addEventListener('pointerup', function (e) { chgEnd(e, false); }, { passive: true });
  addEventListener('pointercancel', function (e) { chgEnd(e, true); }, { passive: true });
  addEventListener('blur', function () { E.chg = null; });
  var rzT; addEventListener('resize', function () { clearTimeout(rzT); rzT = setTimeout(function () { if (!cur) return; if (innerWidth === E.w && innerHeight < E.h) return;   /* phone keyboard / address bar: keep the canvas, no rebuild */ size(); build(); if (motion() === 'off') still(); }, 160); });
  document.addEventListener('visibilitychange', function () { if (document.hidden) halt(); else if (cur && motion() !== 'off') run(); });


  /* ================= v3 tap effects for the ten new looks (all use eased progress, springs and soft fades) ================= */
  var W2 = { kat: ['SHING!', 'SLICE!', 'MAXIMUM EFFORT!', 'CHIMICHANGA!', 'TA-DA!'], bell: ['Ding~', 'Dokodemo Door!', 'Take-copter!', 'Hello, Nobita!', 'Gadget time!'], bump: ['Hello~', 'Ba-la-la-la-la', 'I am here.', 'Are you satisfied?'], vroom: ['VROOM!', 'BRRAP!', 'HEMI!', 'FULL SEND!'] };
  function tag(x, y, txt, o) {                       /* outlined word: springs in, drifts up, fades */
    FX.push({ t: 0, d: o.d || 1.1, f: function (c, p) {
      var s = (p < .35 ? ease.ob(p / .35) : 1) * (o.s || 1), fa = p < .65 ? 1 : 1 - ease.ss((p - .65) / .35);
      c.save(); c.globalAlpha = fa; c.translate(x, y - ease.oc(p) * (o.rise || 26)); c.rotate(o.rot || 0); c.scale(s, s); c.font = o.font; c.textAlign = 'center'; c.textBaseline = 'middle'; c.lineJoin = 'round';
      c.lineWidth = o.lw || 6; c.strokeStyle = o.stroke; c.strokeText(txt, 0, 0); c.fillStyle = o.fill; c.fillText(txt, 0, 0); c.restore();
    } });
  }
  CLICK.burnout = function (x, y) {
    var dir = x < E.w / 2 ? 1 : -1, len = 190 + R() * 90;
    FX.push({ t: 0, d: 2.4, f: function (c, p) {
      var g = ease.oc(M.min(1, p / .4)), fa = p < .5 ? 1 : 1 - ease.ss((p - .5) / .5), i;
      c.save(); c.globalAlpha = .6 * fa; c.strokeStyle = '#1A1210'; c.lineCap = 'round'; c.lineWidth = 3.6;
      for (i = -1; i <= 1; i += 2) { c.beginPath(); c.moveTo(x, y + i * 7); c.quadraticCurveTo(x + dir * len * g * .55, y + i * 7 - 22 * g, x + dir * len * g, y + i * 7 + 8 * g); c.stroke(); }
      c.restore(); if (p < .14) glow(c, x, y, 70 * (1 - p / .14), '#D9141E', .5 * (1 - p / .14));
    } });
    emit(x, y, { n: 16, cols: ['#8C837A', '#B9B0A6', '#6B625A'], sh: 'smoke', s0: 20, s1: 90, dir: -M.PI / 2 - dir * .5, spread: 1, g: -34, d: .94, l0: 1.1, l1: 2, z0: 5, z1: 9 });
    emit(x, y, { n: 10, cols: ['#FF7A12', '#FFC24A', '#D9141E'], sh: 'spark', s0: 120, s1: 320, g: 300, l0: .3, l1: .7 });
    tag(x, y - 30, pick(W2.vroom), { font: 'italic 900 28px Impact,"Arial Narrow Bold",system-ui,sans-serif', fill: '#D9141E', stroke: '#FFFFFF', rot: -.1 * dir, d: 1 });
  };
  CLICK.inkswirl = function (x, y) {
    var rot = R() * TAU, dir = R() < .5 ? 1 : -1;
    FX.push({ t: 0, d: 2, f: function (c, p) {
      var g = ease.oc(M.min(1, p / .55)), fa = p < .5 ? 1 : 1 - ease.ss((p - .5) / .5), n = 46, i, u, u0, a, r, a0, r0, m = n * g;
      c.save(); c.lineCap = 'round'; c.strokeStyle = '#111111';
      for (i = 1; i <= m; i++) {
        u = i / n; u0 = (i - 1) / n; a = rot + dir * u * TAU * 1.9; r = 6 + u * 78; a0 = rot + dir * u0 * TAU * 1.9; r0 = 6 + u0 * 78;
        c.globalAlpha = .75 * fa * (1 - u * .6); c.lineWidth = 4 * (1 - u) + .6; c.beginPath(); c.moveTo(x + M.cos(a0) * r0, y + M.sin(a0) * r0 * .78); c.lineTo(x + M.cos(a) * r, y + M.sin(a) * r * .78); c.stroke();
      }
      c.restore();
    } });
    emit(x, y, { n: 8, cols: ['#111111', '#333333'], sh: 'dot', s0: 10, s1: 70, g: 40, d: .94, l0: 1, l1: 2, z0: 2, z1: 4 });
  };
  CLICK.bump = function (x, y) {
    ringFx(x, y, ['#FFFFFF', '#0B6FCB'], { d: 1.1, r: 120, w: 3, gap: .12 });
    FX.push({ t: 0, d: .6, f: function (c, p) { glow(c, x, y, 110 * ease.oc(p) + 20, '#FFFFFF', .6 * (1 - p)); } });
    emit(x, y, { n: 8, cols: ['#0B6FCB', '#F25C54'], sh: 'plus', s0: 30, s1: 120, g: -30, up: 50, d: .96, l0: 1, l1: 1.8, z0: 4, z1: 7 });
    emit(x, y, { n: 6, cols: ['#F25C54', '#FFFFFF'], sh: 'heart', s0: 20, s1: 90, g: -40, up: 70, d: .97, l0: 1.2, l1: 2, z0: 4, z1: 7 });
    tag(x, y - 36, pick(W2.bump), { font: '800 24px ui-rounded,"SF Pro Rounded",system-ui,sans-serif', fill: '#0C2340', stroke: '#FFFFFF', d: 1.4 });
  };
  CLICK.bell = function (x, y) {
    FX.push({ t: 0, d: 1.8, f: function (c, p) {
      var pop = ease.ob(M.min(1, p / .2)), fa = p < .72 ? 1 : 1 - ease.ss((p - .72) / .28), sw = M.sin(p * 22) * (1 - p) * .55, q, sd, k;
      c.save(); c.globalAlpha = fa; c.translate(x, y - 30); c.scale(pop, pop); c.rotate(sw);
      c.fillStyle = '#E0312F'; c.fillRect(-14, -2, 28, 6); c.fillStyle = '#FFD84A'; c.strokeStyle = '#B8860B'; c.lineWidth = 2; c.beginPath(); c.arc(0, 14, 14, 0, TAU); c.fill(); c.stroke();
      c.beginPath(); c.moveTo(-14, 12); c.lineTo(14, 12); c.stroke(); c.fillStyle = '#7A5A08'; c.beginPath(); c.arc(0, 21, 3, 0, TAU); c.fill();
      c.fillStyle = A('#FFFFFF', .8); c.beginPath(); c.ellipse(-5, 8, 3, 5, -.5, 0, TAU); c.fill(); c.restore();
      if (p > .1) { q = ease.oc((p - .1) / .8); c.lineWidth = 2.4; for (sd = -1; sd <= 1; sd += 2) for (k = 0; k < 2; k++) { c.strokeStyle = A('#FFD84A', (1 - q) * .8 * fa); c.beginPath(); c.arc(x, y - 16, 28 + k * 12 + q * 26, sd > 0 ? -.6 : M.PI - .6, sd > 0 ? .6 : M.PI + .6); c.stroke(); } }
    } });
    emit(x, y - 16, { n: 14, cols: ['#FFD84A', '#FFFFFF', '#0F78C8'], sh: 'star', s0: 30, s1: 160, g: 40, l0: .6, l1: 1.3, z0: 2, z1: 4 });
    tag(x, y - 74, pick(W2.bell), { font: '800 22px ui-rounded,"SF Pro Rounded",system-ui,sans-serif', fill: '#0B5FA3', stroke: '#FFFFFF', d: 1.4 });
  };
  CLICK.katana = function (x, y) {
    var a1 = rr(-.9, -.4), a2 = a1 + rr(1.5, 2.1), L1 = rr(150, 230);
    FX.push({ t: 0, d: .18, f: function (c, p) { glow(c, x, y, 90 * (1 - p), '#C8102E', .5 * (1 - p)); } });
    [[a1, 0], [a2, .08]].forEach(function (s) {
      FX.push({ t: 0, d: .9, f: function (c, p) {
        var q = M.max(0, p - s[1]); if (!q) return; var g = ease.oe(M.min(1, q / .12)), fa = 1 - ease.ss((q - .15) / .6), dx = M.cos(s[0]), dy = M.sin(s[0]);
        c.save(); c.lineCap = 'round'; c.strokeStyle = A('#C8102E', .45 * fa); c.lineWidth = 12 * (1 - q * .7); c.beginPath(); c.moveTo(x - dx * L1 * .5 * g, y - dy * L1 * .5 * g); c.lineTo(x + dx * L1 * .5 * g, y + dy * L1 * .5 * g); c.stroke();
        c.strokeStyle = A('#FFFFFF', .95 * fa); c.lineWidth = 3.4 * (1 - q * .7); c.stroke(); c.restore();
      } });
    });
    emit(x, y, { n: 12, cols: ['#C8102E', '#14090B'], sh: 'dot', s0: 80, s1: 260, g: 500, d: .93, l0: .5, l1: 1, z0: 2, z1: 5 });
    tag(x, y - 20, pick(W2.kat), { font: 'italic 900 28px Impact,"Arial Narrow Bold",system-ui,sans-serif', fill: '#C8102E', stroke: '#FFFFFF', rot: -.08, d: 1 });
  };
  CLICK.chaos = function (x, y) {
    var tn = [], i; for (i = 0; i < 5; i++) tn.push({ a: i * TAU / 5 + rr(-.3, .3), dir: R() < .5 ? 1 : -1, ph: rr(0, TAU), L: rr(90, 150) });
    FX.push({ t: 0, d: 1.3, f: function (c, p) {
      var g = ease.oc(M.min(1, p / .5)), fa = 1 - ease.ss((p - .35) / .65), j, u;
      glow(c, x, y, 120 * (1 - p * .5), E.hi, .4 * fa); c.save(); c.globalCompositeOperation = 'lighter'; c.lineCap = 'round';
      tn.forEach(function (T) {
        c.strokeStyle = A(E.hi, .7 * fa); c.lineWidth = 2.4 * (1 - p * .6); c.beginPath();
        for (j = 0; j <= 28; j++) { u = j / 28 * g; var r = u * T.L, a = T.a + T.dir * u * 2.2 + M.sin(u * 9 + T.ph + p * 8) * .12; (j ? c.lineTo : c.moveTo).call(c, x + M.cos(a) * r, y + M.sin(a) * r); }
        c.stroke();
      }); c.restore();
    } });
    ringFx(x, y, ['#FF2A4A', '#8B1E3F'], { d: 1, r: 150, hex: 1, w: 2.2, gap: .1 });
    emit(x, y, { n: 24, cols: ['#FF2A4A', '#FF6B82', '#FFFFFF'], sh: 'star', s0: 30, s1: 200, g: -20, l0: .7, l1: 1.5, z0: 2, z1: 4 });
  };
  CLICK.classified = function (x, y) {
    var rot = rr(-.16, -.05);
    FX.push({ t: 0, d: 1.7, f: function (c, p) {
      var s = p < .1 ? 1.8 - .8 * ease.oc(p / .1) : 1 + (p < .18 ? .03 * (1 - (p - .1) / .08) : 0), fa = p < .7 ? 1 : 1 - ease.ss((p - .7) / .3), tw = 'CLASSIFIED', bw;
      if (p < .22) glow(c, x, y, 150, '#FFFFFF', .5 * (1 - p / .22));
      c.save(); c.globalAlpha = fa * (p < .06 ? p / .06 : 1); c.translate(x, y); c.rotate(rot); c.scale(s, s);
      c.font = '700 28px "Courier New",Courier,monospace'; c.textAlign = 'center'; c.textBaseline = 'middle'; bw = c.measureText(tw).width + 28;
      c.strokeStyle = '#9E1B20'; c.fillStyle = '#9E1B20'; c.lineWidth = 4; c.strokeRect(-bw / 2, -22, bw, 44); c.lineWidth = 1.4; c.strokeRect(-bw / 2 + 5, -17, bw - 10, 34); c.fillText(tw, 0, 2); c.restore();
    } });
    ringFx(x, y, ['#9E1B20'], { d: .5, r: 110, w: 2 });
    emit(x, y, { n: 14, cols: ['#9E1B20', '#2C3A4C'], sh: 'dot', s0: 60, s1: 240, g: 80, d: .9, l0: .4, l1: .9, z0: 1.5, z1: 4 });
  };
  CLICK.hellchain = function (x, y) {
    var sx = x < E.w / 2 ? -20 : E.w + 20, sy = y - rr(40, 130), cx = (sx + x) / 2, cy = M.min(sy, y) - rr(60, 130);
    function bz(u, a, b, c2) { return (1 - u) * (1 - u) * a + 2 * (1 - u) * u * b + u * u * c2; }
    FX.push({ t: 0, d: 1.2, f: function (c, p) {
      var g = ease.oc(M.min(1, p / .3)), fa = 1 - ease.ss((p - .5) / .5), n = 16, i, u, v, px, py, nx, ny, an, q;
      c.save(); c.globalAlpha = fa; c.lineCap = 'round';
      for (i = 0; i < n * g; i++) {
        u = i / n; v = (i + 1) / n; px = bz(u, sx, cx, x); py = bz(u, sy, cy, y); nx = bz(v, sx, cx, x); ny = bz(v, sy, cy, y); an = M.atan2(ny - py, nx - px);
        c.strokeStyle = '#B9CBD0'; c.lineWidth = 2.4;
        if (i % 2) { c.beginPath(); c.ellipse((px + nx) / 2, (py + ny) / 2, 11, 4.6, an, 0, TAU); c.stroke(); } else { c.lineWidth = 3.4; c.beginPath(); c.moveTo(px, py); c.lineTo(nx, ny); c.stroke(); }
      }
      c.restore(); if (p > .26) { q = (p - .26) / .74; glow(c, x, y, 120 * (1 - q) + 20, '#FF7A12', .55 * (1 - q)); }
    } });
    emit(x, y, { n: 26, cols: ['#FF7A12', '#FFC24A', '#FFE2A8', '#D9141E'], sh: 'flame', s0: 40, s1: 170, dir: -M.PI / 2, spread: 1.1, g: -90, d: .94, l0: .6, l1: 1.3, z0: 4, z1: 9 });
    P.slice(-26).forEach(function (q) { q.r = 0; q.vr = 0; });
    ringFx(x, y, ['#FF7A12'], { d: .7, r: 130, ell: .5, w: 2.4 });
    emit(x, y, { n: 10, cols: ['#FFC24A', '#FFFFFF'], sh: 'spark', s0: 100, s1: 300, g: 260, l0: .3, l1: .7 });
  };
  CLICK.clash = function (x, y) {
    FX.push({ t: 0, d: 1.1, f: function (c, p) {
      var g = ease.oe(M.min(1, p / .14)), fa = 1 - ease.ss((p - .2) / .8), i, a;
      glow(c, x, y, 160 * (1 - p * .4), '#FFD27A', .6 * fa); glow(c, x, y, 60 * (1 - p), '#FFFFFF', .9 * fa);
      c.save(); c.lineCap = 'round';
      for (i = 0; i < 2; i++) { a = (i ? 1 : -1) * .72; c.strokeStyle = A(i ? '#FFF1B8' : '#E8B53C', .95 * fa); c.lineWidth = 6 * (1 - p * .7); c.beginPath(); c.moveTo(x - M.cos(a) * 80 * g, y - M.sin(a) * 80 * g); c.lineTo(x + M.cos(a) * 80 * g, y + M.sin(a) * 80 * g); c.stroke(); }
      c.restore();
    } });
    ringFx(x, y, ['#E8B53C', '#B3121F', '#1D4E9E'], { d: 1, r: 200, w: 3, gap: .1 });
    emit(x, y, { n: 30, cols: ['#E8B53C', '#FFF1B8', '#FFFFFF', '#B3121F'], sh: 'spark', s0: 140, s1: 440, g: 120, l0: .3, l1: .9 });
    emit(x, y, { n: 8, cols: ['#E8B53C', '#FFF1B8'], sh: 'star', s0: 30, s1: 140, g: -20, l0: .8, l1: 1.5, z0: 2, z1: 4 });
    tag(x, y - 46, 'W', { font: '900 46px "Futura","Century Gothic",Georgia,serif', fill: '#E8B53C', stroke: '#7A4E10', d: 1, lw: 5 });
  };


  /* ================= realism layer (every theme) =================
     Film grain + vignette sit in the background plane (never over text), a slow light drift and out-of-focus bokeh give the scene depth,
     hard taps nudge the camera, and two shared tools draw real branching lightning and lit 3-D metal rings. */
  var film = null, vig = null, kx = 0, ky = 0, kvx = 0, kvy = 0, kicking = false, bokeh = [], bokehFor = '';
  var NOBOKEH = { matrix: 1, ironman: 1, agent: 1, ultron: 1, dodge: 1, shinchan: 1, deadpool2: 1 };

  function proMount() {
    if (film || !cvB) return;
    var cv = document.createElement('canvas'), g, id, d, i, v; cv.width = cv.height = 192; g = cv.getContext('2d'); id = g.createImageData(192, 192); d = id.data;
    for (i = 0; i < d.length; i += 4) { v = ((R() + R() + R()) / 3 * 255) | 0; d[i] = d[i + 1] = d[i + 2] = v; d[i + 3] = 255; }
    g.putImageData(id, 0, 0);
    film = document.createElement('div'); film.id = 'vFilm'; film.setAttribute('aria-hidden', 'true'); film.style.backgroundImage = 'url(' + cv.toDataURL('image/png') + ')';
    vig = document.createElement('div'); vig.id = 'vVig'; vig.setAttribute('aria-hidden', 'true');
    document.body.insertBefore(film, cvB.nextSibling); document.body.insertBefore(vig, film.nextSibling);
  }
  function proUnmount() { [film, vig].forEach(function (n) { if (n && n.parentNode) n.parentNode.removeChild(n); }); film = vig = null; bokeh = []; bokehFor = ''; kx = ky = kvx = kvy = 0; }

  function proKick(x, y, m) {                         /* the camera gets shoved away from the impact, then settles on a spring */
    if (!cvB || motion() === 'off') return; var dx = (E.w / 2 - x) / E.w, dy = (E.h / 2 - y) / E.h, n = M.hypot(dx, dy) || 1;
    kvx += dx / n * 70 * m * E.pw; kvy += dy / n * 70 * m * E.pw; kicking = true;
  }
  function proTap(x, y) {                             /* every theme: a flash of light where the finger lands, plus a small camera nudge */
    var col = E.hi;
    FX.push({ t: 0, d: .32, f: function (c, p) { var q = 1 - ease.oc(p); c.save(); if (cur && cur.m === 'dark') c.globalCompositeOperation = 'lighter'; glow(c, x, y, 34 + 70 * p, col, .5 * q); glow(c, x, y, 16 * (1 - p) + 4, '#ffffff', .75 * q * (cur && cur.m === 'dark' ? 1 : .4)); c.restore(); } });
    proKick(x, y, .28);
  }

  function bokehSprite(col) {
    var k = 'b' + col; if (SPR[k]) return SPR[k];
    var cv = document.createElement('canvas'); cv.width = cv.height = 96; var g = cv.getContext('2d'), gr = g.createRadialGradient(48, 48, 0, 48, 48, 46);
    gr.addColorStop(0, A(col, .22)); gr.addColorStop(.7, A(col, .34)); gr.addColorStop(.9, A(col, .75)); gr.addColorStop(1, A(col, 0));      /* lens bokeh: bright rim, hollow middle */
    g.fillStyle = gr; g.beginPath(); g.arc(48, 48, 46, 0, TAU); g.fill(); return (SPR[k] = cv);
  }
  function proAfter(c, t, dt, mo) {
    var dark = cur && cur.m === 'dark', i, b;
    if (kicking) {                                   /* camera spring */
      kvx += (-kx * 90 - kvx * 11) * dt; kvy += (-ky * 90 - kvy * 11) * dt; kx += kvx * dt; ky += kvy * dt;
      if (M.abs(kx) + M.abs(ky) + M.abs(kvx) + M.abs(kvy) < .05) { kicking = false; kx = ky = kvx = kvy = 0; cvB.style.transform = ''; }
      else cvB.style.transform = 'translate3d(' + kx.toFixed(2) + 'px,' + ky.toFixed(2) + 'px,0) scale(1.014)';
    }
    if (mo !== 'full' || E.pw < .9) return;
    c.save(); if (dark) c.globalCompositeOperation = 'lighter';
    glow(c, E.w * (.3 + nz(t * .05, 3) * .25), E.h * (.35 + nz(t * .04, 8) * .2), M.max(E.w, E.h) * .5, E.hi, dark ? .045 : .06);   /* slow drifting light */
    glow(c, E.w * (.78 + nz(t * .045, 12) * .2), E.h * (.7 + nz(t * .05, 4) * .2), M.max(E.w, E.h) * .42, E.b, dark ? .035 : .045);
    if (!NOBOKEH[cur.id] && E.qb >= .7) {
      if (bokehFor !== cur.id) {
        bokehFor = cur.id; bokeh = []; for (i = 0; i < 9; i++) bokeh.push({ x: R(), y: R(), r: rr(18, 60), z: rr(.3, 1), p: rr(0, TAU), v: rr(2, 7), c: i % 3 === 0 ? E.hi : i % 3 === 1 ? E.a : E.b });
      }
      for (i = 0; i < bokeh.length; i++) {
        b = bokeh[i]; b.y -= b.v * b.z * dt / E.h; if (b.y < -.1) { b.y = 1.1; b.x = R(); }
        c.globalAlpha = (dark ? .16 : .1) * (.55 + .45 * M.sin(t * .5 + b.p)) * b.z;
        c.drawImage(bokehSprite(b.c), b.x * E.w - E.px * 26 * b.z, b.y * E.h - E.py * 18 * b.z, b.r * 2 * b.z + 10, b.r * 2 * b.z + 10);
      }
    }
    c.restore();
  }

  /* ---------- lightning that behaves like lightning: midpoint displacement, side branches, a hot core inside a coloured glow ---------- */
  function rng(seed) { var s = (seed >>> 0) || 1; return function () { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; }; }
  function boltPath(x0, y0, x1, y1, rd, amp, it) {
    var pts = [[x0, y0], [x1, y1]], k, j, nx, ny, len, m;
    for (k = 0; k < it; k++) {
      var out = [pts[0]];
      for (j = 1; j < pts.length; j++) {
        var a = pts[j - 1], b = pts[j]; len = M.hypot(b[0] - a[0], b[1] - a[1]) || 1; nx = -(b[1] - a[1]) / len; ny = (b[0] - a[0]) / len; m = (rd() - .5) * 2 * amp;
        out.push([(a[0] + b[0]) / 2 + nx * m, (a[1] + b[1]) / 2 + ny * m], b);
      }
      pts = out; amp *= .52;
    }
    return pts;
  }
  function strokePts(c, pts) { c.beginPath(); for (var i = 0; i < pts.length; i++) i ? c.lineTo(pts[i][0], pts[i][1]) : c.moveTo(pts[i][0], pts[i][1]); c.stroke(); }
  function bolt(c, x0, y0, x1, y1, seed, o) {
    o = o || {}; var rd = rng(seed), len = M.hypot(x1 - x0, y1 - y0), pts = boltPath(x0, y0, x1, y1, rd, o.amp || len * .14, 5), br = o.br === undefined ? 2 : o.br, k, w = o.w || 1, col = o.col || '#FFB347', core = o.core || '#FFFFFF', al = o.a === undefined ? 1 : o.a;
    var list = [[pts, 1]];
    for (k = 0; k < br; k++) {
      var at = 4 + ((rd() * (pts.length - 10)) | 0), p0 = pts[at], p1 = pts[at + 2], an = M.atan2(p1[1] - p0[1], p1[0] - p0[0]) + (rd() < .5 ? -1 : 1) * rr(.4, .8), bl = len * rr(.16, .3);
      list.push([boltPath(p0[0], p0[1], p0[0] + M.cos(an) * bl, p0[1] + M.sin(an) * bl, rd, bl * .16, 4), .55]);
    }
    c.save(); c.lineJoin = c.lineCap = 'round'; c.globalCompositeOperation = 'lighter';
    list.forEach(function (L) { c.strokeStyle = A(col, .16 * al * L[1]); c.lineWidth = 9 * w * L[1]; strokePts(c, L[0]); });
    list.forEach(function (L) { c.strokeStyle = A(col, .75 * al * L[1]); c.lineWidth = 2.6 * w * L[1]; strokePts(c, L[0]); });
    list.forEach(function (L) { c.strokeStyle = A(core, .95 * al * L[1]); c.lineWidth = 1 * w * L[1] + .2; strokePts(c, L[0]); });
    c.restore();
  }

  /* ---------- a lit 3-D metal ring (bracelet): the far half is darker and thinner, the near half carries a conic metal highlight,
     engraved runes that glow and an ember groove. a, b = direction of the ring's axis (b = 0 faces you, b = PI/2 is edge-on). ---------- */
  var METAL = [[0, '#2A1507'], [.1, '#8A5820'], [.19, '#F2CC7C'], [.26, '#FFF3CC'], [.33, '#BE8430'], [.48, '#35200D'], [.62, '#1E0F06'], [.75, '#7C4F1A'], [.84, '#D9A64C'], [.93, '#6B4114'], [1, '#2A1507']];
  function metalGrad(c, x, y) {
    var g, i; if (c.createConicGradient) { g = c.createConicGradient(2.2, x, y); } else { g = c.createLinearGradient(x - 40, y - 40, x + 40, y + 40); }
    for (i = 0; i < METAL.length; i++) g.addColorStop(METAL[i][0], METAL[i][1]); return g;
  }
  function arcPath(c, pts, i0, i1) { c.beginPath(); for (var i = i0; i <= i1; i++) i === i0 ? c.moveTo(pts[i][0], pts[i][1]) : c.lineTo(pts[i][0], pts[i][1]); }
  function drawRing(c, o) {
    var Rr = o.R, ca = M.cos(o.a), sa = M.sin(o.a), cb = M.cos(o.b), sb = M.sin(o.b), D = 1100, n = 24, pts = [], i, th, ct, st, s, dz, tube = o.tube || Rr * .2, al = o.alpha === undefined ? 1 : o.alpha, heat = o.heat || 0, gr;
    if (al <= .01) return;
    for (i = 0; i <= 2 * n; i++) {
      th = i / n * M.PI; ct = M.cos(th); st = M.sin(th); dz = Rr * sb * st; s = D / (D - dz);
      pts.push([o.x + Rr * (-sa * ct - cb * ca * st) * s, o.y + Rr * (ca * ct - cb * sa * st) * s, s]);
    }
    c.save(); c.globalAlpha *= al; c.lineJoin = c.lineCap = 'round';
    c.globalCompositeOperation = 'lighter'; glow(c, o.x, o.y, Rr * 2.1, '#FF9A2E', .1 + .22 * heat); c.globalCompositeOperation = 'source-over';
    gr = metalGrad(c, o.x, o.y);
    c.strokeStyle = 'rgba(8,3,0,.6)'; c.lineWidth = tube * 2.5; arcPath(c, pts, n, 2 * n); c.stroke();                       /* far half: shadow, dimmer metal */
    c.save(); c.globalAlpha *= .55; c.strokeStyle = gr; c.lineWidth = tube * 1.85; arcPath(c, pts, n, 2 * n); c.stroke(); c.restore();
    c.globalCompositeOperation = 'lighter'; c.strokeStyle = A('#FF8A1F', .3 * heat); c.lineWidth = tube * .5; arcPath(c, pts, n, 2 * n); c.stroke(); c.globalCompositeOperation = 'source-over';
    var step = 6, k;
    for (k = 0; k < n; k += step) {                                                                                           /* near half in chunks: nearer pieces are thicker */
      var i1 = M.min(n, k + step), ws = (pts[k][2] + pts[i1][2]) / 2;
      c.strokeStyle = 'rgba(8,3,0,.55)'; c.lineWidth = tube * 2.5 * ws; arcPath(c, pts, k, i1); c.stroke();
      c.strokeStyle = gr; c.lineWidth = tube * 2 * ws; arcPath(c, pts, k, i1); c.stroke();
    }
    c.strokeStyle = 'rgba(255,244,214,.5)'; c.lineWidth = tube * .3; c.setLineDash([]); arcPath(c, pts, 2, n - 2); c.stroke();     /* thin specular along the crown */
    c.globalCompositeOperation = 'lighter';
    c.setLineDash([tube * 1.1, tube * 1.5, tube * .4, tube * 1.5]); c.lineDashOffset = -(o.ph || 0) * tube * 4;                  /* engraved runes, glowing */
    c.strokeStyle = A('#FFA83A', .35 + .55 * heat); c.lineWidth = tube * .62; arcPath(c, pts, 0, n); c.stroke(); c.setLineDash([]);
    c.restore();
  }

  /* ---------- Shang-Chi charge: hold a finger and the ten rings gather around it ---------- */
  function ringCharge(c, g) {
    var held = (performance.now() - g.t0) / 1000; if (held < .14) return; var q = M.min(1, held / .55), i, N = 10, x = g.x, y = g.y, rad = 78 - 34 * ease.oc(q), sp = held * (3 + q * 9);
    c.save(); c.globalCompositeOperation = 'lighter'; glow(c, x, y, 40 + 120 * q, '#FFB02E', .25 + .4 * q); glow(c, x, y, 18 + 24 * q, '#FFFFFF', .3 + .5 * q); c.restore();
    for (i = 0; i < N; i++) {
      var an = i / N * TAU + sp, jx = q >= 1 ? rr(-1.4, 1.4) : 0, jy = q >= 1 ? rr(-1.4, 1.4) : 0;
      drawRing(c, { x: x + M.cos(an) * rad + jx, y: y + M.sin(an) * rad * .55 + jy, R: 15, tube: 3.2, a: an + M.PI / 2, b: .5 + .5 * M.abs(M.sin(sp * .5 + i)), heat: .5 + .5 * q, ph: held * 2 + i, alpha: ease.ss(M.min(1, (held - .14) / .2)) });
    }
    if (R() < .25 + q * .6) { var a1 = (R() * N) | 0, a2 = (a1 + 1 + ((R() * 4) | 0)) % N, p1 = a1 / N * TAU + sp, p2 = a2 / N * TAU + sp; bolt(c, x + M.cos(p1) * rad, y + M.sin(p1) * rad * .55, x + M.cos(p2) * rad, y + M.sin(p2) * rad * .55, (R() * 1e6) | 0, { w: .8, br: 1 }); }
    c.strokeStyle = A(q >= 1 ? '#FFFFFF' : '#FFC947', .85); c.lineWidth = 2; c.beginPath(); c.arc(x, y, 22 + (q >= 1 ? 3 * M.sin(held * 30) : 0), -M.PI / 2, -M.PI / 2 + TAU * q); c.stroke();
  }


  /* ================= Shang-Chi (rebuilt) =================
     Scene: a golden-hour Ta Lo with karst peaks and rolling mist, bamboo swaying in the foreground, and the Ten Rings as ten lit metal bracelets
     travelling a tilted orbit (they morph between a tunnel and the emblem), shedding embers and throwing lightning between each other.
     Tap: the rings are thrown out from the touch point, curve back and orbit it before collapsing. Hold: they gather around your finger, release = full blast. */
  function peaks(w, n, seed, hmin, hmax) {
    var r = rng(seed), p = [], i; for (i = 0; i < n; i++) p.push({ x: (i + r() * .8) / n * w * 1.25 - w * .1, w: rr(28, 70) * (w / 1000 + .5), h: hmin + r() * (hmax - hmin) });
    return p;
  }
  function ridge(w, pk, base) {
    var ys = [], x, i, y, d, hh; for (x = -30; x <= w + 30; x += 6) {
      hh = 0; for (i = 0; i < pk.length; i++) { d = M.abs((x - pk[i].x) / pk[i].w); hh = M.max(hh, pk[i].h * M.exp(-M.pow(d, 1.55))); }
      y = base - hh - 5 * M.sin(x * .021) - 3 * M.sin(x * .053); ys.push(y);
    } return ys;
  }
  function fillRidge(c, ys, w, h, top, c0, c1, ox) {
    var g = c.createLinearGradient(0, top, 0, h); g.addColorStop(0, c0); g.addColorStop(1, c1); c.fillStyle = g; c.beginPath(); c.moveTo(-30 + ox, h + 4);
    for (var i = 0; i < ys.length; i++) c.lineTo(-30 + i * 6 + ox, ys[i]); c.lineTo(w + 30 + ox, h + 4); c.closePath(); c.fill();
  }
  function bambooStalk(c, x, hgt, wd, sway, col, t, k) {
    var ytop = -10, hb = c.canvas ? 0 : 0, h = hgt, n = 14, i, nx = function (u) { return x + sway * u * u; };
    c.strokeStyle = col; c.lineCap = 'round'; c.lineWidth = wd; c.beginPath(); c.moveTo(x, h);
    for (i = 1; i <= n; i++) { var u = i / n; c.lineTo(nx(u), h - u * (h + 10)); } c.stroke();
    c.lineWidth = wd * 1.55; for (i = 1; i < 8; i++) { var u2 = i / 8 - .03, yy = h - u2 * (h + 10), xx = nx(u2); c.beginPath(); c.moveTo(xx - wd * .3, yy); c.lineTo(xx + wd * .3, yy); c.stroke(); }
    c.fillStyle = col; for (i = 0; i < 5; i++) {                       /* leaves hang from the upper nodes */
      var u3 = .55 + i * .09, lx = nx(u3), ly = h - u3 * (h + 10), dir = i % 2 ? 1 : -1, ang = dir * (.5 + .15 * M.sin(t * 1.3 + k + i)) + M.sin(t * .9 + k) * .12;
      c.save(); c.translate(lx, ly); c.rotate(ang + (dir > 0 ? 0 : M.PI)); c.beginPath(); c.moveTo(0, 0); c.quadraticCurveTo(wd * 3, -wd * 2.2, wd * 9, wd * 1.2); c.quadraticCurveTo(wd * 3, wd * .8, 0, 0); c.fill(); c.restore();
    }
  }

  SC.shangchi = function (E) {
    var w = E.w, h = E.h, small = w < 700, i, L = [], bam = [], sparks = [], arcs = [], lastTap = 0, boost = 0, spin = 0, cx = 0, cy = 0, arcT = 0, mist = [], sunX = w * (small ? .72 : .27), sunY = h * .64,
        em = dust(E, (30 * E.q) | 0, '#FFB347', { a: .65, vy: -18, r0: .6, r1: 2, vx0: -4, vx1: 10 });
    L.push({ ys: ridge(w, peaks(w, 7, 11, h * .1, h * .3), h * .8), top: h * .5, c0: 'rgba(214,112,48,.34)', c1: 'rgba(120,52,22,.04)', par: 8 });
    L.push({ ys: ridge(w, peaks(w, 6, 29, h * .08, h * .24), h * .87), top: h * .62, c0: 'rgba(132,60,26,.55)', c1: 'rgba(60,26,12,.2)', par: 16 });
    L.push({ ys: ridge(w, peaks(w, 5, 47, h * .05, h * .15), h * .95), top: h * .78, c0: 'rgba(44,20,10,.85)', c1: 'rgba(14,7,3,.95)', par: 28 });
    for (i = 0; i < 5; i++) mist.push({ x: rr(0, w), y: h * rr(.66, .93), s: rr(160, 320), v: rr(4, 11), a: rr(.07, .12) });
    [[.012, .78, 11], [.04, .66, 8], [.08, .58, 6], [.935, .62, 7], [.965, .76, 10], [.99, .6, 8], [.14, .4, 4], [.86, .42, 4]].forEach(function (b, k) { bam.push({ x: b[0] * w, h: h * (.6 + b[1] * .45), w: b[2] * (small ? .7 : 1), k: k, far: b[2] < 5 }); });
    var N = 10;
    return function (t, dt) {
      var c = E.c, k, ox;
      if (E.tapT > lastTap) { lastTap = E.tapT; boost = M.min(1.4, boost + 1); }
      boost = damp(boost, 0, 1.7, dt); spin += (boost * 5) * dt;
      /* sky: a low sun behind the far peaks and a few slow god-rays */
      c.save(); c.globalCompositeOperation = 'lighter';
      glow(c, sunX - E.px * 6, sunY, h * .7, '#FF7A22', .2); glow(c, sunX - E.px * 6, sunY, h * .24, '#FFC470', .26);
      for (k = 0; k < 5; k++) { var an = -M.PI / 2 + (k - 2) * .27 + M.sin(t * .1 + k) * .05, g = c.createLinearGradient(sunX, sunY, sunX + M.cos(an) * h, sunY + M.sin(an) * h); g.addColorStop(0, A('#FFB65A', .07)); g.addColorStop(1, A('#FFB65A', 0)); c.fillStyle = g; c.beginPath(); c.moveTo(sunX, sunY); c.lineTo(sunX + M.cos(an - .045) * h, sunY + M.sin(an - .045) * h); c.lineTo(sunX + M.cos(an + .045) * h, sunY + M.sin(an + .045) * h); c.closePath(); c.fill(); }
      c.restore();
      var sg = c.createRadialGradient(sunX, sunY, 0, sunX, sunY, h * .055); sg.addColorStop(0, 'rgba(255,238,200,.85)'); sg.addColorStop(1, 'rgba(255,170,70,.5)'); c.fillStyle = sg; c.beginPath(); c.arc(sunX - E.px * 6, sunY, h * .055, 0, TAU); c.fill();
      /* peaks and mist, nearer layers move more with the pointer */
      for (k = 0; k < 3; k++) {
        ox = -E.px * L[k].par; fillRidge(c, L[k].ys, w, h, L[k].top, L[k].c0, L[k].c1, ox);
        if (k < 2) for (var m = 0; m < mist.length; m++) { var f = mist[m]; if ((m + k) % 2) continue; f.x += f.v * dt * (1 + k * .5); if (f.x > w + f.s * 1.6) f.x = -f.s * 1.6; cloud(c, f.x + ox, f.y - k * h * .05, f.s, '#F4B67C', f.a); }
      }
      /* the rings */
      var S = M.min(w, h) * (small ? .2 : .235), hx = w * (small ? .5 : .47), hy = h * (small ? .31 : .37), tx = hx + (E.mx >= 0 ? (E.mx - hx) * .07 : 0), ty = hy + (E.my >= 0 ? (E.my - hy) * .07 : 0) + M.sin(t * .8) * 6;
      cx = cx ? damp(cx, tx, 2.4, dt) : tx; cy = cy ? damp(cy, ty, 2.4, dt) : ty;
      var ps = .55 * M.sin(t * .21) + E.px * .55, lm = .95 + .25 * M.sin(t * .17 + 1) + E.py * .3, ph0 = t * .3 + spin, cp = M.cos(ps), sp2 = M.sin(ps), cl = M.cos(lm), sl = M.sin(lm), Ro = S * .92 * (1 + boost * .22), rr0 = S * .2, morph = .5 + .5 * M.sin(t * .23);
      function rot(v) { var y = v[1] * cl - v[2] * sl, z = v[1] * sl + v[2] * cl, x = v[0]; return [x * cp + z * sp2, y, -x * sp2 + z * cp]; }
      var e1 = rot([1, 0, 0]), e2 = rot([0, 1, 0]), nF = rot([0, 0, 1]), rings = [];
      for (i = 0; i < N; i++) {
        var phi = i / N * TAU + ph0, cph = M.cos(phi), sph = M.sin(phi), P = [Ro * (cph * e1[0] + sph * e2[0]), Ro * (cph * e1[1] + sph * e2[1]), Ro * (cph * e1[2] + sph * e2[2])];
        var T = [-sph * e1[0] + cph * e2[0], -sph * e1[1] + cph * e2[1], -sph * e1[2] + cph * e2[2]], mi = M.max(0, M.min(1, morph + .18 * M.sin(t * .9 + i * 1.3))), nv = [T[0] * (1 - mi) + nF[0] * mi, T[1] * (1 - mi) + nF[1] * mi, T[2] * (1 - mi) + nF[2] * mi], nl = M.hypot(nv[0], nv[1], nv[2]) || 1;
        nv = [nv[0] / nl, nv[1] / nl, nv[2] / nl]; if (nv[2] < 0) nv = [-nv[0], -nv[1], -nv[2]];
        var sc = 1100 / (1100 - P[2]);
        rings.push({ i: i, z: P[2], x: cx + P[0] * sc, y: cy + P[1] * sc, R: rr0 * sc, a: M.atan2(nv[1], nv[0]), b: M.acos(M.min(1, nv[2])), heat: .42 + .2 * M.sin(t * 2.3 + i * 1.7) + boost * .45, s: sc });
      }
      var ord = rings.slice().sort(function (p, q) { return p.z - q.z; });
      c.save(); c.globalCompositeOperation = 'lighter'; glow(c, cx, cy, Ro * 1.6, '#E2461C', .09 + .06 * boost); glow(c, cx, cy, Ro * .8, '#FFB347', .06); c.restore();
      for (k = 0; k < N; k++) { var q = ord[k]; drawRing(c, { x: q.x, y: q.y, R: q.R, tube: q.R * .17, a: q.a, b: q.b, heat: q.heat, ph: t * .8 + q.i, alpha: (.62 + .3 * ease.ss((q.z + Ro) / (2 * Ro))) }); }
      /* lightning between rings, a few at a time, each living ~0.1 s */
      arcT -= dt; if (arcT <= 0) { arcT = .07 + R() * .1; arcs = []; var na = (R() < .55 ? 1 : 0) + (boost > .25 ? 2 : 0) + (R() < .2 ? 1 : 0); for (k = 0; k < na; k++) { var a1 = (R() * N) | 0; arcs.push({ a: a1, b: (a1 + 1 + ((R() * 3) | 0)) % N, s: (R() * 1e6) | 0 }); } }
      arcs.forEach(function (ar) { bolt(c, rings[ar.a].x, rings[ar.a].y, rings[ar.b].x, rings[ar.b].y, ar.s, { w: .7 + boost * .5, a: .55 + boost * .3, br: 1 }); });
      /* sparks shed by the rings */
      if (sparks.length < 70 && R() < dt * (9 + boost * 40)) { var r0 = rings[(R() * N) | 0], an2 = rr(0, TAU), sv = rr(25, 90) * (1 + boost); sparks.push({ x: r0.x + M.cos(an2) * r0.R, y: r0.y + M.sin(an2) * r0.R * .6, vx: M.cos(an2) * sv, vy: M.sin(an2) * sv - 20, l: 1, L: rr(.6, 1.3) }); }
      c.save(); c.globalCompositeOperation = 'lighter'; c.lineCap = 'round';
      for (k = sparks.length - 1; k >= 0; k--) { var s = sparks[k]; s.l -= dt / s.L; if (s.l <= 0) { sparks.splice(k, 1); continue; } s.vy += 60 * dt; s.vx *= 1 - dt * .8; s.x += s.vx * dt; s.y += s.vy * dt; c.strokeStyle = A('#FFC060', .85 * s.l); c.lineWidth = 1.2; c.beginPath(); c.moveTo(s.x, s.y); c.lineTo(s.x - s.vx * .05, s.y - s.vy * .05); c.stroke(); }
      c.restore();
      em(c, t, dt);
      /* bamboo in front, swaying with the shared wind */
      for (k = 0; k < bam.length; k++) { var b = bam[k], sw = (wnd(t * 1.3 + b.k) * 12 + M.sin(t * .8 + b.k * 2) * 4) * (b.h / h); bambooStalk(c, b.x - E.px * (b.far ? 10 : 22), b.h, b.w, sw, b.far ? 'rgba(30,14,6,.55)' : 'rgba(6,3,1,.9)', t, b.k); }
    };
  };

  /* ---------- tap: ten rings thrown from the touch point, curving back to orbit it, then collapsing into embers ---------- */
  function ringBlast(x, y, m) {
    var N = 10, rs = [], i, Dm = (E.w < 700 ? 118 : 172) * (m > 1 ? 1.4 : 1) * (.85 + .15 * E.pw), rot0 = rr(0, TAU), T = m > 1 ? 2.2 : 1.85, did = 0, did2 = 0;
    for (i = 0; i < N; i++) rs.push({ a: rot0 + i / N * TAU, tb: rr(0, TAU), tw: rr(2.5, 5.5) });
    FX.push({ t: 0, d: T, f: function (c, p) {
      var t = p * T, d1 = ease.oc(M.min(1, t / .4)), d2 = ease.io(M.min(1, M.max(0, (t - .4) / .62))), d4 = ease.io(M.min(1, M.max(0, (t - 1.45) / (T - 1.45)))), dist = Dm * d1 * (1 - .8 * d2) * (1 - d4),
          ang = t < .4 ? t * 2.4 : .96 + (t - .4) * (5 + 6 * d2), sc = 1 - .45 * d4, fade = 1 - ease.ss(M.max(0, (t - (T - .3)) / .3)), k, g, q;
      if (!did) { did = 1; emit(x, y, { n: 36, cols: ['#FFC947', '#FFE08A', '#FFFFFF', '#E2461C'], sh: 'spark', s0: 160, s1: 560, g: 150, l0: .35, l1: 1 }); proKick(x, y, m > 1 ? 1.4 : .8); }
      if (t > 1.45 && !did2) { did2 = 1; emit(x, y, { n: 22, cols: ['#FFC947', '#FFE08A', '#E2461C'], sh: 'spark', s0: 60, s1: 260, g: 90, l0: .5, l1: 1.2 }); }
      c.save(); c.globalCompositeOperation = 'lighter';
      if (t < .5) { q = t / .5; glow(c, x, y, 70 + 200 * q, '#FFFFFF', .9 * (1 - q) * (1 - q)); glow(c, x, y, 120 + 260 * q, '#FF8A1F', .5 * (1 - q)); }
      for (k = 0; k < 2; k++) {                                              /* lit shock rims */
        q = (t - k * .09) / .62; if (q > 0 && q < 1) { var rad = 30 + (Dm * 2.1) * ease.oc(q), al = M.pow(1 - q, 1.5); c.strokeStyle = A('#FF9A2E', al * .2); c.lineWidth = 16 * (1 - q) + 2; c.beginPath(); c.arc(x, y, rad, 0, TAU); c.stroke(); c.strokeStyle = A('#FFF1C4', al * .9); c.lineWidth = 2.4 * (1 - q) + .6; c.stroke(); }
      }
      if (t < .4) { for (k = 0; k < 12; k++) { var ra = rot0 + k / 12 * TAU + .13, gl = c.createLinearGradient(x, y, x + M.cos(ra) * Dm * 1.7, y + M.sin(ra) * Dm * 1.7); gl.addColorStop(0, A('#FFE9B0', .5 * (1 - t / .4))); gl.addColorStop(1, A('#FFB347', 0)); c.strokeStyle = gl; c.lineWidth = 1.4; c.beginPath(); c.moveTo(x, y); c.lineTo(x + M.cos(ra) * Dm * 1.7, y + M.sin(ra) * Dm * 1.7); c.stroke(); } }
      c.restore();
      if (t < .32) for (k = 0; k < N; k++) bolt(c, x, y, x + M.cos(rs[k].a + ang) * dist, y + M.sin(rs[k].a + ang) * dist * .82, ((k * 7919 + (t * 22 | 0) * 104729) | 0), { w: .8, a: 1 - t / .32, br: 1 });
      else if (t > .5 && t < 1.5 && ((t * 15) | 0) % 2 === 0) { var rg = rng(((t * 15) | 0) * 31 + 7); for (k = 0; k < 3; k++) { var j = (rg() * N) | 0, j2 = (j + 1) % N; bolt(c, x + M.cos(rs[j].a + ang) * dist, y + M.sin(rs[j].a + ang) * dist * .82, x + M.cos(rs[j2].a + ang) * dist, y + M.sin(rs[j2].a + ang) * dist * .82, (rg() * 1e6) | 0, { w: .7, a: .8, br: 0 }); } }
      for (k = 0; k < N; k++) {
        var r = rs[k], aa = r.a + ang, px = x + M.cos(aa) * dist, py = y + M.sin(aa) * dist * .82;
        if (t < .7) { c.save(); c.globalCompositeOperation = 'lighter'; for (g = 1; g <= 4; g++) { var ga = aa - g * .075, gd = dist * (1 - g * .02); glow(c, x + M.cos(ga) * gd, y + M.sin(ga) * gd * .82, 20 - g * 2.5, '#FFA83A', .3 * (1 - g / 5) * (1 - t / .7)); } c.restore(); }
        drawRing(c, { x: px, y: py, R: 24 * sc * (.9 + .1 * M.sin(aa)), tube: 4.6 * sc, a: aa + M.PI / 2, b: .2 + 1.15 * M.abs(M.sin(t * r.tw + r.tb)), heat: .9, ph: t * 3 + k, alpha: fade * ease.ss(M.min(1, t / .06)) });
      }
    } });
  }
  CLICK.tenrings = function (x, y) { ringBlast(x, y, 1); };


  /* ================= Moon Knight (rebuilt) =================
     Scene: a night over the Giza plateau. A cratered moon that slowly waxes and wanes through its crescent, a real starfield with a rare shooting star,
     three lit dune ridges and pyramids, wind-blown sand and loose linen bandages drifting in the gust.
     Tap: a silver crescent dart spins in on a curve, bites into the page with a flash of moonlight, sand and sparks, wobbles, then turns to dust. */
  function moonSprite() {
    var D = 256, cv = document.createElement('canvas'), g, r = rng(77), i; cv.width = cv.height = D; g = cv.getContext('2d');
    var b = g.createRadialGradient(D * .45, D * .42, 0, D / 2, D / 2, D / 2); b.addColorStop(0, '#FBF8EE'); b.addColorStop(.7, '#E4DFD0'); b.addColorStop(1, '#B9B3A2'); g.fillStyle = b; g.beginPath(); g.arc(D / 2, D / 2, D / 2 - 1, 0, TAU); g.fill();
    g.save(); g.beginPath(); g.arc(D / 2, D / 2, D / 2 - 1, 0, TAU); g.clip();
    [[.36, .36, .2], [.6, .3, .15], [.5, .62, .24], [.28, .62, .12], [.72, .6, .13]].forEach(function (m) { var gr = g.createRadialGradient(m[0] * D, m[1] * D, 0, m[0] * D, m[1] * D, m[2] * D); gr.addColorStop(0, 'rgba(112,108,98,.34)'); gr.addColorStop(1, 'rgba(112,108,98,0)'); g.fillStyle = gr; g.fillRect(0, 0, D, D); });
    for (i = 0; i < 90; i++) {                                                       /* craters: a dark lower rim, a bright upper rim */
      var cx = r() * D, cy = r() * D, cr = 2 + r() * r() * r() * 22; g.fillStyle = 'rgba(90,86,78,.13)'; g.beginPath(); g.arc(cx, cy, cr, 0, TAU); g.fill();
      g.strokeStyle = 'rgba(255,255,248,.3)'; g.lineWidth = .9; g.beginPath(); g.arc(cx + .5, cy + .5, cr, M.PI * 1.05, M.PI * 1.85); g.stroke();
      g.strokeStyle = 'rgba(60,56,50,.18)'; g.beginPath(); g.arc(cx, cy, cr, M.PI * .1, M.PI * .85); g.stroke();
    }
    var lb = g.createRadialGradient(D / 2, D / 2, D * .36, D / 2, D / 2, D / 2); lb.addColorStop(0, 'rgba(40,40,50,0)'); lb.addColorStop(1, 'rgba(40,40,50,.38)'); g.fillStyle = lb; g.fillRect(0, 0, D, D); g.restore();   /* limb darkening */
    return cv;
  }
  function crescentPath(c, r) {
    var d = r * .5, rb = r * .82, x0 = (d * d + r * r - rb * rb) / (2 * d), y0 = M.sqrt(M.max(0, r * r - x0 * x0)), a0 = M.atan2(y0, x0);
    c.beginPath(); c.arc(0, 0, r, a0, TAU - a0, false); c.arc(d, 0, rb, M.atan2(-y0, x0 - d), M.atan2(y0, x0 - d), true); c.closePath();
  }
  function crescent(c, x, y, r, rot, al) {
    c.save(); c.translate(x, y); c.rotate(rot); c.globalAlpha *= al === undefined ? 1 : al;
    crescentPath(c, r); c.fillStyle = 'rgba(0,0,0,.35)'; c.save(); c.translate(1.6, 2.2); c.fill(); c.restore();
    var g = c.createLinearGradient(-r, -r, r * .6, r); g.addColorStop(0, '#FFFFFF'); g.addColorStop(.35, '#AEB4C4'); g.addColorStop(.55, '#6E7486'); g.addColorStop(.8, '#DDE2EE'); g.addColorStop(1, '#F8FAFF');
    crescentPath(c, r); c.fillStyle = g; c.fill(); c.strokeStyle = 'rgba(255,255,255,.95)'; c.lineWidth = 1.1; c.stroke();
    c.save(); crescentPath(c, r); c.clip(); c.strokeStyle = 'rgba(40,46,64,.45)'; c.lineWidth = r * .1; c.beginPath(); c.arc(r * .5, 0, r * .72, M.PI * .55, M.PI * 1.45); c.stroke(); c.restore();      /* bevel on the inner edge */
    c.restore();
  }

  SC.moonknight = function (E) {
    var w = E.w, h = E.h, small = w < 700, i, stars = [], layers = [], sand = [], bands = [], shoot = null, nextShoot = rr(6, 12), base = moonSprite(), mcv = document.createElement('canvas'), tmp = document.createElement('canvas'), lastPh = -9,
        mx = w * (small ? .72 : .3), my = h * (small ? .17 : .25), mr = M.min(w, h) * (small ? .085 : .1);
    mcv.width = mcv.height = tmp.width = tmp.height = 256;
    for (i = 0; i < 170 * E.qb; i++) stars.push({ x: R(), y: R() * .75, r: rr(.4, 1.5), z: rr(.2, 1), p: rr(0, TAU), tw: rr(.6, 2.4), c: pick(['#FFFFFF', '#DDE6FF', '#FFF1D6', '#CFE0FF']) });
    var horizon = h * .86;
    [[.80, 46, .0024, '#2A2A38', '#15151D', 10], [.87, 64, .0017, '#1D1D28', '#101016', 20], [.95, 46, .0029, '#111117', '#07070A', 34]].forEach(function (d, k) {
      var ys = [], x, ph = rr(0, 9), y; for (x = -30; x <= w + 30; x += 6) { var s = .5 + .5 * M.sin(x * d[2] + ph) + .18 * M.sin(x * d[2] * 2.1 + ph * 1.7); y = h * d[0] - d[1] * M.pow(M.max(0, s / 1.18), 2.1) + 1.2 * M.sin(x * .05 + k); ys.push(y); }
      layers.push({ ys: ys, c0: d[3], c1: d[4], par: d[5], top: h * d[0] - d[1] });
    });
    for (i = 0; i < 70 * E.qb; i++) sand.push({ x: rr(0, w), y: h * rr(.76, .99), v: rr(120, 340), l: rr(10, 46), a: rr(.05, .17) });
    for (i = 0; i < 2; i++) bands.push({ y: h * (.3 + i * .22), a: rr(26, 44), f: rr(.5, .8), ph: rr(0, TAU), wd: rr(8, 15), o: rr(.07, .11) });
    var pyr = [[.4, .17, .8], [.53, .105, .62], [.25, .07, .5]];
    function refresh(ph) {
      var g = mcv.getContext('2d'), t2 = tmp.getContext('2d'), D = 256, off = ph * D;
      g.clearRect(0, 0, D, D); g.globalAlpha = .1; g.drawImage(base, 0, 0); g.globalAlpha = 1;           /* earthshine on the dark part */
      t2.clearRect(0, 0, D, D); t2.globalCompositeOperation = 'source-over'; t2.drawImage(base, 0, 0); t2.globalCompositeOperation = 'destination-out';
      var cx = D / 2 + off * .9, cy = D / 2 - off * .3, sg = t2.createRadialGradient(cx, cy, D * .47, cx, cy, D * .53); sg.addColorStop(0, 'rgba(0,0,0,1)'); sg.addColorStop(1, 'rgba(0,0,0,0)'); t2.fillStyle = sg; t2.fillRect(0, 0, D, D);
      g.drawImage(tmp, 0, 0);
    }
    return function (t, dt) {
      var c = E.c, k, ph = .42 + .22 * M.sin(t * .04 + .6), gust = 1 + .9 * M.max(0, wnd(t * 1.4));
      /* stars */
      for (k = 0; k < stars.length; k++) { var s = stars[k], a = (.3 + .7 * (.5 + .5 * M.sin(t * s.tw + s.p))) * s.z; c.fillStyle = A(s.c, a * .9); c.fillRect(s.x * w - E.px * 14 * s.z, s.y * h - E.py * 8 * s.z, s.r * (.7 + s.z * .5), s.r * (.7 + s.z * .5)); }
      nextShoot -= dt; if (nextShoot <= 0 && !shoot) { shoot = { x: rr(.1, .9) * w, y: rr(.04, .3) * h, vx: rr(500, 760) * (R() < .5 ? -1 : 1), vy: rr(160, 300), l: 1 }; nextShoot = rr(9, 18); }
      if (shoot) { shoot.l -= dt * 1.7; shoot.x += shoot.vx * dt; shoot.y += shoot.vy * dt; if (shoot.l <= 0) shoot = null; else { var sg = c.createLinearGradient(shoot.x, shoot.y, shoot.x - shoot.vx * .14, shoot.y - shoot.vy * .14); sg.addColorStop(0, A('#FFFFFF', .9 * shoot.l)); sg.addColorStop(1, A('#BFD0FF', 0)); c.strokeStyle = sg; c.lineWidth = 1.4; c.beginPath(); c.moveTo(shoot.x, shoot.y); c.lineTo(shoot.x - shoot.vx * .14, shoot.y - shoot.vy * .14); c.stroke(); } }
      /* the moon */
      var px = mx - E.px * 16, py = my - E.py * 10 + M.sin(t * .3) * 2;
      c.save(); c.globalCompositeOperation = 'lighter'; glow(c, px, py, mr * 5.2, '#B8C8FF', .15); glow(c, px, py, mr * 2.4, '#E9E4D2', .2); c.strokeStyle = A('#DCE6FF', .05); c.lineWidth = mr * .5; c.beginPath(); c.arc(px, py, mr * 2.7, 0, TAU); c.stroke(); c.restore();
      if (M.abs(ph - lastPh) > .008) { lastPh = ph; refresh(ph); }
      c.drawImage(mcv, px - mr, py - mr, mr * 2, mr * 2);
      /* horizon: pyramids sit behind the middle dunes and take the moon on their lit face */
      var ox0 = -E.px * layers[0].par;
      fillDune(c, layers[0], w, h, ox0);
      pyr.forEach(function (p, n) {
        var bx = p[0] * w + ox0 * .8, bw = h * p[1] * 1.7, bh = h * p[1], by = layers[0].ys[M.min(layers[0].ys.length - 1, M.max(0, ((p[0] * w + 30) / 6) | 0))] + 6;
        var lg = c.createLinearGradient(bx - bw / 2, by, bx, by - bh); lg.addColorStop(0, 'rgba(70,74,96,' + (.55 * p[2]) + ')'); lg.addColorStop(1, 'rgba(150,156,184,' + (.4 * p[2]) + ')');
        c.fillStyle = lg; c.beginPath(); c.moveTo(bx - bw / 2, by); c.lineTo(bx - bw * .02, by - bh); c.lineTo(bx - bw * .02 + bw * .06, by); c.closePath(); c.fill();
        c.fillStyle = 'rgba(16,16,24,' + (.82 * p[2] + .1) + ')'; c.beginPath(); c.moveTo(bx - bw * .02, by - bh); c.lineTo(bx + bw / 2, by); c.lineTo(bx - bw * .02 + bw * .06, by); c.closePath(); c.fill();
      });
      var ox1 = -E.px * layers[1].par; fillDune(c, layers[1], w, h, ox1);
      /* ground fog */
      for (k = 0; k < 4; k++) cloud(c, ((t * (6 + k * 3) + k * w * .3) % (w * 1.6)) - w * .3, h * (.82 + k * .035), 280 + k * 40, '#AEB6D0', .05);
      /* linen bandages drifting in the gust */
      bands.forEach(function (b, n) {
        var N = 40, i2, top = [], bot = [], x2, cy, wd; for (i2 = 0; i2 <= N; i2++) { x2 = i2 / N * (w + 80) - 40; cy = b.y + M.sin(x2 * .006 + t * b.f * gust + b.ph) * b.a + M.sin(x2 * .017 + t * b.f * 1.6 + b.ph * 2) * b.a * .3 - E.py * 10; wd = b.wd * (.55 + .45 * M.sin(x2 * .008 + t * .4 + n)); top.push([x2, cy - wd]); bot.push([x2, cy + wd]); }
        var lg2 = c.createLinearGradient(0, 0, w, 0); lg2.addColorStop(0, A('#E9E4D2', 0)); lg2.addColorStop(.25, A('#E9E4D2', b.o)); lg2.addColorStop(.75, A('#E9E4D2', b.o)); lg2.addColorStop(1, A('#E9E4D2', 0));
        c.fillStyle = lg2; c.beginPath(); top.forEach(function (p, j) { j ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1]); }); for (i2 = N; i2 >= 0; i2--) c.lineTo(bot[i2][0], bot[i2][1]); c.closePath(); c.fill();
        c.strokeStyle = A('#F1EFE8', b.o * 1.4); c.lineWidth = .8; c.beginPath(); top.forEach(function (p, j) { j ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1]); }); c.stroke();
        c.strokeStyle = A('#F1EFE8', b.o * .7); c.lineWidth = .6; c.beginPath(); for (i2 = 0; i2 <= N; i2 += 2) { c.moveTo(top[i2][0], top[i2][1]); c.lineTo(bot[i2][0] + 6, bot[i2][1]); } c.stroke();     /* wrap lines */
      });
      var ox2 = -E.px * layers[2].par; fillDune(c, layers[2], w, h, ox2);
      /* wind-blown sand along the ground */
      c.lineCap = 'round'; for (k = 0; k < sand.length; k++) { var q = sand[k]; q.x += q.v * gust * dt; q.y += M.sin(t * 2 + k) * 8 * dt; if (q.x > w + 60) { q.x = -60; q.y = h * rr(.76, .99); } c.strokeStyle = A('#D8CFB5', q.a * (q.y / h)); c.lineWidth = 1; c.beginPath(); c.moveTo(q.x, q.y); c.lineTo(q.x - q.l * gust, q.y - 1); c.stroke(); }
    };
  };
  function fillDune(c, L, w, h, ox) {
    var g = c.createLinearGradient(0, L.top, 0, h); g.addColorStop(0, L.c0); g.addColorStop(1, L.c1); c.fillStyle = g; c.beginPath(); c.moveTo(-30 + ox, h + 4);
    for (var i = 0; i < L.ys.length; i++) c.lineTo(-30 + i * 6 + ox, L.ys[i]); c.lineTo(w + 30 + ox, h + 4); c.closePath(); c.fill();
    c.strokeStyle = 'rgba(200,205,225,.16)'; c.lineWidth = 1; c.beginPath(); for (i = 0; i < L.ys.length; i++) i ? c.lineTo(-30 + i * 6 + ox, L.ys[i]) : c.moveTo(-30 + ox, L.ys[0]); c.stroke();      /* moonlit crest */
  }

  /* ---------- tap: a crescent dart ---------- */
  CLICK.crescent = function (x, y) {
    var sx = x < E.w / 2 ? -50 : E.w + 50, sy = M.max(-30, y - rr(120, 260)), cx = (sx + x) / 2, cy = M.min(sy, y) - rr(90, 170), rot0 = rr(0, TAU), land = rr(-.7, .7), did = 0, did2 = 0, FL = .27, r = E.w < 700 ? 17 : 22;
    function bz(u, a, b, c2) { return (1 - u) * (1 - u) * a + 2 * (1 - u) * u * b + u * u * c2; }
    FX.push({ t: 0, d: 2.2, f: function (c, p) {
      var t = p * 2.2, u, k, g, q;
      if (t < FL) {
        u = M.pow(t / FL, 1.7); c.save(); c.globalCompositeOperation = 'lighter';
        for (g = 6; g >= 1; g--) { var uu = M.max(0, u - g * .04); glow(c, bz(uu, sx, cx, x), bz(uu, sy, cy, y), 20, '#DCE6FF', .22 * (1 - g / 7)); } c.restore();
        for (g = 4; g >= 1; g--) { var u3 = M.max(0, u - g * .03); crescent(c, bz(u3, sx, cx, x), bz(u3, sy, cy, y), r, rot0 + u3 * TAU * 3.8, .16 * (1 - g / 5)); }
        crescent(c, bz(u, sx, cx, x), bz(u, sy, cy, y), r, rot0 + u * TAU * 3.8, 1);
        return;
      }
      if (!did) {
        did = 1; proKick(x, y, .95);
        emit(x, y, { n: 26, cols: ['#CDBF9A', '#E5DABB', '#9C8F70'], sh: 'ash', s0: 50, s1: 240, dir: -M.PI / 2, spread: 1.3, g: 260, d: .94, l0: .5, l1: 1.2, z0: 1.5, z1: 4 });
        emit(x, y, { n: 20, cols: ['#FFFFFF', '#DCE6FF', '#E9E4D2'], sh: 'spark', s0: 150, s1: 460, g: 220, l0: .3, l1: .8 });
        ringFx(x, y, ['#E9E4D2', '#C9B26B', '#8C93A0'], { d: 1, r: 150, w: 2, gap: .1 });
      }
      k = t - FL;
      c.save(); c.globalCompositeOperation = 'lighter';
      if (k < .5) { q = k / .5; glow(c, x, y, 160 * (1 - q) + 30, '#DCE6FF', .75 * (1 - q) * (1 - q)); glow(c, x, y, 50, '#FFFFFF', .8 * (1 - q) * (1 - q));
        for (g = 0; g < 2; g++) { c.strokeStyle = A('#E9E4D2', .7 * (1 - q)); c.lineWidth = 2.2 * (1 - q) + .5; c.beginPath(); c.arc(x, y, 34 + 70 * ease.oc(q), g * M.PI + q * 2.4, g * M.PI + q * 2.4 + M.PI * .55); c.stroke(); } }      /* two arcs of a crescent halo */
      c.restore();
      var wob = .26 * M.exp(-k * 5.5) * M.sin(k * 36), fa = 1 - ease.ss((t - 1.55) / .5);
      if (t > 1.55 && !did2) { did2 = 1; emit(x, y, { n: 18, cols: ['#DCE6FF', '#FFFFFF', '#AEB4C4'], sh: 'dot', s0: 20, s1: 90, g: -10, up: 40, d: .96, l0: .8, l1: 1.6, z0: 1, z1: 2.4 }); }
      if (fa <= 0) return;
      crescent(c, x, y, r, land + wob, fa);
      var sw = ((k - .15) / .45); if (sw > 0 && sw < 1) { c.save(); c.globalCompositeOperation = 'lighter'; glow(c, x + (sw - .5) * r * 1.6, y - r * .3 + (sw - .5) * r, r * .9, '#FFFFFF', .7 * M.sin(sw * M.PI)); c.restore(); }      /* one glint travels along the blade */
    } });
  };


  /* ================= apply, picker, transitions, reveal ================= */
  function sysMode() { var s = get('abagus-theme'); if (s === 'light' || s === 'dark') return s; return window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'; }
  function paintMeta() { var m = document.querySelector('meta[name="theme-color"]'); if (!m) return; var c = getComputedStyle(root).getPropertyValue('--paper').trim(); if (c) m.setAttribute('content', c); }
  function el(tag, cls, text) { var n = document.createElement(tag); if (cls) n.className = cls; if (text) n.textContent = text; return n; }
  var toastT, toastEl;
  function toast(msg) {
    if (!toastEl) { toastEl = el('div', 'v-toast'); toastEl.setAttribute('role', 'status'); toastEl.setAttribute('aria-live', 'polite'); document.body.appendChild(toastEl); }
    toastEl.textContent = msg; toastEl.classList.add('on'); clearTimeout(toastT); toastT = setTimeout(function () { toastEl.classList.remove('on'); }, 2600);
  }

  function setMotionClass() { root.setAttribute('data-vmotion', S.id ? motion() : 'off'); root.classList.toggle('v-art-off', !S.art); root.setAttribute('data-vpower', S.power); root.setAttribute('data-vextras', S.extras ? 'on' : 'off'); }
  /* a theme change spreads out from where you tapped (View Transitions API); other browsers just switch */
  var vtBusy = false;
  function apply(id, quiet, pt) {
    if (!quiet && !vtBusy && document.startViewTransition && motion() !== 'off' && !mqReduce.matches && pw() > .5) {
      var o = pt || (btn ? (function (r) { return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; })(btn.getBoundingClientRect()) : { x: innerWidth / 2, y: 0 });
      vtBusy = true;
      try {
        var vt = document.startViewTransition(function () { doApply(id, quiet); });
        var done = function () { vtBusy = false; };
        vt.finished.then(done, done);
        vt.ready.then(function () {
          var rad = M.hypot(M.max(o.x, innerWidth - o.x), M.max(o.y, innerHeight - o.y));
          root.animate({ clipPath: ['circle(0px at ' + o.x + 'px ' + o.y + 'px)', 'circle(' + rad + 'px at ' + o.x + 'px ' + o.y + 'px)'] }, { duration: 650 / (pw() > 1 ? 1.1 : 1), easing: 'cubic-bezier(.2,.7,.2,1)', pseudoElement: '::view-transition-new(root)' });
        }, done);
        return;
      } catch (e) { vtBusy = false; }
    }
    doApply(id, quiet);
  }
  function doApply(id, quiet) {
    var t = BY[id] || null; S.id = t ? t.id : '';
    if (S.id) put('abagus-vibe', S.id); else drop('abagus-vibe');
    root.classList.add('theming'); setTimeout(function () { root.classList.remove('theming'); }, 600);
    if (t) {
      root.setAttribute('data-vibe', t.id); root.setAttribute('data-theme', t.m);
      root.style.setProperty('--v-art', t.art ? 'url("themes/art/' + t.id + '.webp")' : 'none'); root.style.setProperty('--v-art-op', String(t.op || 0));
    } else {
      root.removeAttribute('data-vibe'); root.style.removeProperty('--v-art'); root.style.removeProperty('--v-art-op'); root.setAttribute('data-theme', sysMode());
    }
    setMotionClass(); engine(); paintMeta(); reveal(); paintPanel();
    if (!quiet) toast(t ? t.n + ' theme on · ' + t.tag : 'Default look restored');
  }

  /* picker ------------------------------------------------ */
  var panel, btn, grid, filt = 'All', paintPanel = function () {};
  var FILTERS = ['All', 'Marvel', 'DC', 'Movies', 'Cosy', 'Cars', 'Light', 'Dark'];
  function matches(t) { return filt === 'All' || t.g === filt || (filt === 'Light' && t.m === 'light') || (filt === 'Dark' && t.m === 'dark'); }
  function sw(label, cur, opts, pick2) {
    var wrap = el('div', 'vp-set'); wrap.appendChild(el('p', 'vp-h', label)); var seg = el('div', 'vp-seg'); seg.setAttribute('role', 'radiogroup'); seg.setAttribute('aria-label', label);
    opts.forEach(function (o) { var b = el('button', '', o[1]); b.type = 'button'; b.setAttribute('role', 'radio'); b.setAttribute('data-v', o[0]); seg.appendChild(b); });
    seg.addEventListener('click', function (e) { var b = e.target.closest('[role="radio"]'); if (b) { pick2(b.getAttribute('data-v')); paintPanel(); } });
    wrap.appendChild(seg); wrap.paint = function () { var c = cur(); [].forEach.call(seg.children, function (b) { b.setAttribute('aria-checked', b.getAttribute('data-v') === c ? 'true' : 'false'); }); }; return wrap;
  }
  function step(d, e) { var i = S.id ? CAT.indexOf(BY[S.id]) : (d > 0 ? -1 : 0); apply(CAT[(i + d + CAT.length) % CAT.length].id, false, e && e.clientX ? { x: e.clientX, y: e.clientY } : null); }
  function build_panel() {
    panel = el('div', ''); panel.id = 'vPanel'; panel.setAttribute('role', 'dialog'); panel.setAttribute('aria-label', 'Themes'); panel.hidden = true;
    var head = el('div', 'vp-head'); head.appendChild(el('strong', '', 'Themes')); head.appendChild(el('span', 'vp-count', CAT.length + ' looks'));
    var rnd = el('button', 'vp-mini', 'Surprise me'); rnd.type = 'button'; rnd.addEventListener('click', function (e) { var o = CAT.filter(function (t) { return t.id !== S.id; }); apply(pick(o).id, false, { x: e.clientX, y: e.clientY }); });
    var pv = el('button', 'vp-mini', '‹'); pv.type = 'button'; pv.setAttribute('aria-label', 'Previous theme'); pv.addEventListener('click', function (e) { step(-1, e); });
    var x = el('button', 'vp-x', '×'); x.type = 'button'; x.setAttribute('aria-label', 'Close themes'); x.addEventListener('click', function () { closeP(true); });
    var nx = el('button', 'vp-mini', 'Next ›'); nx.type = 'button'; nx.addEventListener('click', function (e) { step(1, e); });
    head.appendChild(pv); head.appendChild(nx); head.appendChild(rnd); head.appendChild(x); panel.appendChild(head);
    var chips = el('div', 'vp-chips'); chips.setAttribute('role', 'group'); chips.setAttribute('aria-label', 'Filter');
    FILTERS.forEach(function (f) { var b = el('button', 'vp-chip', f); b.type = 'button'; b.setAttribute('aria-pressed', f === filt ? 'true' : 'false'); b.addEventListener('click', function () { filt = f; [].forEach.call(chips.children, function (c2) { c2.setAttribute('aria-pressed', c2.textContent === f ? 'true' : 'false'); }); fill(); }); chips.appendChild(b); });
    panel.appendChild(chips); grid = el('div', 'vp-grid'); panel.appendChild(grid);
    var set = el('div', 'vp-sets');
    var s1 = sw('Motion', function () { return S.motion || 'auto'; }, [['auto', 'Auto'], ['full', 'Full'], ['calm', 'Calm'], ['off', 'Off']], function (v) { S.motion = v === 'auto' ? '' : v; if (S.motion) put('abagus-vibe-motion', S.motion); else drop('abagus-vibe-motion'); setMotionClass(); engine(); });
    var s2 = sw('Artwork', function () { return S.art ? 'on' : 'off'; }, [['on', 'Show'], ['off', 'Hide']], function (v) { S.art = v === 'on'; put('abagus-vibe-art', S.art ? '1' : '0'); setMotionClass(); });
    var s3 = sw('Tap effects', function () { return S.fx ? 'on' : 'off'; }, [['on', 'On'], ['off', 'Off']], function (v) { S.fx = v === 'on'; put('abagus-vibe-fx', S.fx ? '1' : '0'); });
    var s4 = sw('Power', function () { return S.power; }, [['soft', 'Soft'], ['normal', 'Normal'], ['max', 'Max']], function (v) { S.power = v; put('abagus-vibe-power', v); setMotionClass(); if (cur) { build(); if (motion() === 'off') still(); } toast(v === 'max' ? 'Max power: bigger effects, glow and tap combos' : v === 'soft' ? 'Soft power: gentle and light on the battery' : 'Normal power'); });
    var s5 = sw('Extras', function () { return S.extras ? 'on' : 'off'; }, [['on', 'On'], ['off', 'Off']], function (v) { S.extras = v === 'on'; put('abagus-vibe-extras', S.extras ? '1' : '0'); setMotionClass(); });
    set.appendChild(s4); set.appendChild(s1); set.appendChild(s2); set.appendChild(s3); set.appendChild(s5); panel.appendChild(set);
    panel.appendChild(el('p', 'vp-note', 'A theme sets colours, background animation, tap effects and page transitions on every page. Power sets how loud it is. Extras = card tilt, pointer spotlight, progress line and tap combos. Keys: T opens this, arrows move, Enter picks. Saved on this device only.'));
    document.body.appendChild(panel);
    paintPanel = function () { s1.paint(); s2.paint(); s3.paint(); s4.paint(); s5.paint(); [].forEach.call(grid.querySelectorAll('.vp-card'), function (b) { var on = b.getAttribute('data-id') === S.id; b.setAttribute('aria-pressed', on ? 'true' : 'false'); }); [].forEach.call(document.querySelectorAll('.v-btn'), function (b) { b.classList.toggle('on', !!S.id); }); };
    fill(); paintPanel();
  }
  function card(t) {
    var b = el('button', 'vp-card'); b.type = 'button'; b.setAttribute('data-id', t ? t.id : ''); b.setAttribute('data-pv', t ? t.id : 'none');
    var th = el('span', 'vp-thumb'); if (t && t.art) th.style.backgroundImage = 'url("themes/thumb/' + t.id + '.webp")'; th.appendChild(el('i')); b.appendChild(th);
    b.appendChild(el('span', 'vp-name', t ? t.n : 'Default')); b.appendChild(el('span', 'vp-from', t ? t.from + ' · ' + (t.m === 'light' ? 'Light' : 'Dark') : 'Abagus original'));
    b.addEventListener('click', function (e) { apply(t ? t.id : '', false, e.clientX ? { x: e.clientX, y: e.clientY } : null); }); return b;
  }
  function fill() { grid.textContent = ''; if (filt === 'All') grid.appendChild(card(null)); CAT.forEach(function (t) { if (matches(t)) grid.appendChild(card(t)); }); paintPanel(); }
  function openP() { put('abagus-vibe-seen', '1'); [].forEach.call(document.querySelectorAll('.v-btn,.dock-theme'), function (b) { b.classList.remove('v-new'); }); if (!panel) build_panel(); panel.hidden = false; btn.setAttribute('aria-expanded', 'true'); dockSync(true); paintPanel(); var c = panel.querySelector('[aria-pressed="true"].vp-card') || panel.querySelector('.vp-card'); if (c) c.focus({ preventScroll: true }); }
  function closeP(ref) { if (!panel || panel.hidden) return; panel.hidden = true; btn.setAttribute('aria-expanded', 'false'); dockSync(false); if (ref) btn.focus(); }
  function dockSync(on) { var d = document.querySelector('.dock-theme'); if (d) d.setAttribute('aria-expanded', on ? 'true' : 'false'); }
  function mountDockBtn(tog) {                       /* the Themes button joins the five bottom-dock buttons */
    function add() {
      var inner = document.querySelector('.dock .dock-inner'); if (!inner) return false;
      if (inner.querySelector('.dock-theme')) return true;
      var b = el('button', 'dock-theme'); b.type = 'button'; b.id = 'dockTheme'; b.setAttribute('aria-haspopup', 'dialog'); b.setAttribute('aria-expanded', 'false'); b.setAttribute('aria-label', 'Themes: characters and films');
      b.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3l1.9 4.6L18.5 9l-4.6 1.9L12 15.5l-1.9-4.6L5.5 9l4.6-1.4z"/><path d="M18.5 15.5l.8 1.9 1.9.8-1.9.8-.8 1.9-.8-1.9-1.9-.8 1.9-.8z"/></svg><span>Theme</span>';
      if (!get('abagus-vibe-seen')) b.classList.add('v-new');
      b.addEventListener('click', function (e) { e.stopPropagation(); tog(); });
      inner.appendChild(b); inner.classList.add('has-theme'); return true;
    }
    if (add() || !('MutationObserver' in window)) return;
    var mo = new MutationObserver(function () { if (add()) mo.disconnect(); }); mo.observe(document.body, { childList: true, subtree: true });
    setTimeout(function () { mo.disconnect(); }, 15000);
  }
  function mountButton() {
    if (document.getElementById('vBtn')) return;
    btn = el('button', 'icon-btn v-btn'); btn.type = 'button'; btn.id = 'vBtn'; btn.setAttribute('aria-haspopup', 'dialog'); btn.setAttribute('aria-expanded', 'false'); btn.setAttribute('aria-label', 'Themes: characters and films'); btn.title = 'Themes';
    btn.innerHTML = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3l1.9 4.6L18.5 9l-4.6 1.9L12 15.5l-1.9-4.6L5.5 9l4.6-1.4z"/><path d="M18.5 15.5l.8 1.9 1.9.8-1.9.8-.8 1.9-.8-1.9-1.9-.8 1.9-.8z"/></svg><span class="v-lbl">Themes</span>';
    if (!get('abagus-vibe-seen')) btn.classList.add('v-new');
    var host = document.querySelector('.nav-actions') || document.querySelector('.gp-bar-r') || document.querySelector('.me-bar-r');
    var tog = function () { if (!panel || panel.hidden) openP(); else closeP(false); };
    if (host) {
      host.insertBefore(btn, host.firstChild);
      if (host.classList.contains('nav-actions')) {            /* phones: the nav row is full, so the button floats above the tab bar */
        var f2 = btn.cloneNode(true); f2.id = 'vBtn2'; f2.classList.add('v-fab2'); f2.addEventListener('click', tog); document.body.appendChild(f2);
      }
    } else { btn.classList.add('v-fab'); document.body.appendChild(btn); }
    btn.addEventListener('click', tog); mountDockBtn(tog);
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { closeP(true); return; }
      var ae = document.activeElement, typing = ae && (/^(INPUT|TEXTAREA|SELECT)$/.test(ae.tagName) || ae.isContentEditable);
      if ((e.key === 't' || e.key === 'T') && !typing && !e.ctrlKey && !e.metaKey && !e.altKey) { e.preventDefault(); tog(); return; }
      if (panel && !panel.hidden && ae && ae.classList && ae.classList.contains('vp-card') && /^Arrow/.test(e.key)) {
        var cards = [].slice.call(grid.querySelectorAll('.vp-card')), i = cards.indexOf(ae), cols = 3, j = e.key === 'ArrowRight' ? i + 1 : e.key === 'ArrowLeft' ? i - 1 : e.key === 'ArrowDown' ? i + cols : i - cols;
        if (j >= 0 && j < cards.length) { e.preventDefault(); cards[j].focus(); }
      }
    });
    document.addEventListener('pointerdown', function (e) { if (panel && !panel.hidden && !panel.contains(e.target) && !btn.contains(e.target)) closeP(false); });
    btn.classList.toggle('on', !!S.id);
  }

  /* a theme keeps its own light/dark: if another control flips it, put it back and say why */
  new MutationObserver(function () {
    if (!S.id) return; var want = BY[S.id].m; if (root.getAttribute('data-theme') !== want) { root.setAttribute('data-theme', want); toast(BY[S.id].n + ' is a ' + want + ' theme. Pick Default in Themes to switch modes.'); }
    paintMeta();
  }).observe(root, { attributes: true, attributeFilter: ['data-theme'] });

  /* page transitions ---------------------------------------- */
  var wipe;
  function wipeEl() { if (!wipe) { wipe = el('div', 'v-wipe'); wipe.setAttribute('aria-hidden', 'true'); document.body.appendChild(wipe); } return wipe; }
  function wipeType() { return cur ? cur.wipe : 'fade'; }
  function runWipe(dir, done) {
    var w = wipeEl(); w.setAttribute('data-w', wipeType()); w.className = 'v-wipe ' + dir; w.style.display = 'block';
    var fin = function () { w.removeEventListener('animationend', fin); if (dir === 'out') w.style.display = 'none'; if (done) done(); };
    w.addEventListener('animationend', fin);
    setTimeout(function () { if (dir === 'out') w.style.display = 'none'; }, 900);
  }
  document.addEventListener('click', function (e) {
    if (!cur || motion() === 'off' || e.defaultPrevented || e.button || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    var a = e.target.closest && e.target.closest('a[href]'); if (!a || a.target || a.hasAttribute('download')) return;
    var u; try { u = new URL(a.href, location.href); } catch (er) { return; }
    if (u.origin !== location.origin && u.protocol !== 'file:') return; if (u.pathname === location.pathname && u.search === location.search) return;
    if (!/\.html?$|\/$/.test(u.pathname)) return;
    e.preventDefault(); try { sessionStorage.setItem('abagus-vibe-wipe', '1'); } catch (er2) { /* ignore */ }
    runWipe('in', function () { location.href = a.href; }); setTimeout(function () { location.href = a.href; }, 700);
  });
  addEventListener('pageshow', function (e) { if (e.persisted && wipe) wipe.style.display = 'none'; });

  /* staged reveal of cards as they scroll in ----------------- */
  var SEL = '.tcard,.tile,.spec,.welcome-card,.security-center,.ready,.faq details,.grp-card,.gd-card,.gp-card,.section-head,.opt';
  var io, scanT;
  function reveal() {
    if (io) { io.disconnect(); io = null; }
    [].forEach.call(document.querySelectorAll('.v-pre'), function (n) { n.classList.remove('v-pre'); });
    if (!S.id || motion() === 'off' || !('IntersectionObserver' in window)) return;
    io = new IntersectionObserver(function (es) { var k = 0; es.forEach(function (en) { if (!en.isIntersecting) return; var n = en.target, dl = M.min(k++, 6) * 70; io.unobserve(n); n.classList.remove('v-pre'); n.style.animationDelay = dl + 'ms'; n.classList.add('v-in'); setTimeout(function () { n.classList.remove('v-in'); n.style.animationDelay = ''; }, 1100 + dl); }); }, { threshold: .06 });
    [].forEach.call(document.querySelectorAll(SEL), function (n) { if (n.__vSeen) return; n.__vSeen = 1; var r = n.getBoundingClientRect(); if (r.top > innerHeight * .96) { n.classList.add('v-pre'); io.observe(n); } });
  }
  if ('MutationObserver' in window) new MutationObserver(function () { if (S.id) { clearTimeout(scanT); scanT = setTimeout(reveal, 300); } }).observe(document.documentElement, { childList: true, subtree: true });
  try { mqReduce.addEventListener('change', function () { setMotionClass(); engine(); reveal(); }); } catch (e) { /* old Safari */ }

  /* card tilt + light glare under a mouse (never on touch, never in Calm/Off) */
  var TILT = '.tcard,.tile,.grp-card,.gd-card,.gp-card', tEl = null, tRaf = 0, tEv = null, tS = null, tLoop = 0;
  /* the tilt is a damped spring toward the pointer, and a damped return to flat when it leaves, so it never snaps */
  function tiltLoop(ts) {
    tLoop = 0; if (!tS) return; var dt = M.min(.05, (ts - (tS.t || ts)) / 1000 || .016); tS.t = ts;
    var k = tS.leave ? 9 : 16; tS.rx = damp(tS.rx, tS.trx, k, dt); tS.ry = damp(tS.ry, tS.try_, k, dt); tS.gx = damp(tS.gx, tS.tgx, k, dt); tS.gy = damp(tS.gy, tS.tgy, k, dt);
    var n = tS.el; n.style.setProperty('--rx', tS.rx.toFixed(2) + 'deg'); n.style.setProperty('--ry', tS.ry.toFixed(2) + 'deg'); n.style.setProperty('--gx', tS.gx.toFixed(1) + '%'); n.style.setProperty('--gy', tS.gy.toFixed(1) + '%');
    if (tS.leave && M.abs(tS.rx) < .08 && M.abs(tS.ry) < .08) { n.classList.remove('v-tilt'); ['--rx', '--ry', '--gx', '--gy'].forEach(function (q) { n.style.removeProperty(q); }); tS = null; return; }
    tLoop = requestAnimationFrame(tiltLoop);
  }
  function tiltOff() { tEl = null; if (tS) { tS.leave = true; tS.trx = 0; tS.try_ = 0; if (!tLoop) tLoop = requestAnimationFrame(tiltLoop); } }
  function tiltDo() {
    tRaf = 0; var e = tEv; if (!e || !cur || !S.extras || motion() !== 'full') { tiltOff(); return; }
    var c = e.target && e.target.closest ? e.target.closest(TILT) : null;
    if (c !== tEl) tiltOff();
    if (!c || e.target.closest('input,textarea,select,[contenteditable]')) return;
    var r = c.getBoundingClientRect(); if (r.width > 560 || r.height > 460 || r.width < 90) { tiltOff(); return; }
    var x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height, a = 7 * M.min(pw(), 1.4);
    if (tS && tS.el !== c) { tS.el.classList.remove('v-tilt'); ['--rx', '--ry', '--gx', '--gy'].forEach(function (q) { tS.el.style.removeProperty(q); }); tS = null; }
    if (!tS) tS = { el: c, rx: 0, ry: 0, gx: x * 100, gy: y * 100, t: 0 };
    tS.leave = false; tEl = c; c.classList.add('v-tilt'); tS.trx = (.5 - y) * a; tS.try_ = (x - .5) * a; tS.tgx = x * 100; tS.tgy = y * 100;
    if (!tLoop) tLoop = requestAnimationFrame(tiltLoop);
  }
  document.addEventListener('pointermove', function (e) { if (e.pointerType !== 'mouse' || !cur) return; tEv = e; if (!tRaf) tRaf = requestAnimationFrame(tiltDo); }, { passive: true });
  document.addEventListener('pointerout', function (e) { if (tEl && !(e.relatedTarget && tEl.contains(e.relatedTarget))) tiltOff(); }, { passive: true });
  addEventListener('blur', tiltOff);

  /* start */
  function start() {
    mountButton(); root.setAttribute('data-vibe-ready', '1');
    if (S.id) { apply(S.id, true); try { if (sessionStorage.getItem('abagus-vibe-wipe')) { sessionStorage.removeItem('abagus-vibe-wipe'); if (motion() !== 'off') { var w = wipeEl(); w.setAttribute('data-w', wipeType()); w.className = 'v-wipe out'; w.style.display = 'block'; runWipe('out'); } } } catch (e) { /* ignore */ } }
    else { setMotionClass(); if (!get('abagus-vibe-seen')) setTimeout(function () { toast('New: ' + CAT.length + ' character themes. Tap the Themes button.'); }, 1800); }
  }
  window.AbagusThemes = { list: CAT, set: function (id) { apply(id); }, current: function () { return S.id; }, next: function () { step(1); }, prev: function () { step(-1); }, power: function (v) { if (POWER[v]) { S.power = v; put('abagus-vibe-power', v); setMotionClass(); if (cur) build(); paintPanel(); } return S.power; } };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
