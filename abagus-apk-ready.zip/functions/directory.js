/**
 * Abagus — public group directory (server-side mirror)
 * ----------------------------------------------------
 * SECURITY CONTRACT — do not weaken this:
 *   - publicGroups/<gid> is written ONLY here (Admin SDK). The Firestore rules refuse every client write.
 *   - A summary exists ONLY while the group's owner/admin has set groups/<gid>.discoverable === true.
 *   - It carries exactly these approved fields: name, publicDesc, memberCount, mediaCount, createdAt, v.
 *   - NEVER copied: descEnc, avatar, settings, invite codes, member ids or names, file names, keys, storage references.
 *   - Counts come from the real members/ and files/ collections, so a client cannot inflate its own rank.
 */
const { onDocumentWritten } = require('firebase-functions/v2/firestore');
const { initializeApp, getApps } = require('firebase-admin/app');
const { getFirestore } = require('firebase-admin/firestore');
if (!getApps().length) initializeApp();
const db = getFirestore();

const clip = (s, n) => (typeof s === 'string' ? s.replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, n) : '');

async function countOf(q) {
  const snap = await q.count().get();
  return snap.data().count || 0;
}

async function refresh(gid) {
  const gref = db.doc(`groups/${gid}`), pref = db.doc(`publicGroups/${gid}`);
  const g = await gref.get();
  if (!g.exists || g.get('discoverable') !== true) { await pref.delete().catch(() => {}); return; }
  const [memberCount, mediaCount] = await Promise.all([
    countOf(gref.collection('members')),
    countOf(gref.collection('files')),
  ]);
  await pref.set({
    name: clip(g.get('name'), 40),
    publicDesc: clip(g.get('publicDesc'), 140),
    memberCount, mediaCount,
    createdAt: typeof g.get('createdAt') === 'string' ? g.get('createdAt') : new Date().toISOString(),
    v: 1,
  });
}

exports.directoryOnGroup = onDocumentWritten('groups/{gid}', (e) => refresh(e.params.gid));
exports.directoryOnMember = onDocumentWritten('groups/{gid}/members/{uid}', (e) => refresh(e.params.gid));
exports.directoryOnFile = onDocumentWritten('groups/{gid}/files/{fid}', (e) => refresh(e.params.gid));
