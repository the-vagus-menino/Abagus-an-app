/**
 * Owner-only endpoints backing the dashboard's "Owner panel".
 *
 * SECURITY CONTRACT — do not weaken this:
 *   - Every export below independently verifies the caller's Firebase ID token and checks
 *     decoded.email === OWNER_EMAIL && decoded.email_verified, server-side, before doing
 *     anything. The dashboard hiding the UI from non-owners is a convenience, NOT the access
 *     control — these checks are.
 *   - ownerApproveChange is the only code path in this whole project that merges a PR (i.e.
 *     the only path that lets a Gemini-authored change reach production). It must stay gated
 *     behind requireOwner().
 *   - trackEvent is intentionally the one PUBLIC endpoint here (anyone can call it) — it only
 *     increments anonymous counters and must never accept or return anything else.
 */

const { onRequest } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");
const { initializeApp, getApps } = require("firebase-admin/app");
const { getAuth } = require("firebase-admin/auth");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");
const github = require("./lib/github");

const GITHUB_TOKEN = defineSecret("GITHUB_TOKEN");
const OWNER_EMAIL = "partha9178712507@gmail.com";

const ALLOWED_ORIGINS = [
  "http://localhost:5000",
  "http://localhost:8080",
  "https://abagus.netlify.app",
];

if (!getApps().length) initializeApp();

/** Throws if the request isn't a verified, authenticated request from OWNER_EMAIL. */
async function requireOwner(req) {
  const authHeader = req.headers.authorization || "";
  const match = authHeader.match(/^Bearer (.+)$/);
  if (!match) throw { status: 401, message: "Missing Authorization header." };
  let decoded;
  try {
    decoded = await getAuth().verifyIdToken(match[1]);
  } catch (e) {
    throw { status: 401, message: "Invalid or expired token." };
  }
  if (decoded.email !== OWNER_EMAIL || !decoded.email_verified) {
    throw { status: 403, message: "Not authorized." };
  }
  return decoded;
}

function handle(fn, extraOptions) {
  return onRequest({ cors: ALLOWED_ORIGINS, ...extraOptions }, async (req, res) => {
    try {
      const result = await fn(req, res);
      if (result !== undefined) res.status(200).json(result);
    } catch (e) {
      const status = e && e.status ? e.status : 500;
      res.status(status).json({ error: (e && e.message) || "Internal error" });
    }
  });
}

exports.ownerListChanges = handle(async (req) => {
  await requireOwner(req);
  const snap = await getFirestore().collection("geminiChanges").where("status", "==", "pending").orderBy("createdAt", "desc").limit(20).get();
  return { changes: snap.docs.map((d) => d.data()) };
});

exports.ownerApproveChange = handle(async (req) => {
  await requireOwner(req);
  const prNumber = Number(req.body && req.body.prNumber);
  if (!prNumber) throw { status: 400, message: "Missing prNumber." };
  await github.mergePR(GITHUB_TOKEN.value(), prNumber);
  await getFirestore().collection("geminiChanges").doc(String(prNumber)).set(
    { status: "merged", mergedAt: FieldValue.serverTimestamp() },
    { merge: true }
  );
  return { merged: true };
}, { secrets: [GITHUB_TOKEN] });

exports.ownerRejectChange = handle(async (req) => {
  await requireOwner(req);
  const prNumber = Number(req.body && req.body.prNumber);
  if (!prNumber) throw { status: 400, message: "Missing prNumber." };
  await github.closePR(GITHUB_TOKEN.value(), prNumber);
  await getFirestore().collection("geminiChanges").doc(String(prNumber)).set(
    { status: "rejected", rejectedAt: FieldValue.serverTimestamp() },
    { merge: true }
  );
  return { rejected: true };
}, { secrets: [GITHUB_TOKEN] });

exports.ownerStats = handle(async (req) => {
  await requireOwner(req);
  const doc = await getFirestore().collection("stats").doc("summary").get();
  const d = doc.exists ? doc.data() : {};
  return {
    pageViews: d.pageViews || 0,
    encryptCount: d.encryptCount || 0,
    decryptCount: d.decryptCount || 0,
    lastRunAt: d.lastRunAt ? d.lastRunAt.toDate().toISOString() : null,
  };
});

// Public, intentionally: increments one named counter. No auth, no PII, nothing else accepted.
const COUNTER_FIELDS = ["pageViews", "encryptCount", "decryptCount"];
exports.trackEvent = handle(async (req) => {
  const field = req.body && req.body.field;
  if (!COUNTER_FIELDS.includes(field)) throw { status: 400, message: "Unknown field." };
  await getFirestore().collection("stats").doc("summary").set(
    { [field]: FieldValue.increment(1) },
    { merge: true }
  );
  return { ok: true };
});
