/**
 * Abagus — Gemini "experience" proxy
 * -----------------------------------
 * Deployed as a Firebase Cloud Function. Holds the Gemini API key server-side
 * (as a Secret Manager secret — never in source, never shipped to the browser).
 *
 * SECURITY CONTRACT — do not weaken this:
 *   - Accepts only: { mode: 'encrypt' | 'decrypt' | 'idle', fileType: string }
 *   - fileType is truncated to a bare extension (e.g. "pdf"), nothing else.
 *   - NEVER accept or forward: passphrases, keyfiles, file contents, full
 *     filenames, checksums, or anything derived from the user's secret.
 *   - This endpoint is purely cosmetic (a tagline + accent color for the
 *     padlock UI). If it fails or times out, the caller falls back to a
 *     static value and encryption/decryption proceeds unaffected.
 */

const { onRequest } = require('firebase-functions/v2/https');
const { defineSecret } = require('firebase-functions/params');

// Daily Gemini -> PR pipeline and the owner-only approve/reject/stats endpoints.
// See dailyImprovement.js and owner.js for their own security-contract comments.
exports.dailyImprovement = require('./dailyImprovement').dailyImprovement;
const ownerFns = require('./owner');
exports.ownerListChanges = ownerFns.ownerListChanges;
exports.ownerApproveChange = ownerFns.ownerApproveChange;
exports.ownerRejectChange = ownerFns.ownerRejectChange;
exports.ownerStats = ownerFns.ownerStats;
exports.trackEvent = ownerFns.trackEvent;

// Public group directory: server-side mirror of opted-in groups (see directory.js).
const dirFns = require('./directory');
exports.directoryOnGroup = dirFns.directoryOnGroup;
exports.directoryOnMember = dirFns.directoryOnMember;
exports.directoryOnFile = dirFns.directoryOnFile;

const GEMINI_API_KEY = defineSecret('GEMINI_API_KEY');
const COVER_TOPICS = require('./covertopics.json');

// Set this to your real deployed frontend origin(s) once you know them,
// e.g. 'https://abagus.pages.dev' or 'https://your-site.web.app'.
const ALLOWED_ORIGINS = [
  'http://localhost:5000',
  'http://localhost:8080',
  'https://abagus.netlify.app',
];

const FALLBACKS = {
  encrypt: { tagline: 'Sealed and layered.', accent: '#22d3ee' },
  decrypt: { tagline: 'Unlocked safely.', accent: '#34d399' },
  idle:    { tagline: 'Ready when you are.', accent: '#a78bfa' },
};

function pickFallback(mode) {
  return FALLBACKS[mode] || FALLBACKS.idle;
}

function isHexColor(s) {
  return typeof s === 'string' && /^#[0-9a-fA-F]{6}$/.test(s);
}

exports.geminiExperience = onRequest(
  { secrets: [GEMINI_API_KEY], cors: ALLOWED_ORIGINS, timeoutSeconds: 8 },
  async (req, res) => {
    if (req.method !== 'POST') {
      res.status(405).json({ error: 'Method not allowed' });
      return;
    }

    const body = req.body || {};
    const mode = ['encrypt', 'decrypt', 'idle'].includes(body.mode) ? body.mode : 'idle';

    // Hard cap: only a short alphanumeric extension is ever accepted.
    const rawType = typeof body.fileType === 'string' ? body.fileType : '';
    const fileType = rawType.replace(/[^a-zA-Z0-9]/g, '').slice(0, 12) || 'file';

    const prompt = [
      'You generate a one-line UI flourish for a client-side file-encryption web app.',
      `Context: user just finished a "${mode}" operation on a ${fileType} file.`,
      'No file names, no personal data, no security claims, nothing alarming.',
      'Reply with STRICT JSON only, no markdown, no commentary, in this exact shape:',
      '{"tagline": "3-6 words, calm and confident", "accent": "#RRGGBB"}',
    ].join(' ');

    try {
      const apiRes = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${GEMINI_API_KEY.value()}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [{ parts: [{ text: prompt }] }],
            generationConfig: { maxOutputTokens: 60, temperature: 0.9 },
          }),
        }
      );

      if (!apiRes.ok) throw new Error(`Gemini HTTP ${apiRes.status}`);

      const data = await apiRes.json();
      const text = data?.candidates?.[0]?.content?.parts?.[0]?.text || '';
      const cleaned = text.replace(/```json|```/g, '').trim();

      let parsed = null;
      try { parsed = JSON.parse(cleaned); } catch { /* fall through to fallback */ }

      const tagline = typeof parsed?.tagline === 'string' ? parsed.tagline.slice(0, 60) : null;
      const accent = isHexColor(parsed?.accent) ? parsed.accent : null;

      if (!tagline || !accent) throw new Error('Malformed Gemini response');

      res.set('Cache-Control', 'no-store');
      res.status(200).json({ tagline, accent });
    } catch (err) {
      console.warn('geminiExperience fallback:', err.message);
      res.set('Cache-Control', 'no-store');
      res.status(200).json(pickFallback(mode));
    }
  }
);

/** geminiCover: accepts ONLY { topic: 0..44 }. The prompt is built here from a fixed list, so callers cannot
 *  inject their own prompts, and nothing about the user's file or passphrase ever reaches this function. */
exports.geminiCover = onRequest(
  { secrets: [GEMINI_API_KEY], cors: ALLOWED_ORIGINS, timeoutSeconds: 40, memory: '512MiB' },
  async (req, res) => {
    res.set('Cache-Control', 'no-store');
    if (req.method !== 'POST') { res.status(405).json({ error: 'Method not allowed' }); return; }
    const i = Number((req.body || {}).topic);
    if (!Number.isInteger(i) || i < 0 || i >= COVER_TOPICS.length) { res.status(400).json({ error: 'Bad topic' }); return; }
    try {
      const r = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-image:generateContent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-goog-api-key': GEMINI_API_KEY.value() },
        body: JSON.stringify({
          contents: [{ parts: [{ text: `A beautiful, calm, photographic landscape-format picture: ${COVER_TOPICS[i]}. No text, no people, no logos.` }] }],
          generationConfig: { responseModalities: ['IMAGE'] },
        }),
      });
      if (!r.ok) throw new Error('Gemini HTTP ' + r.status);
      const part = ((await r.json())?.candidates?.[0]?.content?.parts || []).find((p) => p.inlineData || p.inline_data);
      const d = part && (part.inlineData || part.inline_data);
      if (!d?.data) throw new Error('No image returned');
      res.status(200).json({ image: d.data, mime: d.mimeType || d.mime_type || 'image/png' });
    } catch (e) { console.warn('geminiCover:', e.message); res.status(502).json({ error: 'unavailable' }); }
  }
);
