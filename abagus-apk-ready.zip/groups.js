/* =====================================================================
   ABAGUS — private groups (engine + the UI for groups.html).

   * A person with a mobile-number account creates a group and becomes its OWNER. The owner can make others
     ADMINS (shared power). Admins upload and manage; members view. Admins can allow members to upload too.
   * Everything stored is encrypted in the browser. The server holds ciphertext only.
       G   random 256-bit group key made by the owner. Each member keeps G locked by their OWN Abagus key,
           opened with their fingerprint/face/PIN (cloudkey.js). G lives in memory only and is dropped
           after the group's idle time. An invite code is 160 random bits; the server stores only G locked
           by a key made from the code and a lookup id made from a hash of it.
       File names, descriptions, thumbnails, group and member pictures and file names in the activity log
       are all encrypted with G.
   * Files up to 120 MB, kept in 700 KB encrypted pieces in Firestore.
   * Vault files: an admin can encrypt a file in the Vault with "Group" as the unlock method. Every member can
     then open it with their fingerprint, because its key comes from G. It is uploaded to the group directly.
   * Honesty about capture: no website can stop a screenshot or a screen recording, and nothing can change a
     capture already taken. This hides content when the window loses focus, catches the common capture
     shortcuts, prints the viewer's name over every photo and video, and when a capture attempt is caught the
     member is FLAGGED: the server refuses to send them any photo or video data (they see only a
     middle-finger emoji) until an admin clears them. Inside the native app wrapper (native/) the operating
     system's own protection is switched on too, which is the only way to truly block capture.

   Talks to the backend through window.VaultDB (firebase-lite.js / index.html) and keys through window.CloudKey.
   ===================================================================== */
(function () {
  'use strict';
  var MAX_FILE = 120 * 1024 * 1024;
  var CHUNK = 700 * 1024;
  var READ_PARALLEL = 3;
  var ALPHA = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
  var enc = new TextEncoder(), dec = new TextDecoder();
  var FLAG_EMOJI = '\uD83D\uDD95';
  var DEFAULTS = { memberUpload: false, vaultShare: true, watermark: 'corner', idleMin: 3 };   // watermark: 'off' | 'corner' (one small tag) | 'full' (tiled pattern)

  var me = { uid: null, phone: null, google: false, name: null, avatar: null, avatarV: 0 };   // signed in with a mobile number OR Google: both can use groups
  var st = null;                             // open group: { gid, G, group, settings, my, role, files, members, flagged, tab, gAvatar }
  var idleTimer = null, urls = [], listUrls = [], guardOn = false, keyCache = {}, viewerUrl = null;
  var mineIds = {}, mineList = [];                 // my own groups (for the directory's "Open" / "My Groups")
  var LAYOUT_KEY = 'abagus-gp-layout';

  /* ------------------------------ helpers ------------------------------ */
  function $(id) { return document.getElementById(id); }
  function bytes(n) { var a = new Uint8Array(n); crypto.getRandomValues(a); return a; }
  function hex(a) { return Array.prototype.map.call(a, function (x) { return ('0' + x.toString(16)).slice(-2); }).join(''); }
  function toast(t, m, ms) { if (typeof window.showToast === 'function') window.showToast(t, m, ms || 4200); }
  function iso() { return new Date().toISOString(); }
  function b32(a) { var bits = 0, val = 0, out = ''; for (var i = 0; i < a.length; i++) { val = (val << 8) | a[i]; bits += 8; while (bits >= 5) { out += ALPHA[(val >>> (bits - 5)) & 31]; bits -= 5; } val &= (1 << bits) - 1; } if (bits > 0) out += ALPHA[(val << (5 - bits)) & 31]; return out; }
  function unb32(str) {
    var s = String(str || '').toUpperCase().replace(/[^0-9A-Z]/g, '').replace(/O/g, '0').replace(/[IL]/g, '1');
    if (s.length !== 32) return null;
    var out = [], bits = 0, val = 0;
    for (var i = 0; i < s.length; i++) { var v = ALPHA.indexOf(s[i]); if (v < 0) return null; val = (val << 5) | v; bits += 5; if (bits >= 8) { out.push((val >>> (bits - 8)) & 255); bits -= 8; } val &= (1 << bits) - 1; }
    return out.length === 20 ? new Uint8Array(out) : null;
  }
  function groups4(c) { return c.match(/.{1,4}/g).join('-'); }
  function size(n) { return n >= 1048576 ? (n / 1048576).toFixed(n >= 10485760 ? 0 : 1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB'; }
  function when(t) { try { return new Date(t).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }); } catch (_) { return String(t); } }
  function concat(a, b) { var o = new Uint8Array(a.length + b.length); o.set(a, 0); o.set(b, a.length); return o; }

  /* DOM builder. Text is ALWAYS set with textContent: group, member and file names are user-controlled. */
  function h(tag, props) {
    var e = document.createElement(tag);
    if (props) for (var k in props) {
      if (k === 'text') e.textContent = props[k];
      else if (k === 'class') e.className = props[k];
      else if (k.slice(0, 2) === 'on') e.addEventListener(k.slice(2), props[k]);
      else if (props[k] === true) e.setAttribute(k, '');
      else if (props[k] !== false && props[k] != null) e.setAttribute(k, props[k]);
    }
    for (var i = 2; i < arguments.length; i++) { var c = arguments[i]; if (c == null) continue; e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); }
    return e;
  }
  function clear(el) { while (el.firstChild) el.removeChild(el.firstChild); }

  async function hkBase(secret) { return crypto.subtle.importKey('raw', secret, 'HKDF', false, ['deriveKey']); }
  async function aes(secret, salt, info) { return crypto.subtle.deriveKey({ name: 'HKDF', hash: 'SHA-256', salt: salt, info: enc.encode(info) }, await hkBase(secret), { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']); }
  async function seal(key, data, aad) { var iv = bytes(12); var p = { name: 'AES-GCM', iv: iv }; if (aad) p.additionalData = enc.encode(aad); return { iv: iv, ct: new Uint8Array(await crypto.subtle.encrypt(p, key, data)) }; }
  async function open(key, w, aad) { var p = { name: 'AES-GCM', iv: w.iv }; if (aad) p.additionalData = enc.encode(aad); return new Uint8Array(await crypto.subtle.decrypt(p, key, w.ct)); }
  var NOSALT = new Uint8Array(0);
  function memberKey(S, gid) { return aes(S, NOSALT, 'abagus/group/member/v1/' + gid); }
  function inviteKey(I) { return aes(I, NOSALT, 'abagus/group/invite/v1'); }
  function fileKey(G, fid) { return aes(G, enc.encode(fid), 'abagus/group/file/v1'); }
  function nameKey(G) { return aes(G, NOSALT, 'abagus/group/name/v1'); }
  async function sha(s) { return new Uint8Array(await crypto.subtle.digest('SHA-256', typeof s === 'string' ? enc.encode(s) : s)); }
  async function inviteId(I) { return hex(await sha(concat(enc.encode('abagus/invite/id/v1'), I))).slice(0, 32); }
  async function groupKid(gid) { return (await sha('abagus/group/kid/v1/' + gid)).slice(0, 8); }

  function db() { if (!window.VaultDB) throw fail('Groups need the account service, which has not loaded. Check your connection.'); return window.VaultDB; }
  function fail(msg, code) { var e = new Error(msg); e.groups = true; e.code = code || 'groups'; return e; }
  function explain(e) {
    var c = e && (e.code || '');
    if (e && e.groups) return e.message;
    if (c === 'permission-denied') return 'The server refused that. You may have been removed, flagged, or the Firestore rules are not published yet.';
    if (c === 'unavailable' || c === 'network-request-failed') return 'Could not reach the server. Check your connection.';
    return (e && e.message) || 'Something went wrong.';
  }
  async function mySecret() {
    if (!window.CloudKey) throw fail('The Abagus key service did not load on this page.');
    return (await window.CloudKey.getKey({ purpose: 'lock' })).S;      // biometric prompt (or first-time setup)
  }
  /* Step-up: sensitive actions (removing people, changing admins, freezing, deleting, changing the safety level) ask for the fingerprint / face / PIN
     again, so a phone left unlocked with the group open cannot be used to take the group over. */
  async function stepUp() { await mySecret(); }
  async function getOrNull(path) { try { return await db().get(path); } catch (e) { if (e && e.code === 'permission-denied') return null; throw e; } }

  /* ------------------------------ pictures ------------------------------ */
  async function squareJpeg(file, px, maxBytes) {
    var bm = await createImageBitmap(file), s = Math.min(bm.width, bm.height);
    var c = document.createElement('canvas'); c.width = px; c.height = px;
    c.getContext('2d').drawImage(bm, (bm.width - s) / 2, (bm.height - s) / 2, s, s, 0, 0, px, px);
    for (var q = 0.85; q > 0.3; q -= 0.1) {
      var blob = await new Promise(function (res) { c.toBlob(res, 'image/jpeg', q); });
      if (blob && blob.size <= maxBytes) return new Uint8Array(await blob.arrayBuffer());
    }
    throw fail('That picture could not be made small enough. Try another one.');
  }
  function avatarEl(u8, label, cls) {
    var box = h('span', { class: 'gp-av ' + (cls || ''), 'aria-hidden': 'true' });
    if (u8 && u8.length) {
      var url = URL.createObjectURL(new Blob([u8], { type: 'image/jpeg' })); (st ? urls : listUrls).push(url);
      var img = h('img', { alt: '', draggable: 'false' }); img.src = url; box.appendChild(img);
    } else box.appendChild(document.createTextNode(String(label || '?').trim().slice(0, 1).toUpperCase() || '?'));
    return box;
  }
  async function loadMyProfile() {
    if (!me.uid) return;
    try { var p = await db().get('users/' + me.uid); me.avatar = p && p.avatar ? p.avatar : null; me.avatarV = (p && p.avatarV) || 0; } catch (_) {}
  }

  /* ------------------------------ state ------------------------------ */
  function isAdmin() { return st && (st.role === 'owner' || st.role === 'admin'); }
  function isOwner() { return st && st.role === 'owner'; }
  function canUpload() { return !!st && !st.flagged && !(st.group && st.group.frozen === true && !isOwner()) && (isAdmin() || st.settings.memberUpload === true); }
  function idleMs() { return ((st && st.settings && st.settings.idleMin) || DEFAULTS.idleMin) * 60000; }
  function touch() { clearTimeout(idleTimer); if (st) idleTimer = setTimeout(function () { lockGroup(); }, idleMs()); }
  function revokeUrls() { urls.forEach(function (u) { try { URL.revokeObjectURL(u); } catch (_) {} }); urls = []; }
  function lockGroup(quiet) {
    var was = !!st; if (st) delete keyCache[st.gid]; st = null; clearTimeout(idleTimer); revokeUrls(); closeViewer(true); setGuard(false);
    if (was && $('grpBody')) { showList(); if (quiet !== false) toast('info', 'Group locked. Open it again with your fingerprint, face or PIN.', 4200); }
  }
  async function log(type, detail) {
    if (!st) return;
    try {
      var rec = { t: iso(), uid: me.uid, name: me.name || '', type: type, detail: '' };
      if (type === 'upload' || type === 'delete') rec.detailEnc = await seal(await nameKey(st.G), enc.encode(String(detail || '').slice(0, 120)), 'log');
      else rec.detail = String(detail || '').slice(0, 120);
      await db().set('groups/' + st.gid + '/log/' + hex(bytes(8)), rec);
    } catch (_) {}
  }
  function root() { return $('grpBody'); }
  function setTitle(t) { var e = $('grpTitle'); if (e) e.textContent = t; }
  function msgBox(text, kind) { return h('p', { class: 'acd-msg' + (kind ? ' ' + kind : ''), role: 'alert', text: text }); }
  function backTo(fn) { var b = $('grpBack'); if (!b) return; if (fn) { b.classList.remove('hidden'); b.onclick = fn; } else { b.classList.add('hidden'); b.onclick = null; } }

  /* ------------------------------ list / profile / create / join ------------------------------ */
  async function showList() {
    var r = root(); if (!r) return; clear(r); setTitle('Groups'); backTo(null); listUrls.forEach(function (u) { try { URL.revokeObjectURL(u); } catch (_) {} }); listUrls = [];
    if (!me.uid) {
      r.appendChild(h('div', { class: 'gp-empty' }, h('div', { class: 'gp-empty-ic', text: '\uD83D\uDD12' }), h('h2', { text: 'Sign in to use groups' }), h('p', { class: 'grp-note', text: 'Sign in with your mobile number or with Google. Your files stay encrypted, and only members can open them.' }),
        h('div', { class: 'gp-signin-row' },
          h('button', { class: 'btn primary', id: 'gpSignIn', onclick: function () { if (window.AbagusAccount) window.AbagusAccount.open('signin'); } }, 'Sign in with mobile number'),
          h('button', { class: 'btn', id: 'gpGoogle', onclick: async function () {
            try { if (!window.VaultAuth || !window.VaultAuth.signInWithGoogle) throw fail('Google sign-in is not available on this page. Sign in on the Vault page, then come back.'); await window.VaultAuth.signInWithGoogle(); }
            catch (e) { if (!(e && /popup-closed|cancelled-popup/.test(String(e.code || '')))) toast('error', (e && e.code === 'auth/popup-blocked') ? 'Your browser blocked the Google window. Allow pop-ups for this site, or sign in on the Vault page and come back.' : explain(e), 6500); }
          } }, 'Continue with Google'))));
      return;
    }
    await loadMyProfile();
    r.appendChild(profileCard());
    var nameIn = h('input', { class: 'acd-f', id: 'grpNewName', maxlength: '40', placeholder: 'Group name', 'aria-label': 'New group name' });
    var codeIn = h('input', { class: 'acd-f ck-in', id: 'grpCode', autocomplete: 'off', autocapitalize: 'characters', spellcheck: 'false', placeholder: 'Invite code', 'aria-label': 'Invite code' });
    r.appendChild(h('div', { class: 'grp-forms' },
      h('div', { class: 'grp-card' }, h('b', { text: 'Create a group' }), h('small', { text: 'You become the admin. Uploads are encrypted before they leave this phone.' }), nameIn,
        h('button', { class: 'btn primary', id: 'grpCreate', onclick: function () { doCreate(nameIn.value); } }, 'Create group')),
      h('div', { class: 'grp-card' }, h('b', { text: 'Join with a code' }), h('small', { text: 'Ask a group admin for the invite code.' }), codeIn,
        h('button', { class: 'btn', id: 'grpJoin', onclick: function () { doJoinStart(codeIn.value); } }, 'Continue'))));
    var list = h('div', { class: 'gp-cards', id: 'grpMine' }, h('p', { class: 'grp-note', text: 'Loading your groups…' }));
    r.appendChild(h('h3', { class: 'grp-h', text: 'Your groups' })); r.appendChild(list);
    try {
      var mine = await db().list('users/' + me.uid + '/groups', { orderBy: 'joinedAt', dir: 'desc' });
      mineIds = {}; mineList = mine; mine.forEach(function (g) { mineIds[g.gid] = 1; });
      if (mine.length) { var row = h('div', { class: 'sh-stories', 'aria-label': 'Your groups' }); list.parentNode.insertBefore(row, list.previousSibling);
        mine.slice(0, 12).forEach(function (g) { var badge = h('em', { class: 'hidden' }), tag = h('button', { type: 'button', class: 'sh-story', onclick: function () { doOpen(g.gid); } }, h('i', null, h('b', { text: String(g.name || '?').charAt(0).toUpperCase() }), badge), h('span', { text: g.name || 'Group' }));
          row.appendChild(tag); if (window.AbagusChat) window.AbagusChat.unread(db(), g.gid).then(function (n) { if (n) { badge.textContent = n > 99 ? '99+' : String(n); badge.classList.remove('hidden'); } }); }); }
      clear(list);
      if (!mine.length) list.appendChild(h('p', { class: 'grp-note', text: 'You are not in any group yet. Create one, or join with a code.' }));
      mine.forEach(function (g) {
        list.appendChild(h('button', { class: 'grp-row gp-card-btn', 'data-gid': g.gid, onclick: function () { doOpen(g.gid); } }, avatarEl(null, g.name, 'lg'), h('span', { class: 'grp-row-t', text: g.name || 'Group' }), h('span', { class: 'grp-go', text: 'Open' })));
      });
    } catch (e) { clear(list); list.appendChild(msgBox(explain(e), 'error')); }
    discoverSection(r);
  }

  function profileCard() {
    async function change() {
      try {
        var r = await window.AbagusAvatar.edit({ title: 'Your profile picture', hasCurrent: !!me.avatar }); if (r == null) return;
        var v = Date.now();
        if (r === 'remove') { await db().set('users/' + me.uid, { avatar: null, avatarV: v }, true); me.avatar = null; }
        else { await db().set('users/' + me.uid, { avatar: r, avatarV: v }, true); me.avatar = r; }
        me.avatarV = v; toast('ok', r === 'remove' ? 'Picture removed.' : 'Profile picture saved.', 2400); showList();
      } catch (e) { toast('error', explain(e), 5000); }
    }
    return h('div', { class: 'gp-profile' }, avatarEl(me.avatar, me.name, 'xl'),
      h('div', { class: 'gp-profile-t' }, h('b', { text: me.name || 'You' }), h('small', { text: me.phone ? me.phone.slice(0, 3) + '\u2022\u2022\u2022\u2022' + me.phone.slice(-3) : '' }), h('small', { class: 'gp-note2', text: 'Your picture is shown to group members. It is encrypted with each group\u2019s key.' })),
      h('div', { class: 'grp-acts' }, h('button', { class: 'btn small', id: 'gpAvatarBtn', onclick: change }, me.avatar ? 'Change picture' : 'Add picture'),
        me.avatar ? h('button', { class: 'btn small quiet', onclick: async function () { try { await db().set('users/' + me.uid, { avatar: null, avatarV: Date.now() }, true); me.avatar = null; showList(); } catch (e) { toast('error', explain(e)); } } }, 'Remove') : null,
        h('button', { class: 'btn small quiet', onclick: function () { if (window.AbagusAccount) window.AbagusAccount.open(); } }, 'Account')));
  }


  /* ------------------------- discover (public directory) -------------------------
     Reads ONLY publicGroups/<gid>: a server-written summary (name, short public description, member and file counts, created date)
     that exists only for groups whose owner switched on "Discoverable". Private groups never appear. Counts are written by the
     server (functions/directory.js) from the real member and file lists, so nobody can inflate their own rank. */
  var dirRows = null;
  function plural(n, one, many) { return n + ' ' + (n === 1 ? one : many); }
  function rankMap(rows) {
    var order = rows.slice().sort(function (a, b) { return (b.memberCount || 0) - (a.memberCount || 0) || String(a.createdAt || '').localeCompare(String(b.createdAt || '')); });
    var m = {}; order.forEach(function (g, i) { m[g.id] = i + 1; }); return m;
  }
  function discoverSection(r) {
    var state = { q: '', sort: 'top' };
    var search = h('input', { class: 'acd-f', id: 'gdSearch', type: 'search', placeholder: 'Search public groups', autocomplete: 'off', spellcheck: 'false', 'aria-label': 'Search public groups' });
    var pills = h('div', { class: 'gd-pills', role: 'tablist', 'aria-label': 'Sort groups' });
    var list = h('div', { class: 'gd-list', id: 'gdList', 'aria-busy': 'true' });
    function skeleton() { clear(list); list.setAttribute('aria-busy', 'true'); for (var i = 0; i < 4; i++) list.appendChild(h('div', { class: 'gd-skel gp-skel', 'aria-hidden': 'true' })); }
    function card(g, rank) {
      var isMine = !!mineIds[g.id];
      var badge = rank ? h('span', { class: 'gd-rank ' + (rank === 1 ? 'gold' : rank === 2 ? 'silver' : rank === 3 ? 'bronze' : 'num'), 'aria-label': 'Rank ' + rank, text: '#' + rank }) : null;
      var act = isMine
        ? h('button', { class: 'btn small primary', 'data-act': 'open', onclick: function () { doOpen(g.id); } }, 'Open Group')
        : h('button', { class: 'btn small', 'data-act': 'join', onclick: function () {
            var c = $('grpCode'); if (c) { c.focus(); c.scrollIntoView({ block: 'center', behavior: 'smooth' }); }
            toast('info', 'This group is invite-only. Ask an admin of \u201c' + g.name + '\u201d for an invite code, then enter it above.', 6000);
          } }, 'Join Group');
      return h('div', { class: 'gd-card' + (rank && rank <= 3 ? ' top' : ''), 'data-gid': g.id }, badge, avatarEl(null, g.name, 'lg'),
        h('div', { class: 'gd-t' }, h('b', { text: g.name || 'Group' }), g.publicDesc ? h('small', { text: g.publicDesc }) : null,
          g.memberCount != null ? h('div', { class: 'gd-stats' }, h('span', { text: plural(g.memberCount || 0, 'Member', 'Members') }), h('span', { text: plural(g.mediaCount || 0, 'file', 'files') })) : null),
        act);
    }
    function render() {
      clear(list); list.removeAttribute('aria-busy');
      var rows = dirRows || [], ranks = rankMap(rows), q = state.q.trim().toLowerCase(), out;
      if (state.sort === 'mine') {
        out = mineList.map(function (m) { var d = rows.filter(function (x) { return x.id === m.gid; })[0]; return d ? d : { id: m.gid, name: m.name }; });
      } else {
        out = rows.slice();
        if (state.sort === 'new') out.sort(function (a, b) { return String(b.createdAt || '').localeCompare(String(a.createdAt || '')); });
        else out.sort(function (a, b) { return ranks[a.id] - ranks[b.id]; });
      }
      if (q) out = out.filter(function (g) { return (String(g.name || '') + ' ' + String(g.publicDesc || '')).toLowerCase().indexOf(q) >= 0; });
      if (!out.length) {
        list.appendChild(h('div', { class: 'gp-empty small', id: 'gdEmpty' }, h('div', { class: 'gp-empty-ic', text: q ? '\uD83D\uDD0D' : '\uD83C\uDF10' }),
          h('p', { class: 'grp-note', text: q ? 'No groups match \u201c' + state.q.trim() + '\u201d.' : state.sort === 'mine' ? 'You are not in any group yet.' : 'No public groups yet. An owner can list a group in Settings \u203a Discoverability. Private groups never appear here.' })));
        return;
      }
      out.slice(0, 100).forEach(function (g) { list.appendChild(card(g, state.sort === 'mine' && !ranks[g.id] ? 0 : ranks[g.id])); });
    }
    [['top', 'Top Ranked'], ['new', 'Newest'], ['mine', 'My Groups']].forEach(function (t) {
      pills.appendChild(h('button', { type: 'button', role: 'tab', class: 'gd-pill', 'data-sort': t[0], 'aria-selected': t[0] === state.sort ? 'true' : 'false', onclick: function () {
        state.sort = t[0]; Array.prototype.forEach.call(pills.children, function (b) { b.setAttribute('aria-selected', b.getAttribute('data-sort') === t[0] ? 'true' : 'false'); }); render();
      } }, t[1]));
    });
    search.addEventListener('input', function () { state.q = search.value; render(); });
    r.appendChild(h('h3', { class: 'grp-h', text: 'Discover groups' }));
    r.appendChild(h('div', { class: 'gd-tools' }, search, pills));
    r.appendChild(list); skeleton();
    db().list('publicGroups').then(function (rows) { dirRows = rows; if (list.isConnected) render(); }).catch(function (e) {
      dirRows = [];
      if (!list.isConnected) return; clear(list); list.removeAttribute('aria-busy');
      list.appendChild(msgBox(e && e.code === 'permission-denied' ? 'The group directory is not available yet. Publish the latest firestore.rules.' : explain(e), 'error'));
    });
  }

  async function doCreate(name) {
    name = String(name || '').trim();
    if (name.length < 2 || name.length > 40) { toast('error', 'Give the group a name of 2 to 40 characters.'); return; }
    var btn = $('grpCreate'); btn.disabled = true;
    try {
      var S = await mySecret();
      var gid = hex(bytes(10)), G = bytes(32), now = iso();
      await db().set('groups/' + gid, { name: name, ownerUid: me.uid, createdAt: now, policy: 'block', settings: Object.assign({}, DEFAULTS), v: 2 });
      try {
        var w = await seal(await memberKey(S, gid), G);
        await db().set('groups/' + gid + '/members/' + me.uid, { uid: me.uid, name: me.name || '', role: 'owner', wrappedKey: w, joinedAt: now, flagged: false, violations: 0 });
      } catch (e) { try { await db().del('groups/' + gid); } catch (_) {} throw e; }
      await db().set('users/' + me.uid + '/groups/' + gid, { gid: gid, name: name, joinedAt: now });
      toast('ok', 'Group created. You are the admin.', 3600);
      await doOpen(gid);
    } catch (e) { if (!(e && e.code === 'cancelled')) toast('error', explain(e), 6500); btn.disabled = false; }
  }

  async function doJoinStart(code) {
    var I = unb32(code);
    if (!I) { toast('error', 'An invite code has 32 letters and numbers, in groups of four.'); return; }
    var btn = $('grpJoin'); btn.disabled = true;
    try {
      var id = await inviteId(I), inv = await db().get('invites/' + id);
      if (!inv || !inv.active || inv.expiresAt < Date.now()) throw fail('That invite code is not valid, or it has expired. Ask an admin for a new one.', 'bad-invite');
      var G;
      try { G = await open(await inviteKey(I), inv.wrapped); } catch (_) { throw fail('That invite code is not valid, or it has expired. Ask an admin for a new one.', 'bad-invite'); }
      var existing = await getOrNull('groups/' + inv.gid + '/members/' + me.uid);
      if (existing) { await doOpen(inv.gid); return; }
      showHonor(inv, id, G);
    } catch (e) { toast('error', explain(e), 6000); btn.disabled = false; }
  }

  function showHonor(inv, id, G) {
    var r = root(); clear(r); setTitle('Join ' + inv.gname); backTo(showList);
    var ok = h('input', { type: 'checkbox', id: 'grpHonor' });
    var go = h('button', { class: 'btn primary', id: 'grpJoinGo', disabled: true, onclick: async function () {
      go.disabled = true;
      try {
        var S = await mySecret(), now = iso();
        var w = await seal(await memberKey(S, inv.gid), G);
        await db().set('groups/' + inv.gid + '/members/' + me.uid, { uid: me.uid, name: me.name || '', role: 'member', wrappedKey: w, joinedAt: now, inviteId: id, flagged: false, violations: 0 });
        await db().set('users/' + me.uid + '/groups/' + inv.gid, { gid: inv.gid, name: inv.gname, joinedAt: now });
        if (inv.maxUses > 0) { try { var used = (inv.uses || 0) + 1; await db().set('invites/' + id, { uses: used, active: used < inv.maxUses }, true); } catch (_) {} }   // a one-person code switches itself off
        toast('ok', 'You joined ' + inv.gname + '.', 3200);
        await doOpen(inv.gid);
      } catch (e) { if (!(e && e.code === 'cancelled')) toast('error', explain(e), 6500); go.disabled = !ok.checked; }
    } }, 'Join group');
    ok.addEventListener('change', function () { go.disabled = !ok.checked; });
    r.appendChild(h('div', { class: 'grp-card gp-honor' },
      h('b', { text: 'The group honor code' }),
      h('ul', { class: 'acd-notes' },
        h('li', { text: 'Everything here is private to the group. Do not screenshot, record, copy or share it.' }),
        h('li', { text: 'No website can fully stop a screenshot, so this group watches for it. Every photo and video carries your name.' }),
        h('li', { text: 'If a capture attempt is caught, your access stops (you see only a middle-finger emoji) and the admins are told, until an admin clears you.' }),
        h('li', { text: 'You will be asked to set up your Abagus key first if you have not, and to confirm with your fingerprint, face or PIN.' })),
      h('label', { class: 'ck-confirm' }, ok, h('span', { text: 'I agree to the honor code.' })), go));
  }

  /* ------------------------------ open a group ------------------------------ */
  async function openGroupKey(gid) {
    var group = await getOrNull('groups/' + gid);
    var my = group ? await getOrNull('groups/' + gid + '/members/' + me.uid) : null;
    if (!group || !my) { try { await db().del('users/' + me.uid + '/groups/' + gid); } catch (_) {} throw fail('You are no longer in this group.', 'removed'); }
    var S = await mySecret(), G;
    try { G = await open(await memberKey(S, gid), my.wrappedKey); }
    catch (_) { throw fail('Your key could not open this group. Use the Abagus key you had when you joined.', 'key'); }
    return { group: group, my: my, G: G };
  }

  async function doOpen(gid) {
    var r = root(); clear(r);
    r.appendChild(h('div', { class: 'gp-unlock', role: 'status', 'aria-live': 'polite' }, h('div', { class: 'gp-lockwrap', 'aria-hidden': 'true' }, h('span', { class: 'gp-lockring' }), h('span', { class: 'gp-lockic', text: '\uD83D\uDD12' })),
      h('p', { class: 'gp-unlock-t', text: 'Unlocking your group\u2026' }), h('small', { text: 'Confirm with your fingerprint, face or PIN. The key stays in memory only.' })));
    try {
      var o = await openGroupKey(gid);
      var settings = Object.assign({}, DEFAULTS, o.group.settings || {});
      st = { gid: gid, G: o.G, group: o.group, settings: settings, my: o.my, role: o.my.role, flagged: o.my.flagged === true, files: [], members: [], tab: window.AbagusChat ? 'chat' : 'files', gAvatar: null };
      keyCache[gid] = { G: o.G, t: Date.now() };
      await loadGroupExtras(); await syncMyAvatar();
      setGuard(true); touch(); await showGroup();
    } catch (e) { if (!(e && e.code === 'cancelled')) toast('error', explain(e), 6500); showList(); }
  }
  async function loadGroupExtras() {
    st.desc = ''; st.gAvatar = null;
    try { if (st.group.descEnc) st.desc = dec.decode(await open(await nameKey(st.G), st.group.descEnc, 'desc')); } catch (_) {}
    try { if (st.group.avatar) st.gAvatar = await open(await nameKey(st.G), st.group.avatar, 'gavatar'); } catch (_) {}
  }
  async function syncMyAvatar() {                   // keep my picture in this group, encrypted with the group key
    try {
      await loadMyProfile();
      if (!st || (st.my.avatarV || 0) === (me.avatarV || 0)) return;
      var patch = { avatarV: me.avatarV || 0 };
      patch.avatar = me.avatar ? await seal(await nameKey(st.G), me.avatar, 'mavatar:' + me.uid) : null;
      await db().set('groups/' + st.gid + '/members/' + me.uid, patch, true); st.my.avatarV = patch.avatarV;
    } catch (_) {}
  }

  async function showGroup() {
    if (!st) return;
    var r = root(); clear(r); setTitle(st.group.name); backTo(function () { lockGroup(false); });
    r.appendChild(h('div', { class: 'gp-banner' }, avatarEl(st.gAvatar, st.group.name, 'xl'),
      h('div', { class: 'gp-banner-t' }, h('h2', { text: st.group.name }), st.desc ? h('p', { class: 'gp-desc', text: st.desc }) : null,
        h('div', { class: 'grp-top' }, h('span', { class: 'ak-chip ready', text: st.role }), st.flagged ? h('span', { class: 'ak-chip warn', text: 'Access paused' }) : null,
          h('span', { class: 'ak-chip', text: (st.group.policy === 'warn' ? 'Warn only' : 'Capture protected') })))));
    if (st.group.frozen === true) r.appendChild(h('div', { class: 'gp-frozen', role: 'alert' }, h('b', { text: 'This group is frozen' }),
      h('span', { text: isOwner() ? 'Nobody else can open files, add files or join. Unfreeze it in Settings when you are ready.' : 'The owner has frozen this group. Nothing can be opened or added until it is unfrozen.' })));
    var tabs = [['files', 'Media'], ['members', 'Members']]; if (window.AbagusChat) tabs.unshift(['chat', 'Chat']);
    if (isAdmin()) tabs.push(['invites', 'Invites']);
    tabs.push(['settings', 'Settings']);
    var bar = h('div', { class: 'acd-tabs grp-tabs', role: 'tablist' });
    tabs.forEach(function (t) { bar.appendChild(h('button', { type: 'button', role: 'tab', 'aria-selected': st.tab === t[0] ? 'true' : 'false', 'data-tab': t[0], onclick: function () { st.tab = t[0]; touch(); showGroup(); } }, t[1])); });
    bar.style.gridTemplateColumns = 'repeat(' + tabs.length + ',1fr)';
    r.appendChild(bar);
    var pane = h('div', { id: 'grpPane', class: 'grp-pane' }); r.appendChild(pane);
    if (st.tab !== 'chat' && window.AbagusChat) window.AbagusChat.stop();
    if (st.tab === 'chat' && window.AbagusChat) await window.AbagusChat.render(pane, { gid: st.gid, uid: me.uid, name: me.name, isAdmin: isAdmin(), canPost: !st.flagged && !(st.group.frozen === true && !isOwner()),
      db: db(), h: h, toast: toast, touch: touch, seal: seal, open: open, key: function () { return aes(st.G, NOSALT, 'abagus/group/chat/v1'); }, newId: function () { return hex(bytes(10)); } });
    else if (st.tab === 'files') await paneFiles(pane);
    else if (st.tab === 'members') await paneMembers(pane);
    else if (st.tab === 'invites') await paneInvites(pane);
    else paneSettings(pane);
  }

  /* ------------------------------ files ------------------------------ */
  async function fileName(f) { try { return dec.decode(await open(await nameKey(st.G), f.nameEnc, 'name:' + f.id)); } catch (_) { return 'Unnamed'; } }

  var KIND_LABEL = { all: 'All', image: 'Photos', video: 'Videos', vault: 'Documents' };
  function layoutPref() { try { return localStorage.getItem(LAYOUT_KEY) === 'compact' ? 'compact' : 'grid'; } catch (_) { return 'grid'; } }
  function filteredFiles() { var f = st.filter || 'all'; return (st.files || []).filter(function (x) { return f === 'all' || x.kind === f; }); }

  async function paneFiles(pane) {
    if (st.group.frozen === true && !isOwner()) { pane.appendChild(h('p', { class: 'grp-note', text: 'This group is frozen by its owner. Files cannot be opened until it is unfrozen.' })); return; }
    st.filter = st.filter || 'all'; st.layout = st.layout || layoutPref();
    if (canUpload()) {
      var inp = h('input', { type: 'file', id: 'grpUpload', accept: 'image/*,video/*', multiple: true, class: 'hidden' });
      inp.addEventListener('change', function () { doUpload(Array.prototype.slice.call(inp.files)); inp.value = ''; });
      var zone = h('div', { class: 'grp-up', id: 'grpDrop' }, h('button', { class: 'btn primary', id: 'grpUpBtn', onclick: function () { inp.click(); } }, 'Upload photos or videos'),
        h('small', { text: 'Drag files here or tap Upload. Up to 120 MB each. Encrypted on this device before upload. Documents go through the Vault (\u201cGroup\u201d unlock method).' }), inp, h('div', { id: 'grpProg', class: 'grp-prog hidden' }));
      ['dragenter', 'dragover'].forEach(function (ev) { zone.addEventListener(ev, function (e) { e.preventDefault(); zone.classList.add('drag'); }); });
      ['dragleave', 'drop'].forEach(function (ev) { zone.addEventListener(ev, function (e) { e.preventDefault(); if (ev === 'drop' || e.target === zone) zone.classList.remove('drag'); }); });
      zone.addEventListener('drop', function (e) { var fl = e.dataTransfer && e.dataTransfer.files; if (fl && fl.length) { touch(); doUpload(Array.prototype.slice.call(fl)); } });
      pane.appendChild(zone);
    }
    var bar = h('div', { class: 'gf-bar', id: 'gfBar' });
    var tabs = h('div', { class: 'gf-tabs', role: 'tablist', 'aria-label': 'Filter files' });
    ['all', 'image', 'video', 'vault'].forEach(function (k) {
      tabs.appendChild(h('button', { type: 'button', role: 'tab', class: 'gf-tab', 'data-filter': k, 'aria-selected': st.filter === k ? 'true' : 'false', onclick: function () { touch(); st.filter = k; renderFiles(); } }, KIND_LABEL[k]));
    });
    var lay = h('button', { type: 'button', class: 'gf-lay', id: 'gfLayout', 'aria-label': 'Switch between grid and compact layout', 'aria-pressed': st.layout === 'compact' ? 'true' : 'false', onclick: function () {
      st.layout = st.layout === 'compact' ? 'grid' : 'compact'; try { localStorage.setItem(LAYOUT_KEY, st.layout); } catch (_) {} renderFiles();
    } }, st.layout === 'compact' ? 'Grid' : 'Compact');
    bar.appendChild(tabs); bar.appendChild(lay); pane.appendChild(bar);
    var grid = h('div', { class: 'grp-grid', id: 'grpGrid', 'aria-busy': 'true' }, h('p', { class: 'grp-note', text: 'Loading\u2026' }), h('div', { class: 'gp-skel', 'aria-hidden': 'true' }), h('div', { class: 'gp-skel', 'aria-hidden': 'true' }), h('div', { class: 'gp-skel', 'aria-hidden': 'true' })); pane.appendChild(grid);
    try {
      st.files = await db().list('groups/' + st.gid + '/files', { orderBy: 'createdAt', dir: 'desc' });
      await renderFiles();
    } catch (e) { clear(grid); grid.appendChild(msgBox(explain(e), 'error')); }
  }
  var renderSeq = 0;
  async function renderFiles() {
    var grid = $('grpGrid'); if (!grid || !st) return;
    var seq = ++renderSeq, all = st.files || [], list = filteredFiles();
    Array.prototype.forEach.call(document.querySelectorAll('#gfBar .gf-tab'), function (b) {
      var k = b.getAttribute('data-filter'), n = k === 'all' ? all.length : all.filter(function (x) { return x.kind === k; }).length;
      b.setAttribute('aria-selected', st.filter === k ? 'true' : 'false'); b.textContent = KIND_LABEL[k] + (all.length ? ' \u00b7 ' + n : '');
    });
    var lay = $('gfLayout'); if (lay) { lay.textContent = st.layout === 'compact' ? 'Grid' : 'Compact'; lay.setAttribute('aria-pressed', st.layout === 'compact' ? 'true' : 'false'); }
    clear(grid); grid.removeAttribute('aria-busy'); grid.classList.toggle('compact', st.layout === 'compact');
    if (!list.length) {
      grid.appendChild(h('div', { class: 'gp-empty small', id: 'gfEmpty' }, h('div', { class: 'gp-empty-ic', text: all.length ? '\uD83D\uDD0E' : '\uD83D\uDDBC' }),
        h('p', { class: 'grp-note', text: all.length ? 'Nothing in \u201c' + KIND_LABEL[st.filter] + '\u201d yet.' : (canUpload() ? 'No files yet. Upload the first photo or video.' : 'Nothing has been shared yet.') })));
      return;
    }
    for (var i = 0; i < list.length; i++) { var t = await tile(list[i]); if (seq !== renderSeq || !st) return; grid.appendChild(t); }
  }

  async function tile(f) {
    var nm = f._nm || (f._nm = await fileName(f));
    var face = h('div', { class: 'grp-face' + (st.flagged ? ' flagged' : '') + (f.kind === 'vault' ? ' vault' : '') });
    if (st.flagged) face.appendChild(h('span', { class: 'grp-flag', role: 'img', 'aria-label': 'Access paused', text: FLAG_EMOJI }));
    else if (f.kind === 'vault') { face.appendChild(h('span', { class: 'grp-lock', text: '\uD83D\uDD10' })); face.appendChild(h('span', { class: 'grp-kind', text: 'Locked file' })); }
    else { face.appendChild(h('span', { class: 'grp-kind', text: f.kind === 'video' ? 'Video' : 'Photo' })); if (f.kind === 'video') face.appendChild(h('span', { class: 'gf-play', 'aria-hidden': 'true', text: '\u25B6' })); loadThumb(f, face); }
    var t = h('button', { class: 'grp-tile', 'data-fid': f.id, onclick: function () { touch(); if (f.kind === 'vault') openVaultItem(f, nm); else viewFile(f, nm); } }, face,
      h('span', { class: 'grp-tname', text: nm }), h('span', { class: 'grp-tmeta', text: size(f.size) + ' \u00b7 ' + (f.uploaderName || '') }));
    if (isAdmin() || (f.uploadedBy === me.uid && !st.flagged)) t.appendChild(h('span', { class: 'grp-del', role: 'button', tabindex: '0', 'aria-label': 'Delete ' + nm, title: 'Delete', onclick: function (e) { e.stopPropagation(); doDelete(f, nm); } }, '\u00d7'));
    return t;
  }
  async function loadThumb(f, face) {
    if (!f.hasThumb || !st) return;
    try {
      var tdoc = await db().get('groups/' + st.gid + '/thumbs/' + f.id); if (!tdoc || !st) return;
      var raw = await open(await fileKey(st.G, f.id), { iv: tdoc.iv, ct: tdoc.data }, 'thumb:' + f.id);
      var url = URL.createObjectURL(new Blob([raw], { type: 'image/jpeg' })); urls.push(url);
      var img = h('img', { alt: '', draggable: 'false' }); img.src = url; clear(face); face.appendChild(img);
      if (f.kind === 'video') face.appendChild(h('span', { class: 'gf-play', 'aria-hidden': 'true', text: '\u25B6' }));
    } catch (_) {}
  }

  async function doDelete(f, nm) {
    if (!window.confirm('Delete "' + nm + '" for everyone in the group? This cannot be undone.')) return;
    try {
      for (var i = 0; i < f.chunks; i++) await db().del('groups/' + st.gid + '/files/' + f.id + '/chunks/' + i);
      try { await db().del('groups/' + st.gid + '/thumbs/' + f.id); } catch (_) {}
      await db().del('groups/' + st.gid + '/files/' + f.id);
      await log('delete', nm); toast('ok', 'Deleted.', 2400); showGroup();
    } catch (e) { toast('error', explain(e), 6000); }
  }

  function kindOf(file) { return /^video\//.test(file.type) ? 'video' : /^image\//.test(file.type) && file.type !== 'image/svg+xml' ? 'image' : null; }
  async function makeThumb(file, kind) {
    try {
      var url = URL.createObjectURL(file), src, w, hgt, cleanup = function () { URL.revokeObjectURL(url); };
      if (kind === 'image') { var bm = await createImageBitmap(file); src = bm; w = bm.width; hgt = bm.height; }
      else {
        var v = document.createElement('video'); v.muted = true; v.playsInline = true; v.preload = 'auto'; v.src = url;
        await new Promise(function (res, rej) { v.onloadeddata = res; v.onerror = rej; setTimeout(rej, 5000); });
        try { v.currentTime = Math.min(1, (v.duration || 2) / 2); await new Promise(function (res) { v.onseeked = res; setTimeout(res, 1500); }); } catch (_) {}
        src = v; w = v.videoWidth; hgt = v.videoHeight;
      }
      var sc = Math.min(1, 360 / Math.max(w, hgt)), c = document.createElement('canvas'); c.width = Math.max(1, Math.round(w * sc)); c.height = Math.max(1, Math.round(hgt * sc));
      c.getContext('2d').drawImage(src, 0, 0, c.width, c.height); cleanup();
      var blob = await new Promise(function (res) { c.toBlob(res, 'image/jpeg', 0.7); });
      return blob ? new Uint8Array(await blob.arrayBuffer()) : null;
    } catch (_) { return null; }
  }

  /* Encrypt a Blob/File in 700 KB pieces and store it. Reads the file piece by piece, so a 120 MB video never sits in memory twice. */
  async function putFile(gid, G, blob, name, kind, mime, thumb, onProg) {
    var fid = hex(bytes(12)), key = await fileKey(G, fid), count = Math.ceil(blob.size / CHUNK) || 1;
    for (var i = 0; i < count; i++) {
      var buf = new Uint8Array(await blob.slice(i * CHUNK, Math.min(blob.size, (i + 1) * CHUNK)).arrayBuffer());
      var w = await seal(key, buf, fid + ':' + i);
      await db().set('groups/' + gid + '/files/' + fid + '/chunks/' + i, { i: i, iv: w.iv, data: w.ct });
      if (onProg) onProg((i + 1) / count);
    }
    var hasThumb = false;
    if (thumb && thumb.length < 150000) { var tw = await seal(key, thumb, 'thumb:' + fid); await db().set('groups/' + gid + '/thumbs/' + fid, { iv: tw.iv, data: tw.ct }); hasThumb = true; }
    var nw = await seal(await nameKey(G), enc.encode(name.slice(0, 120)), 'name:' + fid);
    await db().set('groups/' + gid + '/files/' + fid, { kind: kind, mime: mime, size: blob.size, chunks: count, nameEnc: nw, uploadedBy: me.uid, uploaderName: me.name || '', createdAt: iso(), hasThumb: hasThumb, v: 1 });
    return fid;
  }

  async function uploadOne(file, line) {
    var kind = kindOf(file), msg = line.querySelector('.gf-msg'), fill = line.querySelector('.gf-fill'), old = line.querySelector('.gf-retry'); if (old) old.remove();
    function say(t, p) { msg.textContent = t; if (fill && p != null) fill.style.width = Math.round(p * 100) + '%'; }
    if (!kind) { say(file.name + ': only photos and videos here. Send documents from the Vault with the \u201cGroup\u201d unlock method.', 0); line.classList.add('bad'); return false; }
    if (file.size > MAX_FILE) { say(file.name + ': over 120 MB', 0); line.classList.add('bad'); return false; }
    line.classList.remove('bad');
    try {
      var th = await makeThumb(file, kind);
      await putFile(st.gid, st.G, file, file.name, kind, file.type || (kind === 'video' ? 'video/mp4' : 'image/jpeg'), th, function (p) { say(file.name + ': ' + Math.round(p * 100) + '%', p); touch(); });
      say(file.name + ': done', 1); line.classList.add('ok');
      await log('upload', file.name); return true;
    } catch (e) {
      say(file.name + ': ' + explain(e), 0); line.classList.add('bad');
      line.appendChild(h('button', { type: 'button', class: 'btn small gf-retry', onclick: async function () { if (!st) return; if (await uploadOne(file, line)) { toast('ok', 'Uploaded.', 2400); showGroup(); } } }, 'Retry'));
      return false;
    }
  }
  async function doUpload(files) {
    var prog = $('grpProg'); if (!prog) return; prog.classList.remove('hidden'); clear(prog);
    var okCount = 0;
    for (var n = 0; n < files.length; n++) {
      var file = files[n];
      var line = h('div', { class: 'grp-prog-row' }, h('span', { class: 'gf-msg', text: file.name + ' \u2026' }), h('span', { class: 'gf-track', 'aria-hidden': 'true' }, h('i', { class: 'gf-fill' })));
      prog.appendChild(line);
      if (await uploadOne(file, line)) okCount++;
    }
    if (okCount) { toast('ok', okCount + (okCount > 1 ? ' files' : ' file') + ' uploaded.', 3000); showGroup(); }
  }

  /* Fetch + decrypt every piece of a file, three at a time, in order. */
  async function readFile(f, onProg) {
    var key = await fileKey(st.G, f.id), parts = new Array(f.chunks), next = 0, done = 0, failure = null;
    async function worker() {
      while (!failure) {
        var i = next++; if (i >= f.chunks) return;
        try {
          var c = await db().get('groups/' + st.gid + '/files/' + f.id + '/chunks/' + i);
          if (!c || c.i !== i) throw fail('This file is incomplete on the server.');
          parts[i] = await open(key, { iv: c.iv, ct: c.data }, f.id + ':' + i);
          done++; if (onProg) onProg(done / f.chunks);
        } catch (e) { failure = e; }
      }
    }
    var ws = []; for (var k = 0; k < READ_PARALLEL; k++) ws.push(worker());
    await Promise.all(ws);
    if (failure) throw failure;
    return parts;
  }

  /* ------------------------------ viewer + capture guard ------------------------------ */
  function closeViewer() {
    var v = $('grpViewer'); if (!v) return;
    var m = v.querySelector('video'); if (m) { try { m.pause(); } catch (_) {} m.removeAttribute('src'); try { m.load(); } catch (_) {} }
    clear(v); v.classList.add('hidden'); revokeViewerUrl();
  }
  function revokeViewerUrl() { if (viewerUrl) { try { URL.revokeObjectURL(viewerUrl); } catch (_) {} viewerUrl = null; } }

  function wmMode() { var w = st && st.settings ? st.settings.watermark : DEFAULTS.watermark; return w === true ? 'corner' : (w === false ? 'off' : (w || 'corner')); }
  function watermark() {
    var mode = wmMode(); if (mode === 'off') return null;
    var tag = (me.name || 'member') + (me.phone ? ' \u00b7 \u2022\u2022\u2022' + me.phone.slice(-3) : '');
    if (mode === 'corner') return h('div', { class: 'grp-wm corner', 'aria-hidden': 'true' }, h('span', { text: tag }));   // one small, quiet tag: traceable, not intrusive
    var wrap = h('div', { class: 'grp-wm full', 'aria-hidden': 'true' });
    for (var i = 0; i < 24; i++) wrap.appendChild(h('span', { text: tag + ' \u00b7 ' + new Date().toLocaleDateString() }));
    return wrap;
  }
  function flagViewer() {
    var v = $('grpViewer'); if (!v) return;
    clear(v); v.classList.remove('hidden');
    v.appendChild(h('button', { class: 'grp-vclose', 'aria-label': 'Close', onclick: function () { closeViewer(); } }, '\u00d7'));
    v.appendChild(h('div', { class: 'grp-flagbig', role: 'img', 'aria-label': 'Access paused', text: FLAG_EMOJI }));
  }
  function mediaList() { return filteredFiles().filter(function (x) { return x.kind === 'image' || x.kind === 'video'; }); }
  function viewerNav(f) {
    var v = $('grpViewer'), list = mediaList(), i = -1; if (!v) return;
    for (var k = 0; k < list.length; k++) if (list[k].id === f.id) { i = k; break; }
    if (i < 0 || list.length < 2) return;
    v.appendChild(h('button', { class: 'grp-vnav prev', id: 'grpPrev', 'aria-label': 'Previous', onclick: function () { stepViewer(-1); } }, '\u2039'));
    v.appendChild(h('button', { class: 'grp-vnav next', id: 'grpNext', 'aria-label': 'Next', onclick: function () { stepViewer(1); } }, '\u203a'));
    v.appendChild(h('div', { class: 'grp-vcount', 'aria-live': 'polite', text: (i + 1) + ' / ' + list.length }));
    v._cur = f.id;
  }
  async function stepViewer(d) {
    var v = $('grpViewer'); if (!st || !v || v.classList.contains('hidden')) return;
    var list = mediaList(), i = -1; for (var k = 0; k < list.length; k++) if (list[k].id === v._cur) { i = k; break; }
    if (i < 0 || list.length < 2) return;
    var x = list[(i + d + list.length) % list.length]; touch();
    var m = v.querySelector('video'); if (m) { try { m.pause(); } catch (_) {} }
    viewFile(x, x._nm || await fileName(x));
  }
  function viewerKeys(e) {
    var v = $('grpViewer'); if (!st || !v || v.classList.contains('hidden')) return;
    if (e.key === 'Escape') { e.preventDefault(); closeViewer(); }
    else if (e.key === 'ArrowLeft') { e.preventDefault(); stepViewer(-1); }
    else if (e.key === 'ArrowRight') { e.preventDefault(); stepViewer(1); }
  }
  function viewerSwipe() {
    var v = $('grpViewer'), x0 = null; if (!v) return;
    v.addEventListener('touchstart', function (e) { x0 = e.touches.length === 1 ? e.touches[0].clientX : null; }, { passive: true });
    v.addEventListener('touchend', function (e) { if (x0 == null) return; var dx = (e.changedTouches[0].clientX - x0); x0 = null; if (Math.abs(dx) > 70 && !(e.target.closest && e.target.closest('video'))) stepViewer(dx < 0 ? 1 : -1); }, { passive: true });
  }
  async function viewFile(f, nm) {
    if (!st) return;
    if (st.flagged) { flagViewer(); return; }
    var v = $('grpViewer'); clear(v); v.classList.remove('hidden');
    v.appendChild(h('button', { class: 'grp-vclose', 'aria-label': 'Close', onclick: function () { closeViewer(); } }, '\u00d7'));
    viewerNav(f);
    var label = h('p', { class: 'grp-note light', text: 'Decrypting\u2026' });
    var stage = h('div', { class: 'grp-stage' }, label); v.appendChild(stage);
    try {
      var parts = await readFile(f, function (p) { label.textContent = 'Decrypting\u2026 ' + Math.round(p * 100) + '%'; touch(); });
      if (!st || st.flagged) return;
      window.AbagusGroups._last = { size: parts.reduce(function (n, x) { return n + x.length; }, 0), chunks: parts.length };   // read by tests only
      revokeViewerUrl(); viewerUrl = URL.createObjectURL(new Blob(parts, { type: f.mime }));
      var media;
      if (f.kind === 'video') media = h('video', { controls: true, playsinline: true, controlslist: 'nodownload noremoteplayback', disablepictureinpicture: true, disableremoteplayback: true, preload: 'metadata' });
      else media = h('img', { alt: nm, draggable: 'false' });
      media.src = viewerUrl; media.addEventListener('contextmenu', function (e) { e.preventDefault(); });
      clear(stage); stage.appendChild(media);
      var wm = watermark(); if (wm) stage.appendChild(wm);
      /* No download button on purpose: the group's capture and download policy stays as it was. */
      stage.appendChild(h('div', { class: 'grp-cap', text: nm + (f.uploaderName ? ' \u00b7 ' + f.uploaderName : '') + ' \u00b7 ' + size(f.size) + ' \u00b7 ' + (f.kind === 'video' ? 'Video' : 'Photo') }));
    } catch (e) { clear(stage); stage.appendChild(msgBox(explain(e), 'error')); }
  }

  /* Locked files made in the Vault with the "Group" method: hand the ciphertext to the Vault page, where it unlocks with the member's fingerprint. */
  async function openVaultItem(f, nm) {
    if (st.flagged) { flagViewer(); return; }
    try {
      toast('info', 'Preparing the locked file\u2026', 2500);
      var parts = await readFile(f), blob = new Blob(parts, { type: 'application/octet-stream' });
      await handoffPut(blob, nm);
      try { sessionStorage.setItem('abagus-handoff', '1'); } catch (_) {}
      location.href = 'index.html#vault';
    } catch (e) { toast('error', explain(e), 6000); }
  }
  function handoffDb() {
    return new Promise(function (res, rej) { var r = indexedDB.open('abagus-handoff', 1); r.onupgradeneeded = function () { r.result.createObjectStore('f'); }; r.onsuccess = function () { res(r.result); }; r.onerror = function () { rej(r.error); }; });
  }
  async function handoffPut(blob, name) {
    var d = await handoffDb();
    return new Promise(function (res, rej) { var tx = d.transaction('f', 'readwrite'); tx.objectStore('f').put({ blob: blob, name: name }, 'file'); tx.oncomplete = function () { d.close(); res(); }; tx.onerror = function () { d.close(); rej(tx.error); }; });
  }
  async function handoffTake() {
    var d = await handoffDb();
    return new Promise(function (res) {
      var tx = d.transaction('f', 'readwrite'), s = tx.objectStore('f'), g = s.get('file'); var out = null;
      g.onsuccess = function () { out = g.result || null; s.delete('file'); };
      tx.oncomplete = function () { d.close(); res(out); }; tx.onerror = function () { d.close(); res(null); };
    });
  }

  function setGuard(on) {
    var P = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.PrivacyScreen;   // native wrapper: the OS blocks capture
    if (P) { try { if (on) P.enable(); else P.disable(); } catch (_) {} }
    if (on === guardOn) return;
    guardOn = on;
    var m = on ? 'addEventListener' : 'removeEventListener';
    document[m]('keydown', onKey, true); document[m]('keyup', onKey, true);
    document[m]('visibilitychange', onVis); window[m]('blur', onBlur); window[m]('focus', onFocus);
    window[m]('beforeprint', onPrint); document[m]('contextmenu', onCtx, true);
    if (!on) setHidden(false);
  }
  function stageEl() { return $('groupsDialog'); }
  function onCtx(e) { var d = stageEl(); if (d && d.contains(e.target) && e.target.closest && e.target.closest('#grpViewer,.grp-tile')) e.preventDefault(); }
  function setHidden(on) { var d = stageEl(); if (d) d.classList.toggle('grp-cover', on); }
  function onVis() { setHidden(document.hidden || !document.hasFocus()); }
  function onBlur() { setHidden(true); }
  function onFocus() { setHidden(false); }
  function onPrint() { setHidden(true); violation('print'); }
  function onKey(e) {
    if (!st) return;
    touch();
    var k = String(e.key || ''), code = String(e.code || '');
    var shot = k === 'PrintScreen' || code === 'PrintScreen'
      || (e.metaKey && e.shiftKey && /^(Digit[345]|Key4)$/.test(code))
      || (e.metaKey && e.shiftKey && (k === 'S' || k === 's'))
      || ((e.ctrlKey || e.metaKey) && (k === 'p' || k === 'P'));
    if (shot) { e.preventDefault(); setHidden(true); violation('key:' + (k || code)); setTimeout(function () { setHidden(false); }, 1200); }
  }

  async function violation(reason) {
    if (!st) return;
    var policy = (st.group && st.group.policy) || 'block';
    if (policy !== 'block') { toast('info', 'Capturing this group is not allowed. This was logged.', 4200); log('violation', reason + ' (warned)'); return; }
    if (st.flagged) return;
    st.flagged = true;
    var vw = $('grpViewer'), wasOpen = !!vw && !vw.classList.contains('hidden');
    closeViewer(); revokeUrls();
    if (wasOpen) flagViewer();                       // the photo they were looking at becomes the middle finger, right now
    toast('error', 'Capture attempt caught. Your access to this group is paused.', 6000);
    try {
      var n = (st.my.violations || 0) + 1;
      await db().set('groups/' + st.gid + '/members/' + me.uid, { flagged: true, violations: n, lastViolation: iso() }, true);
      st.my.violations = n; await log('violation', reason);
    } catch (_) {}
    if (st) showGroup();
  }

  /* ------------------------------ members ------------------------------ */
  async function paneMembers(pane) {
    var box = h('div', { class: 'grp-list' }, h('p', { class: 'grp-note', text: 'Loading…' })); pane.appendChild(box);
    try {
      st.members = (await db().list('groups/' + st.gid + '/members')).sort(function (a, b) { return String(a.joinedAt).localeCompare(String(b.joinedAt)); });
      clear(box);
      for (var q = 0; q < st.members.length; q++) {
        var m = st.members[q], au = null;
        if (m.avatar) { try { au = await open(await nameKey(st.G), m.avatar, 'mavatar:' + m.uid); } catch (_) {} }
        var row = h('div', { class: 'grp-member', 'data-uid': m.uid }, avatarEl(au, m.name, 'md'),
          h('div', { class: 'grp-mi' }, h('b', { text: (m.name || 'Member') + (m.uid === me.uid ? ' (you)' : '') }), h('small', { text: m.role + ' \u00b7 joined ' + when(m.joinedAt) + (m.flagged ? ' \u00b7 flagged (' + (m.violations || 1) + ')' : '') })));
        var acts = h('div', { class: 'grp-acts' });
        if (m.flagged) acts.appendChild(h('span', { class: 'ak-chip warn', text: 'Paused' }));
        if (isAdmin() && m.uid !== me.uid && m.role !== 'owner') {
          if (m.flagged) acts.appendChild(h('button', { class: 'btn small', onclick: (function (mm) { return function () { memberOp(mm, 'clear'); }; })(m) }, 'Clear'));
          if (isOwner() && m.role === 'member') acts.appendChild(h('button', { class: 'btn small', onclick: (function (mm) { return function () { memberOp(mm, 'promote'); }; })(m) }, 'Make admin'));
          if (isOwner() && m.role === 'admin') acts.appendChild(h('button', { class: 'btn small quiet', onclick: (function (mm) { return function () { memberOp(mm, 'demote'); }; })(m) }, 'Remove admin'));
          if (isOwner() || m.role === 'member') acts.appendChild(h('button', { class: 'btn small quiet danger', onclick: (function (mm) { return function () { memberOp(mm, 'remove'); }; })(m) }, 'Remove'));
        }
        row.appendChild(acts); box.appendChild(row);
      }
    } catch (e) { clear(box); box.appendChild(msgBox(explain(e), 'error')); }
  }
  async function memberOp(m, op) {
    var path = 'groups/' + st.gid + '/members/' + m.uid, nm = m.name || 'this member';
    try {
      if (op === 'remove' && !window.confirm('Remove ' + nm + ' from the group? They stop receiving anything more, but cannot lose files they already saved.')) return;
      if (op === 'promote' && !window.confirm('Make ' + nm + ' an admin? Admins can upload, delete and manage members and invites.')) return;
      if (op !== 'clear') await stepUp();                       // fingerprint / face / PIN again for anything that changes who has power
      if (op === 'remove') { await db().del(path); await log('remove', nm); }
      else if (op === 'promote') { await db().set(path, { role: 'admin' }, true); await log('promote', nm); }
      else if (op === 'demote') { await db().set(path, { role: 'member' }, true); await log('demote', nm); }
      else if (op === 'clear') { await db().set(path, { flagged: false }, true); await log('clear', nm); }
      touch(); showGroup();
    } catch (e) { if (!(e && e.code === 'cancelled')) toast('error', explain(e), 6000); }
  }

  /* ------------------------------ invites ------------------------------ */
  async function paneInvites(pane) {
    var days = h('select', { class: 'acd-f', id: 'grpDays', 'aria-label': 'Valid for' }, h('option', { value: '1', text: '1 day', selected: true }), h('option', { value: '7', text: '7 days' }), h('option', { value: '30', text: '30 days' }));
    var uses = h('select', { class: 'acd-f', id: 'grpUses', 'aria-label': 'How many people can use it' }, h('option', { value: '1', text: 'One person (safest)', selected: true }), h('option', { value: '5', text: 'Up to 5 people' }), h('option', { value: '25', text: 'Up to 25 people' }), h('option', { value: '0', text: 'Anyone with the code until it expires' }));
    pane.appendChild(h('div', { class: 'grp-card' }, h('b', { text: 'Invite someone' }), h('small', { text: 'A one-person code switches itself off as soon as someone joins. You can only see a code the moment you make it.' }), h('small', { text: 'Valid for' }), days, h('small', { text: 'Who can use it' }), uses,
      h('button', { class: 'btn primary', id: 'grpMkInvite', onclick: function () { doInvite(parseInt(days.value, 10), parseInt(uses.value, 10)); } }, 'Create invite code')));
    pane.appendChild(h('div', { id: 'grpNewCode' }));
    var list = h('div', { class: 'grp-list', id: 'grpInvList' }, h('p', { class: 'grp-note', text: 'Loading…' })); pane.appendChild(h('h3', { class: 'grp-h', text: 'Active codes' })); pane.appendChild(list);
    try {
      var inv = (await db().list('groups/' + st.gid + '/invites', { orderBy: 'createdAt', dir: 'desc' })).filter(function (i) { return i.active && i.expiresAt > Date.now(); });
      // the live use-count and on/off state are kept on the invite itself (joiners update it), so read that
      inv = (await Promise.all(inv.map(async function (i) { try { var m = await db().get('invites/' + i.id); return m ? Object.assign({}, i, { active: m.active, uses: m.uses || 0, maxUses: m.maxUses || 0 }) : null; } catch (_) { return i; } }))).filter(function (i) { return i && i.active; });
      clear(list);
      if (!inv.length) list.appendChild(h('p', { class: 'grp-note', text: 'No active codes.' }));
      inv.forEach(function (i) { list.appendChild(h('div', { class: 'grp-member' }, h('div', { class: 'grp-mi' }, h('b', { text: 'Code ending ' + i.id.slice(-4) }), h('small', { text: 'expires ' + when(i.expiresAt) + (i.maxUses > 0 ? ' \u00b7 used ' + (i.uses || 0) + ' of ' + i.maxUses : ' \u00b7 no use limit') })), h('div', { class: 'grp-acts' }, h('button', { class: 'btn small quiet danger', onclick: function () { revokeInvite(i); } }, 'Turn off')))); });
    } catch (e) { clear(list); list.appendChild(msgBox(explain(e), 'error')); }
  }
  async function doInvite(days, maxUses) {
    var btn = $('grpMkInvite'); btn.disabled = true;
    try {
      var I = bytes(20), id = await inviteId(I), code = groups4(b32(I)), exp = Date.now() + days * 86400000, now = iso();
      var w = await seal(await inviteKey(I), st.G);
      var inv0 = { gid: st.gid, gname: st.group.name, active: true, expiresAt: exp, createdBy: me.uid, createdAt: now, wrapped: w, v: 1 }; if (maxUses > 0) inv0.maxUses = maxUses;
      await db().set('invites/' + id, inv0);
      await db().set('groups/' + st.gid + '/invites/' + id, { id: id, active: true, expiresAt: exp, createdBy: me.uid, createdAt: now });
      await log('invite', 'code ' + id.slice(-4));
      var box = $('grpNewCode'); clear(box);
      box.appendChild(h('div', { class: 'grp-card' }, h('b', { text: 'Share this code' }), h('div', { class: 'ck-code', id: 'grpCodeText', text: code }),
        h('div', { class: 'acd-actions' }, h('button', { class: 'btn small', onclick: function () { try { navigator.clipboard.writeText(code); toast('ok', 'Code copied.', 2000); } catch (_) {} } }, 'Copy')),
        h('small', { text: 'It will not be shown again. ' + (maxUses === 1 ? 'One person can join with it' : maxUses > 0 ? 'Up to ' + maxUses + ' people can join with it' : 'Anyone with it can join') + ' until ' + when(exp) + '.' })));
    } catch (e) { toast('error', explain(e), 6000); }
    btn.disabled = false;
  }
  async function revokeInvite(i) {
    try { await db().set('invites/' + i.id, { active: false }, true); await db().set('groups/' + st.gid + '/invites/' + i.id, { active: false }, true); await log('invite-off', 'code ' + i.id.slice(-4)); showGroup(); }
    catch (e) { toast('error', explain(e), 6000); }
  }

  /* ------------------------------ settings ------------------------------ */
  function toggleRow(id, title, sub, on, onChange) {
    var inp = h('input', { type: 'checkbox', id: id }); inp.checked = !!on;
    inp.addEventListener('change', function () { onChange(inp.checked); });
    return h('label', { class: 'switch-row gp-switch' }, h('span', { class: 'switch' }, inp, h('span', { class: 'switch-track' }), h('span', { class: 'switch-thumb' })), h('span', { class: 'dl-text' }, h('b', { text: title }), h('span', { text: sub })));
  }
  /* ---- safety presets: one tap sets a consistent, stronger-or-weaker set of rules ---- */
  var PRESETS = {
    relaxed: { label: 'Relaxed', note: 'Friends and family. Members can add files, small name tag, 10-minute auto-lock, a caught capture only warns.', s: { memberUpload: true, vaultShare: true, watermark: 'corner', idleMin: 10 }, policy: 'warn' },
    standard: { label: 'Standard', note: 'Everyday groups. Admins add files, small name tag, 3-minute auto-lock, a caught capture pauses the member.', s: { memberUpload: false, vaultShare: true, watermark: 'corner', idleMin: 3 }, policy: 'block' },
    strict: { label: 'Strict', note: 'Sensitive material. Full name pattern on media, 1-minute auto-lock, no Vault sharing, a caught capture pauses the member.', s: { memberUpload: false, vaultShare: false, watermark: 'full', idleMin: 1 }, policy: 'block' }
  };
  function currentPreset() {
    var p0 = st.group.policy || 'block', ks = ['memberUpload', 'vaultShare', 'watermark', 'idleMin'];
    for (var k in PRESETS) { var p = PRESETS[k], same = p0 === p.policy; ks.forEach(function (f) { if ((st.settings[f] == null ? DEFAULTS[f] : st.settings[f]) !== p.s[f]) same = false; }); if (same) return k; }
    return 'custom';
  }
  function presetCard() {
    var cur = currentPreset(), row = h('div', { class: 'gp-presets', role: 'radiogroup', 'aria-label': 'Safety level' });
    Object.keys(PRESETS).forEach(function (k) {
      var p = PRESETS[k];
      row.appendChild(h('button', { type: 'button', role: 'radio', class: 'gp-preset' + (cur === k ? ' on' : ''), 'aria-checked': cur === k ? 'true' : 'false', 'data-preset': k, onclick: function () { applyPreset(k); } }, h('b', { text: p.label }), h('small', { text: p.note })));
    });
    return h('div', { class: 'grp-card', id: 'gpPresetCard' }, h('b', { text: 'Safety level' }), h('small', { text: cur === 'custom' ? 'Your settings do not match a preset (they are custom).' : 'Pick one to set every protection below at once. You can still fine-tune afterwards.' }), row);
  }
  async function applyPreset(k) {
    var p = PRESETS[k]; if (k === currentPreset()) return;
    try {
      await stepUp();
      var next = Object.assign({}, st.settings, p.s);
      await db().set('groups/' + st.gid, { settings: next, policy: p.policy }, true);
      st.settings = next; st.group.settings = next; st.group.policy = p.policy;
      await log('policy', p.label); toast('ok', p.label + ' safety level applied.', 2400); touch(); showGroup();
    } catch (e) { if (!(e && e.code === 'cancelled')) toast('error', explain(e), 6000); }
  }
  async function toggleFreeze() {
    var freeze = st.group.frozen !== true;
    if (freeze && !window.confirm('Freeze "' + st.group.name + '"? Every other member is refused until you unfreeze it.')) return;
    try {
      await stepUp();
      await db().set('groups/' + st.gid, { frozen: freeze }, true); st.group.frozen = freeze;
      await log(freeze ? 'freeze' : 'unfreeze', ''); if (navigator.vibrate && navigator.userActivation && navigator.userActivation.hasBeenActive) try { navigator.vibrate(freeze ? [30, 40, 30] : 12); } catch (_) {} toast('ok', freeze ? 'Group frozen.' : 'Group unfrozen.', 2600); touch(); showGroup();
    } catch (e) { if (!(e && e.code === 'cancelled')) toast('error', explain(e), 6000); }
  }
  async function saveSettings(patch, quiet) {
    try {
      var next = Object.assign({}, st.settings, patch);
      await db().set('groups/' + st.gid, { settings: next }, true); st.settings = next; st.group.settings = next;
      var pc = $('gpPresetCard'); if (pc && pc.parentNode) pc.parentNode.replaceChild(presetCard(), pc);   // the safety level follows hand changes (it becomes "custom")
      if (!quiet) toast('ok', 'Saved.', 1600); touch();
    } catch (e) { toast('error', explain(e), 6000); showGroup(); }
  }
  function paneSettings(pane) {
    pane.appendChild(h('div', { class: 'grp-card' }, h('b', { text: 'About this group' }),
      h('small', { text: 'Your role: ' + st.role + '. Everything here is encrypted with a key only members can open. Admins can delete files, but cannot read what was not shared with the group.' })));
    if (isAdmin()) {
      var nameIn = h('input', { class: 'acd-f', id: 'grpRename', maxlength: '40', value: st.group.name, 'aria-label': 'Group name' });
      var descIn = h('textarea', { class: 'acd-f', id: 'grpDesc', maxlength: '300', rows: '3', placeholder: 'Describe the group (only members can read this)', 'aria-label': 'Description' }); descIn.value = st.desc || '';
      var changeGroupPic = async function () {
        try {
          var r = await window.AbagusAvatar.edit({ title: 'Group picture', hasCurrent: !!st.gAvatar }); if (r == null) return;
          if (r === 'remove') { await db().set('groups/' + st.gid, { avatar: null }, true); st.gAvatar = null; }
          else { await db().set('groups/' + st.gid, { avatar: await seal(await nameKey(st.G), r, 'gavatar') }, true); st.gAvatar = r; }
          toast('ok', r === 'remove' ? 'Group picture removed.' : 'Group picture saved.', 2200); showGroup();
        } catch (e) { toast('error', explain(e), 5000); }
      };
      pane.appendChild(h('div', { class: 'grp-card' }, h('b', { text: 'Group profile' }),
        h('div', { class: 'gp-pic-row' }, avatarEl(st.gAvatar, st.group.name, 'lg'), h('button', { class: 'btn small', id: 'grpAvatarBtn', onclick: changeGroupPic }, st.gAvatar ? 'Change picture' : 'Add picture'),
          st.gAvatar ? h('button', { class: 'btn small quiet', onclick: async function () { try { await db().set('groups/' + st.gid, { avatar: null }, true); st.gAvatar = null; showGroup(); } catch (e) { toast('error', explain(e)); } } }, 'Remove') : null),
        nameIn, descIn,
        h('button', { class: 'btn small', id: 'grpSaveProfile', onclick: async function () {
          var nn = nameIn.value.trim(); if (nn.length < 2 || nn.length > 40) { toast('error', 'Name must be 2 to 40 characters.'); return; }
          try { await db().set('groups/' + st.gid, { name: nn, descEnc: await seal(await nameKey(st.G), enc.encode(descIn.value.trim().slice(0, 300)), 'desc') }, true); st.group.name = nn; st.desc = descIn.value.trim(); toast('ok', 'Saved.', 1800); showGroup(); }
          catch (e) { toast('error', explain(e), 6000); } } }, 'Save')));
      pane.appendChild(h('div', { class: 'grp-card' }, h('b', { text: 'Permissions' }),
        toggleRow('setMemberUpload', 'Members can upload', 'Off: only admins upload. On: any member can add photos and videos, and delete their own.', st.settings.memberUpload, function (v) { saveSettings({ memberUpload: v }); }),
        toggleRow('setVaultShare', 'Share locked files from the Vault', 'Allows an admin to encrypt a file in the Vault with \u201cGroup\u201d as the unlock method and send it here. Every member opens it with their fingerprint.', st.settings.vaultShare, function (v) { saveSettings({ vaultShare: v }); })));
      var sel = h('select', { class: 'acd-f', id: 'grpPolicy', 'aria-label': 'When a capture attempt is caught' }, h('option', { value: 'block', text: 'Pause the member\u2019s access (recommended)' }), h('option', { value: 'warn', text: 'Warn and log only' }));
      sel.value = st.group.policy || 'block';
      var idle = h('select', { class: 'acd-f', id: 'grpIdle', 'aria-label': 'Auto-lock' }, h('option', { value: '1', text: 'After 1 minute' }), h('option', { value: '3', text: 'After 3 minutes' }), h('option', { value: '10', text: 'After 10 minutes' }));
      idle.value = String(st.settings.idleMin || 3);
      idle.addEventListener('change', function () { saveSettings({ idleMin: parseInt(idle.value, 10) }); });
      var wmSel = h('select', { class: 'acd-f', id: 'grpWm', 'aria-label': 'Name tag on photos and videos' }, h('option', { value: 'corner', text: 'Small tag in the corner (recommended)' }), h('option', { value: 'full', text: 'Full pattern across the picture' }), h('option', { value: 'off', text: 'Off' }));
      wmSel.value = wmMode(); wmSel.addEventListener('change', function () { saveSettings({ watermark: wmSel.value }); });
      pane.appendChild(presetCard());
      pane.appendChild(h('div', { class: 'grp-card' }, h('b', { text: 'Protection' }), h('small', { text: 'When a capture attempt is caught' }), sel,
        h('button', { class: 'btn small', onclick: async function () { try { await db().set('groups/' + st.gid, { policy: sel.value }, true); st.group.policy = sel.value; toast('ok', 'Saved.', 1800); } catch (e) { toast('error', explain(e), 6000); } } }, 'Save'),
        h('small', { text: 'Name tag on photos and videos' }), wmSel,
        h('small', { text: 'Lock the group on this device' }), idle));
      pane.appendChild(h('div', { class: 'grp-card' }, h('b', { text: 'Activity' }), h('div', { id: 'grpLog', class: 'grp-log' }, h('small', { text: 'Loading…' }))));
      loadLog();
    }
    if (isOwner()) {
      var pubIn = h('textarea', { class: 'acd-f', id: 'grpPubDesc', maxlength: '140', rows: '2', placeholder: 'One public line about the group (optional)', 'aria-label': 'Public description' }); pubIn.value = st.group.publicDesc || '';
      var discRow = toggleRow('setDiscoverable', 'List this group in Discover', 'Off by default. When on, anyone signed in can see only the group name, the public line below, the member count, the file count and when it was created. Nobody can see members, files, invite codes or the private description, and joining still needs an invite code.', st.group.discoverable === true, async function (v) {
        var box = $('setDiscoverable');
        try { await stepUp(); await db().set('groups/' + st.gid, { discoverable: v }, true); st.group.discoverable = v; await log('policy', v ? 'listed in Discover' : 'removed from Discover'); toast('ok', v ? 'Listed in Discover. It can take a few seconds to appear.' : 'Removed from Discover.', 3200); }
        catch (e) { if (box) box.checked = !v; toast('error', explain(e), 6000); }
      });
      pane.appendChild(h('div', { class: 'grp-card', id: 'grpDiscoverCard' }, h('b', { text: 'Discoverability' }), discRow, h('small', { text: 'Public line (140 characters, visible to everyone signed in while listed)' }), pubIn,
        h('button', { class: 'btn small', id: 'grpPubSave', onclick: async function () { try { await db().set('groups/' + st.gid, { publicDesc: pubIn.value.trim().slice(0, 140) }, true); st.group.publicDesc = pubIn.value.trim().slice(0, 140); toast('ok', 'Saved.', 1800); } catch (e) { toast('error', explain(e), 6000); } } }, 'Save public line')));
    }
    if (isOwner()) pane.appendChild(h('div', { class: 'grp-card gp-panic' }, h('b', { text: 'Emergency freeze' }),
      h('small', { text: st.group.frozen === true ? 'The group is frozen: members cannot open or add files and nobody can join. Files and members are untouched.' : 'If you think a phone or an account is compromised, freeze the group. Every member except you is refused at once. Nothing is deleted, and you can unfreeze at any time.' }),
      h('button', { class: 'btn small ' + (st.group.frozen === true ? 'primary' : 'danger'), id: 'grpFreeze', onclick: toggleFreeze }, st.group.frozen === true ? 'Unfreeze group' : 'Freeze group now')));
    if (isOwner()) pane.appendChild(h('div', { class: 'grp-card' }, h('b', { text: 'Delete this group' }), h('small', { text: 'Removes every file and member. This cannot be undone.' }), h('button', { class: 'btn small quiet danger', id: 'grpDeleteGroup', onclick: deleteGroup }, 'Delete group')));
    else pane.appendChild(h('div', { class: 'grp-card' }, h('b', { text: 'Leave this group' }), h('button', { class: 'btn small quiet danger', onclick: leaveGroup }, 'Leave group')));
  }
  async function loadLog() {
    var box = $('grpLog'); if (!box || !st) return;
    try {
      var rows = (await db().list('groups/' + st.gid + '/log', { orderBy: 't', dir: 'desc' })).slice(0, 30); clear(box);
      for (var q = 0; q < rows.length; q++) if (rows[q].detailEnc) { try { rows[q].detail = dec.decode(await open(await nameKey(st.G), rows[q].detailEnc, 'log')); } catch (_) { rows[q].detail = ''; } }
      if (!rows.length) box.appendChild(h('small', { text: 'Nothing yet.' }));
      rows.forEach(function (r) { box.appendChild(h('div', { class: 'grp-logrow' + (r.type === 'violation' ? ' bad' : '') }, h('b', { text: r.type }), h('span', { text: ' ' + (r.name || '') + (r.detail ? ' \u00b7 ' + r.detail : '') }), h('small', { text: ' ' + when(r.t) }))); });
    } catch (e) { clear(box); box.appendChild(h('small', { text: explain(e) })); }
  }
  async function leaveGroup() {
    if (!window.confirm('Leave this group?')) return;
    try { await db().del('groups/' + st.gid + '/members/' + me.uid); await db().del('users/' + me.uid + '/groups/' + st.gid); lockGroup(false); toast('info', 'You left the group.', 3000); }
    catch (e) { toast('error', explain(e), 6000); }
  }
  async function deleteGroup() {
    if (!window.confirm('Delete "' + st.group.name + '" and every file in it for everyone? This cannot be undone.')) return;
    var btn = $('grpDeleteGroup'); btn.disabled = true;
    try {
      await stepUp();
      var gid = st.gid, files = await db().list('groups/' + gid + '/files');
      for (var i = 0; i < files.length; i++) {
        for (var j = 0; j < files[i].chunks; j++) await db().del('groups/' + gid + '/files/' + files[i].id + '/chunks/' + j);
        try { await db().del('groups/' + gid + '/thumbs/' + files[i].id); } catch (_) {}
        await db().del('groups/' + gid + '/files/' + files[i].id);
      }
      var inv = await db().list('groups/' + gid + '/invites');
      for (var k = 0; k < inv.length; k++) { try { await db().del('invites/' + inv[k].id); } catch (_) {} await db().del('groups/' + gid + '/invites/' + inv[k].id); }
      var logs = await db().list('groups/' + gid + '/log'); for (var l = 0; l < logs.length; l++) await db().del('groups/' + gid + '/log/' + logs[l].id);
      var mem = await db().list('groups/' + gid + '/members');
      for (var m = 0; m < mem.length; m++) if (mem[m].uid !== me.uid) await db().del('groups/' + gid + '/members/' + mem[m].uid);
      await db().del('groups/' + gid); await db().del('groups/' + gid + '/members/' + me.uid);
      try { await db().del('users/' + me.uid + '/groups/' + gid); } catch (_) {}
      lockGroup(false); toast('ok', 'Group deleted.', 3000);
    } catch (e) { toast('error', explain(e), 7000); btn.disabled = false; }
  }

  /* ------------------------------ Vault integration (index.html) ------------------------------ */
  // Groups where this person may put a locked file: admins, or members when uploads are allowed, and only if sharing is on.
  async function shareableGroups() {
    if (!me.uid) return [];
    var out = [], mine = await db().list('users/' + me.uid + '/groups');
    for (var i = 0; i < mine.length; i++) {
      try {
        var g = await getOrNull('groups/' + mine[i].gid), my = g && await getOrNull('groups/' + mine[i].gid + '/members/' + me.uid);
        if (!g || !my || my.flagged) continue;
        var s = Object.assign({}, DEFAULTS, g.settings || {});
        if (s.vaultShare && (my.role === 'owner' || my.role === 'admin' || s.memberUpload)) out.push({ gid: mine[i].gid, name: g.name });
      } catch (_) {}
    }
    return out;
  }
  async function keyFor(gid) {
    var c = keyCache[gid];
    if (c && Date.now() - c.t < 60000) return { G: c.G, kid: await groupKid(gid) };
    var o = await openGroupKey(gid);
    if (o.my.flagged === true) throw fail('Your access to this group is paused, so its key cannot be used.', 'flagged');
    keyCache[gid] = { G: o.G, t: Date.now() };
    return { G: o.G, kid: await groupKid(gid) };
  }
  async function keyForKid(kid) {
    if (!me.uid) { if (window.AbagusAccount) window.AbagusAccount.open('signin'); throw fail('Sign in first. This file is locked with a group key.', 'need-signin'); }
    var want = hex(kid), mine = await db().list('users/' + me.uid + '/groups');
    for (var i = 0; i < mine.length; i++) if (hex(await groupKid(mine[i].gid)) === want) return keyFor(mine[i].gid);
    throw fail('You are not a member of the group this file was locked for.', 'not-member');
  }
  async function shareVault(gid, parts, files) {
    var k = await keyFor(gid), blob = new Blob(parts, { type: 'application/octet-stream' });
    var base = files && files.length === 1 ? files[0].name : 'batch-' + (files ? files.length : 0) + '-files';
    if (blob.size > MAX_FILE) throw fail('That locked file is over 120 MB, so it cannot be sent to a group.');
    await putFile(gid, k.G, blob, base + '.locked', 'vault', 'application/octet-stream', null, null);
    try { await db().set('groups/' + gid + '/log/' + hex(bytes(8)), { t: iso(), uid: me.uid, name: me.name || '', type: 'upload', detail: '', detailEnc: await seal(await nameKey(k.G), enc.encode(base + '.locked'), 'log') }); } catch (_) {}
  }

  /* ------------------------------ wiring ------------------------------ */
  async function takeHandoff() {                    // index.html: a locked file arrived from a group
    var flag = null; try { flag = sessionStorage.getItem('abagus-handoff'); sessionStorage.removeItem('abagus-handoff'); } catch (_) {}
    if (!flag || typeof window.applyUnlockFile !== 'function') return;
    try {
      var item = await handoffTake(); if (!item) return;
      var t = $('tabUnlockBtn'); if (t) t.click();
      window.applyUnlockFile(new File([item.blob], item.name || 'group-file.locked', { type: 'application/octet-stream' }));
      toast('info', 'Locked file loaded. Press Unlock and confirm with your fingerprint.', 6000);
    } catch (_) {}
  }
  function wire() {
    var c = $('grpClose'); if (c) c.addEventListener('click', function () { lockGroup(false); });
    window.addEventListener('abagus:user', function (e) {
      var u = e.detail || {};
      var changed = u.uid !== me.uid;
      me = { uid: u.uid || null, phone: u.phone || null, google: !!u.google, name: u.name || null, avatar: changed ? null : me.avatar, avatarV: changed ? 0 : me.avatarV };
      document.querySelectorAll('[data-groups-open]').forEach(function (b) { b.classList.toggle('hidden', !me.uid); });
      if (changed && st) lockGroup(false);
      if ($('grpBody') && !st) showList();
    });
    document.addEventListener('keydown', viewerKeys); viewerSwipe();
    if ($('grpBody')) showList();
    window.addEventListener('load', function () { setTimeout(takeHandoff, 300); });
  }
  /* ---- entrance animation: anything that appears inside the page rises in, one after another (CSS handles reduced motion) ---- */
  (function () {
var SEL = '.grp-tile,.grp-row,.grp-member,.grp-card,.gp-preset,.gp-banner,.gp-profile,.gp-frozen';
function mark(el) {
  if (el.nodeType !== 1) return;
  var list = el.matches && el.matches(SEL) ? [el] : []; if (el.querySelectorAll) list = list.concat(Array.prototype.slice.call(el.querySelectorAll(SEL)));
  list.forEach(function (n, i) { if (n.classList.contains('gp-in')) return; n.style.setProperty('--i', String(Math.min(i, 14))); n.classList.add('gp-in'); });
}
function start() { var r = document.querySelector('.gp-root'); if (!r || !window.MutationObserver) return; new MutationObserver(function (ms) { ms.forEach(function (m) { m.addedNodes.forEach(mark); }); }).observe(r, { childList: true, subtree: true }); }
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
  })();
  window.AbagusGroups = { open: function () { if ($('grpBody')) showList(); }, shareableGroups: shareableGroups, keyFor: keyFor, keyForKid: keyForKid, shareVault: shareVault, kidOf: groupKid,
    _b32: b32, _unb32: unb32, _lock: function () { lockGroup(); }, _limits: { MAX_FILE: MAX_FILE, CHUNK: CHUNK } };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', wire); else wire();
})();
