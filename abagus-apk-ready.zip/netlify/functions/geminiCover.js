// Netlify Function: Gemini cover picture. The key lives ONLY in Netlify's environment variable GEMINI_API_KEY.
// Accepts only { topic: 0..44 }; the prompt is built here, so nothing about the user's file or passphrase is ever sent.
const TOPICS = ["Misty mountain sunrise", "Quiet lakeside cabin", "Neon rainy city street", "Desert dunes at dusk", "Northern lights over snow", "Tropical beach lagoon", "Ancient stone library", "Cherry blossom garden", "Floating lantern festival", "Deep ocean coral reef", "Autumn forest path", "Starry night observatory", "Old lighthouse in a storm", "Rice terraces at dawn", "Snowy village rooftops", "Cozy bookshop window", "Hot air balloons at sunrise", "Bamboo forest mist", "Vintage train station", "Waterfall in a jungle", "Lavender fields", "Moonlit castle ruins", "Futuristic harbor skyline", "Glacier ice cave", "Sunflower meadow", "Paper boats on a river", "Mountain monastery clouds", "Fireflies in a meadow", "Canyon river bend", "Candlelit stone corridor", "Spring greenhouse", "Volcanic island coast", "Wooden bridge in fog", "Market street at golden hour", "Space station window view", "Zen rock garden", "Windmill on green hills", "Underwater kelp forest", "City rooftop at twilight", "Alpine meadow flowers", "Aurora over a calm fjord", "Lotus pond morning", "Stone arch by the sea", "Cloud sea above peaks", "Rainy window with city bokeh"];
const SITES = ['https://abagus.netlify.app'];
const H = { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' };
exports.handler = async (event) => {
  const o = event.headers.origin;
  if (o && !SITES.includes(o) && !/^http:\/\/localhost:\d+$/.test(o) && !/^https:\/\/[a-z0-9-]+--abagus\.netlify\.app$/.test(o)) return { statusCode: 403, headers: H, body: '{"error":"forbidden"}' };
  if (event.httpMethod !== 'POST') return { statusCode: 405, headers: H, body: '{"error":"method"}' };
  let i = -1; try { i = Number(JSON.parse(event.body || '{}').topic); } catch (e) {}
  if (!Number.isInteger(i) || i < 0 || i >= TOPICS.length) return { statusCode: 400, headers: H, body: '{"error":"topic"}' };
  const key = process.env.GEMINI_API_KEY;
  if (!key) return { statusCode: 503, headers: H, body: '{"error":"not configured"}' };
  try {
    const r = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-image:generateContent', {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
      body: JSON.stringify({ contents: [{ parts: [{ text: 'A beautiful, calm, photographic landscape-format picture: ' + TOPICS[i] + '. No text, no people, no logos.' }] }], generationConfig: { responseModalities: ['IMAGE'] } }),
    });
    if (!r.ok) throw new Error('Gemini ' + r.status);
    const p = ((await r.json()).candidates?.[0]?.content?.parts || []).find((x) => x.inlineData || x.inline_data);
    const d = p && (p.inlineData || p.inline_data);
    if (!d || !d.data) throw new Error('no image');
    return { statusCode: 200, headers: H, body: JSON.stringify({ image: d.data, mime: d.mimeType || d.mime_type || 'image/png' }) };
  } catch (e) { return { statusCode: 502, headers: H, body: '{"error":"unavailable"}' }; }
};
