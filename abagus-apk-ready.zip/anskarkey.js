/* =====================================================================
   ABAGUS — AnskarKey and device lock.

   Two extra ways to protect a file, on top of the passphrase:

   AnskarKey     No passphrase. The phone or computer's own passkey (fingerprint, face or
                 screen-lock PIN) produces a secret through the WebAuthn "PRF" extension.
                 That secret is what the vault ciphers are keyed from. Abagus never sees a
                 biometric, and the secret never leaves this tab.

   Device lock   A random HMAC key is created inside this browser and stored as a
                 NON-EXTRACTABLE CryptoKey (IndexedDB). It can be used to sign but never
                 read out, so a file locked with it cannot be opened anywhere else.
                 It can be used alone with a passphrase, or together with an AnskarKey.

   This file sits OUTSIDE the pinned crypto core. It only produces a secret string that the
   core feeds to its existing PBKDF2 -> Argon2id -> HKDF chain, and a small clear-text
   extension block (credential id + device tag, neither secret) written after the header.

   File format: version 7, header identical to v6. Flags byte:  0x10 = AnskarKey,
   0x20 = device lock. After the 65-byte header comes  u16 length + extension body:
       u8  1                      body version
       u16 credentialIdLength     (0 when the AnskarKey flag is off)
       ..  credentialId
       u8  deviceTagLength        (0 when the device flag is off, otherwise 8)
       ..  deviceTag
   Files without these flags stay version 6 and are byte-for-byte what they were before.
   ===================================================================== */
(function () {
  'use strict';

  var FLAG_ANSKAR = 0x10, FLAG_DEVICE = 0x20, FLAG_CLOUD = 0x40, FLAG_GROUP = 0x80;   // 0x80: locked with a group key (every member can open it)   // 0x40: key held by the person's Abagus account (see cloudkey.js)
  var HEADER_V7 = 65;                       // fixed header length of v5-v7 files
  var LS_CRED = 'abagus-anskarkey-v1';      // { credentialId, createdAt, rpId }
  var LS_LEGACY = 'abagus-device-passkey-v1';
  var LS_SKIP = 'abagus-anskarkey-skip';    // set when the user chose Forget here, so sign-in does not bring it back
  var DB_NAME = 'abagus-device', DB_STORE = 'k', DB_KEY = 'device';
  var enc = new TextEncoder();

  /* ------------------------------ helpers ------------------------------ */
  function $(id) { return document.getElementById(id); }
  function bytes(n) { var a = new Uint8Array(n); crypto.getRandomValues(a); return a; }
  function b64u(buf) {
    var a = new Uint8Array(buf), s = '';
    for (var i = 0; i < a.length; i++) s += String.fromCharCode(a[i]);
    return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }
  function fromB64u(s) {
    s = s.replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '=';
    var b = atob(s), a = new Uint8Array(b.length);
    for (var i = 0; i < b.length; i++) a[i] = b.charCodeAt(i);
    return a;
  }
  function concat() {
    var n = 0, i, o = 0, out;
    for (i = 0; i < arguments.length; i++) n += arguments[i].length;
    out = new Uint8Array(n);
    for (i = 0; i < arguments.length; i++) { out.set(arguments[i], o); o += arguments[i].length; }
    return out;
  }
  function same(a, b) {
    if (!a || !b || a.length !== b.length) return false;
    var d = 0; for (var i = 0; i < a.length; i++) d |= a[i] ^ b[i];
    return d === 0;
  }
  function akError(message, code) { var e = new Error(message); e.anskar = true; e.code = code || 'anskar'; return e; }
  function readLS(k) { try { return JSON.parse(localStorage.getItem(k) || 'null'); } catch (_) { return null; } }
  function writeLS(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (_) {} }
  function dropLS(k) { try { localStorage.removeItem(k); } catch (_) {} }
  function toast(type, msg, ms) { if (typeof window.showToast === 'function') window.showToast(type, msg, ms || 4200); }

  function supported() {
    return !!(window.PublicKeyCredential && navigator.credentials && window.isSecureContext);
  }
  async function platformReady() {
    try {
      if (PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable)
        return await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
    } catch (_) {}
    return true;
  }
  var busyCount = 0;
  function busy(on) {
    busyCount = Math.max(0, busyCount + (on ? 1 : -1));
    var w = busyCount > 0;
    document.querySelectorAll('.ak-ic').forEach(function (e) { e.classList.toggle('waiting', w); });
    ['lockAkWait', 'unlockAkWait'].forEach(function (id) { var el = $(id); if (el) el.classList.toggle('hidden', !w); });
  }
  function friendly(e, fallback) {
    if (e && e.anskar) return e;
    var n = e && e.name;
    if (n === 'NotAllowedError' || n === 'AbortError')
      return akError('AnskarKey was cancelled, timed out, or this device does not hold that passkey. If the file was made on another phone, sign in to the same Google or Apple account, or choose \u201cUse a phone or tablet\u201d.', 'cancelled');
    if (n === 'SecurityError')
      return akError('AnskarKey only works on the secure address this site is served from (https).', 'security');
    if (n === 'InvalidStateError')
      return akError('A passkey for Abagus already exists on this device. Use it, or remove it first.', 'exists');
    if (n === 'NotSupportedError')
      return akError('This browser or device cannot make this kind of passkey.', 'unsupported');
    return akError(fallback || 'AnskarKey could not be used on this device.', 'failed');
  }

  /* --------------------------- AnskarKey (PRF) --------------------------- */
  function savedCred() { var r = readLS(LS_CRED); return r && r.credentialId ? r : null; }

  async function prfSalt(fileSalt) {
    return new Uint8Array(await crypto.subtle.digest('SHA-256', concat(enc.encode('abagus/anskarkey/v1'), fileSalt)));
  }
  async function prfSecret(credId, fileSalt) {
    var opts = {
      challenge: bytes(32), rpId: location.hostname, userVerification: 'required', timeout: 60000,
      allowCredentials: credId ? [{ type: 'public-key', id: credId }] : [],
      extensions: { prf: { eval: { first: await prfSalt(fileSalt) } } }
    };
    var a;
    busy(true);
    try { a = await navigator.credentials.get({ publicKey: opts }); }
    catch (e) { throw friendly(e); }
    finally { busy(false); }
    if (!a) throw akError('No passkey was returned.', 'failed');
    var r = a.getClientExtensionResults ? a.getClientExtensionResults() : {};
    if (!r.prf || !r.prf.results || !r.prf.results.first)
      throw akError('This passkey cannot produce an encryption key. Update the browser, or set up AnskarKey again on a device that supports it.', 'prf-missing');
    return { secret: new Uint8Array(r.prf.results.first), credentialId: new Uint8Array(a.rawId) };
  }

  async function enroll() {
    if (!supported()) throw akError('AnskarKey needs a secure page (https) and a browser with passkeys.', 'unsupported');
    if (!(await platformReady())) throw akError('This device did not report a fingerprint, face or screen-lock method. Turn on a screen lock and try again.', 'no-authenticator');
    var cred;
    busy(true);
    try {
      cred = await navigator.credentials.create({
        publicKey: {
          challenge: bytes(32),
          rp: { name: 'Abagus', id: location.hostname },
          user: { id: bytes(16), name: 'anskarkey', displayName: 'AnskarKey' },
          pubKeyCredParams: [{ type: 'public-key', alg: -7 }, { type: 'public-key', alg: -257 }],
          authenticatorSelection: { residentKey: 'required', requireResidentKey: true, userVerification: 'required' },
          extensions: { prf: {} }, timeout: 60000, attestation: 'none'
        }
      });
    } catch (e) { throw friendly(e); }
    finally { busy(false); }
    if (!cred) throw akError('No passkey was created.', 'failed');
    var credId = new Uint8Array(cred.rawId);
    var ext = cred.getClientExtensionResults ? cred.getClientExtensionResults() : {};
    var ok = !!(ext.prf && (ext.prf.enabled || (ext.prf.results && ext.prf.results.first)));
    if (!ok) {   // some authenticators only report support when asked for a value
      try { await prfSecret(credId, new Uint8Array(16)); ok = true; } catch (_) { ok = false; }
    }
    if (!ok) throw akError('This device or browser cannot turn a passkey into an encryption key (PRF is not supported). Chrome 128+ on Android, recent Chrome or Edge on desktop, or Safari 18 can.', 'prf-unsupported');
    var rec = { credentialId: b64u(credId), createdAt: new Date().toISOString(), rpId: location.hostname, version: 1 };
    writeLS(LS_CRED, rec); dropLS(LS_LEGACY); dropLS(LS_SKIP);
    try { window.dispatchEvent(new CustomEvent('abagus:anskar', { detail: { credentialId: rec.credentialId, createdAt: rec.createdAt } })); } catch (_) {}
    return rec;
  }
  async function testAnskar() {
    var rec = savedCred(); if (!rec) throw akError('Set up AnskarKey first.', 'none');
    await prfSecret(fromB64u(rec.credentialId), new Uint8Array(16));
    return true;
  }
  function forgetAnskar() { dropLS(LS_CRED); dropLS(LS_LEGACY); writeLS(LS_SKIP, 1); }
  /* Sign-in on a new device: the account remembers the passkey's (non-secret) id, so this device can use it. */
  function adopt(credentialId, createdAt) {
    if (savedCred() || readLS(LS_SKIP) || !credentialId) return false;
    writeLS(LS_CRED, { credentialId: credentialId, createdAt: createdAt || new Date().toISOString(), rpId: location.hostname, version: 1, adopted: true });
    paintAll(); paintMethod();
    return true;
  }
  function credentialInfo() { var r = savedCred(); return r ? { credentialId: r.credentialId, createdAt: r.createdAt, adopted: !!r.adopted } : null; }

  /* ----------------------- device lock (non-extractable) ----------------------- */
  function idb() {
    return new Promise(function (res, rej) {
      if (!window.indexedDB) return rej(akError('This browser cannot keep a device key.', 'unsupported'));
      var r = indexedDB.open(DB_NAME, 1);
      r.onupgradeneeded = function () { r.result.createObjectStore(DB_STORE); };
      r.onsuccess = function () { res(r.result); };
      r.onerror = function () { rej(r.error); };
    });
  }
  async function idbOp(mode, fn) {
    var db = await idb();
    return new Promise(function (res, rej) {
      var tx = db.transaction(DB_STORE, mode), st = tx.objectStore(DB_STORE), req = fn(st);
      tx.oncomplete = function () { db.close(); res(req && req.result); };
      tx.onerror = tx.onabort = function () { db.close(); rej(tx.error); };
    });
  }
  async function loadDevice() { try { return (await idbOp('readonly', function (s) { return s.get(DB_KEY); })) || null; } catch (_) { return null; } }
  async function ensureDevice() {
    var rec = await loadDevice();
    if (rec && rec.key && rec.tag) return rec;
    var key = await crypto.subtle.generateKey({ name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
    rec = { key: key, tag: bytes(8), createdAt: new Date().toISOString() };
    try { await idbOp('readwrite', function (s) { return s.put(rec, DB_KEY); }); }
    catch (e) { throw akError('This browser would not store a device key (private browsing blocks it).', 'storage'); }
    try { if (navigator.storage && navigator.storage.persist) await navigator.storage.persist(); } catch (_) {}
    return rec;
  }
  async function forgetDevice() { try { await idbOp('readwrite', function (s) { return s.delete(DB_KEY); }); } catch (_) {} }
  async function deviceSecret(rec, fileSalt) {
    var sig = await crypto.subtle.sign('HMAC', rec.key, concat(enc.encode('abagus/device/v1'), fileSalt));
    return new Uint8Array(sig);
  }

  /* ---------------------- extension block (clear text) ---------------------- */
  function u16(n) { return new Uint8Array([n & 255, (n >> 8) & 255]); }
  function buildExt(cred, tag, kid) {
    cred = cred || new Uint8Array(0); tag = tag || new Uint8Array(0);
    var body = kid
      ? concat(new Uint8Array([2]), u16(cred.length), cred, new Uint8Array([tag.length]), tag, new Uint8Array([kid.length]), kid)   // v2 adds the public key id
      : concat(new Uint8Array([1]), u16(cred.length), cred, new Uint8Array([tag.length]), tag);
    return concat(u16(body.length), body);
  }
  function parseExt(buf) {
    if (!buf || buf.length < 4) throw akError('The AnskarKey block in this file is damaged.', 'damaged');
    var len = buf[0] | (buf[1] << 8);
    if (len < 4 || len > 2048 || buf.length < 2 + len) throw akError('The AnskarKey block in this file is damaged.', 'damaged');
    var body = buf.slice(2, 2 + len), o = 0;
    var bv = body[o++];
    if (bv !== 1 && bv !== 2) throw akError('This file needs a newer version of Abagus.', 'newer');
    var cl = body[o] | (body[o + 1] << 8); o += 2;
    if (o + cl + 1 > body.length) throw akError('The AnskarKey block in this file is damaged.', 'damaged');
    var cred = body.slice(o, o + cl); o += cl;
    var tl = body[o++];
    if (o + tl > body.length) throw akError('The AnskarKey block in this file is damaged.', 'damaged');
    var tag = body.slice(o, o + tl); o += tl;
    var kid = new Uint8Array(0);
    if (bv === 2) { var kl = body[o++]; if (o + kl > body.length) throw akError('The AnskarKey block in this file is damaged.', 'damaged'); kid = body.slice(o, o + kl); }
    return { cred: cred, tag: tag, kid: kid, extLen: 2 + len };
  }

  async function groupSecret(G, fileSalt) {
    var base = await crypto.subtle.importKey('raw', G, 'HKDF', false, ['deriveBits']);
    var bits = await crypto.subtle.deriveBits({ name: 'HKDF', hash: 'SHA-256', salt: fileSalt, info: enc.encode('abagus/groupfile/v1') }, base, 256);
    return 'gk1:' + b64u(bits);
  }

  /* -------------------------- used by the vault core -------------------------- */
  var cache = new WeakMap();
  async function readHead(file) {
    if (!file) return null;
    if (cache.has(file)) return cache.get(file);
    var out = null;
    try {
      var h = new Uint8Array(await file.slice(0, HEADER_V7 + 2).arrayBuffer());
      if (h.length >= 44 && String.fromCharCode(h[0], h[1], h[2], h[3]) === 'SVL3') {
        var version = h[4], flags = h[42];
        out = { version: version, salt: h.slice(10, 26), anskar: false, device: false, cloud: false, group: false, flags: 0 };
        if (version >= 7) {
          out.flags = flags & (FLAG_ANSKAR | FLAG_DEVICE | FLAG_CLOUD | FLAG_GROUP);
          out.anskar = !!(flags & FLAG_ANSKAR); out.device = !!(flags & FLAG_DEVICE); out.cloud = !!(flags & FLAG_CLOUD); out.group = !!(flags & FLAG_GROUP);
        }
      }
    } catch (_) {}
    cache.set(file, out);
    return out;
  }
  async function inspect(file) {
    var head = await readHead(file);
    if (!head || !(head.anskar || head.device || head.cloud || head.group)) return head;
    var ext = parseExt(new Uint8Array(await file.slice(HEADER_V7, HEADER_V7 + 2 + 2048).arrayBuffer()));
    var info = { version: head.version, anskar: head.anskar, device: head.device, cloud: head.cloud, group: head.group, deviceMatch: null, tag: ext.tag, kid: ext.kid };
    if (head.device) { var d = await loadDevice(); info.deviceMatch = !!(d && same(d.tag, ext.tag)); }
    return info;
  }

  /* Lock: returns { secret, ext, flags } for the core to use. Prompts the user (AnskarKey). */
  async function sealSecret(o) {
    var parts = [], flags = 0, cred = null, tag = null, kid = null;
    var where = o.where || state.where, gidOut = null;
    if (o.method === 'group') {
      var gid = o.gid || state.gid;
      if (!gid) throw akError('Choose a group first.', 'no-group');
      if (!window.AbagusGroups) throw akError('Groups could not be loaded on this page.', 'failed');
      var gk = await window.AbagusGroups.keyFor(gid);           // fingerprint, face or PIN
      parts.push(await groupSecret(gk.G, o.salt)); flags |= FLAG_GROUP; kid = gk.kid; gidOut = gid;
    } else if (o.method === 'anskar' && where === 'account') {
      if (!window.CloudKey) throw akError('The Abagus account key could not be loaded on this page.', 'failed');
      var ck = await window.CloudKey.getKey({ purpose: 'lock' });
      parts.push(await window.CloudKey.fileSecret(ck.S, o.salt)); flags |= FLAG_CLOUD; kid = ck.kid;
    } else if (o.method === 'anskar') {
      var rec = savedCred();
      if (!rec) { toast('info', 'Setting up your AnskarKey first.', 2600); rec = await enroll(); paintAll(); }
      var r = await prfSecret(fromB64u(rec.credentialId), o.salt);
      parts.push('ak1:' + b64u(r.secret)); flags |= FLAG_ANSKAR; cred = r.credentialId;
    } else {
      parts.push(o.password);
    }
    if (o.device) {
      var d = await ensureDevice();
      parts.push('dv1:' + b64u(await deviceSecret(d, o.salt))); flags |= FLAG_DEVICE; tag = d.tag;
      paintAll();
    }
    return { secret: parts.join('\n'), ext: flags ? buildExt(cred, tag, kid) : new Uint8Array(0), flags: flags, gid: gidOut };
  }

  /* Unlock: returns { secret, extLen }. Parses everything it needs from the file itself. */
  async function openSecret(o) {
    var head = await readHead(o.file);
    if (!head || !(head.anskar || head.device || head.cloud || head.group)) throw akError('This file does not use AnskarKey or a device lock.', 'none');
    var ext = parseExt(new Uint8Array(await o.file.slice(HEADER_V7, HEADER_V7 + 2 + 2048).arrayBuffer()));
    var parts = [];
    if (head.device) {
      var d = await loadDevice();
      if (!d || !same(d.tag, ext.tag))
        throw akError('This file is locked to the device it was made on, and this is not that device. It cannot be opened here.', 'wrong-device');
    }
    if (head.group) {
      if (!window.AbagusGroups) throw akError('Groups could not be loaded on this page.', 'failed');
      if (!ext.kid.length) throw akError('The AnskarKey block in this file is damaged.', 'damaged');
      var gk2 = await window.AbagusGroups.keyForKid(ext.kid);
      parts.push(await groupSecret(gk2.G, head.salt));
    } else if (head.cloud) {
      if (!window.CloudKey) throw akError('The Abagus account key could not be loaded on this page.', 'failed');
      if (!ext.kid.length) throw akError('The AnskarKey block in this file is damaged.', 'damaged');
      var ck = await window.CloudKey.getKey({ purpose: 'unlock', kid: ext.kid });
      parts.push(await window.CloudKey.fileSecret(ck.S, head.salt));
    } else if (head.anskar) {
      if (!ext.cred.length) throw akError('The AnskarKey block in this file is damaged.', 'damaged');
      var r = await prfSecret(ext.cred, head.salt);
      parts.push('ak1:' + b64u(r.secret));
    } else {
      parts.push(o.password);
    }
    if (head.device) parts.push('dv1:' + b64u(await deviceSecret(d, head.salt)));
    return { secret: parts.join('\n'), extLen: ext.extLen };
  }

  /* ------------------------------ lock-side state ------------------------------ */
  var state = { method: 'password', device: false, where: 'passkey', gid: '' };
  try { if (localStorage.getItem('abagus-where') === 'account') state.where = 'account'; } catch (_) {}
  try { if (localStorage.getItem('abagus-method') === 'anskar' && supported()) state.method = 'anskar'; } catch (_) {}   // 'group' is never the default: it needs a chosen group
  function lockChoice() { return { method: state.method, device: state.device, where: state.where, gid: state.gid }; }
  function setWhere(w) { state.where = w === 'account' ? 'account' : 'passkey'; try { localStorage.setItem('abagus-where', state.where); } catch (_) {} paintAll(); paintMethod(); }

  function setChip(el, text, cls) { if (!el) return; el.textContent = text; el.className = 'ak-chip ' + (cls || ''); }

  async function paintAll() {
    var rec = savedCred(), dev = await loadDevice(), ok = supported();
    var anskarText = rec ? 'Ready on this device' : (ok ? 'Not set up yet' : 'Not available here');
    var anskarCls = rec ? 'ready' : (ok ? '' : 'warn');
    setChip($('akMgrStatus'), anskarText, anskarCls);
    if (state.where === 'account' && window.CloudKey) {
      var cs = window.CloudKey.status();
      setChip($('lockAkChip'), cs.localReady ? 'Ready on this device' : (cs.signedIn ? 'Set up on first use' : 'Sign in needed'), cs.localReady ? 'ready' : (cs.signedIn ? '' : 'warn'));
    } else setChip($('lockAkChip'), anskarText, anskarCls);
    if ($('akSignInBtn')) $('akSignInBtn').classList.toggle('hidden', !!(window.CloudKey && window.CloudKey.status().signedIn));
    setChip($('devMgrStatus'), dev ? 'Key on this device' : 'None yet', dev ? 'ready' : '');
    var acct = state.where === 'account';
    var lp = $('lockAkBlock'); if (lp) lp.classList.toggle('is-ready', acct ? !!(window.CloudKey && window.CloudKey.status().localReady) : !!rec);
    var setup = $('lockAkSetup'); if (setup) setup.classList.toggle('hidden', acct || !!rec || !ok);
    if ($('akMgrSetup')) { $('akMgrSetup').textContent = rec ? 'Set up again' : 'Set up AnskarKey'; $('akMgrSetup').disabled = !ok; }
    if ($('akMgrTest')) $('akMgrTest').disabled = !rec;
    if ($('akMgrForget')) $('akMgrForget').disabled = !rec;
    if ($('devMgrForget')) $('devMgrForget').disabled = !dev;
    if ($('devMgrSetup')) $('devMgrSetup').textContent = dev ? 'Replace key' : 'Create device key';
    var unsup = $('lockAkUnsupported'); if (unsup) unsup.classList.toggle('hidden', ok);
  }

  function paintMethod() {
    var gr = state.method === 'group', ak = state.method === 'anskar' || gr;   // ak: no passphrase to type
    document.querySelectorAll('#methodPick [data-method]').forEach(function (b) {
      var on = b.getAttribute('data-method') === state.method;
      b.setAttribute('aria-checked', on ? 'true' : 'false'); b.tabIndex = on ? 0 : -1;
    });
    var pick = $('methodPick'); if (pick) pick.setAttribute('data-method', state.method);
    if ($('lockPwBlock')) $('lockPwBlock').classList.toggle('hidden', ak);
    if ($('lockAkBlock')) $('lockAkBlock').classList.toggle('hidden', state.method !== 'anskar');
    if ($('lockGroupBlock')) $('lockGroupBlock').classList.toggle('hidden', !gr);
    document.querySelectorAll('#akWhere [data-where]').forEach(function (b) {
      var on = b.getAttribute('data-where') === state.where;
      b.setAttribute('aria-checked', on ? 'true' : 'false'); b.tabIndex = on ? 0 : -1;
    });
    if ($('akPasskeyInfo')) $('akPasskeyInfo').classList.toggle('hidden', state.where === 'account');
    if ($('akAccountInfo')) $('akAccountInfo').classList.toggle('hidden', state.where !== 'account');
    if ($('deviceNote')) $('deviceNote').classList.toggle('hidden', !state.device);
    if ($('deviceOnlyToggle')) $('deviceOnlyToggle').checked = state.device;
    var btn = $('lockBtn');
    if (btn) btn.textContent = gr ? 'Encrypt for the group' : (ak ? 'Encrypt with AnskarKey' : 'Encrypt file');
    var rows = document.querySelectorAll('#lockReady .ready-row');
    rows.forEach(function (r) {
      var t = r.querySelector('.rr-t'); if (!t) return;
      var k = r.getAttribute('data-k');
      if (k === 'len') t.textContent = gr ? 'A group is chosen' : (ak ? 'AnskarKey is available on this device' : 'Passphrase is 12+ characters');
      if (k === 'match') t.textContent = gr ? 'Every member opens it with their fingerprint' : (ak ? 'No passphrase to remember or type' : 'Both entries match');
    });
    var meth = $('inspMethod');
    if (meth) meth.textContent = (gr ? 'Group key' : (ak ? 'AnskarKey' : 'Passphrase')) + (state.device ? ' + this device' : '');
    var note = $('lockLedgerNote');
    if (note) note.textContent = gr
      ? 'There is no passphrase. Every member of the chosen group opens this file with their own fingerprint, face or PIN. People outside the group cannot open it.'
      : ak
      ? 'There is no passphrase. The file opens only with the passkey that sealed it, so keep that passkey backed up (a Google or Apple account passkey syncs for you).'
      : 'Keep the passphrase somewhere safe. Abagus never stores it or any derived key, so nobody — including you — can open a file without it.';
    if (typeof window.updateReady === 'function') window.updateReady();
  }

  var groupsLoaded = false;
  async function loadGroups() {
    var sel = $('lockGroupSel'), chip = $('lockGroupChip'), hint = $('lockGroupHint'), link = $('lockGroupSignIn');
    if (!sel) return;
    var signed = !!(window.CloudKey && window.CloudKey.status().signedIn);
    if (!signed || !window.AbagusGroups) {
      sel.innerHTML = ''; var o = document.createElement('option'); o.value = ''; o.textContent = 'Sign in with your mobile number first'; sel.appendChild(o);
      setChip(chip, 'Sign in needed', 'warn'); if (link) { link.classList.remove('hidden'); link.textContent = 'Sign in or open Groups'; } state.gid = ''; paintMethodLite(); return;
    }
    try {
      var list = await window.AbagusGroups.shareableGroups();
      sel.innerHTML = '';
      var first = document.createElement('option'); first.value = ''; first.textContent = list.length ? 'Choose a group' : 'No group can receive locked files'; sel.appendChild(first);
      list.forEach(function (g) { var op = document.createElement('option'); op.value = g.gid; op.textContent = g.name; sel.appendChild(op); });
      if (state.gid && list.some(function (g) { return g.gid === state.gid; })) sel.value = state.gid; else state.gid = '';
      setChip(chip, list.length ? list.length + (list.length > 1 ? ' groups' : ' group') : 'None available', list.length ? 'ready' : 'warn');
      if (hint) hint.classList.toggle('hidden', false); if (link) link.classList.toggle('hidden', list.length > 0);
      groupsLoaded = true;
    } catch (e) { setChip(chip, 'Could not load groups', 'warn'); }
    paintMethodLite();
  }
  function paintMethodLite() { if (typeof window.updateReady === 'function') window.updateReady(); }
  function setMethod(m) { state.method = m === 'anskar' ? 'anskar' : (m === 'group' ? 'group' : 'password'); if (state.method === 'group') loadGroups(); try { localStorage.setItem('abagus-method', state.method); } catch (_) {} paintMethod(); }

  async function doSetup(btn) {
    if (btn) btn.disabled = true;
    try { await enroll(); toast('ok', 'AnskarKey is ready. Files can now be locked with your fingerprint, face or PIN.', 4200); }
    catch (e) { toast('error', (e && e.message) || 'AnskarKey could not be set up.', 6000); }
    finally { if (btn) btn.disabled = false; await paintAll(); paintMethod(); }
  }

  /* ------------------------------ unlock-side UI ------------------------------ */
  var unlockMode = { anskar: false, device: false, cloud: false };
  function unlockNeedsPassword() { return !unlockMode.anskar; }

  async function onUnlockFile(file) {
    var info = null;
    try { info = file ? await inspect(file) : null; } catch (e) { info = null; }
    unlockMode = { anskar: !!(info && (info.anskar || info.cloud || info.group)), device: !!(info && info.device), cloud: !!(info && info.cloud), group: !!(info && info.group) };
    if ($('unlockPwBlock')) $('unlockPwBlock').classList.toggle('hidden', unlockMode.anskar);
    if ($('unlockAkBlock')) $('unlockAkBlock').classList.toggle('hidden', !unlockMode.anskar);
    var dn = $('unlockDeviceNote');
    if (dn) {
      dn.classList.toggle('hidden', !unlockMode.device);
      if (unlockMode.device) {
        var ok = info.deviceMatch;
        dn.className = 'ak-note ' + (ok ? 'ok' : 'bad');
        dn.querySelector('.ak-note-t').textContent = ok ? 'Locked to this device — and this is that device.' : 'Locked to a different device.';
        dn.querySelector('.ak-note-s').textContent = ok ? 'It can only be opened here, in this browser.' : 'This file can only be opened on the device that sealed it.';
      }
    }
    var pwRow = document.querySelector('#unlockReady [data-k="pw"] .rr-t');
    if (pwRow) pwRow.textContent = unlockMode.anskar ? 'AnskarKey will confirm it is you' : 'A passphrase is entered';
    var meth = $('inspUMethod');
    if (meth) meth.textContent = !info ? '—' : (unlockMode.group ? 'Group key' : unlockMode.cloud ? 'AnskarKey (account)' : unlockMode.anskar ? 'AnskarKey' : 'Passphrase') + (unlockMode.device ? ' + one device' : '');
    var btn = $('unlockBtn');
    if (btn) btn.textContent = unlockMode.anskar ? 'Unlock with AnskarKey' : 'Decrypt file';
    var ct = $('unlockCloudNote'); if (ct) ct.classList.toggle('hidden', !unlockMode.cloud);
    var gt = $('unlockGroupNote'); if (gt) gt.classList.toggle('hidden', !unlockMode.group);
    if (typeof window.updateReady === 'function') window.updateReady();
  }

  /* ------------------------------ wiring ------------------------------ */
  function wire() {
    var pick = $('methodPick');
    if (pick) {
      pick.addEventListener('click', function (e) {
        var b = e.target.closest('[data-method]'); if (b) setMethod(b.getAttribute('data-method'));
      });
      pick.addEventListener('keydown', function (e) {
        if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft' && e.key !== 'ArrowDown' && e.key !== 'ArrowUp') return;
        e.preventDefault(); var order = ['password', 'anskar', 'group'], at = order.indexOf(state.method), dir = (e.key === 'ArrowRight' || e.key === 'ArrowDown') ? 1 : -1; setMethod(order[(at + dir + 3) % 3]);
        var on = pick.querySelector('[aria-checked="true"]'); if (on) on.focus();
      });
    }
    var gs = $('lockGroupSel'); if (gs) gs.addEventListener('change', function () { state.gid = gs.value; paintMethodLite(); });
    var wh = $('akWhere');
    if (wh) wh.addEventListener('click', function (e) { var b = e.target.closest('[data-where]'); if (b) setWhere(b.getAttribute('data-where')); });
    if ($('akSignInBtn')) $('akSignInBtn').addEventListener('click', function () { if (window.AbagusAccount) window.AbagusAccount.open('signin'); });
    window.addEventListener('abagus:user', function () { paintAll(); if (state.method === 'group') loadGroups(); });
    var dev = $('deviceOnlyToggle');
    if (dev) dev.addEventListener('change', function () { state.device = dev.checked; paintMethod(); });
    if ($('lockAkSetup')) $('lockAkSetup').addEventListener('click', function () { doSetup(this); });
    if ($('akMgrSetup')) $('akMgrSetup').addEventListener('click', function () { doSetup(this); });
    if ($('akMgrTest')) $('akMgrTest').addEventListener('click', async function () {
      var b = this; b.disabled = true;
      try { await testAnskar(); toast('ok', 'AnskarKey works. This device can produce the key.', 3800); }
      catch (e) { toast('error', (e && e.message) || 'Test failed.', 6000); }
      finally { b.disabled = false; }
    });
    if ($('akMgrForget')) $('akMgrForget').addEventListener('click', function () {
      if (!window.confirm('Forget AnskarKey on this device?\n\nFiles already locked with it can still be opened as long as the passkey itself stays in your password manager. Delete the passkey there to remove it fully.')) return;
      forgetAnskar(); paintAll(); paintMethod(); toast('info', 'AnskarKey forgotten on this device.', 3200);
    });
    if ($('devMgrSetup')) $('devMgrSetup').addEventListener('click', async function () {
      var existing = await loadDevice();
      if (existing && !window.confirm('Replace the device key?\n\nEvery file you locked to this device so far will become permanently unreadable.')) return;
      try { if (existing) await forgetDevice(); await ensureDevice(); toast('ok', 'Device key created. It cannot be copied out of this browser.', 4200); }
      catch (e) { toast('error', (e && e.message) || 'Could not create a device key.', 6000); }
      paintAll();
    });
    if ($('devMgrForget')) $('devMgrForget').addEventListener('click', async function () {
      if (!window.confirm('Delete the device key?\n\nEvery file you locked to this device will become permanently unreadable. This cannot be undone.')) return;
      await forgetDevice(); paintAll(); toast('info', 'Device key deleted.', 3200);
    });
    paintAll(); paintMethod();
    if (!supported()) {
      var m = $('methodAnskar'); if (m) m.classList.add('is-off');
    }
  }

  window.AnskarKey = {
    supported: supported, lockChoice: lockChoice, setMethod: setMethod,
    sealSecret: sealSecret, openSecret: openSecret, inspect: inspect,
    onUnlockFile: onUnlockFile, unlockNeedsPassword: unlockNeedsPassword,
    test: testAnskar, prf: prfSecret, setWhere: setWhere, adopt: adopt, credentialInfo: credentialInfo, enroll: enroll, repaint: function () { paintAll(); paintMethod(); },
    /* exposed for tests only */ _flags: { ANSKAR: FLAG_ANSKAR, DEVICE: FLAG_DEVICE, CLOUD: FLAG_CLOUD }, _headerLen: HEADER_V7
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', wire); else wire();
})();
