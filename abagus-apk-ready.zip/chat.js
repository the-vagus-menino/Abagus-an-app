/* Abagus group chat (WhatsApp-style). Every message is sealed with the group key (AES-GCM) before it leaves the phone;
   the server stores only {t, uid, iv, ct}. Names, text and the quoted reply are inside the ciphertext. Plain script: no inline code. */
(function () {
  'use strict';
  var KEY = 'abagus-chat-read:', MAX_SHOW = 200, MAX_LEN = 1000, timer = null, seen = '', vis = null;
  function fmtT(t) { try { return new Date(t).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }); } catch (_) { return ''; } }
  function dayLabel(t) {
    var d = new Date(t), n = new Date(), y = new Date(Date.now() - 864e5);
    if (d.toDateString() === n.toDateString()) return 'Today'; if (d.toDateString() === y.toDateString()) return 'Yesterday';
    return d.toLocaleDateString([], { day: 'numeric', month: 'long', year: 'numeric' });
  }
  function colour(uid) { var s = 0; for (var i = 0; i < uid.length; i++) s = (s * 31 + uid.charCodeAt(i)) >>> 0; return 'hsl(' + (s % 360) + ',58%,45%)'; }
  function rd(gid) { try { return +localStorage.getItem(KEY + gid) || 0; } catch (_) { return 0; } }
  function setRd(gid, t) { try { localStorage.setItem(KEY + gid, String(t)); } catch (_) {} }

  async function decode(x, raw) {
    try {
      var p = JSON.parse(new TextDecoder().decode(await x.open(await x.key(), { iv: raw.iv, ct: raw.ct }, 'msg:' + raw.id)));
      return { id: raw.id, t: raw.t, uid: raw.uid, n: String(p.n || 'Member').slice(0, 40), x: String(p.x || ''), r: p.r || null };
    } catch (_) { return { id: raw.id, t: raw.t, uid: raw.uid, n: 'Member', x: '\u26A0 Could not be decrypted', r: null, bad: true }; }
  }

  async function render(pane, x) {
    clearInterval(timer); seen = '';
    var h = x.h, replyTo = null, sending = false;
    var list = h('div', { class: 'ch-list', role: 'log', 'aria-live': 'polite', 'aria-label': 'Group messages' });
    var quote = h('div', { class: 'ch-quote hidden' });
    var input = h('textarea', { class: 'ch-in', rows: '1', maxlength: String(MAX_LEN), placeholder: x.canPost ? 'Message' : 'Chat is paused', 'aria-label': 'Message', disabled: !x.canPost });
    var send = h('button', { type: 'button', class: 'ch-send', 'aria-label': 'Send', disabled: !x.canPost }, '\u27A4');
    var jump = h('button', { type: 'button', class: 'ch-jump hidden', 'aria-label': 'Jump to latest' }, '\u2193');
    var box = h('div', { class: 'ch-box' }, list, jump, quote, h('div', { class: 'ch-bar' }, input, send));
    pane.appendChild(h('div', { class: 'ch-enc' }, '\uD83D\uDD12 Messages are end-to-end encrypted with this group\u2019s key. Abagus cannot read them.'));
    pane.appendChild(box);

    function setReply(m) {
      replyTo = m; quote.textContent = ''; quote.classList.toggle('hidden', !m); if (!m) return;
      quote.appendChild(h('div', { class: 'ch-q-b' }, h('b', { text: m.n }), h('span', { text: m.x.slice(0, 90) })));
      quote.appendChild(h('button', { type: 'button', class: 'ch-q-x', 'aria-label': 'Cancel reply', onclick: function () { setReply(null); } }, '\u00D7')); input.focus();
    }
    function bubble(m) {
      var mine = m.uid === x.uid, kids = [];
      if (!mine) kids.push(h('b', { class: 'ch-n', style: 'color:' + colour(m.uid), text: m.n }));
      if (m.r) kids.push(h('div', { class: 'ch-rp' }, h('b', { text: m.r.n }), h('span', { text: m.r.x })));
      kids.push(h('span', { class: 'ch-t', text: m.x }));
      kids.push(h('span', { class: 'ch-m', text: fmtT(m.t) + (mine ? ' \u2713' : '') }));
      var b = h('div', { class: 'ch-b' + (mine ? ' me' : ''), 'data-id': m.id, tabindex: '0' });
      kids.forEach(function (k) { b.appendChild(k); });
      var acts = h('span', { class: 'ch-acts' }, h('button', { type: 'button', 'aria-label': 'Reply', onclick: function () { setReply(m); } }, '\u21A9'));
      if (mine || x.isAdmin) acts.appendChild(h('button', { type: 'button', 'aria-label': 'Delete message', onclick: async function () {
        if (!confirm('Delete this message for everyone?')) return;
        try { await x.db.del('groups/' + x.gid + '/messages/' + m.id); seen = ''; await load(true); } catch (_) { x.toast('error', 'Could not delete the message.'); } } }, '\uD83D\uDDD1'));
      b.appendChild(acts);
      var swipe = null; b.addEventListener('touchstart', function (e) { swipe = { x: e.touches[0].clientX, y: e.touches[0].clientY }; }, { passive: true });
      b.addEventListener('touchend', function (e) { var t = e.changedTouches[0]; if (swipe && Math.abs(t.clientX - swipe.x) > 70 && Math.abs(t.clientY - swipe.y) < 40) setReply(m); swipe = null; });
      b.addEventListener('touchcancel', function () { swipe = null; });
      return b;
    }
    var busy = false, again = null;
    async function load(force) {
      if (!pane.isConnected) { clearInterval(timer); return; }
      if (busy) { again = again || force || true; return; }
      busy = true;
      try { await loadOnce(force); } finally { busy = false; }
      if (again) { var f = again; again = null; await load(f === true ? false : f); }
    }
    async function loadOnce(force) {
      var rows;
      try { rows = await x.db.list('groups/' + x.gid + '/messages', { orderBy: 't', dir: 'asc' }); } catch (_) { return; }
      rows = rows.slice(-MAX_SHOW); var sig = rows.length ? rows[rows.length - 1].id + ':' + rows.length : '0';
      if (!force && sig === seen) return; seen = sig;
      var atEnd = list.scrollHeight - list.scrollTop - list.clientHeight < 90 || force === 'first';
      var msgs = await Promise.all(rows.map(function (r) { return decode(x, r); }));
      list.textContent = '';
      if (!msgs.length) list.appendChild(h('div', { class: 'ch-empty' }, h('b', { text: 'No messages yet' }), h('span', { text: 'Say hello \uD83D\uDC4B Only members of this group can read what you write.' })));
      var day = '';
      msgs.forEach(function (m) { var d = dayLabel(m.t); if (d !== day) { day = d; list.appendChild(h('div', { class: 'ch-day', text: d })); } list.appendChild(bubble(m)); });
      if (atEnd) list.scrollTop = list.scrollHeight;
      var last = msgs.length ? msgs[msgs.length - 1].t : 0; if (atEnd || document.hasFocus()) setRd(x.gid, last);
    }
    async function go() {
      var text = input.value.trim(); if (!text || sending || !x.canPost) return; sending = true; send.disabled = true;
      try {
        var id = x.newId(), pl = { n: x.name || 'Member', x: text.slice(0, MAX_LEN) };
        if (replyTo) pl.r = { n: replyTo.n, x: replyTo.x.slice(0, 120) };
        var w = await x.seal(await x.key(), new TextEncoder().encode(JSON.stringify(pl)), 'msg:' + id);
        await x.db.set('groups/' + x.gid + '/messages/' + id, { t: Date.now(), uid: x.uid, iv: w.iv, ct: w.ct, v: 1 });
        input.value = ''; input.style.height = ''; setReply(null); x.touch(); seen = ''; await load('first');
      } catch (e) { x.toast('error', 'Message not sent. Check your connection.'); }
      sending = false; send.disabled = !x.canPost;
    }
    send.addEventListener('click', go);
    input.addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.shiftKey && !/Mobi|Android/i.test(navigator.userAgent)) { e.preventDefault(); go(); } });
    input.addEventListener('input', function () { input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight, 120) + 'px'; x.touch(); });
    list.addEventListener('scroll', function () { jump.classList.toggle('hidden', list.scrollHeight - list.scrollTop - list.clientHeight < 240); });
    jump.addEventListener('click', function () { list.scrollTop = list.scrollHeight; });
    await load('first');
    timer = setInterval(function () { if (!document.hidden) load(false); }, 4000);
    if (vis) document.removeEventListener('visibilitychange', vis);
    vis = function () { if (!document.hidden && pane.isConnected) load(false); };
    document.addEventListener('visibilitychange', vis);
  }
  /* unread count for a group card: messages newer than the last time this device showed the chat */
  async function unread(db, gid) {
    try { var rows = await db.list('groups/' + gid + '/messages', { orderBy: 't', dir: 'desc' }); var r = rd(gid); return rows.filter(function (m) { return m.t > r; }).length; } catch (_) { return 0; }
  }
  window.AbagusChat = { render: render, stop: function () { clearInterval(timer); if (vis) { document.removeEventListener('visibilitychange', vis); vis = null; } }, unread: unread };
})();
