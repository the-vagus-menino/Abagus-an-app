/* Abagus Groups page: the small slice of the Firebase module the standalone Groups page needs
   (mobile-number sign-in, the account profile, and the path-based database helper). The Firebase web config is
   public by design; access is decided by sign-in and firestore.rules. Same project and same sign-in as the Vault page. */
import { initializeApp } from "https://www.gstatic.com/firebasejs/12.15.0/firebase-app.js";
import { getAuth, onAuthStateChanged, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, updateProfile, GoogleAuthProvider, signInWithPopup }
  from "https://www.gstatic.com/firebasejs/12.15.0/firebase-auth.js";

const app = initializeApp({
  apiKey: "AIzaSyB5yrqytlD2R0yaAyeizvStIedlrlILPDY", authDomain: "abagus-bd19f.firebaseapp.com", projectId: "abagus-bd19f",
  storageBucket: "abagus-bd19f.firebasestorage.app", messagingSenderId: "141785125740", appId: "1:141785125740:web:bd98fe28da1ea06b469949",
});
const auth = getAuth(app);

const ID_EMAIL_RE = /^m(\d{8,15})@abagus-bd19f\.firebaseapp\.com$/;
const isPhoneUser = (u) => !!u && ID_EMAIL_RE.test(u.email || "");
const phoneOf = (u) => { const m = ID_EMAIL_RE.exec((u && u.email) || ""); return m ? "+" + m[1] : null; };
const isGoogleUser = (u) => !!u && (u.providerData || []).some((p) => p.providerId === "google.com");
// Groups work for mobile-number accounts AND Google accounts, so any signed-in person has a uid; "phone" is only set for mobile accounts.
const announce = (u) => window.dispatchEvent(new CustomEvent("abagus:user", { detail: {
  uid: u ? u.uid : null, phone: phoneOf(u), name: (u && u.displayName) || null, google: isGoogleUser(u), email: (u && u.email) || null } }));

window.VaultAuth = {
  signInWithGoogle: async () => { const p = new GoogleAuthProvider(); p.setCustomParameters({ prompt: "select_account" }); return signInWithPopup(auth, p); },
  signUp: (email, password) => createUserWithEmailAndPassword(auth, email, password),
  signIn: (email, password) => signInWithEmailAndPassword(auth, email, password),
  signOut: () => signOut(auth),
  updateName: async (name) => { await updateProfile(auth.currentUser, { displayName: name }); announce(auth.currentUser); },
};

let fsLib = null;
async function fsOpen() {
  if (!fsLib) {
    const m = await import("https://www.gstatic.com/firebasejs/12.15.0/firebase-firestore.js");
    fsLib = { m, db: m.getFirestore(app) };
  }
  return fsLib;
}
const toStore = (m, v) => {
  if (v instanceof Uint8Array) return m.Bytes.fromUint8Array(v);
  if (Array.isArray(v)) return v.map((x) => toStore(m, x));
  if (v && typeof v === "object") { const o = {}; for (const k in v) o[k] = toStore(m, v[k]); return o; }
  return v;
};
const fromStore = (v) => {
  if (v && typeof v.toUint8Array === "function") return v.toUint8Array();
  if (Array.isArray(v)) return v.map(fromStore);
  if (v && typeof v === "object") { const o = {}; for (const k in v) o[k] = fromStore(v[k]); return o; }
  return v;
};
window.VaultProfile = {
  async load(uid) { const { m, db } = await fsOpen(); const s = await m.getDoc(m.doc(db, "users", uid)); return s.exists() ? s.data() : null; },
  async save(uid, data) { const { m, db } = await fsOpen(); await m.setDoc(m.doc(db, "users", uid), data, { merge: true }); },
};
window.VaultDB = {
  async get(path) { const { m, db } = await fsOpen(); const s = await m.getDoc(m.doc(db, path)); return s.exists() ? fromStore(s.data()) : null; },
  async set(path, data, merge) { const { m, db } = await fsOpen(); await m.setDoc(m.doc(db, path), toStore(m, data), merge ? { merge: true } : undefined); },
  async del(path) { const { m, db } = await fsOpen(); await m.deleteDoc(m.doc(db, path)); },
  async list(path, opt) {
    const { m, db } = await fsOpen();
    let q = m.collection(db, path);
    if (opt && opt.orderBy) q = m.query(q, m.orderBy(opt.orderBy, opt.dir || "asc"));
    const snap = await m.getDocs(q);
    return snap.docs.map((d) => Object.assign({ id: d.id }, fromStore(d.data())));
  },
};

onAuthStateChanged(auth, (u) => { announce(u); window.__authReady = true; });
