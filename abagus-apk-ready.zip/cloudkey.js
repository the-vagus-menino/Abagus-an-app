/* =====================================================================
   ABAGUS — account key ("AnskarKey: My Abagus account").  No Google, no Apple.

   A passkey's private key can never leave the phone's secure hardware, so it cannot be "stored" or
   "synced" by Abagus. What Abagus can do is what multi-device messengers do:

     S  a random 256-bit master key, made in the browser.
     • On the SERVER (users/<uid>.cloudKey) only S encrypted with a key made from the RECOVERY CODE
       (160 random bits, shown once). The recovery code and S never leave the browser, so Abagus
       cannot read S and cannot open anyone's files.
     • On each DEVICE, S encrypted with that phone's own passkey (WebAuthn PRF). Fingerprint, face
       or PIN opens it. Nothing else is needed after the first time on a device.
     • A new device: sign in (mobile number + password) and type the recovery code once. S is
       decrypted, then locked to the new device's own passkey. Passkey syncing is not involved.

   Files use the key  HKDF(S, fileSalt)  -> the same PBKDF2/Argon2id/HKDF chain as any passphrase.
   The header carries only a public key id (8 bytes derived from S) so the right key can be found.

   Honest limit: lose every device AND the recovery code, and the files cannot be opened by anyone,
   Abagus included. That is the price of Abagus not being able to read them.
   ===================================================================== */
(function () {
  'use strict';
  var LS_LOCAL = 'abagus-cloudkey-local-v1';
  var enc = new TextEncoder();
  var ALPHA = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';   // Crockford base32: no I, L, O, U

  /* ------------------------------ helpers ------------------------------ */
  function $(id) { return document.getElementById(id); }
  function bytes(n) { var a = new Uint8Array(n); crypto.getRandomValues(a); return a; }
  function b64u(buf) { var a = new Uint8Array(buf), s = ''; for (var i = 0; i < a.length; i++) s += String.fromCharCode(a[i]); return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); }
  function fromB64u(s) { s = s.replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '='; var b = atob(s), a = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) a[i] = b.charCodeAt(i); return a; }
  function hex(a) { return Array.prototype.map.call(a, function (x) { return ('0' + x.toString(16)).slice(-2); }).join(''); }
  function fromHex(h) { var a = new Uint8Array(h.length / 2); for (var i = 0; i < a.length; i++) a[i] = parseInt(h.substr(i * 2, 2), 16); return a; }
  function err(message, code) { var e = new Error(message); e.anskar = true; e.code = code || 'cloudkey'; return e; }
  // One record per account on this phone: "abagus-cloudkey-local-v1:<uid>". (An older build kept a single
  // record with no account; it is only ever used to open a file whose key id it matches, never to lock.)
  function lsKey(uid) { return LS_LOCAL + ':' + uid; }
  function readLS(uid) { try { return uid ? JSON.parse(localStorage.getItem(lsKey(uid)) || 'null') : null; } catch (_) { return null; } }
  function writeLS(uid, v) { try { localStorage.setItem(lsKey(uid), JSON.stringify(v)); } catch (_) {} }
  function allLocals() {
    var out = [];
    try {
      for (var i = 0; i < localStorage.length; i++) {
        var k = localStorage.key(i);
        if (k === LS_LOCAL || k.indexOf(LS_LOCAL + ':') === 0) { try { var r = JSON.parse(localStorage.getItem(k)); if (r && r.kid) out.push(r); } catch (_) {} }
      }
    } catch (_) {}
    return out;
  }
  function toast(t, m, ms) { if (typeof window.showToast === 'function') window.showToast(t, m, ms || 4200); }

  function b32(a) {
    var bits = 0, val = 0, out = '';
    for (var i = 0; i < a.length; i++) {
      val = (val << 8) | a[i]; bits += 8;
      while (bits >= 5) { out += ALPHA[(val >>> (bits - 5)) & 31]; bits -= 5; }
      val &= (1 << bits) - 1;
    }
    if (bits > 0) out += ALPHA[(val << (5 - bits)) & 31];
    return out;
  }
  function unb32(str) {
    var s = String(str || '').toUpperCase().replace(/[^0-9A-Z]/g, '').replace(/O/g, '0').replace(/[IL]/g, '1');
    if (s.length !== 32) return null;
    var out = [], bits = 0, val = 0;
    for (var i = 0; i < s.length; i++) {
      var v = ALPHA.indexOf(s[i]); if (v < 0) return null;
      val = (val << 5) | v; bits += 5;
      if (bits >= 8) { out.push((val >>> (bits - 8)) & 255); bits -= 8; }
      val &= (1 << bits) - 1;
    }
    return out.length === 20 ? new Uint8Array(out) : null;
  }
  function groups(c) { return c.match(/.{1,4}/g).join('-'); }

  async function hkdfBase(secret) { return crypto.subtle.importKey('raw', secret, 'HKDF', false, ['deriveKey', 'deriveBits']); }
  async function aesKey(secret, salt, info) {
    return crypto.subtle.deriveKey({ name: 'HKDF', hash: 'SHA-256', salt: salt, info: enc.encode(info) }, await hkdfBase(secret), { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
  }
  async function bits(secret, salt, info, len) {
    return new Uint8Array(await crypto.subtle.deriveBits({ name: 'HKDF', hash: 'SHA-256', salt: salt, info: enc.encode(info) }, await hkdfBase(secret), len));
  }
  async function keyIdOf(S) { return bits(S, new Uint8Array(0), 'abagus/cloudkey/id/v1', 64); }
  async function fileSecret(S, fileSalt) { return 'ck1:' + b64u(await bits(S, fileSalt, 'abagus/cloudkey/file/v1', 256)); }
  async function seal(S, key) { var iv = bytes(12); return { iv: iv, ct: new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv: iv }, key, S)) }; }
  async function unseal(ct, iv, key) { return new Uint8Array(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: iv }, key, ct)); }

  function session() { return (window.AbagusAccount && window.AbagusAccount.session && window.AbagusAccount.session()) || {}; }
  function status() { var s = session(); return { signedIn: !!s.uid, localReady: !!(s.uid && readLS(s.uid)) }; }

  /* ------------------------------ dialogs ------------------------------ */
  function modal(html) {
    var d = document.createElement('dialog');
    d.className = 'acct-dialog ck-dialog'; d.innerHTML = html;
    document.body.appendChild(d);
    if (typeof d.showModal === 'function') d.showModal(); else d.setAttribute('open', '');
    return d;
  }
  function closeModal(d) { try { d.close(); } catch (_) {} if (d.parentNode) d.parentNode.removeChild(d); }

  function showCreateDialog(code) {
    return new Promise(function (resolve, reject) {
      var d = modal(
        '<div class="acd-head"><h2>Your recovery code</h2></div>' +
        '<p class="ck-p">This code is the only way to add your Abagus key to a new phone. <b>Abagus cannot show it again or reset it.</b> Save it somewhere safe, away from this phone (a password manager, or on paper).</p>' +
        '<div class="ck-code" id="ckCode" aria-label="Recovery code">' + groups(code) + '</div>' +
        '<div class="acd-actions"><button type="button" class="btn small" id="ckCopy">Copy</button><button type="button" class="btn small quiet" id="ckDl">Download .txt</button></div>' +
        '<label class="ck-confirm"><input type="checkbox" id="ckSaved"> <span>I saved this code. I understand that without it, and without my current devices, my locked files cannot be opened by anyone.</span></label>' +
        '<div class="acd-actions"><button type="button" class="btn primary" id="ckGo" disabled>Continue</button><button type="button" class="btn small quiet" id="ckNo">Cancel</button></div>');
      var go = d.querySelector('#ckGo'), saved = d.querySelector('#ckSaved');
      saved.addEventListener('change', function () { go.disabled = !saved.checked; });
      d.querySelector('#ckCopy').addEventListener('click', function () {
        try { navigator.clipboard.writeText(groups(code)); toast('ok', 'Recovery code copied.', 2200); } catch (_) { toast('info', 'Select the code and copy it by hand.', 3200); }
      });
      d.querySelector('#ckDl').addEventListener('click', function () {
        var a = document.createElement('a');
        a.href = URL.createObjectURL(new Blob(['Abagus recovery code\n\n' + groups(code) + '\n\nKeep this private. It adds your Abagus key to a new device.\n'], { type: 'text/plain' }));
        a.download = 'abagus-recovery-code.txt'; document.body.appendChild(a); a.click(); a.remove();
      });
      go.addEventListener('click', function () { closeModal(d); resolve(); });
      function no() { closeModal(d); reject(err('Cancelled. No key was created.', 'cancelled')); }
      d.querySelector('#ckNo').addEventListener('click', no);
      d.addEventListener('cancel', function (e) { e.preventDefault(); no(); });
    });
  }

  function showRecoveryDialog(ck) {
    return new Promise(function (resolve, reject) {
      var d = modal(
        '<div class="acd-head"><h2>Add this device</h2></div>' +
        '<p class="ck-p">Enter the recovery code you saved when you created your Abagus key. You only need it once on each new device. After that, your fingerprint, face or PIN is enough.</p>' +
        '<label class="lbl" for="ckIn">Recovery code</label>' +
        '<input class="acd-f ck-in" id="ckIn" autocomplete="off" autocapitalize="characters" spellcheck="false" placeholder="XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX">' +
        '<p class="acd-msg error hidden" id="ckErr" role="alert"></p>' +
        '<div class="acd-actions"><button type="button" class="btn primary" id="ckGo">Add this device</button><button type="button" class="btn small quiet" id="ckNo">Cancel</button></div>');
      var inp = d.querySelector('#ckIn'), msg = d.querySelector('#ckErr'), go = d.querySelector('#ckGo');
      function fail(t) { msg.textContent = t; msg.classList.remove('hidden'); }
      async function submit() {
        msg.classList.add('hidden');
        var R = unb32(inp.value);
        if (!R) { fail('A recovery code has 32 letters and numbers, in groups of four.'); return; }
        go.disabled = true;
        try {
          var S = await unseal(fromB64u(ck.ct), fromB64u(ck.iv), await aesKey(R, fromB64u(ck.salt), 'abagus/cloudkey/recovery/v1'));
          if (hex(await keyIdOf(S)) !== ck.id) throw new Error('id');
          closeModal(d); resolve(S);
        } catch (_) { fail('That recovery code is not right.'); go.disabled = false; inp.focus(); }
      }
      go.addEventListener('click', submit);
      inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); submit(); } });
      function no() { closeModal(d); reject(err('Cancelled.', 'cancelled')); }
      d.querySelector('#ckNo').addEventListener('click', no);
      d.addEventListener('cancel', function (e) { e.preventDefault(); no(); });
      setTimeout(function () { inp.focus(); }, 30);
    });
  }

  /* --------------------------- key lifecycle --------------------------- */
  async function bindLocal(uid, S, kid) {
    var A = window.AnskarKey;
    if (!A) throw err('AnskarKey could not be loaded on this page.', 'failed');
    var rec = A.credentialInfo();
    // A passkey id restored from the account may not exist on this phone (it only does if Google/Apple synced it).
    // The account key must not depend on that, so this phone always uses a passkey it made itself.
    if (!rec || rec.adopted) { toast('info', 'Now set up this phone\u2019s fingerprint, face or PIN.', 3200); await A.enroll(); rec = A.credentialInfo(); }
    var salt = bytes(16);
    var r = await A.prf(fromB64u(rec.credentialId), salt);   // biometric prompt
    var w = await seal(S, await aesKey(r.secret, salt, 'abagus/cloudkey/localwrap/v1'));
    writeLS(uid, { v: 1, uid: uid, credentialId: rec.credentialId, salt: b64u(salt), iv: b64u(w.iv), ct: b64u(w.ct), kid: hex(kid) });
    if (window.AnskarKey && window.AnskarKey.repaint) window.AnskarKey.repaint();
    try { window.dispatchEvent(new CustomEvent('abagus:cloudkey')); } catch (_) {}
  }
  async function openLocal(loc) {
    var r = await window.AnskarKey.prf(fromB64u(loc.credentialId), fromB64u(loc.salt));   // biometric prompt
    try { return await unseal(fromB64u(loc.ct), fromB64u(loc.iv), await aesKey(r.secret, fromB64u(loc.salt), 'abagus/cloudkey/localwrap/v1')); }
    catch (_) { throw err('This device\u2019s copy of your key could not be opened. Choose Remove from this device in your account, then add this device again with your recovery code.', 'local-broken'); }
  }
  // Show a new recovery code, then store S wrapped by it on the account. Used when the key is first made,
  // and to repair an account whose server record is missing while this phone still holds the key.
  async function publishKey(uid, S, kid) {
    var R = bytes(20);
    await showCreateDialog(b32(R));
    var rsalt = bytes(16), w = await seal(S, await aesKey(R, rsalt, 'abagus/cloudkey/recovery/v1'));
    try {
      await window.VaultProfile.save(uid, { cloudKey: { v: 1, id: hex(kid), salt: b64u(rsalt), iv: b64u(w.iv), ct: b64u(w.ct) }, updatedAt: new Date().toISOString() });
    } catch (e) { throw err('Your key could not be saved to your account (' + ((e && (e.code || e.message)) || 'error') + '), so nothing was locked. Check your connection and that the Firestore rules are published.', 'save'); }
  }
  async function loadProfile(uid) {
    if (!window.VaultProfile) throw err('Your account could not be reached from this page.', 'profile');
    try { return await window.VaultProfile.load(uid); }
    catch (e) { throw err('Your account could not be reached (' + ((e && (e.code || e.message)) || 'error') + '). Check your connection and that Firestore is set up.', 'profile'); }
  }

  /* opts: { purpose: 'lock' | 'unlock', kid?: Uint8Array }  ->  { S, kid } */
  async function getKey(opts) {
    opts = opts || {};
    var want = opts.kid ? hex(opts.kid) : null;
    var sess = session(), signed = !!sess.uid;

    // Opening a file: any key on this phone whose id matches the file works, signed in or not.
    if (opts.purpose === 'unlock' && want) {
      var hit = allLocals().filter(function (r) { return r.kid === want; })[0];
      if (hit) return { S: await openLocal(hit), kid: fromHex(hit.kid) };
    }
    if (!signed) {
      if (window.AbagusAccount) window.AbagusAccount.open('signin');
      throw err('Sign in first, then try again. This phone does not have your Abagus key yet.', 'need-signin');
    }

    // Locking: this account's key on this phone.
    var loc = readLS(sess.uid);
    if (loc && opts.purpose !== 'unlock') {
      var S0 = await openLocal(loc), kid0 = fromHex(loc.kid), prof0 = null;
      try { prof0 = await window.VaultProfile.load(sess.uid); } catch (_) { prof0 = undefined; }   // offline: carry on
      if (prof0 !== undefined) {
        var ck0 = prof0 && prof0.cloudKey;
        if (!ck0) await publishKey(sess.uid, S0, kid0);                       // account lost its record: repair it
        else if (ck0.id !== loc.kid) throw err('This phone holds a different Abagus key than your account. Choose Remove from this device in your account, then add this device again with your recovery code.', 'conflict');
      }
      return { S: S0, kid: kid0 };
    }

    var profile = await loadProfile(sess.uid);
    var ck = profile && profile.cloudKey, S;
    if (ck) {
      if (want && ck.id !== want) throw err('This file was locked with a different Abagus key than this account has.', 'kid');
      S = await showRecoveryDialog(ck);
    } else {
      if (opts.purpose === 'unlock') throw err('This account has no Abagus key yet. If the file was made with another account, sign in with that one. If you made it with this account, open your account and choose Set up Abagus key first.', 'no-key');
      S = bytes(32);
    }
    var kid = await keyIdOf(S);
    if (want && hex(kid) !== want) throw err('This file was locked with a different Abagus key than this account has.', 'kid');
    if (!ck) {                       // brand-new key: bind this phone FIRST, so a failure here leaves nothing on the server
      await bindLocal(sess.uid, S, kid);
      try { await publishKey(sess.uid, S, kid); }
      catch (e) { try { localStorage.removeItem(lsKey(sess.uid)); } catch (_) {} try { window.dispatchEvent(new CustomEvent('abagus:cloudkey')); } catch (_) {} throw e; }
    } else await bindLocal(sess.uid, S, kid);
    toast('ok', 'Your Abagus key is ready on this device.', 3600);
    return { S: S, kid: kid };
  }
  function forgetLocal() { var s = session(); try { if (s.uid) localStorage.removeItem(lsKey(s.uid)); } catch (_) {} try { window.dispatchEvent(new CustomEvent('abagus:cloudkey')); } catch (_) {} }

  window.CloudKey = { getKey: getKey, fileSecret: fileSecret, status: status, forgetLocal: forgetLocal, _b32: b32, _unb32: unb32 };
})();
