/* Abagus safety net. Plain script, no network, no crypto, nothing inline (so the page's CSP hashes are untouched).
   1. Asks before the tab is closed or reloaded while a seal/open is running (the app sets body.is-busy), so a half-written file is not lost.
   2. Empties the passphrase boxes when the page is left, so a passphrase cannot come back from the browser's back/forward cache. */
(function () {
  'use strict';
  var FIELDS = ['lockPassword', 'lockPasswordConfirm', 'unlockPassword'];
  function busy() { return !!(document.body && document.body.classList.contains('is-busy')); }
  window.addEventListener('beforeunload', function (e) {
    if (!busy()) return;
    e.preventDefault();
    e.returnValue = '';           // required by some browsers to show the prompt
    return '';
  });
  function wipe() {
    FIELDS.forEach(function (id) {
      var el = document.getElementById(id);
      if (el && el.value) { try { el.value = ''; el.dispatchEvent(new Event('input', { bubbles: true })); } catch (_) {} }
    });
  }
  window.addEventListener('pagehide', function () { if (!busy()) wipe(); });
  window.addEventListener('pageshow', function (e) { if (e.persisted) wipe(); });
})();
