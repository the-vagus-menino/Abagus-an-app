/* Abagus cover pictures: 45 Gemini-made topics, used one by one, one per encryption. Sends ONLY a topic number. */
(function(){'use strict';
var TOPICS=["Misty mountain sunrise", "Quiet lakeside cabin", "Neon rainy city street", "Desert dunes at dusk", "Northern lights over snow", "Tropical beach lagoon", "Ancient stone library", "Cherry blossom garden", "Floating lantern festival", "Deep ocean coral reef", "Autumn forest path", "Starry night observatory", "Old lighthouse in a storm", "Rice terraces at dawn", "Snowy village rooftops", "Cozy bookshop window", "Hot air balloons at sunrise", "Bamboo forest mist", "Vintage train station", "Waterfall in a jungle", "Lavender fields", "Moonlit castle ruins", "Futuristic harbor skyline", "Glacier ice cave", "Sunflower meadow", "Paper boats on a river", "Mountain monastery clouds", "Fireflies in a meadow", "Canyon river bend", "Candlelit stone corridor", "Spring greenhouse", "Volcanic island coast", "Wooden bridge in fog", "Market street at golden hour", "Space station window view", "Zen rock garden", "Windmill on green hills", "Underwater kelp forest", "City rooftop at twilight", "Alpine meadow flowers", "Aurora over a calm fjord", "Lotus pond morning", "Stone arch by the sea", "Cloud sea above peaks", "Rainy window with city bokeh"],KEY='abagus.coverIdx',TIMEOUT=14000;
function url(){return window.ABAGUS_COVER_URL||'';}
function idx(){try{return (parseInt(localStorage.getItem(KEY),10)||0)%45;}catch(e){return 0;}}
function advance(i){try{localStorage.setItem(KEY,String((i+1)%45));}catch(e){}}
async function next(){
  var i=idx(),topic=TOPICS[i];advance(i);
  var out={topic:topic,n:i+1,bitmap:null};
  if(!url()||!navigator.onLine)return out;
  try{
    var ctl=new AbortController(),t=setTimeout(function(){ctl.abort();},TIMEOUT);
    var r=await fetch(url(),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({topic:i}),signal:ctl.signal});
    clearTimeout(t);if(!r.ok)throw 0;
    var j=await r.json();if(!j.image||!/^image\/(png|jpeg|webp)$/.test(j.mime))throw 0;
    var bin=atob(j.image),u8=new Uint8Array(bin.length);for(var k=0;k<bin.length;k++)u8[k]=bin.charCodeAt(k);
    out.bitmap=await createImageBitmap(new Blob([u8],{type:j.mime}));
  }catch(e){out.bitmap=null;}   /* any failure -> the built-in picture; encryption never waits on Gemini */
  return out;
}
window.AbagusCovers={topics:TOPICS,next:next,index:idx};
})();
